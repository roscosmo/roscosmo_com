"""Shared behavior source lowering, reused by authoring-only project admission.

Property values/overrides remain in the imported-map property system.
"""
from copy import deepcopy
from dataclasses import replace

from .instance_bindings import BehaviorBindings, BehaviorProperty, InstanceAssignment
from .instance_routing import AheadQuery, EventBridge, OutgoingEvent
from .instance_scene import BehaviorSource, compile_instance_scene
from .machine_wire import require
from .world_reference_source import parse_reference


def _record(value, fields):
    require(type(value) is dict and set(value) == set(fields), 'invalid instance source fields')
    return value


def _array(value):
    require(type(value) is list, 'instance source requires a JSON array')
    return value


def _name(value):
    require(type(value) is str and bool(value), 'instance source requires a nonempty identity')
    return value


def _behavior(bundle, scene, source, version=1, *, grid=None):
    _record(source, ('behavior_id', 'properties', 'states', 'machine_logic') +
            (('collision_queries',) if version >= 2 else ()) +
            (('interface',) if version == 3 and 'interface' in source else ()) +
            (('adjacency_queries',) if version == 3 and 'adjacency_queries' in source else ()) +
            (('destinations',) if version == 3 and 'destinations' in source else ()))
    from .behavior_interface_source import lower_behavior as lower_ports
    from .facing_source import lower_behavior as lower_facing
    from .behavior_response import lower_behavior as lower_response
    facings = {p['name'] for p in source['properties'] if p.get('semantic') == 'facing'}
    from .terminal_order import enabled, lower_graph
    programs = None
    if enabled(bundle):
        # Grammar checks retain the complete path; execution uses separate nodes.
        lower_response(source, version, terminal_order=True)
        source = deepcopy(source)
        source, programs = lower_graph(source, source['machine_logic'])

    try:
        source = lower_facing(lower_ports(lower_response(source, version), version), version)
    except (KeyError, TypeError, AttributeError) as exc:
        raise ValueError(f'malformed behavior interface/facing source: {exc}') from exc
    from .behavior_destinations import lower as lower_destinations
    destination_queries, destination_moves = lower_destinations(source, grid, facings)
    properties = []
    for row in _array(source['properties']):
        _record(row, ('name', 'value_type', 'writable') + (('field',) if version >= 2 else ()) +
                (('owner',) if version == 3 else ()))
        properties.append(BehaviorProperty(row['name'], row['value_type'], row['writable'],
                          row.get('field', 'property'), row.get('owner', 'self')))
    queries = []
    for row in _array(source.get('collision_queries', [])):
        _record(row, ('query_id', 'x', 'y', 'cell_width', 'cell_height', 'dx', 'dy', 'include_actors'))
        for key in ('query_id', 'x', 'y'):
            _name(row[key])
        queries.append(tuple(row[k] for k in ('query_id', 'x', 'y', 'cell_width', 'cell_height', 'dx', 'dy', 'include_actors')))
    adjacency_ids = []
    for row in _array(source.get('adjacency_queries', [])):
        _record(row, ('query_id', 'x', 'y', 'target_x', 'target_y', 'cell_width', 'cell_height'))
        for key in ('query_id', 'x', 'y', 'target_x', 'target_y'):
            _name(row[key])
        adjacency_ids.append(row['query_id'])
        queries.append(tuple(row[k] for k in ('query_id', 'x', 'y', 'cell_width', 'cell_height', 'target_x', 'target_y')) + (2,))
    queries.extend(destination_queries)
    declaration = BehaviorBindings(_name(source['behavior_id']), tuple(properties))
    local = deepcopy(scene)
    local.update(states=deepcopy(_array(source['states'])),
                 machine_logic=source['machine_logic'],
                 variables=[], input_actions=[], event_bindings=[], routes=[], event_handlers=[])
    # Behavior-local compilation must not inherit Scene HUD variable references
    # or presentation tracks. Instances own logic, not the enclosing presentation.
    local['objects'] = []
    graph = local['machine_logic']
    require(type(graph) is dict and type(graph.get('routes')) is list, 'behavior graph requires routes')
    require('instance_behaviors' not in graph, 'nested shared behavior definitions are unsupported')
    if graph.get('machines'):
        local['entry_state'] = graph['machines'][0]['entry_state']
    guards, actions, attachments = [], [], {}
    def operand(rows, prefix, name, operation, value):
        # Deduplicate identical declarations without collapsing action executions.
        for identity, prior_name, prior_op, prior_value in rows:
            if (name == prior_name and operation == prior_op and
                    type(value) is type(prior_value) and value == prior_value):
                return identity
        identity = f'{prefix}{len(rows)}'
        rows.append((identity, name, operation, value))
        return identity

    for route in graph['routes']:
        require(type(route) is dict and type(route.get('route_id')) is str,
                'behavior route requires an identity')
        # The graph compiler validates all remaining graph fields/subset rules.
        guard_ids = []
        for row in _array(route.get('guards')):
            is_query = (version >= 2 and row.get('kind') == 'collision.compare' or
                        version == 3 and row.get('kind') == 'adjacency.compare')
            key = 'query_ref' if is_query else 'property_ref'
            _record(row, ('kind', key, 'operator', 'value'))
            require(row['kind'] in ('property.compare', 'collision.compare', 'adjacency.compare') and (not is_query or row['operator'] in ('eq', 'ne')) and type(row['operator']) is str and
                    row['operator'] in ('eq', 'ne', 'lt', 'le', 'gt', 'ge'),
                    'invalid local property guard')
            require(is_query or row['kind'] == 'property.compare', 'unsupported collision source version')
            require(row[key] in ([q[0] for q in queries] if is_query else [p.name for p in properties]),
                    'guard references the wrong local property/query namespace')
            if is_query:
                require((row[key] in adjacency_ids) == (row['kind'] == 'adjacency.compare'),
                        'guard kind does not match query kind')
            identity = operand(guards, 'g', row[key], row['operator'].upper(), row['value'])
            guard_ids.append(identity)
        ordinary, inserts = [], []
        for row in _array(route.get('actions')):
            require(type(row) is dict, 'behavior action must be an object')
            if id(row) in destination_moves:
                identity = operand(actions, 'a', row['property_ref'], 'MOVE', destination_moves[id(row)])
                inserts.append((len(ordinary), identity))
            elif row.get('kind') in ('property.set', 'property.add'):
                _record(row, ('kind', 'property_ref', 'value'))
                identity = operand(actions, 'a', row['property_ref'],
                                   row['kind'].split('.')[1].upper(), row['value'])
                inserts.append((len(ordinary), identity))
            else:
                ordinary.append(row)
        require(route['route_id'] not in attachments, 'duplicate behavior route')
        attachments[route['route_id']] = dict(guards=guard_ids, actions=[inserts])
        route['guards'], route['actions'] = [], ordinary
    local_bundle = replace(bundle, scenes=(local,),
                           project=dict(deepcopy(bundle.project), package_variables=[]))
    return BehaviorSource(local_bundle, scene['scene_id'], declaration,
                          tuple(guards), tuple(actions), attachments, tuple(queries), programs)


def _query(source, version=1):
    interaction = type(source) is dict and 'interaction_targets' in source
    require(not interaction or version == 3, 'interaction targets require source version 3')
    _record(source, ('actor', 'facing', 'facings', 'eligible', 'cell_width', 'cell_height') +
            (('interaction_targets',) if interaction else ()) +
            (('no_target',) if interaction and 'no_target' in source else ()))
    if interaction:
        for row in _array(source['interaction_targets']):
            require(type(row) is dict, 'interaction target must be an object')
            _record(row, ('instance_ref', 'input_event_ref', 'approach_sides') +
                    (('enabled_when',) if 'enabled_when' in row else ()))
            _name(row['instance_ref'])
            _name(row['input_event_ref'])
        if 'no_target' in source:
            _record(source['no_target'], ('machine_ref', 'event_ref'))
            _name(source['no_target']['machine_ref'])
            _name(source['no_target']['event_ref'])
    actor, actor_type = parse_reference(source['actor'])
    facing, facing_type = parse_reference(source['facing'])
    require(actor_type == facing_type == 'int32', 'query coordinates and facing must be int32')
    facings = _record(source['facings'], ('left', 'right', 'up', 'down'))
    vectors = (('left', -1, 0), ('right', 1, 0), ('up', 0, -1), ('down', 0, 1))
    return AheadQuery(actor, facing, tuple((facings[n], x, y) for n, x, y in vectors),
                      tuple(_name(n) for n in _array(source['eligible'])),
                      source['cell_width'], source['cell_height'],
                      source.get('interaction_targets'), source.get('no_target'))


def compile_instance_source(bundle, scene_id, world, attachments, source, *,
                            queue_capacity, initial_event_capacity=1, flow_attachments=None,
                            authoring_scene_exits=False, _execution_scopes=False):
    """Compile a complete private source record without modifying inputs.

    Capacity belongs to the runtime caller, not an editable content promise.
    Writers are stable existing Scene-role IDs, not numeric slots or additional
    machine allocations. Local properties bind to each assigned entity by name.
    """
    _record(source, ('version', 'behaviors', 'instances', 'bridges') +
            (('outgoing',) if type(source) is dict and source.get('version') == 3 and 'outgoing' in source else ()))
    require(type(source['version']) is int and source['version'] in (1, 2, 3),
            'unsupported private instance source version')
    scene = next((s for s in bundle.scenes if s['scene_id'] == scene_id), None)
    require(scene is not None and 'machine_logic' in scene, 'instance source requires a machine Scene')
    from .tilemap_wire import HEADER
    grid = HEADER.unpack_from(world.map.data)[5:7]
    behaviors = [_behavior(bundle, scene, row, source['version'], grid=grid) for row in _array(source['behaviors'])]
    assignments = []
    for row in _array(source['instances']):
        _record(row, ('instance_id', 'behavior_ref', 'entity', 'writer_ref') +
                (('target',) if source['version'] == 3 else ()))
        entity, kind = parse_reference(row['entity'])
        require(kind == 'int32' and entity.field == 'entity_x', 'instance entity requires an X reference')
        writer = _name(row['writer_ref'])
        require(writer in world.machine_sources, 'unknown instance writer_ref')
        target = None
        if row.get('target') is not None:
            target, target_kind = parse_reference(row['target'])
            require(target_kind == 'int32' and target.field == 'entity_x',
                    'Target requires an integer entity X reference')
        assignments.append(InstanceAssignment(_name(row['instance_id']), _name(row['behavior_ref']),
                                              entity, world.machine_sources.index(writer), target))
    bridges = []
    for row in _array(source['bridges']):
        require(type(row) is dict, 'bridge must be an object')
        query = 'query' in row
        _record(row, ('machine_ref', 'event_ref', 'target_event_ref', 'query' if query else 'instance_ref'))
        bridges.append(EventBridge(_name(row['machine_ref']), _name(row['event_ref']),
            _name(row['target_event_ref']), query=_query(row['query'], source['version']) if query else None,
            instance=None if query else _name(row['instance_ref'])))
    outgoing = []
    for row in _array(source.get('outgoing', [])):
        _record(row, ('instance_ref', 'event_ref', 'machine_ref', 'target_event_ref'))
        outgoing.append(OutgoingEvent(*(_name(row[k]) for k in
            ('instance_ref', 'event_ref', 'machine_ref', 'target_event_ref'))))
    from .behavior_interface_source import validate_bindings
    from .facing_source import validate_instances
    validate_bindings(source)
    validate_instances(world, source)
    return compile_instance_scene(bundle, scene_id, world, attachments, behaviors, assignments,
        flow_attachments=flow_attachments, bridges=bridges, queue_capacity=queue_capacity,
        initial_event_capacity=initial_event_capacity, authoring_scene_exits=authoring_scene_exits,
        outgoing=outgoing, _execution_scopes=_execution_scopes)
