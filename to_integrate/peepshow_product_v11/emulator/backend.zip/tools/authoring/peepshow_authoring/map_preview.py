"""Public map source adapter for the existing atomic machine preview engine.

This is host execution, not an egg encoder or device resource admission. Complete
world/instance templates accompany every projected Scene; no gameplay is erased
to make an ordinary visual draft pass validation.
"""
from dataclasses import dataclass, replace
from copy import deepcopy
from .map_colour import effective as effective_base_colour

from .preview import PreviewError, DISPLAY_WIDTH, DISPLAY_HEIGHT, DISPLAY_STRIDE


@dataclass(frozen=True)
class SpatialMap:
    width: int
    height: int
    cell_width: int
    cell_height: int
    collision: tuple
    layers: tuple
    tiles: tuple
    actors: tuple
    layer_ids: tuple = ()
    layer_visible: tuple = ()
    base_colour: str = 'white'

    def __deepcopy__(self, memo):
        # All members are immutable; event candidates only copy mutable world data.
        return self

    def blocked(self, context, query, include_actors, evidence=None):
        xs, ys, width, height, dx, dy = query
        if evidence is not None:
            evidence.update(kind='adjacency' if include_actors == 2 else 'collision',
                            grid=dict(width=width, height=height))
        if (width, height) != (self.cell_width, self.cell_height):
            raise PreviewError('collision query grid differs from map')
        if include_actors == 2:
            pairs = [(context.bindings[a][:2], context.bindings[b][:2])
                     for a,b in ((xs,ys),(dx,dy))]
            if pairs[0] == pairs[1] or any(
                    sum((a,b) == pair for a,b,_ in self.actors) != 1 for pair in pairs):
                raise PreviewError('adjacency requires two distinct admitted actors')
            x, y, tx, ty = (context.read(i) for i in (xs,ys,dx,dy))
            if any(not -2**31 <= value < 2**31 for value in (x,y,tx,ty)) or any(
                    a % width or b % height or not 0 <= a // width < self.width or
                    not 0 <= b // height < self.height for a,b in ((x,y),(tx,ty))):
                raise PreviewError('adjacency actor is outside or off grid')
            adjacent = (abs(tx-x) == width and ty == y) or (abs(ty-y) == height and tx == x)
            if evidence is not None:
                evidence.update(actor=dict(x=x,y=y), target=dict(x=tx,y=ty), adjacent=adjacent)
            return adjacent
        x, y = context.read(xs), context.read(ys)
        if evidence is not None:evidence["actor"]=dict(x=x,y=y)
        if x % width or y % height:
            raise PreviewError('collision query actor is not grid aligned')
        if include_actors in (5, 6):
            x, y = dx * width, dy * height
            include_actors -= 5
        else:
            x, y = x + dx * width, y + dy * height
        if not -2**31 <= x < 2**31 or not -2**31 <= y < 2**31:
            raise PreviewError('collision query coordinate overflow')
        cx, cy = x // width, y // height
        if evidence is not None:
            evidence.update(destination=dict(x=x,y=y,cell_x=cx,cell_y=cy), include_actors=bool(include_actors))
        if not (0 <= cx < self.width and 0 <= cy < self.height):
            if evidence is not None:evidence.update(blocked=True, reason="bounds")
            return True
        if self.collision[cy * self.width + cx]:
            if evidence is not None:evidence.update(blocked=True, reason="terrain")
            return True
        if include_actors:
            own_x, own_y = context.bindings[xs][:2], context.bindings[ys][:2]
            for ax, ay, condition in self.actors:
                if (ax, ay) == (own_x, own_y):
                    continue
                if condition is not None and context.values[condition[0]] != condition[1]:
                    continue
                if context.values[ax] == x and context.values[ay] == y:
                    if evidence is not None:
                        from dataclasses import asdict
                        evidence.update(blocked=True, reason='actor', blocker_slots=[list(ax),list(ay)],
                            blocker_references=[asdict(context.sources[i]) for i,b in enumerate(context.bindings)
                                                if b[:2] in (ax,ay)])
                    return True
        if evidence is not None:evidence.update(blocked=False, reason='clear')
        return False

    def render(self, context):
        frame = bytearray(DISPLAY_STRIDE * DISPLAY_HEIGHT)
        visibility = getattr(context, 'visibility', None)
        if visibility is not None and not visibility['world']:
            return frame
        if self.base_colour == 'black':
            frame[:] = b'\xff' * len(frame)
        camera_x, camera_y = context.values[1, 0], context.values[2, 0]
        stride = (self.cell_width + 7) // 8
        for index, cells in enumerate(self.layers):
            visible = self.layer_visible[index] if self.layer_visible else True
            if visibility is not None:
                visible = visibility['layers'][self.layer_ids[index]]
            if not visible:
                continue
            for sy in range(DISPLAY_HEIGHT):
                wy = sy + camera_y
                if not 0 <= wy < self.height * self.cell_height:
                    continue
                cy, py = divmod(wy, self.cell_height)
                for sx in range(DISPLAY_WIDTH):
                    wx = sx + camera_x
                    if not 0 <= wx < self.width * self.cell_width:
                        continue
                    cx, px = divmod(wx, self.cell_width)
                    tile = cells[cy * self.width + cx]
                    if not tile:
                        continue
                    pixels, mask = self.tiles[tile - 1]
                    offset, bit = py * stride + px // 8, 128 >> (px % 8)
                    if mask and not mask[offset] & bit:
                        continue
                    dest, dest_bit = sy * DISPLAY_STRIDE + sx // 8, 128 >> (sx % 8)
                    if pixels[offset] & bit:
                        frame[dest] |= dest_bit
                    else:
                        frame[dest] &= 255 ^ dest_bit
        return frame


def _spatial(bundle, scene, world):
    from .layered_map import compile_layered_map
    from .tileset_wire import HEADER, RECORD
    from .world_operands_wire import decode_typed_operands as decode_operands
    from .world_references import WorldReference
    source = scene['machine_logic']['map_scene']
    record = next(r for c in bundle.asset_catalogs for r in c.get('map_assets', [])
                  if r['asset_id'] == source['asset_ref'])
    from .scene_map_entities import materialize
    record = materialize(record, source)
    compiled = compile_layered_map(record, bundle.root,
        background_layers=source['background_layers'], object_layer=source['object_layer'],
        collision_layer=source['collision_layer'])
    snapshot = record['snapshot']
    layers = {r['id']: r for r in snapshot['layers']}
    tile_ids = {gid: i + 1 for i, gid in enumerate(compiled.source_gids)}
    tiles = []
    data = compiled.tiles.data
    for i in range(compiled.tiles.tile_count):
        pixels, mask, size, opaque = RECORD.unpack_from(data, HEADER.size + i * RECORD.size)
        tiles.append((data[pixels:pixels + size], b'' if opaque else data[mask:mask + size]))
    bindings, _, _ = decode_operands(world.operands, len(world.machine_sources), len(world.flow_sources))
    refs = {r['reference_id']: WorldReference(**{k: v for k, v in r['target'].items()
                                               if k in ('asset_id', 'field', 'owner_id', 'property_id')})
            for r in scene['machine_logic']['world_references']}
    def key(ref):
        return bindings[world.binding_sources.index(refs[ref])][:2]
    actors = []
    for row in source['occupancy']:
        condition = row.get('solid_when')
        actors.append((key(row['x_ref']), key(row['y_ref']), None if condition is None else
                       (key(condition['reference_ref']), int(condition['equals']))))
    return SpatialMap(snapshot['width'], snapshot['height'], source['cell_width'], source['cell_height'],
        tuple(bool(v) for v in layers[source['collision_layer']]['data']),
        tuple(tuple(tile_ids[v] if v else 0 for v in layers[lid]['data'])
              for lid in source['background_layers']),
        tuple(tiles), tuple(actors), tuple(source['background_layers']),
        tuple(layers[lid].get('visible', True) for lid in source['background_layers']),
        effective_base_colour(record, source))


def build_map_preview_package(bundle, *, scope_host=False):
    from .execution_scope_source import require_execution_ready
    require_execution_ready(bundle, preview=True, scope_host=scope_host)
    authored_bundle = bundle
    from .compiler import build_preview_package, EggCompileError
    from .world_logic_source import prepare, selector_data
    from .instance_preview import create_instance_context
    from .world_preview import create_world_context
    from .map_scene_source import validate_scene
    if not bundle.valid:
        raise EggCompileError('project must validate before map preview')
    # Explicit profile: every map-dependent Scene needs its own role binding.
    # Unbound maps/shared instances cannot silently become ordinary Scene previews.
    if any('map_scene' not in s.get('machine_logic', {}) for s in bundle.scenes):
        raise EggCompileError('MAP_PREVIEW_PROFILE: all Scenes require explicit map_scene bindings')
    # Lifecycle requests are host transaction-boundary operations, not native
    # world actions. Validate the complete authored graph, then project only
    # those requests to inert proof slots and restore them in the host graph.
    # The public scoped-readiness guard above remains authoritative.
    from .execution_scope_source import lifecycle_proof_scene
    menu_actions, proof_scenes = {}, []
    for scene in bundle.scenes:
        proof, actions = lifecycle_proof_scene(bundle.project, scene)
        from .inventory_conditions import proof_scene
        proof = proof_scene(proof)
        # The admitted Scene owns the component. Private shared-behavior
        # evaluators must not inherit it and attempt to own another menu.
        proof = deepcopy(proof)
        proof.pop('menu_component', None)
        proof.pop('pickups', None)
        menu_actions.update({(scene['scene_id'], ref): value for ref, value in actions.items()})
        proof_scenes.append(proof)
    bundle = replace(bundle, scenes=tuple(proof_scenes),
                     project={k:v for k,v in bundle.project.items() if k != 'inventory'})
    contexts, projected_scenes = {}, []
    try:
        for scene in bundle.scenes:
            validate_scene(bundle, scene)
            scene_id = scene['scene_id']
            projected, world, source = prepare(bundle, scene_id)
            catalogs = tuple({k: v for k, v in c.items() if k != 'map_assets'} for c in projected.asset_catalogs)
            projected = replace(projected, asset_catalogs=catalogs)
            spatial = _spatial(bundle, scene, world)
            camera = scene['machine_logic']['map_scene'].get('initial_camera', dict(x=0,y=0))
            options = dict(write_capacity=len(world.binding_sources), camera=(camera['x'], camera['y']),
                flow_attachments=source.flows, selector_data=selector_data(source, world),
                position_source=source.positions)
            instances = source.instance_source
            if instances is not None:
                context = create_instance_context(projected, scene_id, world, source.routes, instances,
                    queue_capacity=64, spatial=spatial, authoring_scene_exits=True, **options)
            else:
                context = create_world_context(projected, scene_id, world, source.routes, **options)
                context.spatial = spatial
            from .camera_source import attach as attach_camera
            attach_camera(context, source, scene['machine_logic'])
            from .visibility_source import attach as attach_visibility
            attach_visibility(context, source)
            contexts[scene_id] = context
            preview_scene = deepcopy(source.scene)
            preview_scene.pop('menu_component', None)
            projected_scenes.append(preview_scene)
        # World/instance contexts already share the outer build's asset indexes.
        package = build_preview_package(replace(projected, scenes=tuple(projected_scenes)), _assets_selected=True)
    except (ValueError, KeyError, TypeError, IndexError) as exc:
        raise EggCompileError('MAP_PREVIEW_UNSUPPORTED: ' + str(exc)) from exc
    for scene in package.scenes:
        scene['_world_template'] = contexts[scene['scene_id']]
        for route in scene['machine_logic']['routes']:
            actions = menu_actions.get((scene['scene_id'], route['route_id']))
            if actions is not None:
                route['actions'] = actions
    if scope_host:
        from .execution_scope_source import attach_preview_sources
        attach_preview_sources(package, authored_bundle)
    return package
