"""Bounded SMG1/MPR1 reader matching the native machine/ownership contract."""
import struct
from .egg_format import _require
from .object_egg import _stable_id
from .machine_limits import MACHINES, STATES, ROUTES, EVENTS, INPUTS, FLOWCHARTS, TIMERS
from .event_graph import find_cycle

NONE, NAMED = 255, 254


class Reader:
    def __init__(self, data):
        self.data, self.offset = data, 0

    def take(self, fmt):
        record = struct.Struct('<' + fmt)
        _require(self.offset + record.size <= len(self.data), 'machine record truncated')
        values = record.unpack_from(self.data, self.offset)
        self.offset += record.size
        return values

    def end(self):
        _require(self.offset == len(self.data), 'machine trailing bytes')


def logic(data):
    r = Reader(data)
    magic, version, header, size, seed, nm, ns, nv, ne, nt, nr, nf, zero = r.take('4sHHII8B')
    flow_count = zero
    _require(magic == b'SMG1' and version in (1, 2, 3, 4, 5) and header == 24 and size == len(data) and seed and
             (flow_count == 0 if version == 1 else (1 <= flow_count <= FLOWCHARTS if version == 2 else flow_count <= FLOWCHARTS)),
             'machine logic header invalid')
    _require(version != 5 or flow_count > 0, 'time predicates require flowcharts')
    _require(1 <= nm <= MACHINES and 1 <= ns <= STATES and nv <= 32 and ne <= EVENTS and nt <= TIMERS and nr <= ROUTES and nf <= 32,
             'machine table capacity invalid')
    entry, owners, recipients, effects = (r.take(f'{n}B') for n in (nm, ns, ne, nf))
    _require(all(m < nm for m in owners) and all(s < ns and owners[s] == m for m, s in enumerate(entry)), 'machine entry/owner invalid')
    def writer(m):
        return m < nm or 128 <= m < 128 + flow_count
    _require(all(m < nm or m in (NONE, NAMED) for m in recipients) and all(writer(m) for m in effects), 'machine recipient/effect owner invalid')
    variables = [r.take('iiiBB') for _ in range(nv)]
    for initial, low, high, owner, boolean in variables:
        _require(low <= initial <= high and (writer(owner) or owner == NONE) and boolean <= 1 and
                 (not boolean or (low, high) == (0, 1)), 'machine variable invalid')

    def recipient(m, e):
        return e < ne and (m < nm if recipients[e] == NAMED else recipients[e] == m)

    def sources(mask, m):
        return mask < (1 << ns) and all(owners[s] == m for s in range(ns) if mask & (1 << s))

    timers, random_delay_max_ms = [], []
    for _ in range(nt):
        timers.append(r.take('IQ4B'))
        random_delay_max_ms.append(r.take('I')[0] if version >= 4 else 0)
    periodic_timers = sum(1 << i for i, t in enumerate(timers) if version >= 3 and t[5] & 2)
    if version >= 3:
        _require((version != 3 or periodic_timers) and all(t[5] <= 3 for t in timers), 'machine periodic flags invalid')
        timers = [(*t[:5], t[5] & 1) for t in timers]
    _require(version != 4 or any(random_delay_max_ms), 'random timer revision needs a range')
    for i, maximum in enumerate(random_delay_max_ms):
        _require(not maximum or timers[i][0] <= maximum <= 86400000 and not periodic_timers & (1 << i),
                 'random timer bounds invalid')
    for delay, mask, m, e, scoped, start in timers:
        _require(10 <= delay <= 86400000 and scoped <= 1 and start <= 1 and recipient(m, e) and recipients[e] != NAMED,
                 'machine timer invalid')
        _require((m < nm and mask and start and sources(mask, m)) if scoped else mask == 0, 'machine timer scope invalid')
    _require(len({t[3] for t in timers}) == nt, 'duplicate timer event')
    routes, edges = [], {}
    calls = []

    def action(record, owner, sends, allow_call):
        op, ref, event, unused, value = record
        _require(not unused and (op == 4 or event == 0) and (op < 3 or value == 0), 'machine action unused fields invalid')
        valid = False
        if op in (1, 2, 3):
            valid = writer(owner) and ref < nv and variables[ref][3] == owner
            if valid:
                valid = (op != 2 or not variables[ref][4]) and (op != 1 or variables[ref][1] <= value <= variables[ref][2])
        elif op == 4:
            valid = ref < nm and event < ne and recipients[event] == NAMED
            if valid:
                sends.add((ref, event))
        elif op in (5, 6, 7):
            valid = ref < nt and not timers[ref][4]
        elif op == 8:
            valid = writer(owner) and ref < nf and effects[ref] == owner
        elif op == 9:
            valid = allow_call and ref < flow_count
            if valid:
                calls.append((sends, ref))
        _require(valid, 'machine action reference/ownership invalid')

    for _ in range(nr):
        m, e, ng, no, weighted, a, b, c, mask = r.take('8BQ')
        _require(not (a or b or c) and recipient(m, e) and ng <= 8 and 1 <= no <= 8 and weighted <= 1 and
                 (weighted or no == 1) and ((m == NONE) == (mask == 0)) and sources(mask, m), 'machine route invalid')
        guards = [r.take('BBi') for _ in range(ng)]
        for v, compare, value in guards:
            _require(v < nv and 1 <= compare <= 6 and (not variables[v][4] or compare <= 2 and value in (0, 1)), 'machine guard invalid')
        outcomes, total = [], 0
        for _ in range(no):
            weight, target, na, zero = r.take('4B')
            total += weight
            _require(not zero and 1 <= weight <= 100 and total <= 100 and na <= 8 and (weighted or weight == 100) and
                     (target == NONE or m < nm and target < ns and owners[target] == m), 'machine outcome invalid')
            actions = [r.take('4Bi') for _ in range(na)]
            for record in actions:
                action(record, m, edges.setdefault((m, e), set()), True)
            outcomes.append((weight, target, actions))
        routes.append({'machine': m, 'event': e, 'sources': mask, 'guards': guards, 'outcomes': outcomes})
    charts = []
    if flow_count:
        f = Reader(data[r.offset:])
        offsets = f.take(f'{flow_count + 1}I')
        _require(offsets[0] == 4 * (flow_count + 1) and offsets[-1] == len(f.data) and
                 all(a < b for a, b in zip(offsets, offsets[1:])), 'flowchart offsets invalid')
        total_nodes = 0
        for index in range(flow_count):
            end, nodes, sends, decoded = offsets[index + 1], {}, set(), {}
            _require(f.offset == offsets[index], 'flowchart start invalid')
            while f.offset < end:
                start = f.offset
                kind, count, length, target = f.take('BBHI')
                _require(kind <= 2 and count <= 8 and length >= 8 and start + length <= end,
                         'flowchart node bounds invalid')
                targets = []
                records, branches = [], []
                if kind == 0:
                    _require(count == 0 and target == 0 and length == 8, 'flowchart return invalid')
                else:
                    targets.append(target)
                if kind == 1:
                    for _ in range(count):
                        record = f.take('4Bi')
                        action(record, 128 + index, sends, False)
                        records.append(record)
                elif kind == 2:
                    _require(count > 0, 'flowchart decision empty')
                    for _ in range(count):
                        branch, tokens, a, b, c = f.take('IBBBB')
                        _require(1 <= tokens <= 16 and not (a or b or c), 'flowchart predicate header invalid')
                        targets.append(branch)
                        depth = 0
                        predicate = []
                        for _ in range(tokens):
                            op, x, y, unused, value = f.take('4Bi')
                            predicate.append((op, x, y, unused, value))
                            _require(not unused or op == 7 and version == 5, 'flowchart predicate reserved field')
                            if op == 1:
                                _require(x < nm and y < ns and owners[y] == x and not value, 'flowchart state invalid')
                                depth += 1
                            elif op == 2:
                                _require(x < nv and 1 <= y <= 6 and
                                         (not variables[x][4] or y <= 2 and value in (0, 1)), 'flowchart variable invalid')
                                depth += 1
                            elif op == 6:
                                _require(version == 5 and not (x or y or value), 'time availability token invalid')
                                depth += 1
                            elif op == 7:
                                range_start = x | y << 8 | unused << 16
                                _require(version == 5 and 0 <= range_start < 86400 and 0 <= value < 86400 and range_start != value,
                                         'time range token invalid')
                                depth += 1
                            else:
                                _require(not (x or y or value) and
                                         (op == 3 and depth >= 1 or op in (4, 5) and depth >= 2), 'flowchart predicate invalid')
                                depth -= int(op in (4, 5))
                        _require(depth == 1, 'flowchart predicate stack invalid')
                        branches.append((branch, predicate))
                _require(f.offset == start + length, 'flowchart node length invalid')
                nodes[start] = targets
                decoded[start] = dict(kind=kind, next=target, actions=records, branches=branches)
                total_nodes += 1
                _require(total_nodes <= 128, 'flowchart node capacity exceeded')
            reached = {offsets[index]}
            for start, targets in nodes.items():
                _require(start in reached and all(start < t < end and t in nodes for t in targets),
                         'flowchart edge or reachability invalid')
                reached.update(targets)
            charts.append({'node_count': len(nodes), 'sends': sorted(sends),
                           'root': offsets[index], 'nodes': decoded})
        f.end()
        r.offset = len(data)
    r.end()
    for sends, chart in calls:
        sends.update(charts[chart]['sends'])
    _require(not find_cycle(edges), 'machine addressed event cycle')
    for timer in timers:
        _require(timer[2] != NONE or sum(route['event'] == timer[3] for route in routes) == 1, 'scene timer needs one handler')
    return dict(seed=seed, machine_count=nm, state_count=ns, variable_count=nv,
                event_count=ne, effect_count=nf, route_count=nr, entry=entry, owners=owners,
                recipients=recipients, effect_owners=effects, variables=variables, timers=timers, routes=routes,
                flowcharts=charts, flow_count=flow_count, periodic_timers=periodic_timers,
                random_delay_max_ms=random_delay_max_ms, local_time_predicates=version == 5)


def parse_machine_graph(payload, strings, objects, overrides, operations, assets, animations, cues):
    r = Reader(payload)
    magic, version, header, size, nl, np, nslots, zero = r.take('4sHHIIIHH')
    _require((magic, version, header, size) == (b'MGS1', 1, 24, len(payload)) and not zero and nslots <= 32 and
             size == 24 + 2 * nslots + nl + np, 'machine scene envelope invalid')
    slots = [_stable_id(strings, i, 'package variable') for i in r.take(f'{nslots}H')]
    _require(len(set(slots)) == len(slots), 'duplicate package variable identity')
    g = logic(payload[r.offset:r.offset + nl])
    r = Reader(payload[r.offset + nl:])
    magic, version, header, size, primary, no, nf, ni, nv, ns, sel_lo, sel_hi, nc, zero = r.take('4sHHI8BHH')
    visual_count = zero
    text_size = r.take('I')[0] if version == 13 else 0
    _require(version != 13 or 0 < text_size <= 64 * 332 and text_size <= len(r.data) - 28,
             'invalid text binding section size')
    text_bindings = []
    if version == 13:
        from .presentation_text_wire import decode_tokens, analyze_tokens
        text_end = r.offset + text_size
        previous = -1
        while r.offset < text_end:
            _require(text_end - r.offset >= 4, 'truncated text binding')
            index, length = r.take('HH')
            _require(previous < index < len(objects) and objects[index]['kind'] == 9 and
                     length <= text_end - r.offset, 'invalid text binding target or length')
            obj = objects[index]
            try:
                tokens = decode_tokens(r.data[r.offset:r.offset + length])
                analysis = analyze_tokens(tokens, g['variables'], style=obj['flags'] >> 3,
                                          width=obj['width'], height=obj['height'])
            except ValueError as error:
                _require(False, str(error))
            text_bindings.append(dict(object_index=index, tokens=tokens, **analysis))
            previous = index
            r.offset += length
    selectors_size = sel_lo + 256 * sel_hi
    transient_count = r.data[-4] if version >= 6 and len(r.data) >= 28 else 0
    calendar_count = r.data[-8] if version >= 7 and len(r.data) >= 32 else 0
    clip_count = r.data[-12] if version >= 10 and len(r.data) >= 36 else 0
    local_time = r.data[-11] if version >= 10 and len(r.data) >= 36 else int(version == 9)
    retain_high = r.data[-10] if version >= 11 and len(r.data) >= 36 else 0
    writer_count = 5 if version >= 12 else 4
    _require(magic == b'MPR1' and version in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13) and header == (28 if version == 13 else 24) and size == len(r.data) and
             local_time == g['local_time_predicates'] and clip_count <= 32 and
             (version < 10 or size >= 36 and local_time <= 1 and not r.data[-9] and
              (version >= 12 or (bool(retain_high) if version == 11 else not r.data[-10]))) and
             (version != 6 or 1 <= transient_count <= 32) and
             transient_count <= 32 and
             (version != 7 or 1 <= calendar_count <= TIMERS - len(g['timers'])) and
             calendar_count <= TIMERS - len(g['timers']) and
             visual_count <= 32 and (version >= 3 or not visual_count) and
             (version >= 4 or ((version == 3) == bool(g['flow_count']))) and
             no == len(objects) and nf == g['effect_count'] and ni <= INPUTS and nv == g['variable_count'] and
             ns == nslots and nc == len(cues) and primary < g['machine_count'] and
             (version >= 3 or ((version == 1) == (selectors_size == 0))) and
             size == header + text_size + writer_count * no + 4 * (nf + ni + nv) + selectors_size + 6 * visual_count +
             (4 + 12 * clip_count if version >= 10 else 0) +
             (8 + 20 * transient_count + 16 * calendar_count if version >= 7 else
              4 + 20 * transient_count if version == 6 else 3 if version == 5 else 2 if version == 4 else 0),
             'machine presentation header invalid')
    _require(len(overrides) == g['state_count'], 'machine state override count invalid')
    writers = [r.take(f'{writer_count}B') for _ in range(no)]
    _require(all(w < g['machine_count'] or w == NONE or 128 <= w < 128 + g['flow_count']
                 for row in writers for w in row), 'object writer invalid')

    def owns(obj, mask, machine):
        return mask < (1 << writer_count) and all(writers[obj][bit] == machine for bit in range(writer_count) if mask & (1 << bit))

    for state, records in enumerate(overrides):
        for override in records:
            _require(owns(override['object_index'], override['mask'], g['owners'][state]), 'state override ownership invalid')
    effects = [r.take('HH') for _ in range(nf)]
    polarity_owner = None
    for i, (kind, ref) in enumerate(effects):
        if kind == 7:
            owner = g['effect_owners'][i]
            _require(owner < g['machine_count'] and polarity_owner in (None, owner), 'scene inversion writer conflict')
            polarity_owner = owner
        if kind == 1:
            _require(ref < len(operations), 'object effect reference invalid')
            op = operations[ref]
            mask = op['axis_mask'] if op['opcode'] <= 2 else 8 if op['opcode'] == 3 else 16 if op['opcode'] == 6 else 4
            _require(owns(op['object_index'], mask, g['effect_owners'][i]), 'object effect writer invalid')
        else:
            _require(kind == 2 and ref < nc or kind == 3 and ref == 0 or
                     kind == 4 and ref < visual_count and g['effect_owners'][i] >= 128 or
                     kind == 5 and version >= 5 and 1 <= ref <= 8 or
                     kind == 6 and version >= 6 and ref < transient_count or
                     kind == 7 and version >= 8 and ref <= 2 or
                     kind == 8 and version >= 10 and ref < clip_count or
                     kind == 9 and version >= 10 and ref < no, 'presentation effect invalid')
            if kind == 9:
                _require(objects[ref]['kind'] == 1 and owns(ref, 4, g['effect_owners'][i]) and
                         not any(o['object_index'] == ref and o['mask'] & 4 for records in overrides for o in records),
                         'clip cancel ownership invalid')
    inputs = [r.take('4B') for _ in range(ni)]
    assigned, input_keys = {t[3] for t in g['timers']}, set()
    for source, kind, machine, event in inputs:
        _require(1 <= source <= 13 and 1 <= kind <= 4 and machine < g['machine_count'] and event < g['event_count'] and
                 g['recipients'][event] == machine and event not in assigned and (source, kind) not in input_keys, 'machine input invalid')
        assigned.add(event)
        input_keys.add((source, kind))
    variable_slots, used = [], set()
    for _ in range(nv):
        scope, zero, slot = r.take('BBH')
        _require(scope <= 1 and not zero and (slot < ns and slot not in used if scope else slot == 65535), 'machine variable scope invalid')
        if scope:
            used.add(slot)
        variable_slots.append(slot)
    _require(len(used) == ns, 'package slots incomplete')
    from .object_egg import _frame
    visuals = []
    for _ in range(visual_count):
        obj, frame, clip = r.take('HHH')
        _require(obj < no and objects[obj]['kind'] == 1, 'flowchart visual target invalid')
        _frame(frame, objects[obj], assets)
        if clip != 65535:
            _require(clip < len(animations), 'flowchart clip invalid')
            anim = animations[clip]
            _require(anim['loop_policy'] == 1 and len(anim['frame_indexes']) <= 12 and
                     len(set(anim['frame_indexes'])) <= 4 and anim['frame_indexes'][0] == frame,
                     'flowchart clip bounds invalid')
            for f in anim['frame_indexes']:
                _frame(f, objects[obj], assets)
        visuals.append({'object_index': obj, 'frame_index': frame, 'clip_index': clip})
    for i, (kind, ref) in enumerate(effects):
        if kind == 4:
            _require(owns(visuals[ref]['object_index'], 4, g['effect_owners'][i]), 'flowchart visual ownership invalid')
    selectors, seen = [], set()
    if selectors_size:
        from .object_egg import _frame
        count, = r.take('B')
        extended = bool(count & 0x80)
        count &= 0x7f
        _require(1 <= count <= 8, 'selector count invalid')
        for _ in range(count):
            obj, nr, zero = r.take('HBB')
            _require(obj < no and obj not in seen and objects[obj]['kind'] == 1 and writers[obj][2] == NONE and
                     1 <= nr <= 8 and not zero, 'selector target invalid')
            seen.add(obj)
            rules = []
            for i in range(nr):
                nt, zero, frame, clip = r.take('BBHH')
                _require(nt <= 16 and not zero and ((nt == 0) == (i == nr - 1)), 'selector fallback invalid')
                _frame(frame, objects[obj], assets)
                if clip != 65535:
                    _require(clip < len(animations), 'selector clip invalid')
                    anim = animations[clip]
                    _require(anim['loop_policy'] == 1 and len(anim['frame_indexes']) <= 12 and
                             len(set(anim['frame_indexes'])) <= 4 and anim['frame_indexes'][0] == frame, 'selector clip bounds invalid')
                    for f in anim['frame_indexes']:
                        _frame(f, objects[obj], assets)
                tokens, depth = [], 0
                for _ in range(nt):
                    if extended:
                        op, m, s, reserved, value = r.take('4Bi')
                        _require(not reserved and (op == 5 or not value), 'selector token reserved fields invalid')
                    else:
                        op, m, s = r.take('3B')
                    if op == 1:
                        _require(m < g['machine_count'] and s < g['state_count'] and g['owners'][s] == m, 'selector state reference invalid')
                        depth += 1
                    elif op == 5 and extended:
                        _require(m < g['variable_count'] and 1 <= s <= 6 and
                                 (not g['variables'][m][4] or s <= 2 and value in (0, 1)),
                                 'selector variable comparison invalid')
                        depth += 1
                    else:
                        _require(not m and not s and (op == 2 and depth >= 1 or op in (3, 4) and depth >= 2), 'selector predicate invalid')
                        depth -= int(op in (3, 4))
                    tokens.append((op, m, s, value) if extended else (op, m, s))
                _require(not nt or depth == 1, 'selector predicate stack invalid')
                rules.append({'frame_index': frame, 'clip_index': clip, 'tokens': tokens})
            selectors.append({'object_index': obj, 'rules': rules})
    transients, effect_writers = [], {}
    for _ in range(transient_count):
        obj, owner, kind, duration, step, amplitude, completion, machine, event, a, b, c = r.take('HBBIIH6B')
        _require(obj < no and objects[obj]['kind'] == 1 and owner < g['machine_count'] and
                 duration > 0 and step > 0 and completion <= 1 and not (a or b or c) and
                 (kind == 1 and amplitude == 0 or kind == 2 and 1 <= amplitude <= 32767),
                 'transient effect definition invalid')
        _require((machine < g['machine_count'] and event < g['event_count'] and g['recipients'][event] == NAMED)
                 if completion else machine == 0 and event == 0, 'transient completion invalid')
        _require(effect_writers.get(obj, owner) == owner, 'transient object writer conflict')
        effect_writers[obj] = owner
        transients.append(dict(object_index=obj, owner=owner, kind=kind, duration_ms=duration,
                               step_ms=step, amplitude=amplitude, completion=completion, machine=machine, event=event))
    for i, (kind, ref) in enumerate(effects):
        if kind == 6:
            _require(transients[ref]['owner'] == g['effect_owners'][i], 'transient action owner invalid')
    calendars = []
    for _ in range(calendar_count):
        mode, time_of_day, argument, machine, event, a, b = r.take('III4B')
        _require(1 <= mode <= 5 and time_of_day < 86400 and not (a or b) and
                 machine < g['machine_count'] and event < g['event_count'] and
                 g['recipients'][event] == machine and event not in assigned and
                 (argument == 0 if mode in (1, 3) else argument <= 32767 if mode == 2 else
                  1 <= argument <= 7 if mode == 4 else 1 <= argument <= 127), 'calendar definition invalid')
        assigned.add(event)
        calendars.append(dict(mode=mode, time_of_day=time_of_day, argument=argument, machine=machine, event=event))
    _require(all(i in assigned or m == NAMED for i, m in enumerate(g['recipients'])), 'unbound external machine event')
    clips = []
    for _ in range(clip_count):
        obj, owner, end, animation, completion, machine, event, a, b, c = r.take('HBBH6B')
        _require(obj < no and objects[obj]['kind'] == 1 and owns(obj, 4, owner) and
                 owner != NONE and animation < len(animations) and end <= 1 and completion <= 1 and not (a or b or c),
                 'one-shot definition invalid')
        anim = animations[animation]
        _require(1 <= len(anim['frame_indexes']) <= 12 and
                 0 < sum(anim['frame_duration_ms']) <= 0xffffffff and all(d > 0 for d in anim['frame_duration_ms']),
                 'one-shot duration invalid')
        for frame in anim['frame_indexes']:
            _frame(frame, objects[obj], assets)
        _require(not any(o['object_index'] == obj and o['mask'] & 4 for records in overrides for o in records),
                 'one-shot state visual override invalid')
        _require((machine < g['machine_count'] and event < g['event_count'] and g['recipients'][event] == NAMED)
                 if completion else machine == 0 and event == 0, 'one-shot completion invalid')
        clips.append(dict(object_index=obj, owner=owner, end_policy=end, animation_index=animation,
                          completion=completion, machine=machine, event=event))
    for i, (kind, ref) in enumerate(effects):
        if kind == 8:
            _require(clips[ref]['owner'] == g['effect_owners'][i], 'one-shot action owner invalid')
    if version >= 10:
        _require(r.take('4B') == (clip_count, local_time, retain_high, 0), 'one-shot footer invalid')
    reconciliation = None
    if version >= 7:
        count, enabled, machine, event = r.take('4B')
        _require(count == calendar_count, 'calendar footer invalid')
        if local_time and enabled == 1:
            _require(machine < g['machine_count'] and event < g['event_count'] and
                     g['recipients'][event] == NAMED, 'time reconciliation binding invalid')
            reconciliation = (machine, event)
        else:
            _require(not (enabled or machine or event), 'time reconciliation footer invalid')
    if version >= 6:
        _require(r.take('B')[0] == transient_count, 'transient count invalid')
    activation = None
    retain_mask = 0
    if version >= 5:
        retain_mask, = r.take('B')
        retain_mask |= retain_high << 8
        _require(retain_mask < (1 << g['machine_count']), 'machine retention mask invalid')
    if version >= 4:
        activation = r.take('BB')
        machine, event = activation
        if version >= 5 and machine == NONE and event == NONE:
            activation = None
        else:
            _require(machine < g['machine_count'] and event < g['event_count'] and
                     g['recipients'][event] == NAMED, 'scene activation binding invalid')
    r.end()
    if text_bindings:
        g['text_bindings'] = text_bindings
    g.update(retain_mask=retain_mask, scene_activated=activation, time_reconcile=reconciliation, entry_state=g['entry'][primary], primary=primary, writers=writers, effects=effects,
             inputs=inputs, package_variable_ids=slots, variable_slots=variable_slots, selectors=selectors,
             visuals=visuals, transients=transients, calendars=calendars, clips=clips)
    return g
