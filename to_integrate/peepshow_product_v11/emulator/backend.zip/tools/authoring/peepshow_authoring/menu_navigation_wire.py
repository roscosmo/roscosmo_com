"""MNV1 navigation tables for device integration, not executable egg admission.

Conditions, ordinary object bindings, input mappings and lifecycle ownership stay
in the enclosing component. The navigator consumes one evaluated availability
snapshot and emits an intent for the existing transaction/scope owner. This image
alone must never be advertised or installed as a complete Menu component.
"""
from dataclasses import dataclass
import struct

from .machine_wire import require
from .menu_component import validate
from .presentation_selectors import variable_definitions

NONE = 0xffff
HEADER = struct.Struct('<4s9I')
PAGE = struct.Struct('<8H')
ENTRY = struct.Struct('<HHi6H')
DRAFT = struct.Struct('<ii')


@dataclass(frozen=True)
class NavigationImage:
    data: bytes
    pages: tuple[str, ...]
    entries: tuple[tuple[str, str], ...]
    drafts: tuple[str, ...]


def compile_navigation(project, scene, *, machines=(), events=(), audio_cues=()):
    """Compile validated public source without generated authored machines.

    Receiver indices are the enclosing compiled Scene's exact identity tables;
    never assume that authored order equals device indices. Source references are
    returned alongside the bytes for component binding and diagnostic mapping.
    """
    validate(project, scene, audio_cues)
    menu = scene['menu_component']
    for name, values in (('machine', machines), ('event', events)):
        require(len(values) < NONE and len(values) == len(set(values)),
                f'MENU_NAVIGATION_IDENTITIES: duplicate or excessive {name} identities')
    pages = tuple(p['page_id'] for p in menu['pages'])
    drafts = tuple(d['draft_id'] for d in menu['drafts'])
    parent = {e['page_ref']: p['page_id'] for p in menu['pages']
              for e in p['entries'] if e['kind'] == 'submenu'}
    variables = variable_definitions(project, scene)
    page_data, entry_data, draft_data, entry_ids = [], [], [], []
    for page in menu['pages']:
        ids = [e['entry_id'] for e in page['entries']]
        flags = int(page.get('choice_mode') == 'stage_on_navigation') | (2 if 'neighbors' in page else 0)
        page_data.append(PAGE.pack(len(entry_ids), len(ids),
            ids.index(page['initial_entry']) if 'initial_entry' in page else NONE,
            drafts.index(page['initial_draft']) if 'initial_draft' in page else NONE,
            flags, ('stay', 'back', 'confirm').index(page.get('choice_result', 'stay')),
            pages.index(parent[page['page_id']]) if page['page_id'] in parent else NONE, 0))
        for entry in page['entries']:
            kind = entry['kind']
            operand, value, receiver, event = NONE, 0, NONE, NONE
            if kind == 'inventory': code = 0
            elif kind == 'submenu': code, operand = 1, pages.index(entry['page_ref'])
            elif kind == 'choice': code, operand, value = 2, drafts.index(entry['draft_ref']), int(entry['value'])
            elif kind == 'action': code = 3 if entry['operation'] == 'confirm' else 4
            else:
                code = 5
                path = f"scenes[{scene['scene_id']}].menu_component.pages[{page['page_id']}].entries[{entry['entry_id']}]"
                require(entry['machine_ref'] in machines and entry['event_ref'] in events,
                        f'MENU_NAVIGATION_IDENTITIES: {path}: receiver missing from compiled Scene')
                receiver, event = machines.index(entry['machine_ref']), events.index(entry['event_ref'])
            neighbors = page.get('neighbors', {}).get(entry['entry_id'], {})
            entry_data.append(ENTRY.pack(code, operand, value,
                *(ids.index(neighbors[d]) if d in neighbors else NONE for d in ('left', 'right', 'up', 'down')),
                receiver, event))
            entry_ids.append((page['page_id'], entry['entry_id']))
    for draft in menu['drafts']:
        ref = draft['source']
        definition = variables[(ref['variable_scope'], ref['variable_ref'])]
        bounds = (0, 1) if definition['value_type'] == 'bool' else (definition['minimum'], definition['maximum'])
        draft_data.append(DRAFT.pack(*bounds))
    payload = b''.join(page_data + entry_data + draft_data)
    data = HEADER.pack(b'MNV1', 1, HEADER.size + len(payload), len(pages), len(entry_ids),
        len(drafts), pages.index(menu['root_page']), int(menu['wrap']),
        menu['presentation'].get('visible_rows', 64), 0) + payload
    return NavigationImage(data, pages, tuple(entry_ids), drafts)
