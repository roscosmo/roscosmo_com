"""Bounded, session-owned reuse of deterministic authoring results.

No persistent cache, timestamp freshness assumptions, or cached failures. Calls
outside an AuthoringService session retain the ordinary uncached implementation.
"""
from collections import OrderedDict
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from dataclasses import fields, is_dataclass
from functools import wraps
import hashlib
import json
from pathlib import Path

_ACTIVE = ContextVar('authoring_processing_cache', default=None)
_FILE_LIMIT = 16 * 1024 * 1024


def _json_default(value):
    if isinstance(value, bytes):
        return {'bytes_sha256': hashlib.sha256(value).hexdigest(), 'length': len(value)}
    if isinstance(value, Path):
        return str(value.resolve())
    if is_dataclass(value):
        return {field.name: getattr(value, field.name) for field in fields(value)}
    raise TypeError(type(value).__name__)


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, default=_json_default, sort_keys=True,
                                    separators=(',', ':'), ensure_ascii=True).encode('ascii')).digest()


class ProcessingCache:
    """LRU bounded by entry count and charged retained payload, not process RAM.

    Python object overhead is additional. Large files/results simply bypass reuse.
    The budget is a private host resource guard, not a firmware tuning parameter.
    """
    def __init__(self, *, max_entries=128, max_bytes=16 * 1024 * 1024):
        self.max_entries = max_entries
        self.max_bytes = max_bytes
        self.entries = OrderedDict()
        self.bytes = 0

    def clear(self):
        self.entries.clear()
        self.bytes = 0

    def get(self, key):
        if key not in self.entries:
            return None
        value, size = self.entries.pop(key)
        self.entries[key] = (value, size)
        return deepcopy(value)

    def put(self, key, value, size):
        size = max(256, size)
        if size > self.max_bytes or self.max_entries <= 0:
            return
        if key in self.entries:
            self.bytes -= self.entries.pop(key)[1]
        while self.entries and (len(self.entries) >= self.max_entries or self.bytes + size > self.max_bytes):
            self.bytes -= self.entries.popitem(last=False)[1][1]
        self.entries[key] = (deepcopy(value), size)
        self.bytes += size

    @contextmanager
    def active(self):
        token = _ACTIVE.set(self)
        try:
            yield
        finally:
            _ACTIVE.reset(token)


def _file_bytes(path):
    # Oversized files retain the previous streaming decoder path and semantics.
    with path.open('rb') as stream:
        data = stream.read(_FILE_LIMIT + 1)
    return data if len(data) <= _FILE_LIMIT else None


def _map_dependencies(records, root):
    from .image_assets import resolve_project_path
    dependencies = []
    for record in records:
        source = resolve_project_path(root, record['source_path'], 'map.source_path')
        for atlas in record['snapshot']['tilesets']:
            relative = (source.parent.relative_to(root.resolve()) / atlas['image']).as_posix()
            path = resolve_project_path(root, relative, 'tileset.image')
            data = _file_bytes(path)
            if data is None:
                return None
            dependencies.append((str(path), hashlib.sha256(data).hexdigest()))
    return dependencies


def _optional_key(make):
    # Missing/invalid source must take the existing validation/error path. A
    # cache lookup must never replace authored diagnostics with its own error.
    try:
        return make()
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        return None


def cached_images(function):
    @wraps(function)
    def run(root, asset, **kwargs):
        cache = _ACTIVE.get()
        if cache is None:
            return function(root, asset, **kwargs)
        from .image_assets import resolve_project_path
        data = _optional_key(lambda: _file_bytes(resolve_project_path(root, asset.get('source_path'), 'source_path')))
        if data is None:
            return function(root, asset, **kwargs)
        key = _optional_key(lambda: ('images', fingerprint((Path(root), asset, kwargs, data))))
        if key is None:
            return function(root, asset, **kwargs)
        hit = cache.get(key)
        if hit is not None:
            return hit
        # Decode exactly the bytes used for the key, never reopen a changed file.
        result = function(root, asset, _source_bytes=data, **kwargs)
        cache.put(key, result, sum(len(f.pixels) + len(f.mask) + 256 for f in result))
        return result
    return run


def cached_map(function):
    @wraps(function)
    def run(record, root, **kwargs):
        cache = _ACTIVE.get()
        if cache is None:
            return function(record, root, **kwargs)
        from .tiled_assets import validate_record
        validate_record(record, Path(root))
        def make_key():
            dependencies = _map_dependencies([record], Path(root))
            return None if dependencies is None else ('map', fingerprint((Path(root), record, kwargs, dependencies)))
        key = _optional_key(make_key)
        hit = cache.get(key) if key is not None else None
        if hit is not None:
            return hit
        result = function(record, root, **kwargs)
        # Concurrent external writes must not seed an old key with new pixels.
        if key is not None and key == _optional_key(make_key):
            size = len(result.layout.data) + len(result.tiles.data) + len(result.terrain)
            size += len(json.dumps(result.visual_record).encode('utf-8')) * 4 + len(result.source_gids) * 32
            cache.put(key, result, size)
        return result
    return run


def cached_map_readiness(function):
    @wraps(function)
    def run(bundle):
        cache = _ACTIVE.get()
        if cache is None or not bundle.valid:
            return function(bundle)
        def make_key():
            from .target_profile import TARGET_PROFILE
            dependencies = _map_dependencies([r for c in bundle.asset_catalogs for r in c.get('map_assets', [])], bundle.root)
            if dependencies is None:
                return None
            content = {field.name: getattr(bundle, field.name) for field in fields(bundle)}
            content['project'] = {k: v for k, v in bundle.project.items() if k != 'editor'}
            # Only the top-level Scene label is proven absent from map encoding.
            # Do not strip nested display names, menu text or arbitrary metadata.
            content['scenes'] = tuple({k: v for k, v in s.items() if k != 'display_name'} for s in bundle.scenes)
            return ('map_readiness', fingerprint((content, TARGET_PROFILE, dependencies)))
        key = _optional_key(make_key)
        hit = cache.get(key) if key is not None else None
        if hit is not None:
            return hit
        result = function(bundle)
        if (key is not None and not result['issues'] and result['reason'] == 'device_map_admission_required'
                and key == _optional_key(make_key)):
            cache.put(key, result, 256)
        return result
    return run
