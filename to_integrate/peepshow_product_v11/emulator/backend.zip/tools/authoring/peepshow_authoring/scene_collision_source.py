"""Ordinary Scene collision conditions; no instance or query-result variable."""
from dataclasses import replace

from .imported_properties import ImportedPropertyError
from .world_operands_wire import decode_typed_operands, compile_query_operands

DIRECTIONS = {'left': (-1, 0), 'right': (1, 0), 'up': (0, -1), 'down': (0, 1)}
CAPABILITY = {
    'host_editing': True, 'persisted': True, 'undo_redo': True, 'host_preview': True,
    'runtime': False, 'export': False, 'status': 'host_preview',
    'field': 'machine_logic.collision_queries', 'guard_kind': 'collision.compare',
    'schema': 'schemas/authoring/scene-collision-queries-v1.schema.json',
    'commands': ['scene.machines.set', 'scene.flowcharts.set'],
    'directions': [*DIRECTIONS, 'facing'], 'facing_reference_field': 'facing_ref',
    'explicit_cell': True, 'cell_field': 'cell', 'cell_units': 'zero_based_map_grid',
    'comparisons': ['eq', 'ne'],
    'result_type': 'bool', 'true_means': 'blocked', 'read_only': True,
    'grid': 'map_scene', 'requires': 'registered_occupancy_entity',
    'route_field': 'guards', 'flow_branch_field': 'world_guards',
    'flow_combination': 'and_with_when', 'reads': 'current_transaction',
    'out_of_bounds': 'blocked', 'failed_query': 'reject_transaction',
    'readiness_error': 'SCENE_COLLISION_DEVICE_UNAVAILABLE',
}


def declarations(scene, refs):
    from .project import STABLE_ID
    graph = scene.get('machine_logic', {})
    rows = graph.get('collision_queries', [])
    if type(rows) is not list:
        raise ImportedPropertyError('collision_queries must be an array')
    if not rows:
        return []
    source = graph.get('map_scene')
    if type(source) is not dict:
        raise ImportedPropertyError('Scene collision queries require map_scene')
    width, height = source.get('cell_width'), source.get('cell_height')
    if any(type(v) is not int or not 1 <= v <= 0xffffffff for v in (width, height)):
        raise ImportedPropertyError('Scene collision queries require a valid map grid')
    occupants = source.get('occupancy', [])
    if type(occupants) is not list:
        raise ImportedPropertyError('Scene collision queries require occupancy declarations')
    result, seen = [], set()
    for row in rows:
        facing = type(row) is dict and row.get('direction') == 'facing'
        absolute = type(row) is dict and 'cell' in row
        if type(row) is not dict or set(row) != ({'query_id', 'entity_ref', 'cell' if absolute else 'direction', 'include_actors'} | ({'facing_ref'} if facing else set())):
            raise ImportedPropertyError('invalid Scene collision query fields')
        name, entity, direction = row['query_id'], row['entity_ref'], row.get('direction')
        if type(name) is not str or not STABLE_ID.fullmatch(name) or name in seen:
            raise ImportedPropertyError('invalid or duplicate collision query_id')
        if (type(entity) is not str or (not absolute and (type(direction) is not str or (not facing and direction not in DIRECTIONS)))
                or type(row['include_actors']) is not bool):
            raise ImportedPropertyError('collision query requires entity, cardinal direction and Boolean include_actors')
        candidates = [r for r in occupants if isinstance(r, dict) and r.get('entity_ref') == entity]
        if len(candidates) != 1:
            raise ImportedPropertyError('collision query actor must have exactly one occupancy declaration')
        coordinates = []
        for axis in ('x', 'y'):
            identity = candidates[0].get(axis + '_ref')
            if type(identity) is not str or identity not in refs:
                raise ImportedPropertyError('collision query actor coordinates must be declared')
            ref, kind = refs[identity]
            if (kind != 'int32' or ref.asset_id != source.get('asset_ref') or
                    ref.owner_id != entity or ref.field != 'entity_' + axis):
                raise ImportedPropertyError('collision query coordinates must belong to its actor and map')
            coordinates.append(ref)
        seen.add(name)
        if absolute:
            cell = row['cell']
            if type(cell) is not dict or set(cell) != {'x', 'y'} or any(
                    type(cell[a]) is not int or not -2**31 <= cell[a] < 2**31 for a in ('x', 'y')):
                raise ImportedPropertyError('explicit collision cell requires signed integer grid x/y literals')
            if any(not -2**31 <= cell[a] * size < 2**31 for a, size in (('x', width), ('y', height))):
                raise ImportedPropertyError('explicit cell exceeds integer world coordinate range')
            result.append((name, *coordinates, width, height, cell['x'], cell['y'], 5 + int(row['include_actors'])))
        elif facing:
            identity = row['facing_ref']
            declarations = {r['reference_id']: r for r in graph.get('world_references', [])}
            if type(identity) is not str or identity not in refs or declarations[identity].get('semantic') != 'facing':
                raise ImportedPropertyError('facing-relative query requires a declared facing semantic')
            ref, kind = refs[identity]
            if kind != 'int32' or ref.asset_id != source.get('asset_ref') or ref.owner_id != entity or ref.field != 'property':
                raise ImportedPropertyError('facing reference must belong to the querying actor and map')
            result.append((name, *coordinates, width, height, ref, 0, 3 + int(row['include_actors'])))
        else:
            result.append((name, *coordinates, width, height, *DIRECTIONS[direction], int(row['include_actors'])))
    return result


def lower(world, queries, guards, moves=()):
    if not queries:
        return world
    bindings, ordinary_guards, actions = decode_typed_operands(
        world.operands, len(world.machine_sources), len(world.flow_sources))
    slots = {ref: i for i, ref in enumerate(world.binding_sources)}
    ids = {q[0]: i for i, q in enumerate(queries)}
    records = [(slots[x], slots[y], w, h, slots[dx] if kind in (3, 4) else dx, dy)
               for _, x, y, w, h, dx, dy, kind in queries]
    for action_id, query_id in moves:
        index = world.action_sources.index(action_id)
        actions[index] = (actions[index][0], 7, ids[query_id])
    predicates = [(len(bindings) + ids[q], 1 if op == 'eq' else 2, int(value))
                  for _, q, op, value in guards]
    operands = compile_query_operands(bindings, ordinary_guards + predicates, actions,
        records, len(world.machine_sources), len(world.flow_sources), occupancy=[q[-1] for q in queries])
    return replace(world, operands=operands, guard_sources=world.guard_sources + tuple(g[0] for g in guards))
