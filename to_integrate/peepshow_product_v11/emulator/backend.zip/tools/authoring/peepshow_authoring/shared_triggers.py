"""Explicit shared coverage, lowered without changing unannotated handlers."""
from copy import deepcopy
from dataclasses import replace

FIELD = 'trigger_scope'
CAPABILITY = dict(field=FIELD, values=['state', 'selected', 'any'],
    schema='schemas/authoring/shared-trigger-v1.schema.json',
    commands=['scene.response.set', 'scene.machines.set'],
    contexts=['ordinary_machine', 'shared_behavior'],
    state_specific_override='complete_including_failed_checks',
    shared_overlap='execution_error', duplicate_state_handler='execution_error',
    any_includes_future_states=True, unannotated_handlers='unchanged',
    mixed_annotated_event='execution_error', authoring_save=True, host_preview=True,
    runtime=False, export=False)


def prepare(bundle):
    from .project import ValidationIssue
    scenes = deepcopy(bundle.scenes)
    issues = list(bundle.issues)
    enabled = bundle.project.get('execution_semantics') == 'terminal_order_v1'
    def graph_prepare(graph, path):
        routes = graph.get('routes', [])
        annotated = [r for r in routes if FIELD in r]
        if not annotated:
            return
        def problem(route, message):
            issues.append(ValidationIssue('SHARED_TRIGGER_INVALID',
                path + '.routes[' + str(route.get('route_id', '?')) + '].' + FIELD, message))
        if not enabled:
            for route in annotated:
                problem(route, 'Explicit trigger scope requires terminal_order_v1; no implicit migration')
            return
        malformed = False
        for route in annotated:
            if (any(type(route.get(key)) is not str for key in ('route_id', 'machine_ref', 'event_ref')) or
                type(route.get('from_states')) is not list or
                any(type(state) is not str for state in route.get('from_states', []))):
                problem(route, 'Trigger requires route, machine and event identities and a from_states list of State identities')
                malformed = True
        if malformed:
            return
        owners = {m['machine_id']: m['states'] for m in graph.get('machines', [])
                  if isinstance(m, dict) and type(m.get('machine_id')) is str and
                  isinstance(m.get('states'), list) and all(type(state) is str for state in m['states'])}
        groups = {(r['machine_ref'], r['event_ref']) for r in annotated}
        effective = {}
        for owner, event in groups:
            rows = [r for r in routes if (r.get('machine_ref'), r.get('event_ref')) == (owner, event)]
            states = owners.get(owner, [])
            if any(FIELD not in r for r in rows):
                for route in rows:
                    problem(route, 'Set explicit scope on every handler for this machine/event before enabling shared precedence')
                continue
            coverage = {}
            for route in rows:
                scope = route[FIELD]; refs = route['from_states']
                if (scope not in ('state', 'selected', 'any') or
                    (scope == 'state' and len(refs) != 1) or
                    (scope == 'selected' and not refs) or
                    (scope == 'any' and refs) or len(set(refs)) != len(refs)):
                    problem(route, 'State requires one from_states entry; Selected requires a nonempty unique set; Any requires []')
                if owner not in owners or any(ref not in states for ref in refs):
                    problem(route, 'Trigger coverage must reference States belonging to its machine')
                coverage[route['route_id']] = set(states if scope == 'any' else refs)
            for i, route in enumerate(rows):
                for other in rows[i+1:]:
                    same_class = (route[FIELD] == 'state') == (other[FIELD] == 'state')
                    if same_class and coverage[route['route_id']] & coverage[other['route_id']]:
                        problem(route, 'Overlapping handler: ' + other['route_id'])
                        problem(other, 'Overlapping handler: ' + route['route_id'])
            overrides = set().union(*(coverage[r['route_id']] for r in rows if r[FIELD] == 'state'))
            for route in rows:
                allowed = coverage[route['route_id']]
                if route[FIELD] != 'state':
                    allowed = allowed - overrides
                effective[route['route_id']] = [s for s in states if s in allowed]
        lowered = []
        for route in routes:
            if route['route_id'] not in effective:
                lowered.append(route)
            elif effective[route['route_id']]:
                row = deepcopy(route); row.pop(FIELD)
                row['from_states'] = effective[route['route_id']]
                lowered.append(row)
        graph['routes'] = lowered
    for scene in scenes:
        path = 'scenes[' + scene['scene_id'] + '].machine_logic'
        graph = scene.get('machine_logic', {})
        graph_prepare(graph, path)
        for behavior in graph.get('instance_behaviors', {}).get('behaviors', []):
            graph_prepare(behavior['machine_logic'], path + '.instance_behaviors.behaviors[' + behavior['behavior_id'] + '].machine_logic')
    return replace(bundle, scenes=scenes, issues=tuple(issues))
