"""Shared source-driven map encoder; public admission lives in map_export.

No fixture graphs, baked route tables or post-build binary replacement. The same
public source lowering used by preview supplies every behavior and world action.
Native installation/resource checks remain required before hardware testing.
"""
from dataclasses import replace
import struct
from .map_colour import effective as effective_base_colour

from .egg_format import EggChunkSpec, fnv1a64
from .instance_metadata import Metadata, NONE, encode_terrain_metadata
from .instance_source import compile_instance_source
from .layered_map import compile_layered_map
from .machine_package import encode_machine_package
from .machine_wire import require
from .map_scene_source import validate_scene
from .terrain_actors import compile_terrain_actors
from .tilemap_binding import compile_terrain_bindings
from .world_logic_source import prepare, compile_position_source, compile_selector_source
from .world_operands_wire import decode_operands, decode_typed_operands, compile_query_operands
from .world_scene_wire import compile_graph


def _metadata(combined):
    slots, instances, cells, queries, bridges, policies = [], [], [], [], [], []
    has_policy = False
    for row in combined.instances.instances:
        instances.append((row.behavior, combined.world.binding_sources.index(row.entity),
                          row.writer, len(slots), len(row.bindings)))
        slots.extend(row.bindings)
    for bridge, query in zip(combined.routing.bridges, combined.routing.queries, strict=True):
        index = NONE
        if query is not None:
            require(query.no_target is None,
                    'INTERACTION_DEVICE_UNAVAILABLE: authored No target delivery is not device qualified')
            if query.interaction_targets is not None:
                targets = query.interaction_targets
                by_instance = {r[0]: r for r in targets}
                for cell in query.targets:
                    _, event, sides, enabled, expected = by_instance[cell[2]]
                    mask = sum({(-1, 0): 1, (1, 0): 2, (0, -1): 4, (0, 1): 8}[s] for s in sides)
                    policies.append((event, mask, NONE if enabled is None else enabled, int(expected or False)))
                has_policy = True
            else:
                policies.extend((bridge[3], 15, NONE, 0) for _ in query.targets)
            index = len(queries)
            queries.append((query.actor_x, query.actor_y, query.facing, query.width,
                query.height, len(cells), len(query.targets), *(v for r in query.facings for v in r)))
            cells.extend(query.targets)
        bridges.append((*bridge, index))
    routing = combined.routing
    behaviors = []
    for behavior in combined.behaviors:
        operands = behavior.operands
        if struct.unpack_from('<I', operands, 4)[0] == 1:
            local, guards, actions = decode_operands(operands, 1)
            operands = compile_query_operands(local, guards, actions, [], 1)
        behaviors.append((behavior.logic.data, operands))
    return Metadata(tuple(behaviors),
        tuple(instances), tuple(bridges), tuple(queries), tuple(slots), tuple(cells),
        routing.maximum_single_root_events, routing.initial_event_capacity,
        routing.required_queue_entries, len(combined.world.binding_sources),
        len(combined.scene.machines), len(combined.scene.events),
        outgoing=routing.outgoing, interaction_policies=tuple(policies) if has_policy else ())


def build_qualification_egg(bundle):
    from .execution_scope_source import require_execution_ready
    require_execution_ready(bundle)
    return _build(bundle)


def build_scoped_inspection_egg(bundle):
    """Private MGW1 v4 input for inspection and runtime qualification tests."""
    require(all('execution_scopes' in s.get('machine_logic', {}) or 'menu_component' in s
                for s in bundle.scenes),
            'scoped inspection requires explicit scopes or a menu component in every Scene')
    return _build(bundle, scoped=True)


def build_scoped_qualification_egg(bundle):
    """Qualification entry, bypassing the public map_export profile checks.

    Uses the identical complete source tested by scoped inspection and ARM
    preparation. Emitting bytes does not certify hardware behavior or timings.
    """
    return build_scoped_inspection_egg(bundle)


def _build(bundle, *, scoped=False):
    from .menu_component import require_execution_ready as require_menu_ready
    components = scoped and any('menu_component' in s for s in bundle.scenes)
    if components:
        require(all('menu_component' in s for s in bundle.scenes),
                'COMPONENT_PACKAGE_UNAVAILABLE: mixed component/legacy scope Scenes are not qualified')
    else:
        require_menu_ready(bundle)
    require(bundle.valid, 'qualification source must validate')
    require(all('map_scene' in s.get('machine_logic', {}) for s in bundle.scenes),
            'qualification profile requires map source in every Scene')
    graphs, selectors, chunks, bindings, combined_scenes = {}, {}, [], [], {}
    content_names = {}
    scenes = sorted(bundle.scenes, key=lambda s: s['scene_id'])
    for number, scene in enumerate(scenes, 1):
        validate_scene(bundle, scene)
        sid, source = scene['scene_id'], scene['machine_logic']
        spec = source['map_scene']
        require('visibility' not in spec or spec['visibility'] == dict(world=True, layers=[]),
                'VISIBILITY_DEVICE_UNAVAILABLE: map visibility is not hardware qualified')
        projected, world, lowered = prepare(bundle, sid, _execution_scopes=scoped)
        require(not lowered.camera_actions,
                'CAMERA_ACTION_DEVICE_UNAVAILABLE: retarget/Look at actions are not device qualified')
        require(int.from_bytes(world.operands[4:8], 'little') != 6,
                'EXPLICIT_DESTINATION_DEVICE_UNAVAILABLE: explicit-cell destinations are not hardware qualified')
        require(int.from_bytes(world.operands[4:8], 'little') != 5,
                'FACING_DESTINATION_DEVICE_UNAVAILABLE: facing-relative destinations are not hardware qualified')
        combined = compile_instance_source(projected, sid, world, lowered.routes,
            lowered.instance_source if lowered.instance_source is not None else
                dict(version=2, behaviors=[], instances=[], bridges=[]),
            queue_capacity=64, flow_attachments=lowered.flows,
            authoring_scene_exits=True, _execution_scopes=scoped)
        combined_scenes[sid] = combined
        record = next(r for c in bundle.asset_catalogs for r in c.get('map_assets', [])
                      if r['asset_id'] == spec['asset_ref'])
        from .scene_map_entities import materialize
        compiled = compile_layered_map(materialize(record, spec), bundle.root,
            background_layers=spec['background_layers'], object_layer=spec['object_layer'],
            collision_layer=spec['collision_layer'])
        names = [f'map.{sid}', f'tiles.{sid}', f'terrain.{sid}']
        # Intern exact immutable bytes, never a CRC or Scene label. A cell bank
        # can share only with the same tileset interpretation. Runtime positions,
        # properties, machines and activation still belong to each Scene.
        data = (compiled.layout.data, compiled.tiles.data, compiled.terrain)
        bank_name = content_names.get((16, data[1]), names[1])
        keys = ((15, bank_name, data[0]), (16, data[1]), (18, data[2]))
        for i, (key, kind, payload) in enumerate(zip(keys, (15, 16, 18), data, strict=True)):
            if key in content_names:
                names[i] = content_names[key]
            else:
                content_names[key] = names[i]
                chunks.append(EggChunkSpec(names[i], kind, payload))
        map_id, bank_id, terrain_id = map(fnv1a64, names)
        rows = decode_typed_operands(world.operands, len(world.machine_sources), len(world.flow_sources))[0]
        # Lowering can append bindings; resolve declarations by stable identity,
        # never assume source list order is the numeric operand order.
        from .world_reference_source import parse_reference
        refs = {r['reference_id']: world.binding_sources.index(parse_reference(r['target'])[0])
                for r in source['world_references']}
        actors = []
        for actor in spec['occupancy']:
            x, y = refs[actor['x_ref']], refs[actor['y_ref']]
            row = dict(entity=rows[x][1], x=x, y=y,
                       cell_width=spec['cell_width'], cell_height=spec['cell_height'])
            if 'solid_when' in actor:
                condition = actor['solid_when']
                row['solid_when'] = dict(binding=refs[condition['reference_ref']], equals=condition['equals'])
            actors.append(row)
        positions, _ = compile_position_source(bundle, sid)
        graphs[sid] = dict(logic=combined.scene.data, operands=world.operands,
            positions=positions, map_id=map_id, terrain_id=terrain_id,
            instance_metadata=encode_terrain_metadata(_metadata(combined), maximum_bytes=16*1024*1024,
                target_bindings=any(row.target is not None for row in combined.instances.instances)),
            terrain_actors=compile_terrain_actors(actors))
        selectors[sid] = compile_selector_source(bundle, sid)[0]
        camera = lowered.camera
        initial = spec.get('initial_camera', dict(x=0, y=0))
        policy = None
        if camera is not None:
            from .camera_source import origin
            width, height, tw, th = struct.unpack_from('<4I', compiled.layout.data, 12)
            if camera['mode'] == 'follow':
                target = next(a for a in spec['occupancy'] if a['entity_ref'] == camera['target_ref'])
                entity = rows[refs[target['x_ref']]][1]
                entity_offset = struct.unpack_from('<I', compiled.layout.data, 56)[0]
                focus = struct.unpack_from('<ii', compiled.layout.data, entity_offset+32*entity+8)
                offset = camera['offset']
                mode = 2
            else:
                entity, mode = NONE, 1
                focus = camera['position']['x'], camera['position']['y']
                offset = dict(x=0, y=0)
            x, y = origin(focus, offset, camera['clamp'], width*tw, height*th)
            initial = dict(x=x, y=y)
            policy = (mode, entity, offset['x'], offset['y'], int(camera['clamp']), width*tw, height*th)
        binding = dict(scene_id=number, map_id=map_id, bank_id=bank_id, terrain_id=terrain_id,
            camera_x=initial['x'], camera_y=initial['y'], width=168, height=144, gutter=1,
            base_colour=effective_base_colour(record, spec))
        if policy is not None:
            binding['camera_policy'] = policy
        bindings.append(binding)
    chunks.append(EggChunkSpec('map.bindings', 17, compile_terrain_bindings(bindings, len(scenes))))
    projected = replace(projected, asset_catalogs=tuple(
        {k: v for k, v in c.items() if k != 'map_assets'} for c in projected.asset_catalogs))
    def scope_encoder(sid, payload):
        from .execution_scope_wire import compile_execution_scopes
        combined = combined_scenes[sid]
        for field in ('machines', 'events', 'variables', 'effects'):
            require(getattr(payload, field) == getattr(combined.scene, field),
                    'scoped presentation and world logic identities disagree: ' + field)
        authored = next(s for s in scenes if s['scene_id'] == sid)
        return compile_execution_scopes(authored, machines=payload.machines, events=payload.events,
            objects=[o['object_id'] for o in authored['objects']],
            instances=[i.instance_id for i in combined.instances.instances])
    def graph_encoder(sid, sections, ids):
        return compile_graph(presentation=sections.presentation, package_ids=ids,
                             _execution_scopes=scoped, **graphs[sid])
    return encode_machine_package(projected, _flowcharts=True, _object_effects=True,
        _calendars=True, _periodic=True, _selector_encoder=lambda sid: selectors[sid],
        _scope_encoder=scope_encoder if scoped and not components else None,
        _component_sources={s['scene_id']:(s, len(combined_scenes[s['scene_id']].instances.instances),
                                         combined_scenes[s['scene_id']].scene)
                            for s in scenes} if components else None,
        _graph_encoder=graph_encoder, _map_chunks=chunks)
