"""Private mixed routing admission and conservative event-count analysis.

No elapsed-time, LPBAM, memory-budget or installed package capability claim.
Guards/States are not assumed true or false. Alternatives use their maximum;
ordered repeated SENDs retain multiplicity. No recursion or path enumeration.
"""
from dataclasses import dataclass, replace

from .event_graph import find_cycle
from .instance_bindings import compile_instance_query
from .machine_limits import ROUTES
from .machine_wire import require
from .scene_machines import CAPABILITY


@dataclass(frozen=True)
class AheadQuery:
    actor: object
    facing: object
    facings: tuple
    eligible: tuple
    width: int
    height: int
    interaction_targets: list | None = None
    no_target: dict | None = None


def interaction_targets(combined, query, source):
    """Validate the v3 query extension even when supplied without source sugar."""
    from .interaction_source import SIDES
    from .world_reference_source import parse_reference
    from .world_operands_wire import decode_typed_operands
    rows = source.interaction_targets
    require(type(rows) is list and len(rows) <= 128, 'invalid interaction targets')
    instances = {r.instance_id: (i, r) for i, r in enumerate(combined.instances.instances)}
    slots = {ref: i for i, ref in enumerate(combined.world.binding_sources)}
    bindings, _, _ = decode_typed_operands(combined.world.operands,
        len(combined.world.machine_sources), len(combined.world.flow_sources))
    compiled, seen = [], set()
    for row in rows:
        require(type(row) is dict and {'instance_ref', 'input_event_ref', 'approach_sides'} <= set(row)
                and not set(row) - {'instance_ref', 'input_event_ref', 'approach_sides', 'enabled_when'},
                'invalid interaction target fields')
        name, event, sides = row['instance_ref'], row['input_event_ref'], row['approach_sides']
        require(type(name) is str and name in instances and name not in seen,
                'unknown or duplicate interaction target')
        seen.add(name)
        index, instance = instances[name]
        events = combined.behaviors[instance.behavior].logic.events
        require(type(event) is str and event in events, 'target behavior lacks interaction input')
        require(type(sides) is list and bool(sides) and
                all(type(s) is str and s in SIDES for s in sides) and len(set(sides)) == len(sides),
                'invalid interaction approach sides')
        slot, expected = None, None
        if 'enabled_when' in row:
            condition = row['enabled_when']
            require(type(condition) is dict and set(condition) == {'reference', 'equals'} and
                    type(condition['equals']) is bool, 'invalid interaction eligibility condition')
            ref, kind = parse_reference(condition['reference'])
            require(kind == 'bool' and ref.field == 'property' and
                    ref.asset_id == instance.entity.asset_id and ref.owner_id == instance.entity.owner_id and
                    ref in slots and bindings[slots[ref]][2] == 1,
                    'interaction eligibility requires a bound target Boolean')
            slot, expected = slots[ref], condition['equals']
        compiled.append((index, events.index(event), tuple(SIDES[s] for s in sides), slot, expected))
    require(seen == set(source.eligible), 'interaction target list must match eligible instances')
    fallback = source.no_target
    if fallback is not None:
        require(type(fallback) is dict and set(fallback) == {'machine_ref', 'event_ref'} and
                fallback['machine_ref'] in combined.scene.machines and fallback['event_ref'] in combined.scene.events,
                'invalid interaction no-target endpoint')
        fallback = (fallback['machine_ref'], fallback['event_ref'])
    return replace(query, interaction_targets=tuple(compiled), no_target=fallback)


@dataclass(frozen=True)
class EventBridge:
    machine: str
    event: str
    target_event: str
    instance: str | None = None
    query: AheadQuery | None = None


@dataclass(frozen=True)
class Routing:
    bridges: tuple
    queries: tuple
    maximum_single_root_events: int
    initial_event_capacity: int
    required_queue_entries: int
    outgoing: tuple = ()


@dataclass(frozen=True)
class OutgoingEvent:
    instance: str
    event: str
    machine: str
    target_event: str


def compile_routing(combined, scene, behavior_sources, bridges, queue_capacity, initial_event_capacity,
                    *, outgoing=()):
    """Called only after complete Scene/behavior source compilation.

    Legacy numeric bridge target_event is shared by eligible definitions; those
    queries reject different local indices. V3 interaction targets explicitly
    bind each recipient's own event and optional approach/eligibility condition.
    The caller must enforce the declared initial queue capacity at runtime.
    The current mixed queue retains consumed entries, so total appends (not
    just peak outstanding entries) determine its required storage.
    """
    require(isinstance(bridges, (tuple, list)) and len(bridges) <= ROUTES,
            'invalid mixed event bridge table')
    require(isinstance(outgoing, (tuple, list)) and len(outgoing) <= ROUTES,
            'invalid outgoing event table')
    require(type(queue_capacity) is int and 0 < queue_capacity <= 0xffffffff,
            'mixed queue capacity must be a positive integer')
    require(type(initial_event_capacity) is int and
            1 <= initial_event_capacity <= CAPABILITY['maximum_queue'],
            'invalid initial event capacity')
    graph = scene['machine_logic']
    nodes, roots = {}, set()
    # A node is base event work + max(alternative ordered child sums).
    def address(kind, owner, event):
        key = (kind, owner, event)
        nodes.setdefault(key, (1, []))
        return key

    charts = {f['flowchart_id']: f for f in graph.get('flowcharts', [])}
    def actions(rows, behavior=None):
        children = []
        for action in rows:
            if action['kind'] == 'send_event':
                children.append(address('s', action['machine_ref'], action['event_ref']) if behavior is None
                                else address('b', behavior, action['event_ref']))
            elif action['kind'] == 'run_flowchart':
                ref = action['flowchart_ref']
                children.append(('f', ref, charts[ref]['root']))
        return tuple(children)

    for chart_id, chart in charts.items():
        for node in chart['nodes']:
            key = ('f', chart_id, node['node_id'])
            if node['kind'] == 'actions':
                alternatives = [actions(node['actions']) + (('f', chart_id, node['next']),)]
            elif node['kind'] == 'decision':
                alternatives = [(('f', chart_id, target),) for target in
                                [node['default'], *(b['next'] for b in node['branches'])]]
            else:
                alternatives = [()]
            nodes[key] = (0, alternatives)

    behavior_handlers = set()
    for instance, record in enumerate(combined.instances.instances):
        source = behavior_sources[record.behavior]
        definition = next(s for s in source.bundle.scenes if s['scene_id'] == source.scene_id)
        for route in definition['machine_logic']['routes']:
            key = address('b', instance, route['event_ref'])
            behavior_handlers.add(key)
            nodes[key][1].append(actions(route['actions'], instance))
            roots.add(key)
    handlers = set()
    for route in graph['routes']:
        key = address('s', route['machine_ref'], route['event_ref'])
        handlers.add(key)
        roots.add(key)
        nodes[key][1].extend(actions(outcome['actions']) for outcome in route.get('outcomes', [route]))

    instances = {r.instance_id: (i, r) for i, r in enumerate(combined.instances.instances)}
    named = {e['event_id'] for e in graph['events']}
    emitted, queries, endpoints = [], [], set()
    for bridge in bridges:
        require(isinstance(bridge, EventBridge) and type(bridge.machine) is str and
                bridge.machine in combined.scene.machines and type(bridge.event) is str and
                bridge.event in named and type(bridge.target_event) is str and bridge.target_event,
                'bridge requires an existing machine and named event')
        require((bridge.instance is not None) != (bridge.query is not None),
                'bridge requires exactly one static instance or facing query')
        key = address('s', bridge.machine, bridge.event)
        require(key not in endpoints and key not in handlers,
                'duplicate bridge or bridge shadows a Scene handler')
        endpoints.add(key)
        roots.add(key)
        if bridge.query is not None:
            q = bridge.query
            require(isinstance(q, AheadQuery), 'invalid facing query source')
            query = compile_instance_query(combined.world, combined.instances,
                q.actor, q.facing, q.facings, q.eligible, q.width, q.height)
            targets = [row[2] for row in query.targets]
            instance = 0xffffffff
        else:
            require(type(bridge.instance) is str and bridge.instance in instances, 'unknown bridge instance')
            instance, record = instances[bridge.instance]
            targets, query = [instance], None
        if query is not None and q.interaction_targets is not None:
            query = interaction_targets(combined, query, q)
        indices, alternatives = set(), []
        for target in sorted(set(targets)):
            behavior = combined.instances.instances[target].behavior
            events = combined.behaviors[behavior].logic.events
            event = bridge.target_event
            if query is not None and query.interaction_targets is not None:
                event = events[next(r[1] for r in query.interaction_targets if r[0] == target)]
            require(event in events, 'target behavior lacks bridge event')
            indices.add(events.index(event))
            alternatives.append((address('b', target, event),))
        interaction = query is not None and query.interaction_targets is not None
        require(interaction or len(indices) <= 1, 'eligible behaviors disagree on target event index')
        if interaction and query.no_target is not None:
            alternatives.append((address('s', *query.no_target),))
        # Empty eligibility never delivers; the unused numeric field is zero.
        event_index = 0 if interaction else next(iter(indices), 0)
        nodes[key] = (int(query is not None), alternatives or [()])
        queries.append(query)
        emitted.append((combined.scene.machines.index(bridge.machine),
                        combined.scene.events.index(bridge.event), instance, event_index))

    outputs, output_keys = [], set()
    for output in outgoing:
        require(isinstance(output, OutgoingEvent) and type(output.instance) is str and
                output.instance in instances, 'outgoing event requires an existing instance')
        instance, record = instances[output.instance]
        events = combined.behaviors[record.behavior].logic.events
        require(type(output.event) is str and output.event in events and
                type(output.machine) is str and output.machine in combined.scene.machines and
                type(output.target_event) is str and output.target_event in named,
                'outgoing event requires existing named endpoints')
        key = address('b', instance, output.event)
        require(key not in output_keys and key not in behavior_handlers,
                'duplicate outgoing event or output shadows a behavior handler')
        output_keys.add(key)
        # Delivery replaces this local endpoint; it is not an extra queue entry.
        nodes[key] = (0, [(address('s', output.machine, output.target_event),)])
        roots.add(key)
        outputs.append((instance, events.index(output.event),
                        combined.scene.machines.index(output.machine),
                        combined.scene.events.index(output.target_event)))

    adjacency = {key: {child for option in alternatives for child in option}
                 for key, (_, alternatives) in nodes.items()}
    require(not find_cycle(adjacency), 'mixed immediate event cycle')
    remaining, cost, direct = set(nodes), {}, {}
    while remaining:
        ready = sorted((key for key in remaining if adjacency[key].isdisjoint(remaining)), key=repr)
        require(bool(ready), 'mixed routing dependency is unresolved')
        for key in ready:
            base, alternatives = nodes[key]
            cost[key] = base + max((sum(cost[c] for c in option) for option in alternatives), default=0)
            direct[key] = (max((sum(direct[c] for c in option) for option in alternatives), default=0)
                           if key[0] == 'f' else 1)
            if key[0] == 's' and key not in endpoints:
                require(max((sum(direct[c] for c in option) for option in alternatives), default=0)
                        <= CAPABILITY['maximum_queue'], 'Scene receiver SEND batch exceeds native queue')
        remaining.difference_update(ready)
    maximum = max((cost[key] for key in roots), default=1)
    required = maximum * initial_event_capacity
    require(required <= CAPABILITY['maximum_event_chain'], 'mixed event chain exceeds native work limit')
    require(required <= queue_capacity, 'mixed event chain exceeds supplied queue capacity')
    return Routing(tuple(emitted), tuple(queries), maximum, initial_event_capacity, required,
                   tuple(outputs))
