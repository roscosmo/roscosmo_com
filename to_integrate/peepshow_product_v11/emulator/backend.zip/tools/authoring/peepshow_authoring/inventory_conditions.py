"""Read-only named inventory comparisons on the existing host transaction."""
from copy import deepcopy

KIND = 'inventory.compare'
OPERATORS = ('eq', 'ne', 'lt', 'le', 'gt', 'ge')
CAPABILITY = dict(kind=KIND, schema='schemas/authoring/inventory-condition-v1.schema.json',
    contexts=['ordinary_response', 'ordinary_route_guard', 'flowchart', 'menu_condition'],
    operators=list(OPERATORS), value_type='integer', minimum=0, maximum=65535,
    read_only=True, requires_writer=False, requires_shadow_variable=False,
    shared_behavior=False, presentation_selector=False,
    sampling='accepted_inventory_before_current_event_chain',
    collection_visibility='next_event_or_settled_menu_presentation',
    host_editing=True, persisted=True, undo_redo=True, host_preview=True,
    preview_requires='scope_host_v1', runtime=False, export=False)


def is_condition(value):
    return type(value) is dict and value.get('kind') == KIND


def validate(value, items, location):
    from .inventory_source import fail
    if (set(value) != {'kind', 'item_ref', 'operator', 'value'} or
            type(value.get('item_ref')) is not str or value['item_ref'] not in items):
        fail(f'{location}: inventory comparison requires a known item {value.get("item_ref")!r}')
    if (type(value['operator']) is not str or value['operator'] not in OPERATORS or
            type(value['value']) is not int or not 0 <= value['value'] <= 65535):
        fail(f'{location}: inventory comparison requires eq/ne/lt/le/gt/ge and an integer in 0..65535')


def leaves(value, path=(), depth=0):
    """Only predicate trees; never reinterpret actions or arbitrary JSON."""
    if type(value) is not dict or depth > 8:
        return
    if is_condition(value):
        yield path, value
    elif 'not' in value:
        yield from leaves(value['not'], path+('not',), depth+1)
    else:
        for op in ('all', 'any'):
            if type(value.get(op)) is list:
                for i, child in enumerate(value[op]):
                    yield from leaves(child, path+(op,i), depth+1)


def locations(scene):
    graph = scene.get('machine_logic', {})
    for ri, route in enumerate(graph.get('routes', [])):
        root = ('machine_logic','routes',ri)
        for i, guard in enumerate(route.get('guards', [])):
            if is_condition(guard):
                yield root+('guards',i), guard
        for i, node in enumerate(route.get('response', {}).get('nodes', [])):
            if is_condition(node.get('condition')):
                yield root+('response','nodes',i,'condition'), node['condition']
    for ci, chart in enumerate(graph.get('flowcharts', [])):
        for ni, node in enumerate(chart['nodes']):
            for bi, branch in enumerate(node.get('branches', [])):
                for path, value in leaves(branch.get('when')):
                    yield ('machine_logic','flowcharts',ci,'nodes',ni,'branches',bi,'when')+path, value
    menu = scene.get('menu_component', {})
    for path, value in leaves(menu.get('open', {}).get('when')):
        yield ('menu_component','open','when')+path, value
    for pi, page in enumerate(menu.get('pages', [])):
        for ei, entry in enumerate(page['entries']):
            for field in ('visible_when','enabled_when'):
                for path, value in leaves(entry.get(field)):
                    yield ('menu_component','pages',pi,'entries',ei,field)+path, value


def validate_scene(project, scene):
    from .inventory_source import catalog
    conditions = list(locations(scene))
    if not conditions:
        return
    items = catalog(project)
    for path, condition in conditions:
        validate(condition, items, f"Scene {scene['scene_id']} /"+'/'.join(map(str,path)))


def compare(value, counts, evidence=None):
    from .preview import PreviewError
    if value['item_ref'] not in counts:
        raise PreviewError('inventory comparison has no admitted item: '+value['item_ref'])
    left, right = counts[value['item_ref']], value['value']
    result = dict(eq=left == right, ne=left != right, lt=left < right,
                  le=left <= right, gt=left > right, ge=left >= right)[value['operator']]
    if evidence is not None:
        evidence.append(dict(kind='inventory', item_ref=value['item_ref'], left=left,
                             right=right, operator=value['operator'], result=result))
    return result


def proof_scene(scene):
    """Legacy structural proof only. Host restores and reads the actual counts.

    No authored variables, writes or event bridges are generated. Public device
    readiness refuses inventory before this private preview projection is used.
    """
    from .behavior_response import lower_scene
    result = deepcopy(lower_scene(scene))
    graph = result.get('machine_logic', {})
    for route in graph.get('routes', []):
        if type(route.get('guards')) is not list or len(route['guards']) > 8:
            from .inventory_source import fail
            fail('ordinary routes support at most eight guards')
        route['guards'] = [g for g in route['guards'] if not is_condition(g)]
    for chart in graph.get('flowcharts', []):
        for node in chart['nodes']:
            for branch in node.get('branches', []):
                for path, _ in list(leaves(branch['when'])):
                    parent, key = branch, 'when'
                    for part in path:
                        parent, key = parent[key], part
                    machine = graph['machines'][0]
                    parent[key] = dict(machine_ref=machine['machine_id'], state_ref=machine['entry_state'])
    return result


def restore_host(scene, source):
    """Restore only inventory leaves; keep world/action projections intact."""
    from .behavior_response import lower_scene
    authored = lower_scene(source).get('machine_logic', {})
    graph = scene.get('machine_logic', {})
    guards = {r['route_id']: [g for g in r['guards'] if is_condition(g)]
              for r in authored.get('routes', [])}
    for route in graph.get('routes', []):
        route['guards'] = [g for g in route['guards'] if not is_condition(g)] + deepcopy(guards.get(route['route_id'], []))
    charts = {c['flowchart_id']: c for c in graph.get('flowcharts', [])}
    for chart in authored.get('flowcharts', []):
        target = charts[chart['flowchart_id']]
        nodes = {n['node_id']: n for n in target['nodes']}
        for node in chart['nodes']:
            for bi, branch in enumerate(node.get('branches', [])):
                for path, condition in leaves(branch['when']):
                    parent, key = nodes[node['node_id']]['branches'][bi], 'when'
                    for part in path:
                        parent, key = parent[key], part
                    parent[key] = deepcopy(condition)
