"""Scene-machine capacities shared by source, preview and package admission."""

MACHINES = 16
TIMERS = 16
STATES = 64
ROUTES = 128
NAMED_EVENTS = 64
EVENTS = 96
INPUTS = 32
FLOWCHARTS = 32
OUTCOMES = 8
# Private legacy-IR handlers, not additional authored timers or device bindings.
LOWERED_BINDINGS = 32 + ROUTES * OUTCOMES
