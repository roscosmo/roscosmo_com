"""Gameplay/menu ownership, with explicit opt-in host preview admission."""
from copy import deepcopy

from .imported_properties import ImportedPropertyError

CAPABILITY = dict(status='host_preview_opt_in', host_editing=True, persisted=True, undo_redo=True,
    host_preview=False, runtime=False, export=False, hardware_validation='historical_dungeon_operator_tested',
    field='machine_logic.execution_scopes', source_version=1,
    schema='schemas/authoring/execution-scopes-v1.schema.json',
    commands=['scene.machines.set'], scopes=['gameplay','menu'], maximum_menus=1,
    membership=['machines','instances','objects'], complete_partition=True,
    menu_inputs='declared_action_to_menu_machine_event', unmapped_menu_inputs='consume',
    flow_ownership='caller_context_not_a_separate_clock', shared_definitions='instance_scope',
    pause_menu=False, live_overlay=False, lifecycle_actions=['menu.open', 'menu.close'],
    lifecycle_action_support='source_editing_and_preview_adapter_v1',
    lifecycle_action_placement='sole_action_in_deterministic_ordinary_machine_route',
    lifecycle_delivery='root_dispatch_only_no_queued_delivery',
    lifecycle_action_schema='schemas/authoring/execution-scopes-v1.schema.json#/$defs/action',
    entry_receiver='optional_menu_machine_event_variables_and_explicit_state',
    timing_foundation='preview_adapter_v1',
    input_foundation='preview_adapter_v1',
    audio_foundation='preview_adapter_v1_external_owner',
    menu_lifecycle_foundation='preview_adapter_v1',
    inventory_apply_foundation='preview_adapter_v1',
    confirm_receiver='optional_gameplay_machine_event_variable_only',
    pending=['studio_audio_and_input_consumer', 'calendar_reconciliation', 'public_scoped_export',
             'pause_menu_prefab'],
    validation_error='EXECUTION_SCOPE_INVALID',
    preview_error='EXECUTION_SCOPE_PREVIEW_UNAVAILABLE',
    readiness_error='EXECUTION_SCOPE_DEVICE_UNAVAILABLE')

# Reference evidence is not an export capability or qualification of edited games.
# Additive metadata: service API 93 and preview adapter v1 are unchanged.
CAPABILITY['device_qualification'] = dict(
    status='reference_only', project='examples/authoring/dungeon.peepproj',
    firmware_commit='b5a57f9', source_commit='0f7d6fe',
    applies_to_current_source=False,
    source_reference='tools/authoring/tests/fixtures/dungeon_legacy_source.json',
    report='docs/11 Development Tools/Dungeon_Pause_Menu_Hardware_Test.md',
    studio_handoff='docs/11 Development Tools/Studio_Dungeon_Pause_Menu_Integration.md',
    public_export=False, edited_projects_require_qualification=True,
    latency_target_met=False)

# Additive, opt-in transport. Legacy preview clients must not silently ignore
# focus generations or play the diagnostic copies of scoped audio requests.
CAPABILITY['preview_adapter'] = dict(version=1, host_preview=True,
    reset_option={'scope_host': {'version': 1}},
    schema='schemas/authoring/scope-preview-host-v1.schema.json',
    menu_wait_budget_ms=1000, audio='external_owner_acknowledgement',
    input='generation_stamped_events_and_full_held_snapshots',
    notifications='scope_input.last_handoff_and_scope_menu.last',
    calendar=False, runtime=False, export=False,
    operations=['project.preview_input_snapshot', 'project.preview_audio_take',
                'project.preview_audio_stop_complete', 'project.preview_menu_finish',
                'project.preview_menu_cancel'])


class ExecutionScopeError(ImportedPropertyError):
    code = 'EXECUTION_SCOPE_INVALID'


def configuration(scene):
    graph = scene.get('machine_logic', {})
    if 'execution_scopes' not in graph:
        return None
    source = graph['execution_scopes']
    if (type(source) is not dict or set(source) != {'version','gameplay','menu'} or
            type(source['version']) is not int or source['version'] != 1):
        raise ExecutionScopeError('execution_scopes: expected version 1, gameplay and menu')
    known = dict(machines={m['machine_id'] for m in graph['machines']},
        instances={i['instance_id'] for i in graph.get('instance_behaviors', {}).get('instances', [])},
        objects={o['object_id'] for o in scene.get('objects', [])})
    owners = {kind:{} for kind in known}
    for scope in ('gameplay','menu'):
        row = source[scope]
        required = set(known) | ({'input_receivers'} if scope == 'menu' else set())
        optional = {'confirm_receiver', 'entry_receiver'} if scope == 'menu' else set()
        if type(row) is not dict or not required <= set(row) or set(row) - required - optional:
            raise ExecutionScopeError(f'execution_scopes.{scope}: invalid ownership fields')
        for kind, ids in known.items():
            members = row[kind]
            if type(members) is not list or any(type(ref) is not str for ref in members):
                raise ExecutionScopeError(f'execution_scopes.{scope}.{kind}: expected identity array')
            if kind == 'machines' and not members:
                raise ExecutionScopeError(f'execution_scopes.{scope}: requires at least one machine')
            for ref in members:
                if ref not in ids:
                    raise ExecutionScopeError(f'execution_scopes.{scope}.{kind}: unknown {ref!r}')
                if ref in owners[kind]:
                    raise ExecutionScopeError(f'execution_scopes.{scope}.{kind}: duplicate ownership of {ref!r}')
                owners[kind][ref] = scope
    for kind, ids in known.items():
        missing = sorted(ids - owners[kind].keys())
        if missing:
            raise ExecutionScopeError(f'execution_scopes.{kind}: missing ownership for {missing}')
    for position in graph.get('world_positions', []):
        if owners['objects'].get(position['object_ref']) != 'gameplay':
            raise ExecutionScopeError('execution_scopes: world-position objects belong to gameplay; menu visuals use screen space')
    inputs = {r['action_id'] for r in scene.get('input_actions', [])}
    events = inputs | {r['event_id'] for r in graph['events']}
    receivers = source['menu']['input_receivers']
    if type(receivers) is not dict:
        raise ExecutionScopeError('execution_scopes.menu.input_receivers: expected action/address mapping')
    for action, address in receivers.items():
        if action not in inputs:
            raise ExecutionScopeError(f'execution_scopes.menu.input_receivers: unknown action {action!r}')
        if (type(address) is not dict or set(address) != {'machine_ref','event_ref'} or
                type(address['machine_ref']) is not str or type(address['event_ref']) is not str or
                owners['machines'].get(address['machine_ref']) != 'menu' or address['event_ref'] not in events):
            raise ExecutionScopeError(f'execution_scopes.menu.input_receivers[{action}]: expected menu machine and declared event')
    for action, receiver in graph['input_receivers'].items():
        if owners['machines'].get(receiver) != 'gameplay':
            raise ExecutionScopeError(f'execution_scopes: ordinary input {action!r} requires a gameplay receiver')
    for timer, receiver in graph['timer_receivers'].items():
        if receiver not in owners['machines']:
            raise ExecutionScopeError(f'execution_scopes: timer {timer!r} needs an explicit machine owner')
    if 'confirm_receiver' in source['menu']:
        confirm_routes(graph, source['menu']['confirm_receiver'], owners['machines'])
    if 'entry_receiver' in source['menu']:
        confirm_routes(graph, source['menu']['entry_receiver'], owners['machines'], entry=True)
    return deepcopy(source)


def confirm_routes(graph, address, owners, *, entry=False):
    """A close-time apply is deliberately narrower than a normal event chain."""
    field = 'entry_receiver' if entry else 'confirm_receiver'
    scope = 'menu' if entry else 'gameplay'
    if (type(address) is not dict or set(address) != {'machine_ref', 'event_ref'}
            or type(address['machine_ref']) is not str or type(address['event_ref']) is not str
            or owners.get(address['machine_ref']) != scope
            or address['event_ref'] not in {e['event_id'] for e in graph['events']}):
        raise ExecutionScopeError(f'execution_scopes.menu.{field}: expected {scope} machine and named event')
    routes = [r for r in graph['routes'] if r['machine_ref'] == address['machine_ref']
              and r['event_ref'] == address['event_ref']]
    owner = next(m for m in graph['machines'] if m['machine_id'] == address['machine_ref'])
    writes = {(v['scope'], v['variable_ref']) for v in owner['variable_writes']}
    if not routes:
        raise ExecutionScopeError(f'execution_scopes.menu.{field}: requires an authored handler')
    for route in routes:
        allowed = {'route_id', 'machine_ref', 'event_ref', 'from_states', 'guards', 'actions'}
        if entry:
            allowed.add('target_state')
        if (set(route) - allowed
                or (not route.get('actions') and not (entry and 'target_state' in route))
                or any(a.get('kind') != 'set_variable'
                       or (a.get('variable_scope', 'scene'), a.get('variable_ref')) not in writes
                       for a in route['actions'])):
            raise ExecutionScopeError(f'execution_scopes.menu.{field}: handlers may only update owned variables'
                + (' and explicitly select their own State' if entry else '; no State change') + '; no other effects')
    return routes


def validate_action(graph, action, owner, component=None):
    if component is not None and component.get('version') == 2 and action['kind'] == 'menu.close':
        if (set(action) != {'kind','disposition'} or action['disposition'] not in ('confirm','cancel')
                or owner not in component['scope']['machines']):
            raise ExecutionScopeError('Close Menu requires a menu-owned machine and confirm/cancel disposition')
        return
    if component is not None and action['kind'] == 'menu.open':
        if (type(component) is not dict or set(action) != {'kind', 'menu_ref'} or action['menu_ref'] != component.get('menu_id')
                or owner not in {m['machine_id'] for m in graph['machines']}):
            raise ExecutionScopeError('Open Menu requires an ordinary machine and the actual menu_ref')
        if 'open' in component:
            raise ExecutionScopeError('Choose explicit Open Menu actions or the legacy opening binding, not both')
        if owner in component.get('scope',{}).get('machines',[]):
            raise ExecutionScopeError('Open Menu requires a gameplay owner')
        return
    scopes = graph.get('execution_scopes')
    if scopes is None or type(owner) is not str:
        raise ExecutionScopeError('menu actions require scoped ordinary machine routes')
    opening = action['kind'] == 'menu.open'
    fields = {'kind', 'hide_world'} if opening else {'kind', 'disposition'}
    if (set(action) - fields or (opening and type(action.get('hide_world', True)) is not bool)
            or (not opening and action.get('disposition') not in ('confirm', 'cancel'))):
        raise ExecutionScopeError('menu action requires Boolean hide_world or explicit confirm/cancel disposition')
    scope = 'gameplay' if opening else 'menu'
    if owner not in scopes[scope]['machines']:
        raise ExecutionScopeError(f'{action["kind"]} requires a {scope} owner')
    if not opening and action['disposition'] == 'confirm' and 'confirm_receiver' not in scopes['menu']:
        raise ExecutionScopeError('menu.close confirm requires confirm_receiver')


def validate_route(route):
    for outcome in route.get('outcomes', [route]):
        actions = outcome.get('actions', [])
        if any(a.get('kind') in ('menu.open', 'menu.close') for a in actions):
            if (len(actions) != 1 or 'outcomes' in route
                    or set(route) - {'route_id', 'machine_ref', 'event_ref', 'from_states', 'guards', 'actions'}):
                raise ExecutionScopeError('menu action must be the sole action of a deterministic route without State/Scene change')


def report(scene):
    if 'menu_component' in scene:
        graph = scene.get('machine_logic', {})
        owners = dict(
            machines={m['machine_id']: 'gameplay' for m in graph.get('machines', [])},
            objects={o['object_id']: 'gameplay' for o in scene.get('objects', [])},
            instances={i['instance_id']: 'gameplay' for i in graph.get('instance_behaviors', {}).get('instances', [])},
            timers={ref: 'gameplay' for ref in graph.get('timer_receivers', {})})
        scope=scene['menu_component'].get('scope',{})
        for kind in ('machines','objects'):
            for ref in scope.get(kind,[]): owners[kind][ref]='menu'
        owners['timers']={ref:owners['machines'][machine] if machine is not None else 'gameplay'
                          for ref,machine in graph.get('timer_receivers',{}).items()}
        return dict(status='host_preview_opt_in', owners=owners, menu_input_receivers={},
                    menu_confirm_receiver=None, menu_entry_receiver=None)
    source = configuration(scene)
    if source is None:
        return None
    owners = {kind:{ref:scope for scope in ('gameplay','menu') for ref in source[scope][kind]}
              for kind in ('machines','instances','objects')}
    owners['timers'] = {ref:owners['machines'][machine]
        for ref,machine in scene['machine_logic']['timer_receivers'].items()}
    return dict(status='host_preview_opt_in', owners=owners, menu_input_receivers=deepcopy(source['menu']['input_receivers']),
                menu_confirm_receiver=deepcopy(source['menu'].get('confirm_receiver')),
                menu_entry_receiver=deepcopy(source['menu'].get('entry_receiver')))


def readiness_issues(bundle, *, preview=False, scope_host=False):
    if 'inventory' in bundle.project and (not preview or not scope_host):
        code = 'INVENTORY_DEVICE_UNAVAILABLE' if not preview else 'INVENTORY_PREVIEW_UNAVAILABLE'
        return [dict(code=code, path='inventory', message=code+': inventory requires negotiated host preview; device execution is not connected')]
    if 'inventory' in bundle.project:
        unsupported = [dict(code='INVENTORY_PREVIEW_UNAVAILABLE',
            path=f"scenes[{s['scene_id']}]", message='INVENTORY_PREVIEW_UNAVAILABLE: inventory preview currently requires object Scenes with ordinary machines throughout the session')
            for s in bundle.scenes if s.get('schema_version') != 2 or 'machine_logic' not in s]
        if unsupported:
            return unsupported
    from .response_conditions import is_guard
    if not preview and any('response' in r or any(is_guard(g) for g in r.get('guards', []))
                           for s in bundle.scenes for r in s.get('machine_logic',{}).get('routes',[])):
        return [dict(code='EVENT_RESPONSE_DEVICE_UNAVAILABLE',path='machine_logic.routes',
                     message='Event response graphs require host preview; device export is not qualified')]
    from .menu_component import readiness_issues as menu_issues
    unsupported = menu_issues(bundle, preview=preview, scope_host=scope_host)
    if unsupported:
        return unsupported
    if preview and scope_host:
        scoped = [s for s in bundle.scenes if 'execution_scopes' in s.get('machine_logic', {}) or 'menu_component' in s]
        if not scoped:
            return []
        issues = []
        for scene in bundle.scenes:
            graph = scene.get('machine_logic', {})
            reason = None
            if graph.get('time_reconcile') or any(b['event_type'] == 'time.local_schedule'
                                                 for b in scene.get('event_bindings', [])):
                reason = 'calendar reconciliation is not supported in scoped preview sessions'
            elif scene in scoped and 'map_scene' in graph and 'visibility' not in graph['map_scene']:
                reason = 'scoped map preview requires explicit map_scene.visibility'
            if reason:
                issues.append(dict(code='EXECUTION_SCOPE_PREVIEW_UNAVAILABLE',
                    path=f"scenes[{scene['scene_id']}]", message='EXECUTION_SCOPE_PREVIEW_UNAVAILABLE: '+reason))
        return issues
    code = 'EXECUTION_SCOPE_PREVIEW_UNAVAILABLE' if preview else 'EXECUTION_SCOPE_DEVICE_UNAVAILABLE'
    return [dict(code=code, path=f"scenes[{s['scene_id']}].machine_logic.execution_scopes",
        message=code+(': negotiate scope_host version 1 for supported preview; legacy clients cannot ignore input/audio ownership.'
                      if preview else ': scoped device execution is not connected.'))
        for s in bundle.scenes if 'execution_scopes' in s.get('machine_logic', {})]


def require_execution_ready(bundle, *, preview=False, scope_host=False):
    issues = readiness_issues(bundle, preview=preview, scope_host=scope_host)
    if issues:
        from .compiler import EggCompileError
        raise EggCompileError(issues[0]['message'])


def attach_preview_sources(package, bundle):
    """In-memory host metadata only; never encoded into a device egg."""
    sources = {s['scene_id']: s for s in bundle.scenes
               if 'execution_scopes' in s.get('machine_logic', {}) or 'menu_component' in s or 'inventory' in bundle.project}
    for scene in package.scenes:
        if scene['scene_id'] in sources:
            scene['_scope_source'] = deepcopy(sources[scene['scene_id']])
            if 'inventory' in bundle.project:
                scene['_scope_source']['_inventory_catalog'] = deepcopy(bundle.project['inventory'])
                from .inventory_conditions import restore_host
                restore_host(scene, sources[scene['scene_id']])
    return package


def lifecycle_proof_scene(project, scene):
    """Validate source first; reserve inert slots for host-owned lifecycle work.

    Shared-behavior structural admission and map preview use the same projection.
    This is never a device-export grant or a rewrite of saved source.
    """
    from .behavior_response import lower_scene
    scene = lower_scene(scene)
    routes = scene.get('machine_logic', {}).get('routes', [])
    actions = {r['route_id']: deepcopy(r['actions']) for r in routes
               if any(a['kind'] in ('menu.open', 'menu.close') for a in r.get('actions', []))}
    if not actions:
        return scene, actions
    from .scene_machines import validate
    validate(project, scene)
    proof = deepcopy(scene)
    for route in proof['machine_logic']['routes']:
        if route['route_id'] in actions:
            route['actions'] = [dict(kind='request_render')]
    return proof, actions
