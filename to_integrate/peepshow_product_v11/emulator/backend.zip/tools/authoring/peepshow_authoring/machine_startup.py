"""Opt-in machine participation; projection is private and never saved."""
from copy import deepcopy
from dataclasses import replace

VERSION = 'machine_startup_v1'
COMMAND = 'scene.machine.set_entry'


def enabled(value):
    project = value.project if hasattr(value, 'project') else value
    return project.get('execution_semantics') in (VERSION, 'terminal_order_v1')


def starter(scene):
    from .authoring_foundation import graph
    scene['entry_state'] = None
    scene['states'] = [dict(state_id='start', display_name='Start', object_overrides=[])]
    graph(scene)['machines'] = [dict(machine_id='main', display_name='Main',
        states=['start'], entry_state='start', variable_writes=[], object_writes=[])]


def set_entry(scenes, command):
    from .project import _command_scene, ProjectCommandError
    scene = _command_scene(scenes, command['scene_id'])
    machine = next((m for m in scene.get('machine_logic', {}).get('machines', [])
                    if m['machine_id'] == command['machine_id']), None)
    if machine is None:
        raise ProjectCommandError('COMMAND_TARGET_UNKNOWN', 'Unknown machine')
    state = command['state_id']
    if state is not None and (state not in machine['states'] or
                             state not in {s['state_id'] for s in scene['states']}):
        raise ProjectCommandError('MACHINE_ENTRY_INVALID', 'Initial State must belong to this machine and exist')
    machine['entry_state'] = state
    return deepcopy(command)


def report(bundle):
    if not enabled(bundle) or not bundle.valid:
        return None
    return {s['scene_id']: dict(scene_entry_state_used=False, machines=[dict(
        machine_id=m['machine_id'], initial_state=m['entry_state'],
        participation='inactive' if m['entry_state'] is None else 'connected')
        for m in s.get('machine_logic', {}).get('machines', [])]) for s in bundle.scenes}


def prepare(bundle):
    """Exclude disconnected owners and their subscriptions, retaining source intact.

    Other Scenes and all owned States of connected machines still undergo strict
    admission. This is not general Scene/branch reachability or Draft Run.
    """
    from .project import ValidationIssue
    scenes = deepcopy(bundle.scenes)
    issues = list(bundle.issues)
    def problem(path, message, code='MACHINE_PARTICIPATION_INVALID'):
        issues.append(ValidationIssue(code, path, message))
    for scene in scenes:
        path = f"scenes[{scene['scene_id']}]"
        if scene['entry_state'] is not None:
            problem(path+'.entry_state', 'This contract uses machine initial States; Scene entry_state must be null')
        graph = scene.get('machine_logic', {})
        machines = graph.get('machines', [])
        active = [m for m in machines if m['entry_state'] is not None]
        inactive = {m['machine_id'] for m in machines if m['entry_state'] is None}
        states = {s['state_id'] for s in scene['states']}
        owners = {}
        for i, m in enumerate(machines):
            if m['entry_state'] is None:
                continue
            if m['entry_state'] not in m['states'] or m['entry_state'] not in states:
                problem(path+f'.machine_logic.machines[{i}].entry_state', 'Connect an existing State owned by this machine')
            for state in m['states']:
                if state in owners:
                    problem(path+f'.machine_logic.machines[{i}].states', 'Connected machines cannot share State membership')
                owners[state] = m['machine_id']
        if not active:
            problem(path+'.machine_logic.machines', 'Connect at least one machine initial State before Run')
        # Find references from retained logic before removing anything, for original paths.
        def check(value, where):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key in ('layout', 'editor'):
                        continue
                    if key in ('machine_ref', 'position_writer') and isinstance(child, str) and child in inactive:
                        problem(where+'.'+key, 'Active logic references inactive machine '+child,
                                'MACHINE_TARGET_INACTIVE')
                    else:
                        check(child, where+'.'+key)
            elif isinstance(value, list):
                for i, child in enumerate(value):
                    check(child, where+f'[{i}]')
        routes = graph.get('routes', [])
        removed_timers = {ref for ref, owner in graph.get('timer_receivers', {}).items() if owner in inactive}
        disabled_inputs = {ref for ref, owner in graph.get('input_receivers', {}).items() if owner in inactive}
        kept = []
        for i, route in enumerate(routes):
            if route.get('machine_ref') in inactive:
                continue
            if route.get('event_ref') in removed_timers | disabled_inputs:
                problem(path+f'.machine_logic.routes[{i}].event_ref',
                        'Active handler depends on an inactive machine subscription')
            check(route, path+f'.machine_logic.routes[{i}]')
            kept.append(route)
        # Only flows called by participating handlers need admission. Typed nested
        # calls are retained transitively; legacy nested calls remain invalid.
        wanted = set()
        def calls(value):
            if isinstance(value, dict):
                if value.get('kind') == 'run_flowchart' or (value.get('kind') == 'call' and bundle.project.get('execution_semantics') == 'terminal_order_v1'):
                    wanted.add(value.get('flowchart_ref'))
                for child in value.values(): calls(child)
            elif isinstance(value, list):
                for child in value: calls(child)
        calls(kept)
        flows = graph.get('flowcharts', [])
        for _ in range(len(flows)):
            previous = set(wanted)
            for flow in flows:
                if flow['flowchart_id'] in wanted:
                    calls(flow)
            if wanted == previous:
                break
        for i, flow in enumerate(flows):
            if flow['flowchart_id'] in wanted:
                check(flow, path+f'.machine_logic.flowcharts[{i}]')
        for key, value in graph.items():
            if key not in ('machines', 'routes', 'flowcharts', 'input_receivers', 'timer_receivers', 'layout'):
                check(value, path+'.machine_logic.'+key)
        for key, value in scene.items():
            if key not in ('machine_logic', 'states', 'layout', 'editor'):
                check(value, path+'.'+key)
        for i, state in enumerate(scene['states']):
            if state['state_id'] in owners:
                check(state, path+f'.states[{i}]')
        graph['machines'] = active
        graph['routes'] = kept
        if 'flowcharts' in graph:
            graph['flowcharts'] = [f for f in flows if f['flowchart_id'] in wanted]
        graph['input_receivers'] = {ref: owner for ref, owner in graph.get('input_receivers', {}).items() if owner not in inactive}
        # Only explicitly disconnected subscriptions are disabled. Missing receivers
        # on other authored inputs remain errors through ordinary validation.
        scene['input_actions'] = [a for a in scene['input_actions'] if a['action_id'] not in disabled_inputs]
        graph['timer_receivers'] = {ref: owner for ref, owner in graph.get('timer_receivers', {}).items() if owner not in inactive}
        scene['event_bindings'] = [b for b in scene.get('event_bindings', []) if b['binding_id'] not in removed_timers]
        for policy in ('reactive_wait_default', 'interaction_policy'):
            if 'event_interests' in scene.get(policy, {}):
                scene[policy]['event_interests'] = [r for r in scene[policy]['event_interests'] if r not in disabled_inputs | removed_timers]
            if 'meaningful_activity_actions' in scene.get(policy, {}):
                scene[policy]['meaningful_activity_actions'] = [r for r in scene[policy]['meaningful_activity_actions'] if r not in disabled_inputs]
        scene['states'] = [s for s in scene['states'] if s['state_id'] in owners]
    return replace(bundle, scenes=tuple(scenes), issues=tuple(issues))


def authored_paths(original, projected, issues):
    """Translate filtered list offsets back to authored offsets in diagnostics."""
    import re
    pairs = [('states', 'state_id'), ('input_actions', 'action_id'),
             ('event_bindings', 'binding_id'), ('machine_logic.machines', 'machine_id'),
             ('machine_logic.routes', 'route_id'), ('machine_logic.flowcharts', 'flowchart_id')]
    replacements = {}
    for scene in projected.scenes:
        source = next(s for s in original.scenes if s['scene_id'] == scene['scene_id'])
        for path, identity in pairs:
            old, new = source, scene
            for key in path.split('.'):
                old = old.get(key, {}) if isinstance(old, dict) else {}
                new = new.get(key, {}) if isinstance(new, dict) else {}
            if not isinstance(old, list) or not isinstance(new, list):
                continue
            offsets = {item[identity]: i for i, item in enumerate(old)}
            for i, item in enumerate(new):
                if item[identity] in offsets:
                    prefix = f"scenes[{scene['scene_id']}].{path}"
                    replacements[f'{prefix}[{i}]'] = f'{prefix}[{offsets[item[identity]]}]'
    if not replacements:
        return issues
    pattern = re.compile('|'.join(re.escape(k) for k in sorted(replacements, key=len, reverse=True)))
    return [replace(i, path=pattern.sub(lambda m: replacements[m.group()], i.path)) for i in issues]
