"""Host-only ordered response programs on the existing bounded transaction executor."""
from copy import deepcopy

VERSION = 'terminal_order_v1'


def enabled(value):
    project = value.project if hasattr(value, 'project') else value
    return project.get('execution_semantics') == VERSION


def lower_scene(scene, project):
    """Compile individual nodes, never hoist decisions across their preceding actions.

    The generated routes provide existing validation/operation compilation only.
    They are not events that authors send or handlers the queue dispatches.
    """
    from .actor_output_response import lower
    result, origins = lower(scene)
    result = deepcopy(result)
    graph = result.get('machine_logic', {})
    result, programs = lower_graph(result, graph)
    for identity, origin in origins.items():
        programs[identity]['origin'] = origin
    return result, programs


def lower_graph(result, graph):
    """Retain authored node identities while compiling each operation separately."""
    from .response_conditions import is_condition, GUARD_KIND
    scene = result
    validate_destinations(graph)
    strings = set()
    def collect(value):
        if isinstance(value,str): strings.add(value)
        elif isinstance(value,dict):
            for child in value.values(): collect(child)
        elif isinstance(value,list):
            for child in value: collect(child)
    collect(scene)
    sequence = 0
    def identity():
        nonlocal sequence
        while True:
            sequence += 1
            value = f'terminal.private.{sequence}'
            if value not in strings:
                strings.add(value)
                return value
    programs, routes = {}, []
    event = None
    for route in graph.get('routes', []):
        if 'response' not in route:
            routes.append(route)
            continue
        if event is None:
            event = identity()
            graph['events'].append(dict(event_id=event, display_name='Private response compilation'))
        root = {k: deepcopy(v) for k,v in route.items() if k!='response'}
        root.update(guards=[],actions=[])
        routes.append(root)
        program = deepcopy(route)
        program['compiled_nodes'] = {}
        for node in route['response']['nodes']:
            key = identity()
            compiled = dict(route_id=key, machine_ref=route['machine_ref'], event_ref=event,
                            from_states=deepcopy(route['from_states']),guards=[],actions=[])
            if node['kind']=='actions':
                if any(a['kind'] in ('menu.open','menu.close','exit_to_shell') for a in node['actions']):
                    raise ValueError('TERMINAL_ORDER_LIFECYCLE_UNAVAILABLE: use a dedicated root lifecycle handler')
                compiled['actions'] = deepcopy(node['actions'])
                # Full-path proof was checked above. The private node compiler
                # still requires a local clear guard for its move operands.
                compiled['guards'] = [dict(kind='destination.clear',destination_ref=a['destination_ref'])
                                      for a in node['actions'] if a['kind']=='destination.move']
            elif node['kind']=='decision':
                condition = deepcopy(node['condition'])
                compiled['guards'] = [dict(kind=GUARD_KIND,condition=condition,expected=True)
                                      if is_condition(condition) else condition]
            else:
                compiled.update({k:v for k,v in node.items() if k not in ('kind','node_id')})
            routes.append(compiled)
            program['compiled_nodes'][node['node_id']] = key
        programs[route['route_id']] = program
    graph['routes'] = routes
    return result, programs


def attach(package, bundle):
    """Attach source identity and node maps to private preview packages only."""
    from .authoring_foundation import enabled as incremental, project_for_execution
    debug_calls = []
    source = project_for_execution(bundle, _terminal=False, _debug_calls=debug_calls) if incremental(bundle) else bundle
    programs = {s['scene_id']: lower_scene(s, bundle.project)[1] for s in source.scenes}
    for scene in package.scenes:
        scene['_debug_flow_calls'] = [c for c in debug_calls if c['scene_id']==scene['scene_id']]
        scene['_terminal_order'] = True
        scene['_terminal_programs'] = programs[scene['scene_id']]


def execute(player, program, context):
    from .preview_steps import drain
    return drain(iterate(player, program, context))


def iterate(player, program, context):
    from .preview_steps import checkpoint
    from .flowcharts import charge, execute_actions
    from .response_conditions import matches
    from .inventory_conditions import is_condition, compare
    from .preview import PreviewError
    nodes = {n['node_id']:n for n in program['response']['nodes']}
    compiled_indexes = {r['route_id']:i for i,r in enumerate(player._machines['routes'])}
    current = program['response']['root']
    sends, audio, visited, decisions = [], [], [], []
    trace = dict(route_id=program['route_id'], node_path=visited, decisions=decisions)
    if 'origin' in program:
        trace['origin'] = deepcopy(program['origin'])
        trace['route_id'] = program['origin']['route_id']
    player._terminal_response_trace = trace
    call_prefix = []
    while True:
        charge(player)
        if current in visited or len(visited)>=32:
            raise PreviewError('response cycle or node budget')
        visited.append(current)
        node = nodes[current]
        parts = current.split('/')[:-1]
        if parts != call_prefix:
            common = 0
            while common < min(len(parts), len(call_prefix)) and parts[common] == call_prefix[common]:
                common += 1
            for depth in range(common//2*2, len(parts)-1, 2):
                yield checkpoint(player, 'call', route_id=trace['route_id'],
                    node_id='/'.join(parts[:depth+1]), flowchart_ref=parts[depth+1])
            call_prefix = parts
        ri = compiled_indexes[program['compiled_nodes'][current]]
        source = player._machines['routes'][ri]
        compiled = player._machine_compiled[f'machine.{ri}.0']
        if node['kind']=='return':
            yield checkpoint(player, 'terminal', route_id=trace['route_id'], node_id=current, terminal=deepcopy(node))
            trace['terminal'] = current
            outcome = dict(actions=[], **{k:v for k,v in node.items() if k not in ('node_id','kind')})
            return outcome, {**compiled, 'operations':()}, sends, audio, trace
        if node['kind']=='actions':
            if not node['actions']:
                yield checkpoint(player, 'flow_return' if '/' in current and not node['next'].startswith(current.rsplit('/',1)[0]+'/') else 'actions', route_id=trace['route_id'], node_id=current)
            action_index = 0
            def observe():
                nonlocal action_index
                mark = checkpoint(player, 'action', route_id=trace['route_id'], node_id=current,
                    action_index=action_index, action=deepcopy(node['actions'][action_index]))
                from .preview_steps import action_operands
                mark['operands_before']=action_operands(player,mark['action'])
                action_index += 1
                return mark
            if player._world_context is not None:
                yield from player._world_context.iterate_execute(player, source, 0, compiled, context, sends, audio, observe)
            else:
                for ai, action in enumerate(source['actions']):
                    mark = observe()
                    yield mark
                    execute_actions(player, [action], {**compiled, 'operations': (compiled['operations'][ai],)}, context, sends, audio)
                    from .preview_steps import complete_action
                    complete_action(mark)
            current = node['next']
        else:
            mark = checkpoint(player, 'decision', route_id=trace['route_id'], node_id=current, condition=deepcopy(node['condition']))
            yield mark
            operands = mark.setdefault('decision_operands', [])
            passed = (all(player._guard_passes(g, evidence=operands) for g in compiled['guards']) and
                      all(compare(g,player._inventory_state['counts'], evidence=operands) for g in source['guards'] if is_condition(g)) and
                      matches(player,source['guards'], evidence=operands) and
                      (player._world_context is None or player._world_context.matches(source['route_id'], evidence=mark.setdefault('world_operands', []))))
            port = 'when_true' if passed else 'when_false'
            mark.update(result=passed, selected_port=port)
            decisions.append(dict(node_id=current,port=port,result=passed))
            current = node[port]['next']


def proof_bundle(bundle):
    """Validate full paths before node compilation can hide cross-node edges."""
    from dataclasses import replace
    from .actor_output_response import lower
    scenes = []
    for scene in bundle.scenes:
        scene, _ = lower(scene)
        holder = dict(behavior_id=scene['scene_id'], states=scene['states'], machine_logic=scene.get('machine_logic', {}))
        scene = dict(scene, machine_logic=path_proof(holder, 3, ordinary=True)['machine_logic'])
        instances = scene['machine_logic'].get('instance_behaviors')
        if instances:
            instances['behaviors'] = [path_proof(b, instances['version']) for b in instances['behaviors']]
        scenes.append(scene)
    return replace(bundle, scenes=tuple(scenes), project=dict(bundle.project, execution_semantics='machine_startup_v1'))


def path_proof(holder, version, *, ordinary=False):
    from .behavior_response import lower_behavior
    generated = {r['route_id'] for r in holder['machine_logic']['routes'] if 'response' in r}
    mapping = {}
    proof = lower_behavior(holder, version, ordinary=ordinary, terminal_order=True, source_map=mapping)
    validate_destinations(holder['machine_logic'])
    # A flattened path cannot express a check AFTER a position write. Its move
    # proof is performed in diagram order above, and its type/writer/operand
    # checks are performed by the guarded private node compiler. Retain all
    # other effects here for whole-chain event and ownership admission.
    for route in proof['machine_logic']['routes']:
        if mapping.get(route['route_id'], {}).get('route_id') in generated:
            route['actions'] = [a for a in route['actions'] if a['kind']!='destination.move']
    return proof


def validate_destinations(graph):
    """Clear proofs are response-local and invalidated by writes or flow calls.

    Conservative across world/property writes: authors can recheck after a
    write. Queued sends do not run until after this response's terminal.
    """
    for route in graph.get('routes', []):
        if 'response' not in route:
            continue
        response = route['response']
        nodes = {n['node_id']:n for n in response['nodes']}
        pending = [(response['root'], frozenset(), frozenset())]
        work = 0
        while pending:
            current, proven, visited = pending.pop()
            work += 1
            if current in visited or work > 1024:
                raise ValueError('response destination proof exceeds bounded acyclic paths')
            node = nodes[current]; visited = visited | {current}
            if node['kind']=='actions':
                proven = set(proven)
                for action in node['actions']:
                    kind = action['kind']
                    if kind=='destination.move':
                        if action['destination_ref'] not in proven:
                            raise ValueError(f"routes[{route['route_id']}].response.nodes[{current}]: move requires a clear check after the last world/property/facing write or flow call")
                        proven.clear()
                    elif kind=='run_flowchart' or kind.startswith(('world.', 'property.', 'facing.')):
                        proven.clear()
                pending.append((node['next'], frozenset(proven), visited))
            elif node['kind']=='decision':
                condition = node['condition']
                for port in ('when_true','when_false'):
                    next_proven = proven
                    if (condition.get('kind')=='destination.clear' and port=='when_true' or
                            condition.get('kind')=='destination.blocked' and port=='when_false'):
                        next_proven = proven | {condition['destination_ref']}
                    pending.append((node[port]['next'], next_proven, visited))
