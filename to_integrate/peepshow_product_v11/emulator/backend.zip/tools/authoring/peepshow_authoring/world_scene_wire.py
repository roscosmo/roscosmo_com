"""Private map-associated Scene graph envelope; not installed export admission."""
import struct

from .machine_wire import require
from .world_operands_wire import decode_operands, decode_typed_operands

HEADER = struct.Struct('<4sHHIIIHHQII')
POSITION = struct.Struct('<IIii')


def compile_graph(logic, presentation, operands, positions, *, map_id, package_ids=(),
                  instance_metadata=None, terrain_actors=None, terrain_id=None, _execution_scopes=False):
    """Associate already-lowered records. Parent still validates Scene/map semantics."""
    require(type(map_id) is int and 0 < map_id < 2**64, 'map chunk identity required')
    require(type(logic) is bytes and len(logic) >= 24 and logic[:4] == b'SMW1' and
            struct.unpack_from('<I', logic, 8)[0] == len(logic), 'private world logic required')
    require(type(presentation) is bytes and len(presentation) >= 24 and presentation[:4] == b'MPR1' and
            struct.unpack_from('<I', presentation, 8)[0] == len(presentation), 'presentation required')
    require(type(operands) is bytes, 'world operand bytes required')
    require((struct.unpack_from('<H', presentation, 4)[0] in (14, 15)) == bool(_execution_scopes),
            'scoped presentation requires the explicit scoped map envelope')
    require(int.from_bytes(operands[4:8], 'little') != 6,
            'EXPLICIT_DESTINATION_DEVICE_UNAVAILABLE: explicit cells are host-only; firmware Scene encoding is not connected')
    require(int.from_bytes(operands[4:8], 'little') != 5,
            'FACING_DESTINATION_DEVICE_UNAVAILABLE: facing destinations are host-only; firmware Scene encoding is not connected')
    (decode_typed_operands if terrain_actors is not None and terrain_id is not None else
     decode_operands)(operands, logic[16], logic[23])
    require(isinstance(package_ids, (list, tuple)) and len(package_ids) <= 32 and
            all(type(v) is int and 0 <= v < 65536 for v in package_ids) and
            len(set(package_ids)) == len(package_ids), 'unique package string IDs required')
    require(isinstance(positions, (list, tuple)), 'position records required')
    last = -1
    rows = bytearray()
    for row in positions:
        require(isinstance(row, (list, tuple)) and len(row) == 4 and
                all(type(v) is int for v in row), 'invalid position record')
        obj, entity, x, y = row
        require(last < obj < 2**32 and 0 <= entity < 2**32 and
                -2**31 <= x < 2**31 and -2**31 <= y < 2**31,
                'positions require ordered objects and signed offsets')
        rows.extend(POSITION.pack(obj, entity, x, y))
        last = obj
    extension = b''
    version, header_bytes = 1, HEADER.size
    if instance_metadata is not None:
        from .instance_metadata import inspect_metadata, inspect_terrain_metadata
        require(type(instance_metadata) is bytes, 'instance metadata bytes required')
        record = (inspect_terrain_metadata(instance_metadata)
                  if terrain_actors is not None and terrain_id is not None else
                  inspect_metadata(instance_metadata))
        # Identity comes from the enclosing selected Scene and pinned package;
        # matching dimensions alone never authorizes execution.
        require(record.scene_machine_count == logic[16] and record.scene_event_count == logic[19] and
                record.world_binding_count == struct.unpack_from('<I', operands, 12)[0],
                'instance metadata disagrees with enclosing Scene')
        version, header_bytes = 2, HEADER.size + 4
        extension = struct.pack('<I', len(instance_metadata))
    else:
        instance_metadata = b''
    if terrain_actors is not None or terrain_id is not None:
        from .terrain_actors import HEADER as ACTORS_HEADER, RECORD as ACTOR_RECORD, CONDITIONAL_RECORD
        require(version == 2, 'terrain graph requires instance metadata')
        require(type(terrain_id) is int and 0 < terrain_id < 2**64 and terrain_id != map_id,
                'distinct terrain chunk identity required')
        require(type(terrain_actors) is bytes and len(terrain_actors) >= 40,
                'terrain actor bytes required')
        magic, revision, total, count, stride, reserved = ACTORS_HEADER.unpack_from(terrain_actors)
        require(magic == b'TAC1' and total == len(terrain_actors) and
                ((revision == 1 and stride == ACTOR_RECORD.size) or
                 (revision == 2 and stride == CONDITIONAL_RECORD.size)) and
                count > 0 and reserved == 0 and
                ACTORS_HEADER.size + count * stride == total, 'invalid terrain actor envelope')
        # Payload membership/spacing and graph coverage require later admission.
        version, header_bytes = 3, HEADER.size + 16
        extension += struct.pack('<IQ', len(terrain_actors), terrain_id)
    else:
        terrain_actors = b''
    if _execution_scopes:
        from .execution_scope_wire import decode_execution_scopes
        require(version == 3 and len(presentation) >= 32, 'scoped map requires terrain and instance metadata')
        text_bytes, scope_bytes = struct.unpack_from('<II', presentation, 24)
        presentation_header = struct.unpack_from('<H', presentation, 6)[0]
        require(presentation_header == (36 if struct.unpack_from('<H', presentation, 4)[0] == 15 else 32) and
                presentation_header + text_bytes + scope_bytes <= len(presentation),
                'invalid scoped presentation bounds')
        scope_data = presentation[presentation_header + text_bytes:presentation_header + text_bytes + scope_bytes]
        if scope_data[:4] == b'MNC1':
            from .menu_component_wire import component_shape
            scope = component_shape(scope_data)
            instance_count = scope['instance_count']
        else:
            scope = decode_execution_scopes(scope_data)
            instance_count = len(scope['instances'])
        require(instance_count == len(record.instances) and
                scope['machine_count'] == logic[16] and scope['event_count'] == logic[19],
                'scope membership disagrees with enclosing instance Scene')
        version = 4
    size = header_bytes + 2*len(package_ids) + len(logic) + len(presentation) + len(operands) + len(rows) + len(instance_metadata) + len(terrain_actors)
    require(size < 2**32, 'map graph byte capacity exceeded')
    return (HEADER.pack(b'MGW1', version, header_bytes, size, len(logic), len(presentation),
                        len(package_ids), 0, map_id, len(operands), len(positions)) +
            extension + struct.pack(f'<{len(package_ids)}H', *package_ids) +
            logic + presentation + operands + rows + instance_metadata + terrain_actors)
