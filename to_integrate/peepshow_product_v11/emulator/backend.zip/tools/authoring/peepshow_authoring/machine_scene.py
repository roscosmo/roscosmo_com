"""Combined machine scene sections shared by native tests and restricted export."""
from copy import deepcopy
from dataclasses import dataclass
import struct

from .compiler import _string_table, _compile_asset_chunks, LOGICAL_SOURCES, LOGICAL_EVENTS
from .machine_wire import compile_machine_logic, require, NONE
from .object_egg import compile_object_chunks
from .v2_export import LIMITS
from .machine_limits import STATES


@dataclass(frozen=True)
class MachineSceneSections:
    logic: bytes
    presentation: bytes
    objects: bytes
    controls: bytes
    strings: bytes
    assets: bytes
    animations: bytes
    sprites: bytes


def compile_machine_scene(bundle, scene_id, *, sprite_chunk_index, animation_chunk_index,
                          string_table=None, _flowcharts=False, _object_effects=False, _calendars=False, _periodic=False,
                          _text_bindings=(), _selector_encoder=None, _execution_scopes=False, _scope_encoder=None,
                          _component=None, _inventory_items=()):
    """Parent container owns chunk placement, integrity and complete asset admission.

    Sections are deliberately not wrapped in an egg. Public package building
    applies machine_export restrictions around the shared container encoder.
    """
    payload = compile_machine_logic(bundle, scene_id, _flowcharts=_flowcharts, _object_effects=_object_effects,
                                    _calendars=_calendars, _periodic=_periodic, _execution_scopes=_execution_scopes)
    source = next(s for s in bundle.scenes if s["scene_id"] == scene_id)
    scope_bytes = b''
    require(_scope_encoder is None or _execution_scopes, 'scope encoder requires explicit scoped compilation')
    require(_component is None or _execution_scopes and _scope_encoder is None,
            'component requires exclusive scoped compilation')
    if _component is not None:
        from .menu_component_wire import compile_component
        authored, instance_count, expected = _component
        require(authored['scene_id'] == scene_id and authored['objects'] == source['objects'],
                'component source must match the enclosing Scene and object table')
        for field in ('machines', 'states', 'events', 'variables', 'effects'):
            require(getattr(payload, field) == getattr(expected, field),
                    'component and enclosing world logic identities disagree: ' + field)
        scope_bytes = compile_component(bundle.project, authored, states=payload.states,
            instance_count=instance_count, machines=payload.machines, events=payload.events,
            variables=payload.variables, objects=[o['object_id'] for o in source['objects']],
            inventory=_inventory_items, cues=[c['cue_id'] for c in sorted(bundle.audio_cues, key=lambda c:c['cue_id'])])
    elif _execution_scopes:
        from .execution_scope_wire import compile_execution_scopes, decode_execution_scopes
        if _scope_encoder is None:
            require(not source['machine_logic'].get('instance_behaviors', {}).get('instances'),
                    'scoped shared-instance Scene requires its enclosing map encoder')
            scope_bytes = compile_execution_scopes(source, machines=payload.machines,
                events=payload.events, objects=[o['object_id'] for o in source['objects']], instances=())
        else:
            scope_bytes = _scope_encoder(payload)
        decode_execution_scopes(scope_bytes)
    scene = deepcopy(source)
    from .presentation_text_source import scene_bindings, resolved_source
    from .presentation_selectors import variable_definitions
    authored_bindings = scene_bindings(bundle.project, source)
    require(not (_text_bindings and authored_bindings), 'cannot mix private and authored text bindings')
    _text_bindings = authored_bindings or _text_bindings
    text_definitions = variable_definitions(bundle.project, source)
    for obj in scene['objects']:
        if obj['kind'] == 'text':
            obj['text'] = resolved_source(obj, text_definitions)
    graph = scene.pop("machine_logic")
    # Reuse the real object encoder; its operation order is the effect catalog's
    # object-only subsequence. No synthetic timer handlers reach native execution.
    scene["routes"] = [{"route_id": "machine.effects", "actions": [
        e for e in payload.effects if e['kind'] not in ('object.select_visual', 'scene.replace', 'object.play_effect', 'scene.set_inversion', 'object.play_clip', 'object.cancel_clip', 'menu.open', 'menu.close')]}]
    scene["event_handlers"] = []
    _, strings, string_bytes = string_table if string_table is not None else _string_table(bundle, (scene,))
    objects, controls = compile_object_chunks(scene, strings, bundle.frames, bundle.animations)
    assets, sprites, animations = _compile_asset_chunks(bundle, strings, sprite_chunk_index, animation_chunk_index)
    machine_index = {ref: i for i, ref in enumerate(payload.machines)}
    object_index = {o["object_id"]: i for i, o in enumerate(scene["objects"])}
    property_index = {"x": 0, "y": 1, "visual_ref": 2, "visible": 3, "inverted": 4}
    text_bindings = bytearray()
    from .presentation_text_wire import encode_tokens, analyze_tokens
    from .machine_decode import logic as decode_logic
    text_variables = decode_logic(payload.data)['variables'] if _text_bindings else ()
    previous_text_object = -1
    for index, tokens in _text_bindings:
        require(type(index) is int and previous_text_object < index < len(object_index),
                'text bindings require increasing object indices')
        obj = scene['objects'][index]
        require(obj['kind'] == 'text', 'text binding requires a text object')
        analyze_tokens(tokens, text_variables,
            style=obj.get('scale', 1) - 1 + 8 * ('left', 'center', 'right').index(obj.get('alignment', 'left')),
            width=obj['width'], height=obj['height'])
        record = encode_tokens(tokens)
        text_bindings.extend(struct.pack('<HH', index, len(record)) + record)
        previous_text_object = index
    if _component is not None:
        from .inventory_wire import compile_quantity_bindings, merge_text_bindings
        quantities = compile_quantity_bindings(bundle.project, authored, items=_inventory_items,
                                                objects=tuple(object_index))
        text_bindings = merge_text_bindings(bytes(text_bindings), quantities, len(object_index))
    object_polarity = bool(scope_bytes) or bool(text_bindings) or objects[4:6] == b'\x02\x00' or any(
        'inverted' in declaration['properties'] for owner in [*graph['machines'], *graph.get('flowcharts', [])]
        for declaration in owner['object_writes'])
    writer_count = 5 if object_polarity else 4
    require(len(object_index) <= LIMITS["objects"] and len(payload.states) <= STATES, "presentation capacity exceeded")
    writers = bytearray([NONE] * (len(object_index) * writer_count))
    for machine in graph["machines"]:
        for declaration in machine["object_writes"]:
            for prop in declaration["properties"]:
                writers[writer_count * object_index[declaration["object_ref"]] + property_index[prop]] = machine_index[machine["machine_id"]]
    for fi, chart in enumerate(graph.get('flowcharts', [])):
        for declaration in chart['object_writes']:
            for prop in declaration['properties']:
                writers[writer_count * object_index[declaration['object_ref']] + property_index[prop]] = 128 + fi
    cues = {c["cue_id"]: i for i, c in enumerate(sorted(bundle.audio_cues, key=lambda c: c["cue_id"]))}
    effects, operation, visuals, transients = bytearray(), 0, bytearray(), bytearray()
    one_shots = bytearray()
    frames = {f.frame_id: i for i, f in enumerate(sorted(bundle.frames, key=lambda f: (f.asset_id, f.frame_id)))}
    clips = {c['animation_id']: (i, c) for i, c in enumerate(sorted(bundle.animations, key=lambda c: c['animation_id']))}
    for effect in payload.effects:
        if effect['kind'] == 'menu.open':
            kind, ref = 10, int(effect.get('hide_world', True))
        elif effect['kind'] == 'menu.close':
            kind, ref = 11, int(effect['disposition'] == 'confirm')
        elif effect['kind'] == 'scene.set_inversion':
            kind, ref = 7, {'normal': 0, 'inverted': 1, 'toggle': 2}[effect['mode']]
        elif effect['kind'] == 'object.cancel_clip':
            kind, ref = 9, object_index[effect['object_ref']]
        elif effect['kind'] == 'object.play_clip':
            kind, ref = 8, len(one_shots) // 12
            obj = object_index[effect['object_ref']]
            completion = effect.get('completion')
            one_shots.extend(struct.pack('<HBBH6B', obj, writers[obj * writer_count + 2],
                int(effect['end_policy'] == 'hold_last'), clips[effect['animation_ref']][0],
                int(completion is not None), machine_index[completion['machine_ref']] if completion else 0,
                payload.events.index(completion['event_ref']) if completion else 0, 0, 0, 0))
        elif effect['kind'] == 'object.select_visual':
            kind, ref = 4, len(visuals) // 6
            clip, frame = 65535, effect.get('visual_ref')
            if 'animation_ref' in effect:
                clip, record = clips[effect['animation_ref']]
                frame = record['frame_refs'][0]
            visuals.extend(struct.pack('<HHH', object_index[effect['object_ref']], frames[frame], clip))
        elif effect['kind'] == 'object.play_effect':
            kind, ref = 6, len(transients) // 20
            owner = next(machine_index[m['machine_id']] for m in graph['machines']
                         if effect['object_ref'] in m.get('effect_writes', []))
            completion = effect.get('completion')
            transients.extend(struct.pack('<HBBIIHBBB3x', object_index[effect['object_ref']], owner,
                {'invert': 1, 'shake': 2}[effect['effect']], effect['duration_ms'], effect['step_ms'],
                effect.get('amplitude', 0), int(completion is not None),
                machine_index[completion['machine_ref']] if completion else 0,
                payload.events.index(completion['event_ref']) if completion else 0))
        elif effect["kind"].startswith("object."):
            kind, ref = 1, operation
            operation += 1
        elif effect["kind"] == "play_sfx":
            kind, ref = 2, cues[effect["cue_ref"]]
        elif effect['kind'] == 'scene.replace':
            kind, ref = 5, effect['scene_id']
        else:
            require(effect["kind"] == "request_render", "unsupported presentation effect")
            kind, ref = 3, 0
        effects.extend(struct.pack("<HH", kind, ref))
    inputs = bytearray()
    for action in source["input_actions"]:
        ref = action["action_id"]
        inputs.extend(bytes((LOGICAL_SOURCES[action["logical_source"]], LOGICAL_EVENTS[action.get("event_kind", "press")],
                            machine_index[graph["input_receivers"][ref]], payload.events.index(ref))))
    package_slots = {v["variable_id"]: i for i, v in enumerate(bundle.project.get("package_variables", []))}
    variables = b"".join(struct.pack("<BBH", int(scope == "package"), 0,
        package_slots[ref] if scope == "package" else 65535) for scope, ref in payload.variables)
    primary = next(machine_index[m["machine_id"]] for m in graph["machines"] if source["entry_state"] in m["states"])
    body = writers + effects + inputs + variables
    from .presentation_selectors import compile_selectors
    # Private world containers supply their already-resolved predicate encoder.
    # Assemble its result here so clip/retention/text trailers remain owned by
    # this encoder rather than being located and patched by container builders.
    selectors = (compile_selectors(bundle, source) if _selector_encoder is None
                 else _selector_encoder(scene_id))
    require(isinstance(selectors, bytes) and len(selectors) <= 65535,
            'invalid private presentation selector span')
    activation = graph.get('scene_activated')
    retain_mask = sum(1 << i for i, m in enumerate(graph['machines']) if m.get('retain_state', False))
    trailer = bytes((machine_index[activation['machine_ref']], payload.events.index(activation['event_ref']))) if activation else b''
    replacement = any(e['kind'] == 'scene.replace' for e in payload.effects)
    if retain_mask or replacement:
        trailer = bytes((retain_mask & 255,)) + (trailer or bytes((NONE, NONE)))
    if transients:
        trailer = transients + bytes((len(transients) // 20, retain_mask & 255,
            machine_index[activation['machine_ref']] if activation else NONE,
            payload.events.index(activation['event_ref']) if activation else NONE))
    calendars = bytearray()
    for binding in source.get('event_bindings', []):
        if binding['event_type'] != 'time.local_schedule':
            continue
        config = binding['configuration']
        receiver = graph['timer_receivers'][binding['binding_id']]
        require(receiver in machine_index, 'calendar requires an addressed machine')
        mode = {'daily': 1, 'today_offset': 2, 'next_occurrence': 3, 'next_weekday': 4, 'weekly': 5}.get(config['mode'])
        require(mode is not None, 'calendar source mode not admitted by this encoder')
        from .calendar_schedule import valid_configuration
        require(valid_configuration(config, expanded=True), 'invalid calendar configuration')
        argument = (config['weekday'] if mode == 4 else sum(1 << (d - 1) for d in config['weekdays'])
                    if mode == 5 else config.get('day_offset', 0))
        calendars.extend(struct.pack('<III2B2x', mode, config['time_of_day_seconds'],
            argument, machine_index[receiver], payload.events.index(binding['binding_id'])))
    polarity = any(e['kind'] == 'scene.set_inversion' for e in payload.effects)
    from .flowcharts import uses_local_time
    local_time = uses_local_time(source)
    reconcile = graph.get('time_reconcile')
    finite = any(e['kind'] in ('object.play_clip', 'object.cancel_clip') for e in payload.effects)
    wide_retention = retain_mask > 255
    if calendars or polarity or local_time or finite or wide_retention or object_polarity:
        clip_footer = bytes((len(one_shots) // 12, int(local_time), retain_mask >> 8, 0)) if finite or wide_retention or object_polarity else b''
        trailer = transients + calendars + one_shots + clip_footer + bytes((len(calendars) // 16, int(reconcile is not None),
            machine_index[reconcile['machine_ref']] if reconcile else 0,
            payload.events.index(reconcile['event_ref']) if reconcile else 0,
            len(transients) // 20, retain_mask & 255,
            machine_index[activation['machine_ref']] if activation else NONE,
            payload.events.index(activation['event_ref']) if activation else NONE))
    metadata = struct.pack("<4sHHI8BHH", b"MPR1", 12 if object_polarity else 11 if wide_retention else 10 if finite else 9 if local_time else 8 if polarity else 7 if calendars else 6 if transients else 5 if retain_mask or replacement else 4 if activation else 3 if graph.get('flowcharts') else 2 if selectors else 1, 24, 24 + len(body) + len(selectors) + len(visuals) + len(trailer), primary,
        len(object_index), len(payload.effects), len(source["input_actions"]), len(payload.variables),
        len(package_slots), len(selectors) & 255, len(selectors) >> 8, len(cues), len(visuals) // 6) + body + visuals + selectors + trailer
    if scope_bytes:
        metadata = bytearray(metadata[:24] + struct.pack('<II', len(text_bindings), len(scope_bytes))
                             + text_bindings + scope_bytes + metadata[24:])
        struct.pack_into('<HHI', metadata, 4, 14, 32, len(metadata))
        metadata = bytes(metadata)
    elif text_bindings:
        metadata = bytearray(metadata[:24] + struct.pack('<I', len(text_bindings)) + text_bindings + metadata[24:])
        struct.pack_into('<HHI', metadata, 4, 13, 28, len(metadata))
        metadata = bytes(metadata)
    if _component is not None:
        from .inventory_wire import compile_catalog, attach_catalog
        ordered_strings = tuple(ref for ref, index in sorted(strings.items(), key=lambda row:row[1]))
        require(sorted(strings.values()) == list(range(len(strings))),
                'inventory requires the exact contiguous package string table')
        metadata = attach_catalog(metadata, compile_catalog(bundle.project, items=_inventory_items,
            strings=ordered_strings, scene=authored, objects=tuple(object_index)))
    return MachineSceneSections(payload.data, metadata, objects, controls, string_bytes, assets, animations, sprites)
