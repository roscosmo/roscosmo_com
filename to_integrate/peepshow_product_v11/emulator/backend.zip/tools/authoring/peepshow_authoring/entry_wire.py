"""STG8 bounded scoped-variable and fresh-entry wire extension."""
import struct
from .egg_format import _require
from .v2_export import LIMITS

HEADER = struct.Struct("<4s6H")
VARIABLE = struct.Struct("<BBHiii")
INSTRUCTION = struct.Struct("<BBHiHHI")
NONE = 65535
MAX_INSTRUCTIONS = LIMITS["entry_instructions"]
MAX_CUES = LIMITS["entry_sfx"]


def compile_entry(project, scene, cues):
    from .scene_entry import validate
    validate(project, scene, set(cues))
    declarations = [(scope, record) for scope, records in (
        (0, scene["variables"]), (1, project.get("package_variables", []))) for record in records]
    _require(len(declarations) <= LIMITS["variables"], "STG8 HW6 limit is eight combined scene/package variables")
    indexes = {("package" if scope else "scene", record["variable_id"]): i
               for i, (scope, record) in enumerate(declarations)}
    states = {s["state_id"]: i for i, s in enumerate(scene["states"])}
    graph = scene.get("entry_graph", {"root": "entry", "nodes": [
        {"node_id": "entry", "kind": "state", "state_ref": scene["entry_state"]}]})
    nodes = {n["node_id"]: n for n in graph["nodes"]}
    edges = {key: ([n["next"]] if n["kind"] == "actions" else
        [b["next"] for b in n["branches"]] + [n["default"]] if n["kind"] == "decision" else [])
        for key, n in nodes.items()}
    degrees = {key: 0 for key in nodes}
    for targets in edges.values():
        for target in targets:
            degrees[target] += 1
    pending = [graph["root"]]
    order = []
    while pending:
        key = pending.pop(0)
        order.append(key)
        for target in edges[key]:
            degrees[target] -= 1
            if degrees[target] == 0:
                pending.append(target)
    records, labels = [], {}
    compares = {"eq": 1, "ne": 2, "lt": 3, "le": 4, "gt": 5, "ge": 6}
    for key in order:
        node = nodes[key]
        labels[key] = len(records)
        if node["kind"] == "state":
            records.append([0, 0, states[node["state_ref"]], 0, NONE, NONE, 0])
        elif node["kind"] == "actions":
            for action in node["actions"]:
                if action["kind"] == "play_sfx":
                    kind, ref, value = 3, cues[action["cue_ref"]], 0
                else:
                    ref = indexes[(action.get("variable_scope", "scene"), action["variable_ref"])]
                    kind = 2 if action["operation"] == "add" else 1
                    value = declarations[ref][1]["initial"] if action["operation"] == "reset" else action["value"]
                records.append([kind, 0, ref, int(value), len(records) + 1, NONE, 0])
            if not node["actions"]:
                records.append([5, 0, 0, 0, node["next"], NONE, 0])
            records[-1][4] = node["next"]
        else:
            for branch_index, branch in enumerate(node["branches"]):
                failed = len(records) + len(branch["guards"]) if branch_index + 1 < len(node["branches"]) else node["default"]
                for index, guard in enumerate(branch["guards"]):
                    ref = indexes[(guard.get("variable_scope", "scene"), guard["variable_ref"])]
                    passed = len(records) + 1 if index + 1 < len(branch["guards"]) else branch["next"]
                    records.append([4, compares[guard["operator"]], ref, int(guard["value"]), passed, failed, 0])
    _require(0 < len(records) <= MAX_INSTRUCTIONS, "STG8 lowered instruction budget exceeded")
    variables, slot = bytearray(), 0
    for scope, record in declarations:
        variables.extend(VARIABLE.pack(scope, int(record["value_type"] == "bool"), slot if scope else NONE,
            int(record["initial"]), record.get("minimum", 0), record.get("maximum", 1)))
        slot += scope
    for record in records:
        for index in (4, 5):
            if isinstance(record[index], str):
                record[index] = labels[record[index]]
    payload = HEADER.pack(b"ENT1", 1, 16, len(declarations), len(records), 0, 0) + variables + b"".join(INSTRUCTION.pack(*r) for r in records)
    decode_entry(payload, len(declarations), len(states), len(cues))
    return payload


def decode_entry(payload, variable_count, state_count, cue_count):
    _require(len(payload) >= HEADER.size, "entry extension truncated")
    magic, version, size, variables, count, root, reserved = HEADER.unpack_from(payload)
    _require((magic, version, size, variables, root, reserved) == (b"ENT1", 1, 16, variable_count, 0, 0)
             and variables <= 32 and 0 < count <= MAX_INSTRUCTIONS
             and len(payload) == 16 + variables * 16 + count * 16, "entry extension header/size invalid")
    definitions, packages = [], 0
    for i in range(variables):
        scope, boolean, slot, initial, minimum, maximum = VARIABLE.unpack_from(payload, 16 + i * 16)
        _require(scope in (0, 1) and boolean in (0, 1) and minimum <= initial <= maximum
                 and (not boolean or (minimum, maximum) == (0, 1))
                 and (slot == packages if scope else slot == NONE and packages == 0), "entry variable metadata invalid")
        definitions.append(dict(scope=scope, boolean=boolean, slot=slot, initial=initial, minimum=minimum, maximum=maximum))
        packages += scope
    records = [INSTRUCTION.unpack_from(payload, 16 + variables * 16 + i * 16) for i in range(count)]
    reached = {0}
    for i, (kind, code, ref, value, next_, other, reserved) in enumerate(records):
        _require(i in reached and kind in range(6) and reserved == 0, "entry instruction invalid/unreachable")
        if kind == 0:
            _require(ref < state_count and (code, value, next_, other) == (0, 0, NONE, NONE), "entry state invalid")
            continue
        _require(i < next_ < count, "entry edge must be forward")
        reached.add(next_)
        if kind == 4:
            _require(i < other < count and code in range(1, 7), "entry condition edge/operator invalid")
            reached.add(other)
        else:
            _require(code == 0 and other == NONE, "entry unused fields invalid")
        if kind in (1, 2, 4):
            _require(ref < variables, "entry variable reference invalid")
            v = definitions[ref]
            _require(kind != 1 or v["minimum"] <= value <= v["maximum"], "entry assignment out of range")
            _require(not v["boolean"] or (kind != 2 and code <= 2 and value in (0, 1)), "entry boolean operation invalid")
        elif kind == 3:
            _require(ref < cue_count and value == 0, "entry cue invalid")
        else:
            _require(ref == value == 0, "entry jump operands invalid")
    effects = [0] * count
    for i in reversed(range(count)):
        kind, _, _, _, next_, other, _ = records[i]
        if kind:
            effects[i] = max(effects[next_], effects[other] if kind == 4 else 0) + (kind == 3)
        _require(effects[i] <= MAX_CUES, "entry cue budget exceeded")
    return {"variables": definitions, "instructions": records}
