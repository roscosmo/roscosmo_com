"""Conservative edit classification and staged live screen-object refresh."""
from dataclasses import fields, replace
from copy import deepcopy
from .processing_cache import fingerprint

CAPABILITY = {
    'version': 3,
    'operations': ['project.apply_commands', 'project.undo', 'project.redo'],
    'preserves': ['project.editor', 'scene.display_name'],
    'response_field': 'preview_update',
    'outcomes': ['preserved', 'restart_required', 'not_started', 'visual_updated'],
    'execution_changes': 'explicit_restart',
    'scene_dependencies': {
        'response_field': 'preview_dependencies',
        'unrelated_scene_edits': 'preserve_active_preview',
        'stale_destination': 'PREVIEW_SCENE_RESTART_REQUIRED',
        'shared_assets': 'invalidate_referencing_scenes',
        'project_settings_and_templates': 'conservative_all_scenes',
        'partial_compilation': False,
    },
    'live_visual_patch': {
        'properties': ['x', 'y', 'visible'],
        'source': 'object.defaults',
        'scope': 'active_scene_screen_objects',
        'snapshot_field': 'preview_snapshot',
        'runtime_overrides': 'restart_required',
        'world_and_menu_objects': 'restart_required',
    },
    'audio_stop_required_before_execution_change': True,
    'automatic_build': False,
}


def execution_identity(bundle):
    if bundle is None:
        return None
    content = {f.name: getattr(bundle, f.name) for f in fields(bundle)}
    from .execution_semantics import execution_project
    content['project'] = {k: v for k, v in execution_project(bundle.project).items() if k != 'editor'}
    content['scenes'] = tuple({k: v for k, v in s.items() if k != 'display_name'} for s in bundle.scenes)
    return fingerprint(content)


def visual_candidate(before, after, player):
    """Stage a render on a private executor copy; never run entry or advance time.

    Return None when the complete edit is outside this narrow visual subset.
    The caller publishes the candidate only with the accepted source transaction.
    """
    if player is None or not after.valid or player._object_source is None:
        return None
    if getattr(getattr(player, '_scope_menu', None), 'pending', None) is not None:
        return None
    scene_id = player._scene['scene_id']
    old_scene = next((s for s in before.scenes if s['scene_id'] == scene_id), None)
    new_scene = next((s for s in after.scenes if s['scene_id'] == scene_id), None)
    if old_scene is None or new_scene is None:
        return None
    old_objects = {o['object_id']: o for o in old_scene.get('objects', [])}
    new_objects = {o['object_id']: o for o in new_scene.get('objects', [])}
    if old_objects.keys() != new_objects.keys():
        return None
    patches = {}
    for ref, old in old_objects.items():
        a, b = old['defaults'], new_objects[ref]['defaults']
        changed = {k for k in a.keys() | b.keys() if a.get(k) != b.get(k)}
        if changed:
            if not changed <= {'x', 'y', 'visible'} or any(k not in a or k not in b for k in changed):
                return None
            patches[ref] = {k: b[k] for k in changed}
    if not patches:
        return None
    # Prove that there are no other executable changes, including assets,
    # bindings, other Scenes, object dimensions or State overrides.
    restored = deepcopy(after.scenes)
    for scene in restored:
        if scene['scene_id'] == scene_id:
            for obj in scene['objects']:
                if obj['object_id'] in patches:
                    obj['defaults'] = deepcopy(old_objects[obj['object_id']]['defaults'])
    if execution_identity(before) != execution_identity(replace(after, scenes=restored)):
        return None
    active = set(player._machine_states.values()) if hasattr(player, '_machine_states') else {player._state()['state_id']}
    for ref, values in patches.items():
        world = getattr(player, '_world_context', None)
        if world is not None and world.position(ref) is not None:
            return None
        scopes = getattr(player, '_scope_timing', None)
        if scopes is not None and scopes.scope('objects', ref) == 'menu':
            return None
        if any(player._object_live.get(ref, {}).get(k) != old_objects[ref]['defaults'][k] for k in values):
            return None
        for state in player._object_source['states']:
            if state['state_id'] in active:
                if any(o['object_ref'] == ref and values.keys() & o.keys() for o in state['object_overrides']):
                    return None
    candidate = deepcopy(player)
    # Update all source copies used by later Scene activation as well as the
    # current live defaults. Existing State masks/effects retain precedence.
    sources = [candidate._object_source,
               candidate._scenes[scene_id].get('object_source'),
               candidate._scenes[scene_id].get('_scope_source'),
               candidate._scope_sources.get(scene_id)]
    for source in sources:
        if source is not None:
            for obj in source.get('objects', []):
                if obj['object_id'] in patches:
                    obj['defaults'].update(patches[obj['object_id']])
    for ref, values in patches.items():
        candidate._object_definitions[ref]['defaults'].update(values)
        candidate._object_live[ref].update(values)
    candidate._render_framebuffer()
    candidate.snapshot()  # Fail before publishing if snapshot resolution fails.
    return candidate
