"""Conservative FW0 text/graphics arena admission, separate from LPBAM packing.

ARM descriptor sizes are checked against firmware types by the native test.
No whole-package bytes or separately retained Scene strings are charged here.
"""
from .target_profile import TARGET_PROFILE
from .v2_export import LIMITS

FRAME_DESCRIPTOR_BYTES = 28
TEXT_DESCRIPTOR_BYTES = 12
TEXT_ALIGNMENT = 4


def text_layout(count, bytes_per_bank):
    if not 0 <= count <= 64 or not count <= bytes_per_bank <= count * 256:
        raise ValueError('invalid bounded-text reservation')
    prefix = LIMITS['combined_steps'] * LIMITS['objects'] * FRAME_DESCRIPTOR_BYTES
    offset = prefix
    for _ in range(2 if count else 0):
        offset = (offset + TEXT_ALIGNMENT - 1) // TEXT_ALIGNMENT * TEXT_ALIGNMENT
        offset += count * TEXT_DESCRIPTOR_BYTES + bytes_per_bank
    arena = TARGET_PROFILE['package']['resident_prefix_bytes']
    return dict(arena_bytes=arena, frame_descriptor_bytes=prefix,
                text_bank_count=2 if count else 0, text_binding_count=count,
                text_bytes_per_bank=bytes_per_bank, text_reserved_bytes=offset - prefix,
                graphics_capacity_bytes=max(0, arena - offset), layout_fits=offset < arena)


def scene_working_set(package, scene):
    bindings = scene['graph'].get('text_bindings', [])
    result = text_layout(len(bindings), sum(b['maximum_bytes'] for b in bindings))
    choices = {i: {(obj['frame_index'], obj['clip_index'])}
               for i, obj in enumerate(scene['objects']) if obj['kind'] == 1}
    for records in scene.get('state_overrides', []):
        for record in records:
            if record['mask'] & 4:
                choices[record['object_index']].add((record['frame_index'], 65535))
    for operation in scene.get('object_operations', []):
        if operation['opcode'] == 4:
            choices[operation['object_index']].add((operation['frame_index'], 65535))
    graph = scene['graph']
    for selector in graph['selectors']:
        choices[selector['object_index']].update((r['frame_index'], r['clip_index']) for r in selector['rules'])
    for visual in graph['visuals']:
        choices[visual['object_index']].add((visual['frame_index'], visual['clip_index']))
    for clip in graph.get('clips', []):
        choices[clip['object_index']].add((65535, clip['animation_index']))
    contributors = []
    for index, alternatives in choices.items():
        maximum_bytes = maximum_frames = 0
        for frame, clip in alternatives:
            frames = {frame} if clip == 65535 else set(package.animations[clip]['frame_indexes'])
            maximum_frames = max(maximum_frames, len(frames))
            maximum_bytes = max(maximum_bytes, sum(len(package.assets[f]['pixels']) +
                len(package.assets[f]['mask']) for f in frames))
        contributors.append(dict(object_id=scene['objects'][index]['object_id'],
                                 frame_count_upper_bound=maximum_frames,
                                 graphics_bytes_upper_bound=maximum_bytes))
    used = sum(c['graphics_bytes_upper_bound'] for c in contributors)
    count = sum(c['frame_count_upper_bound'] for c in contributors)
    result.update(graphics_bytes_upper_bound=used, frame_count_upper_bound=count,
                  frame_count_limit=LIMITS['combined_steps'] * LIMITS['objects'],
                  contributors=contributors, method='sum_of_per_object_maximum_visual_working_sets',
                  shared_frames_deduplicated=False, hidden_and_offscreen_included=True,
                  exact_device_admission_required=True)
    result['status'] = ('passed_conservative' if result['layout_fits'] and
        used <= result['graphics_capacity_bytes'] and count <= result['frame_count_limit'] else 'blocked')
    return result


def capability():
    return dict(host_editing=True, host_preview=True, runtime=True, export=True,
                hardware_validation='pending', text_forms=['literal_string', 'typed_token_array'],
                token_kinds=['literal', 'variable'], scopes=['scene', 'package'], explicit_scope_required=True,
                maximum_tokens=16, maximum_resolved_bytes=256, integer_format='signed_decimal',
                boolean_format='0_or_1', clock_tokens=False, wire_format='MPR1_v13_BPT1',
                admission='declared_range_box_fit_and_shared_frame_arena',
                exact_device_admission_required=True)
