"""SMG1 logic lowering shared by native tests and restricted machine export.

Presentation, effect catalog contents, variable scope and input bindings remain
adapter metadata in the result. Do not install the payload as a complete scene.
"""
from copy import deepcopy
from dataclasses import dataclass
import struct

from .compiler import EggCompileError
from .scene_machines import validate
from .machine_limits import EVENTS, TIMERS

NONE, NAMED = 255, 254
HEADER = struct.Struct("<4sHHII8B")


@dataclass(frozen=True)
class MachinePayload:
    data: bytes
    machines: tuple
    states: tuple
    events: tuple
    variables: tuple
    effects: tuple


def require(condition, message):
    if not condition:
        raise EggCompileError("SMG1: " + message)


def compile_machine_logic(bundle, scene_id, *, _flowcharts=False, _object_effects=False, _calendars=False, _periodic=False, _world_routes=None, _execution_scopes=False):
    """Lower a validated project scene into the generic native transaction core."""
    require(bundle.valid, "project must validate")
    scene = next((s for s in bundle.scenes if s["scene_id"] == scene_id), None)
    require(scene is not None and "machine_logic" in scene, "machine scene required")
    from .behavior_response import lower_scene
    scene = lower_scene(scene)
    validate(bundle.project, scene)
    require(not scene['machine_logic'].get('execution_scopes') or _execution_scopes,
            'execution scopes require the explicit scoped Scene encoder')
    from .world_logic_source import project as project_world
    authored_world = project_world(scene)
    require(not authored_world.guards and not authored_world.actions,
            'authored world operands require the explicit world source compiler')
    graph = scene["machine_logic"]
    flows = graph.get('flowcharts', [])
    from .flowcharts import uses_local_time
    local_time = uses_local_time(scene)
    require(not flows or _flowcharts, 'callable flowcharts are not supported by native export')
    flow_ids = {f['flowchart_id']: i for i, f in enumerate(flows)}
    machines = {m["machine_id"]: i for i, m in enumerate(graph["machines"])}
    states = {s["state_id"]: i for i, s in enumerate(scene["states"])}
    bindings = scene.get("event_bindings", [])
    events = {ref: i for i, ref in enumerate([
        *(a["action_id"] for a in scene["input_actions"]),
        *(b["binding_id"] for b in bindings), *(e["event_id"] for e in graph["events"])])}
    declarations = [(scope, v) for scope, records in (
        ("scene", scene["variables"]), ("package", bundle.project.get("package_variables", []))) for v in records]
    variables = {(scope, v["variable_id"]): i for i, (scope, v) in enumerate(declarations)}
    relative = [b for b in bindings if b['event_type'] != 'time.local_schedule']
    timers = {b["binding_id"]: i for i, b in enumerate(relative)}
    require(len(states) <= 64 and len(events) <= EVENTS and len(declarations) <= 32 and len(bindings) <= TIMERS,
            "native table capacity exceeded")
    require(all(b["event_type"] in ("time.scene_elapsed", "time.state_entry_elapsed") or
                _calendars and b['event_type'] == 'time.local_schedule' for b in bindings),
            "calendar transport is not integrated; refusing to drop calendar bindings")
    owner = {s: machines[m["machine_id"]] for m in graph["machines"] for s in m["states"]}
    writers = {(v["scope"], v["variable_ref"]): machines[m["machine_id"]]
               for m in graph["machines"] for v in m["variable_writes"]}
    writers.update({(v['scope'], v['variable_ref']): 128 + i
                    for i, f in enumerate(flows) for v in f['variable_writes']})
    receivers = {**graph["input_receivers"], **graph["timer_receivers"]}
    recipient = lambda m: NONE if m is None else machines[m]
    mask = lambda refs: sum(1 << states[s] for s in set(refs))
    body = bytearray(bytes(states[m["entry_state"]] for m in graph["machines"]))
    body.extend(owner[s] for s in states)
    body.extend(recipient(receivers[e]) if e in receivers else NAMED for e in events)
    variable_bytes = b"".join(struct.pack("<iiiBB", int(v["initial"]), v.get("minimum", 0),
        v.get("maximum", 1), writers.get((scope, v["variable_id"]), NONE), int(v["value_type"] == "bool"))
        for scope, v in declarations)
    timer_bytes = bytearray()
    periodic = any(b['configuration'].get('mode', 'one_shot') == 'periodic' for b in relative)
    random_delay = any('delay_max_ms' in b['configuration'] for b in relative)
    require(not periodic or _periodic, 'periodic timer export awaits hardware validation')
    for b in relative:
        ref = b["binding_id"]
        scoped = b["event_type"] == "time.state_entry_elapsed"
        eligible = {s for r in graph["routes"] if r["event_ref"] == ref for s in r["from_states"]}
        require(not scoped or eligible, "state timer requires a receiving route")
        delay = b["configuration"]["delay_ms"]
        require(10 <= delay <= 86400000, "relative timer delay outside native bounds")
        timer_bytes.extend(struct.pack("<IQ4B", delay, mask(eligible) if scoped else 0,
            recipient(receivers[ref]), events[ref], int(scoped),
            int(scoped or b["configuration"].get("start_policy", "scene_entry") == "scene_entry") |
            (2 if b['configuration'].get('mode', 'one_shot') == 'periodic' else 0)))
        if random_delay or local_time:
            maximum = b['configuration'].get('delay_max_ms', 0)
            require(not maximum or delay <= maximum <= 86400000 and
                    b['configuration'].get('mode', 'one_shot') == 'one_shot', 'invalid random delay bounds')
            timer_bytes.extend(struct.pack('<I', maximum))
    effects, effect_owners, route_bytes = [], [], bytearray()
    compares = {"eq": 1, "ne": 2, "lt": 3, "le": 4, "gt": 5, "ge": 6}
    operations = {"assign": 1, "add": 2, "reset": 3}

    def encode_action(action, writer):
        kind, event, value = action['kind'], 0, 0
        if kind == 'set_variable':
            op = operations[action['operation']]
            target = variables[(action.get('variable_scope', 'scene'), action['variable_ref'])]
            value = 0 if op == 3 else int(action['value'])
        elif kind == 'send_event':
            op, target, event = 4, machines[action['machine_ref']], events[action['event_ref']]
        elif kind in ('start_timer', 'restart_timer', 'cancel_timer'):
            require(action['timer_ref'] in timers, 'calendar controls are not relative timer actions')
            op, target = {'start_timer': 5, 'restart_timer': 6, 'cancel_timer': 7}[kind], timers[action['timer_ref']]
        elif kind == 'run_flowchart':
            op, target = 9, flow_ids[action['flowchart_ref']]
        else:
            require(kind != 'exit_to_shell', 'shell action adapter is not integrated')
            require(kind not in ('menu.open', 'menu.close') or _execution_scopes,
                    'menu lifecycle requires the explicit scoped Scene encoder')
            require(kind != 'object.play_effect' or _object_effects, 'transient effects require the internal encoder')
            require(kind in {'scene.set_inversion', 'scene.replace', 'play_sfx', 'request_render', 'object.set_position', 'object.move_by',
                             'object.set_visibility', 'object.set_frame', 'object.clear_frame', 'object.set_inversion',
                             'object.select_visual', 'object.play_effect', 'object.play_clip', 'object.cancel_clip',
                             'menu.open', 'menu.close'}, 'unknown effect')
            require(writer != NONE, 'effects need a declared owner')
            require(len(effects) < 32, 'effect catalog capacity exceeded')
            op, target = 8, len(effects)
            effects.append(deepcopy(action)); effect_owners.append(writer)
        return struct.pack('<3Bxi', op, target, event, value)

    for route in graph["routes"]:
        outcomes = route.get("outcomes", [route])
        world_guards = _world_routes.guards(route['route_id']) if _world_routes else ()
        require(len(route["guards"]) + len(world_guards) <= 8, "guard capacity exceeded")
        route_bytes.extend(struct.pack("<5B3xQ", recipient(route["machine_ref"]), events[route["event_ref"]],
            len(route["guards"]) + len(world_guards), len(outcomes), int("outcomes" in route), mask(route["from_states"])))
        for guard in route["guards"]:
            route_bytes.extend(struct.pack("<BBi", variables[(guard.get("variable_scope", "scene"), guard["variable_ref"])],
                compares[guard["operator"]], int(guard["value"])))
        for index in world_guards:
            route_bytes.extend(struct.pack('<BBi', NONE, 0, index))
        for outcome_index, outcome in enumerate(outcomes):
            actions = list(outcome['actions'])
            if 'target_scene' in outcome:
                require(len(actions) < 8, 'scene exit permits at most seven actions before its destination request')
                scene_ids = {s['scene_id']: i + 1 for i, s in enumerate(sorted(bundle.scenes, key=lambda s: s['scene_id']))}
                actions.append({'kind': 'scene.replace', 'scene_id': scene_ids[outcome['target_scene']]})
            else:
                require('scene_exit_ref' not in outcome, 'scene exit requires a resolved destination')
            encoded = [encode_action(action, recipient(route['machine_ref'])) for action in actions]
            if _world_routes:
                encoded = _world_routes.actions(route['route_id'], outcome_index, encoded)
            require(len(encoded) <= 8, 'action capacity exceeded')
            route_bytes.extend(struct.pack("<3Bx", outcome.get("weight", 100),
                states[outcome["target_state"]] if "target_state" in outcome else NONE, len(encoded)))
            route_bytes.extend(b''.join(encoded))

    def predicate(value):
        if 'time_available' in value:
            return bytes((6, 0, 0, 0, 0, 0, 0, 0))
        if 'time_of_day_range' in value:
            bounds = value['time_of_day_range']
            return bytes((7,)) + bounds['start_seconds'].to_bytes(3, 'little') + struct.pack('<I', bounds['end_seconds'])
        if 'machine_ref' in value:
            return struct.pack('<4Bi', 1, machines[value['machine_ref']], states[value['state_ref']], 0, 0)
        if 'variable_ref' in value:
            return struct.pack('<4Bi', 2, variables[(value.get('variable_scope', 'scene'), value['variable_ref'])],
                               compares[value['operator']], 0, int(value['value']))
        if 'not' in value:
            return predicate(value['not']) + struct.pack('<4Bi', 3, 0, 0, 0, 0)
        kind = 'all' if 'all' in value else 'any'
        parts = value[kind]
        result = predicate(parts[0])
        for child in parts[1:]:
            result += predicate(child) + struct.pack('<4Bi', 4 if kind == 'all' else 5, 0, 0, 0, 0)
        return result

    # Topological layout makes every edge forward; native traversal needs no
    # recursion or maximum-sized node table in RAM.
    flow_bytes = bytearray(4 * (len(flows) + 1)) if flows else bytearray()
    for fi, chart in enumerate(flows):
        struct.pack_into('<I', flow_bytes, fi * 4, len(flow_bytes))
        nodes = {n['node_id']: n for n in chart['nodes']}
        edges = {ref: ([n['next']] if n['kind'] == 'actions' else
                      [n['default'], *(b['next'] for b in n['branches'])] if n['kind'] == 'decision' else [])
                 for ref, n in nodes.items()}
        incoming = {ref: sum(ref in targets for targets in edges.values()) for ref in nodes}
        order = []
        while len(order) < len(nodes):
            ready = next((ref for ref in nodes if incoming[ref] == 0 and ref not in order), None)
            require(ready is not None, 'flowchart cycle')
            order.append(ready)
            for target in set(edges[ready]):
                incoming[target] -= 1
        require(order[0] == chart['root'], 'flowchart root must reach every node')
        positions, patches = {}, []
        for ref in order:
            node = nodes[ref]
            start = len(flow_bytes); positions[ref] = start
            kind = {'return': 0, 'actions': 1, 'decision': 2}[node['kind']]
            count = len(node.get('actions', node.get('branches', [])))
            flow_bytes.extend(struct.pack('<BBHI', kind, count, 0, 0))
            if kind:
                patches.append((start + 4, node['next'] if kind == 1 else node['default']))
            if kind == 1:
                encoded = [encode_action(action, 128 + fi) for action in node['actions']]
                if _world_routes:
                    encoded = _world_routes.flows.actions(chart['flowchart_id'], ref, encoded)
                require(len(encoded) <= 8, 'flow action capacity exceeded')
                flow_bytes[start + 1] = len(encoded)
                flow_bytes.extend(b''.join(encoded))
            elif kind == 2:
                for bi, branch in enumerate(node['branches']):
                    tokens = predicate(branch['when'])
                    if _world_routes:
                        for guard in _world_routes.flows.guards(chart['flowchart_id'], ref, bi):
                            tokens += struct.pack('<4Bi', 8, 0, 0, 0, guard) + struct.pack('<4Bi', 4, 0, 0, 0, 0)
                    require(len(tokens) // 8 <= 16, 'flow predicate capacity exceeded')
                    patches.append((len(flow_bytes), branch['next']))
                    flow_bytes.extend(struct.pack('<IB3x', 0, len(tokens) // 8) + tokens)
            struct.pack_into('<H', flow_bytes, start + 2, len(flow_bytes) - start)
        for offset, target in patches:
            struct.pack_into('<I', flow_bytes, offset, positions[target])
    if flows:
        struct.pack_into('<I', flow_bytes, len(flows) * 4, len(flow_bytes))
    body.extend(effect_owners)
    body.extend(variable_bytes); body.extend(timer_bytes); body.extend(route_bytes); body.extend(flow_bytes)
    header = HEADER.pack(b"SMW1" if _world_routes else b"SMG1", 5 if local_time else 4 if random_delay else 3 if periodic else 2 if flows else 1, HEADER.size, HEADER.size + len(body), graph["seed"],
        len(machines), len(states), len(variables), len(events), len(timers), len(graph["routes"]), len(effects), len(flows))
    return MachinePayload(header + body, tuple(machines), tuple(states), tuple(events),
                          tuple(variables), tuple(effects))
