"""Bounded read-only visual selection, evaluated at settled machine boundaries."""
import struct
from copy import deepcopy

COMMANDS = ("scene.presentation_selectors.set", "scene.presentation_selectors.clear")
COMPARE = {"eq": 1, "ne": 2, "lt": 3, "le": 4, "gt": 5, "ge": 6}


def variable_comparison_capability():
    return {"scopes": ["scene", "package"], "explicit_scope_required": True,
            "operators": {"int32": list(COMPARE), "bool": ["eq", "ne"]},
            "literal_type": "declared_variable_type", "read_only": True,
            "requires_variable_writer": False, "wire_encoding": "selector_tokens_v2",
            "hardware_validation": "pending"}


def variable_definitions(project, scene):
    return {(scope, v["variable_id"]): v
            for scope, records in (("scene", scene.get("variables", [])),
                                   ("package", project.get("package_variables", [])))
            for v in records}


def apply_command(scenes, command):
    from .project import _require_command_fields, _command_scene
    from .scene_machines import fail
    setting = command["kind"] == COMMANDS[0]
    required = {"kind", "scene_id"} | ({"selectors"} if setting else set())
    _require_command_fields(command, required, required | {"command_id"})
    scene = _command_scene(scenes, command["scene_id"])
    if "machine_logic" not in scene:
        fail("presentation selectors require scene machines")
    if setting:
        scene["machine_logic"]["presentation_selectors"] = deepcopy(command["selectors"])
    else:
        scene["machine_logic"].pop("presentation_selectors", None)
    return deepcopy(command)


def predicate_tokens(value, machines, states, depth=0, *, variables=None, world_guard=None, inventory_items=None):
    from .scene_machines import fail
    if depth > 8 or not isinstance(value, dict):
        fail("selector predicate nesting exceeds eight levels")
    if value.get('kind') == 'inventory.compare':
        if inventory_items is None:
            fail('inventory comparisons are unavailable in presentation selectors')
        from .inventory_conditions import validate
        validate(value, inventory_items, 'menu condition')
        return [(9, 0, 0)]  # Validation/counting only; never a device token.
    if value.get('kind') == 'world.compare':
        if world_guard is None:
            fail('world selectors require the explicit world preparation path')
        return [(8, 0, 0, world_guard(value))]
    if set(value) == {"machine_ref", "state_ref"}:
        machine, state = value["machine_ref"], value["state_ref"]
        if not isinstance(machine, str) or not isinstance(state, str) or machine not in machines or state not in machines[machine]["states"]:
            fail("selector predicate must reference a state of its named machine")
        return [(1, list(machines).index(machine), list(states).index(state))]
    if set(value) == {"variable_scope", "variable_ref", "operator", "value"}:
        scope, ref, op, literal = (value[k] for k in ("variable_scope", "variable_ref", "operator", "value"))
        if not isinstance(scope, str) or not isinstance(ref, str) or (scope, ref) not in (variables or {}):
            fail("selector requires an existing explicitly scoped variable")
        boolean = variables[(scope, ref)]["value_type"] == "bool"
        if not isinstance(op, str) or op not in COMPARE or (boolean and op not in ("eq", "ne")):
            fail("selector comparison is invalid for the variable type")
        if type(literal) is not (bool if boolean else int) or not -2147483648 <= literal <= 2147483647:
            fail("selector comparison literal must match the variable type and fit int32")
        return [(5, list(variables).index((scope, ref)), COMPARE[op], int(literal))]
    if len(value) != 1 or next(iter(value)) not in ("all", "any", "not"):
        fail("selector predicate must be machine/state, scoped variable comparison, all, any or not")
    op, children = next(iter(value.items()))
    if op == "not":
        tokens = predicate_tokens(children, machines, states, depth + 1, variables=variables, world_guard=world_guard, inventory_items=inventory_items) + [(2, 0, 0)]
    else:
        if not isinstance(children, list) or not 2 <= len(children) <= 8:
            fail("selector all/any requires two to eight predicates")
        tokens = []
        for i, child in enumerate(children):
            tokens += predicate_tokens(child, machines, states, depth + 1, variables=variables, world_guard=world_guard, inventory_items=inventory_items)
            if i:
                tokens.append((3 if op == "all" else 4, 0, 0))
    if len(tokens) > 16:
        fail("selector predicate exceeds sixteen tokens")
    return tokens


def validate(project, scene, writers):
    from .scene_machines import fail, shape, records
    graph = scene["machine_logic"]
    selectors = records(graph.get("presentation_selectors", []), "selector_id", 8)
    machines = {m["machine_id"]: m for m in graph["machines"]}
    states = {s["state_id"]: s for s in scene["states"]}
    objects = {o["object_id"]: o for o in scene["objects"]}
    seen = set()
    for selector in selectors.values():
        shape(selector, {"selector_id", "object_ref", "rules"})
        ref = selector["object_ref"]
        if not isinstance(ref, str) or ref not in objects or objects[ref]["kind"] != "sprite" or ref in seen:
            fail("selector must exclusively target one existing sprite")
        if ("object", ref, "visual_ref") in writers:
            fail("selector conflicts with machine visual writer", "MACHINE_WRITER_CONFLICT")
        seen.add(ref)
        rules = selector["rules"]
        if not isinstance(rules, list) or not 1 <= len(rules) <= 8:
            fail("selector requires one to eight ordered rules")
        for i, rule in enumerate(rules):
            shape(rule, set(), {"when", "animation_ref", "visual_ref"})
            if ("when" in rule) != (i < len(rules) - 1):
                fail("selector requires exactly one final unconditional fallback")
            if ("animation_ref" in rule) == ("visual_ref" in rule):
                fail("selector rule must select either an animation or a static frame")
            ref = rule.get("animation_ref", rule.get("visual_ref"))
            if not isinstance(ref, str) or not ref:
                fail("selector visual reference must be a nonempty string")
            if "when" in rule:
                predicate_tokens(rule["when"], machines, states, variables=variable_definitions(project, scene))


def compile_selectors(bundle, scene, *, _world_guard=None):
    from .machine_wire import require
    selectors = scene["machine_logic"].get("presentation_selectors", [])
    if not selectors:
        return b""
    machines = {m["machine_id"]: m for m in scene["machine_logic"]["machines"]}
    states = {s["state_id"]: s for s in scene["states"]}
    frames = {f.frame_id: (i, f) for i, f in enumerate(sorted(bundle.frames, key=lambda f: (f.asset_id, f.frame_id)))}
    clips = {c["animation_id"]: (i, c) for i, c in enumerate(sorted(bundle.animations, key=lambda c: c["animation_id"]))}
    objects = {o["object_id"]: (i, o) for i, o in enumerate(scene["objects"])}
    variables = variable_definitions(bundle.project, scene)
    predicates = [[predicate_tokens(rule["when"], machines, states, variables=variables, world_guard=_world_guard)
                   if "when" in rule else [] for rule in selector["rules"]] for selector in selectors]
    extended = any(token[0] in (5, 8) for rules in predicates for tokens in rules for token in tokens)
    # Bit 7 identifies eight-byte typed tokens. Old decoders reject the count;
    # state-only packages retain their original three-byte encoding exactly.
    data = bytearray([len(selectors) | (0x80 if extended else 0)])
    for selector, rule_tokens in zip(selectors, predicates):
        index, obj = objects[selector["object_ref"]]
        data += struct.pack("<HBB", index, len(selector["rules"]), 0)
        for rule, tokens in zip(selector["rules"], rule_tokens):
            clip_index = 65535
            if "animation_ref" in rule:
                require(rule["animation_ref"] in clips, "unknown selector animation")
                clip_index, clip = clips[rule["animation_ref"]]
                refs = clip["frame_refs"]
                require(clip["loop_policy"] == "loop" and len(refs) <= 12 and len(set(refs)) <= 4,
                        "selector clip exceeds looping/step/frame bounds")
            else:
                refs = [rule["visual_ref"]]
            for ref in refs:
                require(ref in frames, "unknown selector frame")
                frame = frames[ref][1]
                require((frame.width, frame.height) == (obj["width"], obj["height"]), "selector frame dimensions mismatch")
            data += struct.pack("<BBHH", len(tokens), 0, frames[refs[0]][0], clip_index)
            for token in tokens:
                data += (struct.pack("<BBBBi", *token[:3], 0, token[3] if len(token) == 4 else 0)
                         if extended else bytes(token))
    return bytes(data)


def matches(predicate, states, variables=None, *, world_guard=None, inventory_counts=None):
    if predicate.get('kind') == 'inventory.compare':
        from .inventory_conditions import compare
        return compare(predicate, inventory_counts or {})
    if predicate.get('kind') == 'world.compare':
        if world_guard is None:
            from .preview import PreviewError
            raise PreviewError('world selector access is unavailable')
        return world_guard(predicate)
    if "machine_ref" in predicate:
        return states[predicate["machine_ref"]] == predicate["state_ref"]
    if "variable_ref" in predicate:
        left = variables[(predicate["variable_scope"], predicate["variable_ref"])]
        right = predicate["value"]
        return {"eq": left == right, "ne": left != right, "lt": left < right,
                "le": left <= right, "gt": left > right, "ge": left >= right}[predicate["operator"]]
    if "not" in predicate:
        return not matches(predicate["not"], states, variables, world_guard=world_guard, inventory_counts=inventory_counts)
    op = "all" if "all" in predicate else "any"
    # Native postfix evaluates every operand; failed reads cannot short-circuit.
    results = [matches(p, states, variables, world_guard=world_guard, inventory_counts=inventory_counts) for p in predicate[op]]
    return (all if op == "all" else any)(results)
