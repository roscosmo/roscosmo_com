"""Private world attachments to existing callable flowchart nodes."""
import struct
from .machine_wire import require
from .flowcharts import predicate_size
from .world_operands_wire import decode_typed_operands as decode_operands


class WorldFlows:
    def __init__(self, graph, lowered, attachments):
        charts = graph.get('flowcharts', [])
        ids = {f['flowchart_id']: i for i, f in enumerate(charts)}
        bindings, guards, actions = decode_operands(lowered.operands, len(graph['machines']), len(charts))
        gi = {name: i for i, name in enumerate(lowered.guard_sources)}
        ai = {name: i for i, name in enumerate(lowered.action_sources)}
        require(type(attachments) is dict and not attachments.keys() - ids.keys(), 'unknown world flowchart')
        self._guards, self._actions = {}, {}
        for flow, records in attachments.items():
            nodes = {n['node_id']: n for n in charts[ids[flow]]['nodes']}
            require(type(records) is dict and not records.keys() - nodes.keys(), 'unknown world flow node')
            for node_id, record in records.items():
                node = nodes[node_id]
                require(type(record) is dict, 'invalid world flow attachment')
                if node['kind'] == 'actions':
                    require(set(record) == {'actions'} and isinstance(record['actions'], (list, tuple)),
                            'action node requires world action insertions')
                    previous, inserts = -1, []
                    for item in record['actions']:
                        require(isinstance(item, (list, tuple)) and len(item) == 2, 'invalid world flow insertion')
                        position, identity = item
                        require(type(position) is int and 0 <= position <= len(node['actions']) and position >= previous,
                                'world flow insertions must be ordered action boundaries')
                        require(type(identity) is str and identity in ai, 'unknown world flow action')
                        operand = ai[identity]
                        require(bindings[actions[operand][0]][3] == 128 + ids[flow], 'wrong world flow writer')
                        inserts.append((position, operand))
                        previous = position
                    require(len(node['actions']) + len(inserts) <= 8, 'flow action capacity exceeded')
                    self._actions[flow, node_id] = tuple(inserts)
                else:
                    require(node['kind'] == 'decision' and set(record) == {'guards'}, 'only action/decision nodes accept world attachments')
                    rows = record['guards']
                    require(isinstance(rows, (list, tuple)) and len(rows) == len(node['branches']), 'world guards must address each branch')
                    for i, row in enumerate(rows):
                        require(isinstance(row, (list, tuple)) and all(type(g) is str and g in gi for g in row), 'unknown world flow guard')
                        require(predicate_size(node['branches'][i]['when']) + 2 * len(row) <= 16, 'flow predicate capacity exceeded')
                        self._guards[flow, node_id, i] = tuple(gi[g] for g in row)

    def guards(self, flow, node, branch):
        return self._guards.get((flow, node, branch), ())

    def insertions(self, flow, node):
        return self._actions.get((flow, node), ())

    def actions(self, flow, node, ordinary):
        inserts = self.insertions(flow, node)
        result, cursor = [], 0
        for position in range(len(ordinary) + 1):
            while cursor < len(inserts) and inserts[cursor][0] == position:
                result.append(struct.pack('<3Bxi', 10, 0, 0, inserts[cursor][1]))
                cursor += 1
            if position < len(ordinary):
                result.append(ordinary[position])
        return result
