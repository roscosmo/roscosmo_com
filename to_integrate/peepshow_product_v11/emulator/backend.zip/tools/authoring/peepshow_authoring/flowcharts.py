"""Explicit, bounded scene flowcharts with restricted native export."""
from copy import deepcopy
from .machine_limits import FLOWCHARTS
from .instance_event_source import CAPABILITY as EVENT_CAPABILITY
from .facing_source import CAPABILITY as FACING_CAPABILITY
from .destination_source import CAPABILITY as DESTINATION_CAPABILITY
from .interaction_source import CAPABILITY as INTERACTION_CAPABILITY
from .camera_source import CAPABILITY as CAMERA_CAPABILITY
from .visibility_source import CAPABILITY as VISIBILITY_CAPABILITY

COMMANDS = ('scene.flowcharts.set', 'scene.flowcharts.clear')
MAX_CHARTS, MAX_NODES, MAX_LIST, MAX_WORK = FLOWCHARTS, 128, 8, 4096
LOCAL_TIME_CAPABILITY = dict(host_editing=True, host_preview=True, runtime=True, export=True,
    status='development_restricted', hardware_validation='pending',
    predicate_kinds=['time_available', 'time_of_day_range'],
    range_start_inclusive=True, range_end_exclusive=True, midnight_wrap=True,
    unavailable_range_result=False, sampling='one_snapshot_per_external_transaction',
    invocation='explicit_flowchart_call', reconciliation_field='time_reconcile',
    reconciliation_triggers=['clock_mapping_change', 'shell_resume'],
    paused_delivery='defer_until_resume', scene_entry='scene_activated',
    commands=['scene.machines.set', 'scene.flowcharts.set'])
CAPABILITY = dict(host_editing=True, host_preview=True, runtime=True, export=True,
    export_profile='hw6_machines_resident_v1', status='development_restricted',
    commands=list(COMMANDS), maximum_flowcharts=MAX_CHARTS, maximum_total_nodes=MAX_NODES,
    maximum_actions_per_node=MAX_LIST, maximum_branches_per_node=MAX_LIST,
    maximum_predicate_tokens=16, maximum_predicate_depth=8, maximum_transaction_work=MAX_WORK,
    maximum_effects_per_receiver=8, overflow_policy='reject_private_transaction',
    work_accounting='nodes_actions_and_full_postfix_predicate_tokens',
    node_kinds=['decision', 'actions', 'return'], invocation='explicit_inline',
    action_kind='run_flowchart', cycles=False, nested_calls=False,
    action_kinds=['set_variable', 'send_event', 'play_sfx', 'request_render',
                  'start_timer', 'restart_timer', 'cancel_timer', 'object.select_visual',
                  'object.set_position', 'object.move_by', 'object.set_visibility',
                  'object.set_frame', 'object.clear_frame', 'object.play_clip', 'object.cancel_clip', 'object.set_inversion'],
    destination_before_actions=True, writer_policy='exclusive_declared_owner',
    visual_commit='final_identity_preserves_unchanged_phase')
CAPABILITY['local_time_conditions'] = LOCAL_TIME_CAPABILITY
CAPABILITY['event_addressing'] = EVENT_CAPABILITY
CAPABILITY['facing'] = FACING_CAPABILITY
CAPABILITY['destinations'] = DESTINATION_CAPABILITY
CAPABILITY['interactions'] = INTERACTION_CAPABILITY
CAPABILITY['camera'] = CAMERA_CAPABILITY
CAPABILITY['visibility'] = VISIBILITY_CAPABILITY
from .inventory_conditions import CAPABILITY as INVENTORY_CONDITION_CAPABILITY
CAPABILITY['inventory_conditions'] = INVENTORY_CONDITION_CAPABILITY


def fail(message):
    from .project import ProjectCommandError
    raise ProjectCommandError('FLOWCHART_INVALID', message)


def predicate_leaves(value, depth=0):
    if depth > 8 or not isinstance(value, dict):
        fail('predicate must be an object with nesting at most eight')
    keys = set(value)
    if value.get('kind') == 'inventory.compare':
        return [value]  # Item/type/reference admission uses the project catalog.
    if keys == {'time_available'}:
        if value['time_available'] is not True:
            fail('time_available must be true; use not for its inverse')
        return [value]
    if keys == {'time_of_day_range'}:
        bounds = value['time_of_day_range']
        if (not isinstance(bounds, dict) or set(bounds) != {'start_seconds', 'end_seconds'}
                or any(type(v) is not int or not 0 <= v < 86400 for v in bounds.values())
                or bounds['start_seconds'] == bounds['end_seconds']):
            fail('time range requires distinct integer endpoints in 0..86399')
        return [value]
    if keys == {'machine_ref', 'state_ref'} or keys in (
            {'variable_ref', 'operator', 'value'}, {'variable_scope', 'variable_ref', 'operator', 'value'}):
        return [value]
    if keys == {'not'}:
        return predicate_leaves(value['not'], depth + 1)
    if keys in ({'all'}, {'any'}):
        children = next(iter(value.values()))
        if not isinstance(children, list) or not 2 <= len(children) <= 8:
            fail('Boolean conditions require two through eight children')
        return [leaf for child in children for leaf in predicate_leaves(child, depth + 1)]
    fail('unknown predicate structure')


def predicate_size(value):
    if 'not' in value:
        return 1 + predicate_size(value['not'])
    if 'all' in value or 'any' in value:
        children = value.get('all', value.get('any'))
        return len(children) - 1 + sum(predicate_size(c) for c in children)
    return 1


def charts(scene):
    return scene.get('machine_logic', {}).get('flowcharts', [])


def uses_local_time(scene):
    from .response_conditions import uses_local_time as response_uses_local_time
    return response_uses_local_time(scene.get('machine_logic', {})) or any('time_available' in leaf or 'time_of_day_range' in leaf
               for chart in charts(scene) for node in chart['nodes']
               for branch in node.get('branches', []) for leaf in predicate_leaves(branch['when']))


def validate(scene, writers, variables, objects, machines):
    from .scene_machines import shape, records, ident
    from .scene_objects import PROPERTY_KEYS
    definitions = records(charts(scene), 'flowchart_id', MAX_CHARTS)
    total = 0
    for ref, chart in definitions.items():
        shape(chart, {'flowchart_id', 'display_name', 'variable_writes', 'object_writes', 'root', 'nodes'}, {'layout'})
        if not isinstance(chart['display_name'], str) or not 1 <= len(chart['display_name'].strip()) <= 128:
            fail('flowchart display name must contain 1..128 characters')
        owner = ('flowchart', ref)
        for field, limit in (('variable_writes', 32), ('object_writes', 64)):
            if not isinstance(chart[field], list) or len(chart[field]) > limit:
                fail('invalid flowchart writer list')
        keys = []
        for declaration in chart['variable_writes']:
            shape(declaration, {'scope', 'variable_ref'})
            key = (ident(declaration['scope']), ident(declaration['variable_ref']))
            if key not in variables:
                fail('unknown flowchart variable declaration')
            keys.append(('variable', *key))
        for declaration in chart['object_writes']:
            shape(declaration, {'object_ref', 'properties'})
            if ident(declaration['object_ref']) not in objects or not isinstance(declaration['properties'], list) or not declaration['properties']:
                fail('invalid flowchart object declaration')
            for prop in declaration['properties']:
                if not isinstance(prop, str) or prop not in PROPERTY_KEYS:
                    fail('unknown object property')
                keys.append(('object', declaration['object_ref'], prop))
        for key in keys:
            if key in writers:
                fail(f'competing writer for {key}')
            writers[key] = owner
        nodes = records(chart['nodes'], 'node_id', MAX_NODES)
        total += len(nodes)
        if not nodes or total > MAX_NODES or ident(chart['root']) not in nodes:
            fail('flowcharts require a root and at most 128 total nodes')
        edges = {}
        for nid, node in nodes.items():
            if node.get('kind') == 'return':
                shape(node, {'node_id', 'kind'})
                edges[nid] = []
            elif node.get('kind') == 'actions':
                shape(node, {'node_id', 'kind', 'actions', 'next'})
                if not isinstance(node['actions'], list) or len(node['actions']) > MAX_LIST:
                    fail('action nodes support at most eight actions')
                edges[nid] = [node['next']]
            elif node.get('kind') == 'decision':
                shape(node, {'node_id', 'kind', 'branches', 'default'})
                if not isinstance(node['branches'], list) or not 1 <= len(node['branches']) <= MAX_LIST:
                    fail('decision nodes require one through eight branches')
                edges[nid] = [node['default']]
                for branch in node['branches']:
                    shape(branch, {'when', 'next'})
                    for leaf in predicate_leaves(branch['when']):
                        if 'machine_ref' in leaf:
                            machine = ident(leaf['machine_ref'])
                            if machine not in machines or ident(leaf['state_ref']) not in machines[machine]['states']:
                                fail('unknown machine/state predicate')
                    if predicate_size(branch['when']) > 16:
                        fail('predicate exceeds sixteen tokens')
                    edges[nid].append(branch['next'])
            else:
                fail('unsupported flowchart node kind')
            for target in edges[nid]:
                if ident(target) not in nodes:
                    fail('missing flowchart edge target')
        reached, pending = set(), [chart['root']]
        while pending:
            nid = pending.pop()
            if nid not in reached:
                reached.add(nid)
                pending.extend(edges[nid])
        if reached != set(nodes):
            fail('all flowchart nodes must be reachable')
        remaining = set(nodes)
        while remaining:
            leaves = {n for n in remaining if not (set(edges[n]) & remaining)}
            if not leaves:
                fail('flowchart cycles are unsupported')
            remaining -= leaves
        layout = chart.get('layout', {})
        if not isinstance(layout, dict) or layout.keys() - nodes.keys():
            fail('layout must reference existing nodes')
        for point in layout.values():
            shape(point, {'x', 'y'})
            if any(type(v) is not int or not -100000 <= v <= 100000 for v in point.values()):
                fail('invalid layout coordinate')
    return definitions


def actions(chart):
    return [a for n in chart['nodes'] if n['kind'] == 'actions' for a in n['actions']]


def records_for_projection(scene):
    for ci, chart in enumerate(charts(scene)):
        for ni, node in enumerate(chart['nodes']):
            key = f'flow.{ci}.{ni}'
            if node['kind'] == 'actions':
                yield key, [], node['actions']
            elif node['kind'] == 'decision':
                for bi, branch in enumerate(node['branches']):
                    for li, leaf in enumerate(predicate_leaves(branch['when'])):
                        if 'variable_ref' in leaf:
                            yield f'{key}.{bi}.{li}', [leaf], []


def project_action(action):
    return {'kind': 'request_render'} if action.get('kind') in (
        'send_event', 'run_flowchart', 'object.select_visual', 'object.play_effect', 'scene.set_inversion',
        'object.play_clip', 'object.cancel_clip', 'menu.open', 'menu.close') else deepcopy(action)


def validate_visuals(scene, frames, clips):
    from .object_clips import validate_assets
    validate_assets(scene, frames, clips)
    objects = {o['object_id']: o for o in scene.get('objects', [])}
    for chart in charts(scene):
        for action in actions(chart):
            if action.get('kind') != 'object.select_visual':
                continue
            obj = objects.get(action.get('object_ref'))
            if obj is None or obj['kind'] != 'sprite':
                fail('visual selection requires a sprite object')
            clip = clips.get(action.get('animation_ref')) if 'animation_ref' in action else None
            if 'animation_ref' in action and (clip is None or clip['loop_policy'] != 'loop'
                    or len(clip['frame_refs']) > 12 or len(set(clip['frame_refs'])) > 4):
                fail('invalid selected looping animation')
            refs = clip['frame_refs'] if clip else [action.get('visual_ref')]
            if any(ref not in frames or (frames[ref].width, frames[ref].height) != (obj['width'], obj['height']) for ref in refs):
                fail('selected frame must exist and match object dimensions')


def apply_command(scenes, command):
    from .project import _require_command_fields, _command_scene
    setting = command['kind'] == COMMANDS[0]
    required = {'kind', 'scene_id'} | ({'flowcharts'} if setting else set())
    _require_command_fields(command, required, required | {'command_id'})
    scene = _command_scene(scenes, command['scene_id'])
    if 'machine_logic' not in scene:
        fail('flowcharts require scene machines')
    if setting:
        scene['machine_logic']['flowcharts'] = deepcopy(command['flowcharts'])
    else:
        scene['machine_logic'].pop('flowcharts', None)
    return deepcopy(command)


def charge(player, work=1):
    from .preview import PreviewError
    if work > MAX_WORK - player._flow_work:
        raise PreviewError('flowchart transaction work budget exhausted')
    player._flow_work += work


def evaluate(player, value, leaves, prefix, *, _charged=False, evidence=None):
    # Charge the full immutable predicate, matching native postfix evaluation.
    # Host short-circuiting is safe: predicates only read the private snapshot.
    if not _charged:
        charge(player, predicate_size(value))
    if value.get('kind') == 'inventory.compare':
        from .inventory_conditions import compare
        return compare(value, player._inventory_state['counts'], evidence=evidence)
    if 'time_available' in value:
        result = player._flow_local_seconds is not None
        if evidence is not None:
            evidence.append(dict(kind='time_available', local_seconds=player._flow_local_seconds, result=result))
        return result
    if 'time_of_day_range' in value:
        seconds = player._flow_local_seconds
        start, end = (value['time_of_day_range'][k] for k in ('start_seconds', 'end_seconds'))
        result = seconds is not None and (start <= seconds < end if start < end else seconds >= start or seconds < end)
        if evidence is not None:
            evidence.append(dict(kind='time_of_day_range', local_seconds=seconds,
                                 start_seconds=start, end_seconds=end, result=result))
        return result
    if 'machine_ref' in value:
        state = player._machine_states[value['machine_ref']]
        result = state == value['state_ref']
        if evidence is not None:
            evidence.append(dict(kind='machine_state', machine_ref=value['machine_ref'],
                                 actual_state=state, expected_state=value['state_ref'], result=result))
        return result
    if 'variable_ref' in value:
        compiled = player._machine_compiled[f'{prefix}.{leaves.index(value)}']
        return player._guard_passes(compiled['guards'][0], evidence=evidence)
    if 'not' in value:
        return not evaluate(player, value['not'], leaves, prefix, _charged=True, evidence=evidence)
    op = 'all' if 'all' in value else 'any'
    return (all if op == 'all' else any)(evaluate(player, p, leaves, prefix, _charged=True, evidence=evidence) for p in value[op])


def execute_actions(player, actions, compiled, context, sends, audio):
    from .preview import StateScenePreview, PreviewError
    system_action = None
    if len(actions) != len(compiled['operations']):
        raise PreviewError('flowchart action projection lost ordering')
    for action, operation in zip(actions, compiled['operations']):
        charge(player)
        kind = action['kind']
        if kind == 'scene.set_inversion':
            player._scene_inverted = not player._scene_inverted if action['mode'] == 'toggle' else action['mode'] == 'inverted'
        elif kind == 'object.play_effect':
            player._start_object_effect(action)
        elif kind in ('object.play_clip', 'object.cancel_clip'):
            player._change_object_clip(action)
        elif kind == 'run_flowchart':
            execute(player, action['flowchart_ref'], context, sends, audio)
        elif kind == 'send_event':
            sends.append((action['machine_ref'], action['event_ref']))
            if len(sends) > 32:
                raise PreviewError('event_queue_or_chain_capacity')
        elif kind == 'object.select_visual':
            field = 'animation_ref' if 'animation_ref' in action else 'visual_ref'
            player._flow_pending[action['object_ref']] = (field, action[field])
        else:
            route = {**compiled, 'target_state_index': None, 'target_scene': None, 'operations': (operation,)}
            result = StateScenePreview._execute_route(player, route, *context)
            audio.extend(result.audio_events)
            if len(audio) > 8:
                raise PreviewError('event_chain_audio_capacity')
            if result.system_action:
                system_action = result.system_action
    return system_action


def execute(player, ref, context, sends, audio):
    ci, chart = next((i, c) for i, c in enumerate(player._machines['flowcharts']) if c['flowchart_id'] == ref)
    nodes = {n['node_id']: (i, n) for i, n in enumerate(chart['nodes'])}
    current = chart['root']
    while True:
        charge(player)
        ni, node = nodes[current]
        player._flow_trace.append(dict(flowchart_id=ref, node_id=current))
        key = f'flow.{ci}.{ni}'
        if node['kind'] == 'return':
            return
        if node['kind'] == 'actions':
            world = getattr(player, '_world_context', None)
            if world is not None:
                world.execute_flow(player, ref, node, player._machine_compiled[key], context, sends, audio)
            else:
                execute_actions(player, node['actions'], player._machine_compiled[key], context, sends, audio)
            current = node['next']
        else:
            current = node['default']
            for bi, branch in enumerate(node['branches']):
                result = evaluate(player, branch['when'], predicate_leaves(branch['when']), f'{key}.{bi}')
                world = getattr(player, '_world_context', None)
                if world is not None:
                    result = world.flow_matches(player, ref, node['node_id'], bi, result)
                if result:
                    current = branch['next']
                    break
