"""Private enclosing-Scene admission; no project command or package ABI.

Compile all graphs from source in this call. Do not accept caller-substituted
CompiledBehavior objects whose operand declarations could disagree with bytes.
Scene and instance action domains are disjoint; shared numeric writer tags are
not authority to escape a receiver's admitted local-to-world property map.
"""
from dataclasses import dataclass

from .instance_behavior import compile_behavior
from .instance_bindings import compile_instance_bindings
from .machine_wire import require
from .world_operands_wire import decode_typed_operands as decode_operands
from .world_routes import compile_world_machine_logic


@dataclass(frozen=True)
class BehaviorSource:
    bundle: object
    scene_id: str
    bindings: object
    guards: tuple
    actions: tuple
    attachments: dict
    queries: tuple = ()
    terminal_programs: object = None


@dataclass(frozen=True)
class CompiledInstanceScene:
    scene: object
    world: object
    behaviors: tuple
    instances: object
    descriptors: tuple
    initial_states: tuple
    routing: object = None


def compile_instance_scene(bundle, scene_id, world, attachments, behaviors, assignments,
                           *, flow_attachments=None, bridges=None, queue_capacity=None,
                           initial_event_capacity=1, authoring_scene_exits=False, outgoing=(), _execution_scopes=False):
    """Return a coherent private set or raise without publication.

    WORLD operations, including those in callable flows, all address the one
    supplied world operand table. Instance writable properties may not appear
    anywhere in that table's action records, even if no route currently uses
    the record. Read-only Scene guards on those properties are allowed.
    Behavior-local role zero maps through each explicit assignment's existing
    world writer tag, never to an additional Scene machine for each instance.
    Optional bridge admission checks mixed event/queue bounds. Full runtime
    resource/lifecycle admission remains separate.
    """
    require(isinstance(behaviors, (tuple, list)) and
            all(isinstance(b, BehaviorSource) for b in behaviors),
            'shared behaviors require source records')
    # Also checks entity membership, types, aliases, duplicate definitions and
    # assignments, declared ownership, and every Scene/flow action record.
    instances = compile_instance_bindings(world, [b.bindings for b in behaviors], assignments)
    scene = compile_world_machine_logic(bundle, scene_id, world, attachments,
        flow_attachments=flow_attachments, _flowcharts=True, _object_effects=True,
        _calendars=True, _periodic=True, _execution_scopes=_execution_scopes)
    require(authoring_scene_exits or not any(effect.get('kind') == 'scene.replace' for effect in scene.effects),
            'mixed instance Scene replacement awaits lifecycle admission')
    compiled = []
    entries = []
    for source in behaviors:
        result = compile_behavior(source.bundle, source.scene_id, source.bindings,
                                  source.guards, source.actions, source.attachments,
                                  queries=source.queries)
        compiled.append(result)
        # Derive State identities from the same source/encoder, not a caller
        # supplied count or copied per-object machine definition.
        definition = next(s for s in source.bundle.scenes if s['scene_id'] == source.scene_id)
        entry = definition['machine_logic']['machines'][0]['entry_state']
        entries.append(result.logic.states.index(entry))

    world_bindings, _, world_actions = decode_operands(
        world.operands, len(world.machine_sources), len(world.flow_sources))
    written_by_scene = {row[0] for row in world_actions}
    if any(row[1] == 7 for row in world_actions):
        from .world_operands_wire import decode_query_operands
        queries = decode_query_operands(world.operands, len(world.machine_sources), len(world.flow_sources))[3]
        written_by_scene.update(queries[row[2]][1] for row in world_actions if row[1] == 7)
    claimed = set()
    descriptors, initial = [], []
    for instance in instances.instances:
        behavior = compiled[instance.behavior]
        local, _, actions = decode_operands(behavior.operands, 1)
        require(len(local) == len(instance.bindings), 'local binding count mismatch')
        for index, (_, _, kind, writer) in enumerate(local):
            slot = instance.bindings[index]
            require(world_bindings[slot][2] == kind, 'local/world property type mismatch')
            require(writer in (0, 255), 'behavior local writer must be self or read-only')
            if writer == 0:
                require(world_bindings[slot][3] == instance.writer and
                        slot not in written_by_scene and slot not in claimed,
                        'Scene and instance property writers conflict')
                claimed.add(slot)
        for binding, _, _ in actions:
            require(local[binding][3] == 0, 'behavior action targets a read-only property')
        descriptors.append((instance.behavior, len(behavior.logic.states)))
        initial.append((entries[instance.behavior], 1))
    combined = CompiledInstanceScene(scene, world, tuple(compiled), instances,
                                     tuple(descriptors), tuple(initial))
    if bridges is not None:
        from dataclasses import replace
        from .instance_routing import compile_routing
        source = next(s for s in bundle.scenes if s['scene_id'] == scene_id)
        combined = replace(combined, routing=compile_routing(combined, source, behaviors,
            bridges, queue_capacity, initial_event_capacity, outgoing=outgoing))
    else:
        require(queue_capacity is None and initial_event_capacity == 1 and not outgoing,
                'routing capacity requires explicit bridge admission')
    return combined
