"""Internal authoring primitive for imported defaults and local property edits.

Not a project schema, Tiled parser, service capability, or runtime property API.
Callers provide stable identities; names and source ordering are not identities.
All operations are pure. A conflicting reimport cannot publish a partial asset.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


class ImportedPropertyError(ValueError):
    pass


@dataclass(frozen=True, order=True)
class PropertyKey:
    asset_id: str
    owner_id: str
    property_id: str

    def __post_init__(self):
        if any(not isinstance(value, str) or not value for value in
               (self.asset_id, self.owner_id, self.property_id)):
            raise ImportedPropertyError("Property identities must be nonempty strings")


@dataclass(frozen=True)
class PropertyDefinition:
    value_type: str
    default: bool | int | str
    minimum: int | None = None
    maximum: int | None = None
    editable: bool = True

    def __post_init__(self):
        if type(self.editable) is not bool:
            raise ImportedPropertyError("editable must be boolean")
        if self.value_type == "int32":
            if (type(self.minimum) is not int or type(self.maximum) is not int or
                    not -(2**31) <= self.minimum <= self.maximum < 2**31):
                raise ImportedPropertyError("int32 requires valid explicit bounds")
        elif self.value_type not in ("bool", "string"):
            raise ImportedPropertyError("Unsupported property type")
        elif self.minimum is not None or self.maximum is not None:
            raise ImportedPropertyError("Only integers have numeric bounds")
        self.validate(self.default)

    def validate(self, value):
        expected = {"bool": bool, "int32": int, "string": str}[self.value_type]
        if type(value) is not expected:
            raise ImportedPropertyError("Property value has the wrong type")
        if self.value_type == "int32" and not self.minimum <= value <= self.maximum:
            raise ImportedPropertyError("Property value is outside declared bounds")
        # Strings here are authored immutable text, not mutable firmware strings.


def effective_defaults(definitions: Mapping[PropertyKey, PropertyDefinition],
                       edits: Mapping[PropertyKey, bool | int | str]):
    """Resolve authoring defaults; this never creates or changes runtime state."""
    for key, value in edits.items():
        if key not in definitions:
            raise ImportedPropertyError("Edit refers to a missing property")
        definition = definitions[key]
        if not definition.editable:
            raise ImportedPropertyError("Property is not editable")
        definition.validate(value)
    return {key: edits.get(key, definition.default)
            for key, definition in sorted(definitions.items())}


@dataclass(frozen=True)
class ReimportConflict:
    key: PropertyKey
    reason: str


@dataclass(frozen=True)
class ReimportPlan:
    definitions: tuple[tuple[PropertyKey, PropertyDefinition], ...]
    edits: tuple[tuple[PropertyKey, bool | int | str], ...]
    conflicts: tuple[ReimportConflict, ...]

    def resolved_defaults(self):
        if self.conflicts:
            raise ImportedPropertyError("Resolve reimport conflicts before publication")
        return effective_defaults(dict(self.definitions), dict(self.edits))


def plan_reimport(previous: Mapping[PropertyKey, PropertyDefinition],
                  incoming: Mapping[PropertyKey, PropertyDefinition],
                  edits: Mapping[PropertyKey, bool | int | str],
                  referenced: frozenset[PropertyKey] = frozenset()) -> ReimportPlan:
    """Three-way reconciliation, retaining explicit Studio edits and conflicts.

    referenced contains logic/binding references, independent of local edits.
    Type changes on referenced properties require review even with no override.
    Removed, edited properties remain in the plan's edit records for resolution.
    No name matching, silent coercion, or automatic reference reassignment.
    """
    effective_defaults(previous, edits)
    if not referenced.issubset(previous):
        raise ImportedPropertyError("Existing reference has no property definition")
    conflicts = []
    for key in sorted(set(edits) | set(referenced)):
        before = previous[key]
        after = incoming.get(key)
        if after is None:
            conflicts.append(ReimportConflict(key, "property_removed"))
            continue
        if before.value_type != after.value_type:
            conflicts.append(ReimportConflict(key, "type_changed"))
            continue
        if key in referenced and (before.minimum, before.maximum, before.editable) != (
                after.minimum, after.maximum, after.editable):
            conflicts.append(ReimportConflict(key, "referenced_definition_changed"))
        if key not in edits:
            continue
        if not after.editable:
            conflicts.append(ReimportConflict(key, "no_longer_editable"))
            continue
        try:
            after.validate(edits[key])
        except ImportedPropertyError:
            conflicts.append(ReimportConflict(key, "edit_out_of_bounds"))
            continue
        if before.default != after.default and edits[key] != after.default:
            conflicts.append(ReimportConflict(key, "source_and_studio_changed"))
    return ReimportPlan(tuple(sorted(incoming.items())), tuple(sorted(edits.items())),
                        tuple(conflicts))
