"""Public complete placed-actor duplication using existing Scene components."""
from copy import deepcopy
from .imported_properties import ImportedPropertyError
from .scene_map_entities import materialize
from .actor_output_response import COMMANDS as OUTPUT_COMMANDS, CAPABILITY as OUTPUT_CAPABILITY
from .actor_templates import CAPABILITY as TEMPLATE_CAPABILITY

COMMANDS = ('scene.actor.duplicate', 'scene.actor.set_position', 'scene.actor.set_bindings', 'scene.actor.remove', *OUTPUT_COMMANDS)
CAPABILITY = dict(version=1, commands=list(COMMANDS),
    command_schema='schemas/authoring/actor-assembly-command-v1.schema.json',
    inspection=dict(operation='project.actor.inspect', parameters=['scene_id', 'instance_ref']),
    host_editing=True, persisted=True, undo_redo=True, host_preview=True,
    runtime=False, export=False, preview_requires='scope_host_v1_for_scoped_scenes',
    placement_units='world_grid_cells', placement_scope='scene',
    shared=['behavior_definition', 'visual_assets', 'animations', 'sound_assets'],
    copied=['property_defaults', 'visual_objects', 'world_bindings', 'occupancy', 'interactions',
            'presentation_selectors', 'state_overrides', 'output_bindings', 'output_responses'],
    connections='explicit_copy_connections_flag', ordering='insert_after_source_action',
    inheritance='independent_duplicate_or_explicit_template_link', linked_assembly_prefabs=True,
    duplication_inheritance='shared_behavior_and_assets_only',
    runtime_state_copied=False, runtime_spawning=False,
    binding_fields=['target_entity_ref', 'outputs', 'solid_when'], new_entity_storage='map_scene.local_entities',
    output_responses=OUTPUT_CAPABILITY,
    templates=TEMPLATE_CAPABILITY,
    maximum_local_entities=64, capacity_policy='existing_final_transaction_limits',
    validation_error='ACTOR_ASSEMBLY_INVALID', readiness_error='ACTOR_ASSEMBLY_DEVICE_UNAVAILABLE',
    unsupported=['multi_behavior_entity', 'legacy_event_bridges', 'explicit_execution_scopes',
                 'pickup_components', 'menu_owned_objects'],
    removal=dict(command='scene.actor.remove', connection_choice='remove_connections',
        inspection_field='removal', references_error='ACTOR_ASSEMBLY_REFERENCED',
        repair_order='retarget_dependencies_before_remove', preserve_shared_resources=True,
        imported_map_marker='retained', empty_action_nodes='retained'))


def require(ok, message):
    if not ok:
        raise ImportedPropertyError(message)


def action_lists(graph):
    """Only actual authored action arrays, not compiler routes or arbitrary text."""
    for index, route in enumerate(graph['routes']):
        base = ['machine_logic', 'routes', index]
        if 'response' in route:
            for ni, node in enumerate(route['response']['nodes']):
                if node['kind'] == 'actions':
                    yield base + ['response', 'nodes', ni, 'actions'], node['actions']
        elif 'outcomes' in route:
            for oi, outcome in enumerate(route['outcomes']):
                yield base + ['outcomes', oi, 'actions'], outcome['actions']
        else:
            yield base + ['actions'], route['actions']
    for index, flow in enumerate(graph.get('flowcharts', [])):
        for ni, node in enumerate(flow['nodes']):
            if node['kind'] == 'actions':
                yield ['machine_logic', 'flowcharts', index, 'nodes', ni, 'actions'], node['actions']
    for ii, instance in enumerate(graph.get('instance_behaviors', {}).get('instances', [])):
        for ri, response in enumerate(instance.get('output_responses', [])):
            for ni, node in enumerate(response['response']['nodes']):
                if node['kind'] == 'actions':
                    yield ['machine_logic', 'instance_behaviors', 'instances', ii,
                           'output_responses', ri, 'response', 'nodes', ni, 'actions'], node['actions']


def owns_actions(graph, path, identity):
    return (path[1:3] == ['instance_behaviors', 'instances'] and
            graph['instance_behaviors']['instances'][path[3]]['instance_id'] == identity)


def connections(graph, identity, visuals):
    incoming = []
    for path, actions in action_lists(graph):
        if owns_actions(graph, path, identity):
            continue
        for index, action in enumerate(actions):
            if action.get('instance_ref') == identity or action.get('object_ref') in visuals:
                require(action['kind'] in ('send_event', 'object.play_effect', 'object.play_clip',
                    'object.cancel_clip', 'object.set_visibility'),
                    'Actor connection cannot yet be duplicated: ' + str(path + [index]))
                incoming.append(dict(source_path=path + [index], action=deepcopy(action)))
    return incoming


def property_defaults(a):
    properties = deepcopy(a['placement'].get('properties', []))
    for edit in a['record']['edits']:
        if edit['owner_id'] == a['instance']['entity']['owner_id']:
            next(p for p in properties if p['name'] == edit['property_id'])['value'] = deepcopy(edit['value'])
    return properties


def assembly(scene, catalogs, identity):
    graph = scene.get('machine_logic', {})
    source = graph.get('instance_behaviors', {})
    require(source.get('version') == 3 and 'map_scene' in graph, 'Actor placement requires a V3 shared instance in a map Scene')
    instance = next((i for i in source['instances'] if i['instance_id'] == identity), None)
    require(instance is not None, 'Unknown actor instance: ' + str(identity))
    entity = instance['entity']['owner_id']
    config = graph['map_scene']
    imported = next((r for c in catalogs for r in c.get('map_assets', []) if r['asset_id'] == config['asset_ref']), None)
    require(imported is not None, 'Actor has no selected map asset')
    record = materialize(imported, config)
    objects = next(l['objects'] for l in record['snapshot']['layers'] if l['id'] == config['object_layer'])
    placement = next((o for o in objects if 'object:' + str(o['id']) == entity), None)
    require(placement is not None, 'Actor placement is missing')
    positions = [p for p in graph.get('world_positions', []) if p['entity_ref'] == entity]
    visuals = {p['object_ref'] for p in positions}
    require(visuals, 'Actor duplication requires at least one bound world visual')
    require(sum(i['entity']['owner_id'] == entity for i in source['instances']) == 1,
            'Multiple behaviors on one entity require an explicit multi-behavior assembly')
    refs = [r for r in graph.get('world_references', []) if r['target'].get('owner_id') == entity]
    selectors = [s for s in graph.get('presentation_selectors', []) if s['object_ref'] in visuals]
    return dict(instance=instance, graph=graph, config=config, record=record, imported=imported,
        placement=placement, positions=positions, visuals=visuals, refs=refs, selectors=selectors,
        incoming=connections(graph, identity, visuals))


def inspect_source(scene, catalogs, identity):
    from .actor_removal import inspection as removal_inspection
    a = assembly(scene, catalogs, identity)
    g, instance, config = a['graph'], a['instance'], a['config']
    return dict(scene_id=scene['scene_id'], instance_ref=identity, behavior_ref=instance['behavior_ref'],
        entity_ref=instance['entity']['owner_id'], writer_ref=instance['writer_ref'],
        position=dict(column=a['placement']['x']//config['cell_width'], row=a['placement']['y']//config['cell_height']),
        scene_local=any(o['id'] == a['placement']['id'] for o in config.get('local_entities', [])),
        objects=[deepcopy(o) for o in scene['objects'] if o['object_id'] in a['visuals']],
        world_positions=deepcopy(a['positions']), world_references=deepcopy(a['refs']),
        presentation_selectors=deepcopy(a['selectors']),
        property_defaults=property_defaults(a),
        state_overrides=[dict(state_id=s['state_id'], objects=deepcopy([
            r for r in s['object_overrides'] if r['object_ref'] in a['visuals']]))
            for s in scene['states'] if any(r['object_ref'] in a['visuals'] for r in s['object_overrides'])],
        occupancy=deepcopy([o for o in config['occupancy'] if o['entity_ref'] == instance['entity']['owner_id']]),
        interactions=deepcopy([r for r in g.get('interactables', []) if r['instance_ref'] == identity]),
        output_responses=deepcopy(instance.get('output_responses', [])),
        bindings=dict(target_entity_ref=instance['target']['owner_id'] if instance['target'] else None,
            outputs=[{k:v for k,v in r.items() if k != 'instance_ref'}
                     for r in g['instance_behaviors'].get('outgoing', []) if r['instance_ref'] == identity]),
        connections=a['incoming'], removal=removal_inspection(scene, a),
        duplication='independent_assembly_shared_behavior_and_assets')


def point(position, a, *, exclude=None):
    require(type(position) is dict and set(position) == {'column', 'row'} and
            all(type(v) is int for v in position.values()), 'Position requires integer column and row')
    snap, config = a['record']['snapshot'], a['config']
    col, row = position['column'], position['row']
    require(0 <= col < snap['width'] and 0 <= row < snap['height'], 'Placement is outside the map')
    collision = next(l for l in snap['layers'] if l['id'] == config['collision_layer'])
    require(not collision['data'][row * snap['width'] + col], 'Placement is on a blocked terrain cell')
    x, y = col * config['cell_width'], row * config['cell_height']
    entities = {f"object:{o['id']}": o for l in snap['layers'] if l['id'] == config['object_layer'] for o in l['objects']}
    require(not any(o['entity_ref'] != exclude and
                    (entities[o['entity_ref']]['x'], entities[o['entity_ref']]['y']) == (x, y)
                    for o in config['occupancy']), 'Placement overlaps a registered actor')
    return x, y


def set_bindings(a, identity, bindings):
    require(type(bindings) is dict and not set(bindings) - {'target_entity_ref', 'outputs', 'solid_when'}, 'Unknown actor binding fields')
    instance = a['instance']
    if 'target_entity_ref' in bindings:
        target = bindings['target_entity_ref']
        require(target is None or type(target) is str, 'Target must be a map entity identity or null')
        instance['target'] = (None if target is None else dict(asset_id=a['config']['asset_ref'],
            field='entity_x', owner_id=target, value_type='int32'))
    if 'outputs' in bindings:
        rows = bindings['outputs']
        require(type(rows) is list, 'Output bindings require an array')
        for row in rows:
            require(type(row) is dict and set(row) == {'event_ref', 'machine_ref', 'target_event_ref'} and
                    all(type(v) is str for v in row.values()), 'Output bindings require output and receiving machine/input')
        source = a['graph']['instance_behaviors']
        source['outgoing'] = [r for r in source.get('outgoing', []) if r['instance_ref'] != identity]
        source['outgoing'].extend(dict(instance_ref=identity, **deepcopy(r)) for r in rows)
    if 'solid_when' in bindings:
        rows = [r for r in a['config']['occupancy'] if r['entity_ref'] == instance['entity']['owner_id']]
        require(len(rows) == 1, 'Collision binding requires one registered occupant')
        condition = bindings['solid_when']
        require(condition is None or (type(condition) is dict and set(condition) == {'reference_ref', 'equals'}
            and type(condition['reference_ref']) is str and type(condition['equals']) is bool),
            'solid_when requires a Boolean world reference comparison or null for always solid')
        if condition is None:
            rows[0].pop('solid_when', None)
        else:
            rows[0]['solid_when'] = deepcopy(condition)


def remap(value, mappings):
    result = deepcopy(value)
    pending = [result]
    while pending:
        current = pending.pop()
        if type(current) is list:
            pending.extend(current)
        elif type(current) is dict:
            for key, item in current.items():
                if type(item) is str and key in mappings:
                    current[key] = mappings[key].get(item, item)
                elif type(item) in (dict, list):
                    pending.append(item)
    return result


def duplicate(scene, catalogs, command):
    from .project import STABLE_ID
    a = assembly(scene, catalogs, command['source_instance_ref'])
    g, config, source = a['graph'], a['config'], a['graph']['instance_behaviors']
    identity = command['instance_id']
    require(type(identity) is str and STABLE_ID.fullmatch(identity), 'Invalid new actor identity')
    require(not any(i['instance_id'] == identity for i in source['instances']), 'Actor identity already exists')
    require(type(command['copy_connections']) is bool, 'copy_connections must explicitly be true or false')
    require(not source['bridges'], 'Legacy event bridges require explicit migration before actor duplication')
    require('execution_scopes' not in g, 'Explicit scope partitions require a separate assembly scope binding')
    require(not any(p['object_ref'] in a['visuals'] for p in scene.get('pickups', [])),
            'Pickup assemblies are not yet supported by actor duplication')
    require(not set(scene.get('menu_component', {}).get('scope', {}).get('objects', [])) & a['visuals'],
            'Menu-owned objects cannot be duplicated as gameplay actors')
    x, y = point(command['position'], a)
    oid = max(o['id'] for l in a['record']['snapshot']['layers'] if l['type'] == 'objectgroup' for o in l['objects']) + 1
    entity = 'object:' + str(oid)
    object_ids = {old: identity if len(a['visuals']) == 1 else identity + '.' + old for old in a['visuals']}
    reference_ids = {r['reference_id']: identity + '.' + r['reference_id'] for r in a['refs']}
    selector_ids = {s['selector_id']: identity + '.' + s['selector_id'] for s in a['selectors']}
    for names, used in [(object_ids, {o['object_id'] for o in scene['objects']}),
                        (reference_ids, {r['reference_id'] for r in g['world_references']}),
                        (selector_ids, {s['selector_id'] for s in g.get('presentation_selectors', [])})]:
        require(all(STABLE_ID.fullmatch(n) and n not in used for n in names.values()),
                'Generated actor member identity conflicts or is too long; choose another actor identity')
    maps = dict(object_ref=object_ids, object_id=object_ids, reference_id=reference_ids,
        reference_ref=reference_ids, source_ref=reference_ids, x_ref=reference_ids, y_ref=reference_ids,
        selector_id=selector_ids, entity_ref={a['instance']['entity']['owner_id']: entity},
        owner_id={a['instance']['entity']['owner_id']: entity},
        instance_ref={command['source_instance_ref']: identity}, instance_id={command['source_instance_ref']: identity})
    placement = {k:deepcopy(a['placement'].get(k, [] if k == 'properties' else 0))
                 for k in ('id', 'name', 'x', 'y', 'width', 'height', 'properties')}
    placement['properties'] = property_defaults(a)
    placement.update(id=oid, name=identity, x=x, y=y)
    config.setdefault('local_entities', []).append(placement)
    for key, members in [('world_references', a['refs']), ('world_positions', a['positions']),
                         ('presentation_selectors', a['selectors'])]:
        g.setdefault(key, []).extend(remap(members, maps))
    scene['objects'].extend(remap([o for o in scene['objects'] if o['object_id'] in a['visuals']], maps))
    config['occupancy'].extend(remap([r for r in config['occupancy'] if r['entity_ref'] == a['instance']['entity']['owner_id']], maps))
    for state in scene['states']:
        state['object_overrides'].extend(remap([r for r in state['object_overrides'] if r['object_ref'] in a['visuals']], maps))
    for owner in [*g['machines'], *g.get('flowcharts', [])]:
        owner['object_writes'].extend(remap([r for r in owner['object_writes'] if r['object_ref'] in a['visuals']], maps))
        if 'effect_writes' in owner:
            owner['effect_writes'].extend(object_ids[r] for r in list(owner['effect_writes']) if r in object_ids)
    new_instance = remap(a['instance'], maps)
    source['instances'].append(new_instance)
    source.setdefault('outgoing', []).extend(remap([r for r in source.get('outgoing', []) if r['instance_ref'] == command['source_instance_ref']], maps))
    if 'interactables' in g:
        g['interactables'].extend(remap([r for r in g['interactables'] if r['instance_ref'] == command['source_instance_ref']], maps))
    # The authored scheduler stays visible; relative order of existing actions is preserved.
    if command['copy_connections']:
        for path, actions in action_lists(g):
            if any(owns_actions(g, path, who) for who in (command['source_instance_ref'], identity)):
                continue
            changed = []
            for action in actions:
                changed.append(action)
                if action.get('instance_ref') == command['source_instance_ref'] or action.get('object_ref') in a['visuals']:
                    changed.append(remap(action, maps))
            actions[:] = changed
    a['instance'] = new_instance
    set_bindings(a, identity, command.get('bindings', {}))
    return dict(kind=command['kind'], scene_id=scene['scene_id'], instance_id=identity,
        entity_ref=entity, object_ids=object_ids, reference_ids=reference_ids,
        copied_connections=connections(g, identity, set(object_ids.values())))


def apply_command(scenes, catalogs, command):
    from .project import _command_scene, _require_command_fields, ProjectCommandError
    kind = command['kind']
    required = {'kind', 'scene_id'}
    if kind == 'scene.actor.duplicate':
        required |= {'source_instance_ref', 'instance_id', 'position', 'copy_connections'}
        optional = {'bindings'}
    elif kind == 'scene.actor.remove':
        required |= {'instance_ref', 'remove_connections'}
        optional = set()
    elif kind in OUTPUT_COMMANDS:
        required |= {'instance_ref', 'event_ref'} | ({'response'} if kind.endswith('.set') else set())
        optional = set()
    else:
        required |= {'instance_ref', 'position' if kind.endswith('set_position') else 'bindings'}
        optional = set()
    _require_command_fields(command, required, required | optional | {'command_id'})
    scene = _command_scene(scenes, command['scene_id'])
    try:
        if kind == 'scene.actor.duplicate':
            return duplicate(scene, catalogs, command)
        a = assembly(scene, catalogs, command['instance_ref'])
        if kind in OUTPUT_COMMANDS:
            from .actor_output_response import edit
            edit(a['instance'], command)
        elif kind == 'scene.actor.remove':
            from .actor_removal import remove
            return remove(scene, a, command)
        elif kind == 'scene.actor.set_position':
            local = next((o for o in a['config'].get('local_entities', []) if o['id'] == a['placement']['id']), None)
            require(local is not None, 'Position edit requires a Scene-local placed actor; imported markers remain owned by the map')
            local['x'], local['y'] = point(command['position'], a, exclude=a['instance']['entity']['owner_id'])
        else:
            set_bindings(a, command['instance_ref'], command['bindings'])
    except (ImportedPropertyError, KeyError, TypeError, StopIteration) as exc:
        raise ProjectCommandError('ACTOR_ASSEMBLY_INVALID', str(exc)) from exc
    return deepcopy(command)
