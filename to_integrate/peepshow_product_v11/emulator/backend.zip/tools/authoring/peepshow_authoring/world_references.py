"""Private stable-reference lowering. Not a project schema or export capability."""
from dataclasses import dataclass

from .imported_properties import ImportedPropertyError, PropertyKey
from .tiled_assets import definitions
from .tilemap_wire import CompiledMap, compile_map, HEADER, ENTITY
from .world_operands_wire import compile_operands
from .world_reference_source import validate_target


@dataclass(frozen=True)
class WorldReference:
    asset_id: str
    field: str
    owner_id: str = 'map'
    property_id: str = ''

    def __post_init__(self):
        if (any(type(v) is not str for v in (self.asset_id, self.field, self.owner_id, self.property_id))
                or not self.asset_id or not self.field or not self.owner_id):
            raise ImportedPropertyError('invalid world reference identity')


@dataclass(frozen=True)
class CompiledWorldReferences:
    map: CompiledMap
    operands: bytes
    binding_sources: tuple
    guard_sources: tuple
    action_sources: tuple
    machine_sources: tuple
    flow_sources: tuple


def compile_references(record, root, bindings, guards, actions, machines, flows=()):
    """Compile one map and its operands atomically (pure, no publication).

    bindings: (WorldReference, expected type 'bool'/'int32', writer).
    guards: (stable operand id, reference, comparison EQ..GE, typed value).
    actions: (stable operand id, reference, executing writer, operation, value).
    SET/ADD/MIN/MAX take typed literals; COPY/SUBTRACT take integer WorldReferences.
    writer: None (read-only) or ('machine'/'flow', stable id). Machine/flow lists
    MUST be the graph compiler's ordered identities, not independently sorted.
    Returned source tuples map emitted table indices back to identities.
    """
    def fail(message):
        raise ImportedPropertyError(message)

    def identities(values):
        if not isinstance(values, (list, tuple)) or any(type(v) is not str or not v for v in values):
            fail('world graph identities must be nonempty strings')
        if len(set(values)) != len(values):
            fail('duplicate world graph identity')
        return {value: i for i, value in enumerate(values)}

    machine_ids, flow_ids = identities(machines), identities(flows)

    def writer(value):
        if value is None:
            return 255
        if not isinstance(value, tuple) or len(value) != 2 or any(type(v) is not str for v in value):
            fail('invalid world writer identity')
        kind, identity = value
        owners = machine_ids if kind == 'machine' else flow_ids if kind == 'flow' else {}
        if identity not in owners:
            fail('missing world writer')
        return owners[identity] + (128 if kind == 'flow' else 0)

    compiled = compile_map(record, root)
    defs = definitions(record['asset_id'], record['snapshot'])
    mutable = {key: i for i, key in enumerate(
        key for key in compiled.property_sources if defs[key].value_type != 'string')}
    header = HEADER.unpack_from(compiled.data)
    entities = {f'object:{ENTITY.unpack_from(compiled.data, header[14] + i * ENTITY.size)[0]}': i
                for i in range(header[11])}

    def resolve(ref, expected):
        if (not isinstance(ref, WorldReference) or ref.asset_id != record['asset_id'] or
                any(type(v) is not str for v in (ref.asset_id, ref.field, ref.owner_id, ref.property_id))):
            fail('invalid or foreign world reference')
        if expected not in ('int32', 'bool'):
            fail('world reference requires a mutable primitive type')
        validate_target(record, ref, expected, defs)
        if ref.field == 'property':
            key = PropertyKey(ref.asset_id, ref.owner_id, ref.property_id)
            if key not in mutable or defs[key].value_type != expected:
                fail('missing, static or mistyped world property')
            return 5, mutable[key]
        fields = {'camera_x': 1, 'camera_y': 2, 'entity_x': 3, 'entity_y': 4}
        field = fields.get(ref.field)
        if field is None or expected != 'int32' or ref.property_id:
            fail('invalid world coordinate reference')
        if field <= 2:
            if ref.owner_id != 'map':
                fail('camera reference must address the map')
            return field, 0
        if ref.owner_id not in entities:
            fail('missing world entity')
        return field, entities[ref.owner_id]

    def records(values, width):
        if not isinstance(values, (list, tuple)) or any(
                not isinstance(v, (list, tuple)) or len(v) != width for v in values):
            fail('invalid world reference record shape')
        return values

    resolved = []
    for ref, expected, owner in records(bindings, 3):
        field, index = resolve(ref, expected)
        resolved.append(((field, index, int(expected == 'bool'), writer(owner)), ref, expected))
    resolved.sort(key=lambda item: item[0][:2])
    if len({item[0][:2] for item in resolved}) != len(resolved):
        fail('duplicate world target declaration')
    slots = {ref: i for i, (_, ref, _) in enumerate(resolved)}

    def lower(values, is_action):
        lowered, sources = [], []
        for row in records(values, 5 if is_action else 4):
            identity, ref = row[:2]
            if type(identity) is not str or not identity or identity in sources:
                fail('invalid or duplicate world operand identity')
            if not isinstance(ref, WorldReference) or ref not in slots:
                fail('undeclared world target')
            slot = slots[ref]
            binding, _, expected = resolved[slot]
            if is_action and (row[2] is None or writer(row[2]) != binding[3]):
                fail('world action does not belong to the declared writer')
            op, value = row[-2:]
            allowed = {'SET': 1, 'ADD': 2, 'COPY': 3, 'MIN': 4, 'MAX': 5, 'SUBTRACT': 6} if is_action else {'EQ': 1, 'NE': 2, 'LT': 3, 'LE': 4, 'GT': 5, 'GE': 6}
            if is_action and op in ('COPY', 'SUBTRACT'):
                if (expected != 'int32' or not isinstance(value, WorldReference) or
                        value not in slots or resolved[slots[value]][2] != 'int32'):
                    fail('world copy requires declared integer source and destination')
                value = slots[value]
            if type(op) is not str or op not in allowed or type(value) is not (bool if expected == 'bool' else int):
                fail('invalid typed world operation')
            lowered.append((slot, allowed[op], int(value)))
            sources.append(identity)
        return lowered, tuple(sources)

    guard_records, guard_sources = lower(guards, False)
    action_records, action_sources = lower(actions, True)
    operands = compile_operands([item[0] for item in resolved], guard_records, action_records,
                                len(machines), len(flows))
    return CompiledWorldReferences(compiled, operands, tuple(item[1] for item in resolved),
                                   guard_sources, action_sources, tuple(machines), tuple(flows))
