"""Shared instance preview using MachinePreview's evaluator and atomic candidate.

The public map adapter attaches these contexts; no installed-package, timing or
device memory-admission claim follows from host execution.
Per-instance host preview players are not firmware Scene-machine allocations.
"""
from copy import deepcopy
from dataclasses import dataclass, replace

from .instance_source import compile_instance_source, _behavior
from .compiler import build_preview_package
from .machine_preview import MachinePreview
from .preview import PreviewError
from .world_operands_wire import (compile_operands, decode_typed_operands as decode_operands,
                                  compile_query_operands, decode_query_operands)
from .world_preview import WorldPreviewContext, create_world_preview, create_world_context
from .world_references import CompiledWorldReferences


@dataclass(frozen=True)
class _Instance:
    index: int


class InstanceResponseError(PreviewError):
    def __init__(self, message, trace):
        super().__init__(message)
        self.terminal_response = deepcopy(next((r['terminal_response'] for r in trace if 'terminal_response' in r), None))
        self.selected_response = deepcopy(next((r['selected_response'] for r in trace
                                                if 'selected_response' in r), None))


class InstancePreviewContext(WorldPreviewContext):
    def resolve_receiver(self, machine, event):
        # Static bridges and outputs replace endpoints without queue appends.
        # Admission rejects cycles; retain a finite runtime guard as well.
        for _ in range(len(self.endpoints) + len(self.outputs) + 1):
            if isinstance(machine, _Instance):
                target = self.outputs.get((machine.index, event))
                if target is None:
                    return machine, event
                machine, event = target
            else:
                bridge = self.endpoints.get((machine, event))
                if bridge is None or self.combined.routing.queries[bridge] is not None:
                    return machine, event
                _, _, index, local_event = self.combined.routing.bridges[bridge]
                machine, event = _Instance(index), self._event(index, local_event)
        raise PreviewError('instance endpoint resolution cycle')

    def receiver_identity(self, receiver):
        if isinstance(receiver, _Instance):
            return dict(instance_id=self.ids[receiver.index] if 0 <= receiver.index < len(self.ids) else None)
        return dict(machine_id=receiver)

    def instance_snapshot(self):
        rows = []
        for i, instance in enumerate(self.combined.instances.instances):
            behavior = self.combined.behaviors[instance.behavior]
            values = {}
            for prop, slot in zip(behavior.bindings.properties, instance.bindings):
                value = self.read(slot)
                values[prop.name] = bool(value) if prop.value_type == 'bool' else value
            rows.append(dict(instance_id=self.ids[i], behavior_id=behavior.bindings.behavior_id,
                             state_id=self.instance_state(self.ids[i]), properties=values))
        return rows

    def deliver_instance(self, machine, event, elapsed):
        from .preview_steps import drain
        return drain(self.iterate_instance(machine, event, elapsed))

    def iterate_instance(self, machine, event, elapsed):
        if not isinstance(machine, _Instance):
            bridge_index = self.endpoints.get((machine, event))
            if bridge_index is None:
                return None
            _, _, instance, event_index = self.combined.routing.bridges[bridge_index]
            query = self.combined.routing.queries[bridge_index]
            if query is not None:
                facing = self.read(query.facing)
                direction = next(((dx, dy) for value, dx, dy in query.facings if value == facing), None)
                if direction is None:
                    raise PreviewError('invalid instance facing')
                x = self.read(query.actor_x) + direction[0] * query.width
                y = self.read(query.actor_y) + direction[1] * query.height
                if not all(-2**31 <= value < 2**31 for value in (x, y)):
                    raise PreviewError('instance query coordinate overflow')
                hits = [target for tx, ty, target, _ in query.targets
                        if self.read(tx) == x and self.read(ty) == y]
                if query.interaction_targets is not None:
                    eligible = {i: event for i, event, sides, slot, expected in query.interaction_targets
                                if direction in sides and (slot is None or self.read(slot) == expected)}
                    hits = [target for target in hits if target in eligible]
                    if hits:
                        event_index = eligible[hits[0]]
                if len(hits) > 1:
                    raise PreviewError('overlapping instance targets')
                sends = [] if not hits else [(_Instance(hits[0]), self._event(hits[0], event_index))]
                if not hits and query.no_target is not None:
                    sends = [query.no_target]
                return dict(machine_id=machine, event_id=event, result='query',
                            instance_id=None if not hits else self.ids[hits[0]]), sends
            machine, event = _Instance(instance), self._event(instance, event_index)
        index = machine.index
        if not 0 <= index < len(self.players):
            raise PreviewError('invalid instance target')
        player = self.players[index]
        player._elapsed_ms = elapsed
        player._world_context.values = deepcopy(self.values)
        player._world_context.written = set(self.written)
        player._flow_pending, player._flow_trace, player._flow_work = {}, [], 0
        player._flow_local_seconds = None
        sends = []
        role = player._machines['machines'][0]['machine_id']
        # This player evaluates an addressed behavior within the Scene's
        # private root transaction; only the Scene publishes presentation.
        player._scope_dispatching = True
        try:
            for mark in player._iterate_chain(None, 'INSTANCE', 'named', event, receiver=role, _deferred_sends=sends):
                mark.update(instance_id=self.ids[index], behavior_id=self.combined.behaviors[self.combined.instances.instances[index].behavior].bindings.behavior_id)
                yield mark
        finally:
            player._scope_dispatching = False
        if player._machine_rejection:
            raise InstanceResponseError(player._machine_rejection, player._machine_trace)
        self.values = player._world_context.values
        self.written = player._world_context.written
        record = dict(instance_id=self.ids[index], event_id=event,
                    result='applied' if any(r['result'] == 'applied' for r in player._machine_trace) else 'unhandled',
                    state=player._machine_states[role])
        selected = next((r['selected_response'] for r in player._machine_trace if 'selected_response' in r), None)
        if selected is not None:
            record['selected_response'] = deepcopy(selected)
        terminal = next((r['terminal_response'] for r in player._machine_trace if 'terminal_response' in r), None)
        if terminal is not None:
            record['terminal_response'] = deepcopy(terminal)
        return record, [(_Instance(index), e) for _, e in sends]

    def _event(self, instance, event):
        behavior = self.combined.instances.instances[instance].behavior
        return self.combined.behaviors[behavior].logic.events[event]

    def instance_state(self, identity):
        """Return a State identity, not a mutable preview player."""
        player = self.players[self.ids.index(identity)]
        return player._machine_states[player._machines['machines'][0]['machine_id']]


def create_instance_context(bundle, scene_id, world, attachments, source, *,
                            write_capacity, queue_capacity, camera=(0, 0),
                            flow_attachments=None, selector_data=None, position_source=(),
                            spatial=None, authoring_scene_exits=False):
    from .response_conditions import structural_bundle
    combined = compile_instance_source(structural_bundle(bundle), scene_id, world, attachments, source,
                                        queue_capacity=queue_capacity, flow_attachments=flow_attachments,
                                        authoring_scene_exits=authoring_scene_exits)
    context = create_world_context(bundle, scene_id, world, attachments,
        write_capacity=write_capacity, camera=camera, flow_attachments=flow_attachments,
        selector_data=selector_data, position_source=position_source)
    context.__class__ = InstancePreviewContext
    context.combined, context.queue_limit = combined, queue_capacity
    context.ids = tuple(r.instance_id for r in combined.instances.instances)
    context.endpoints = {(combined.scene.machines[m], combined.scene.events[e]): i
                         for i, (m, e, _, _) in enumerate(combined.routing.bridges)}
    context.outputs = {(i, context._event(i, e)): (combined.scene.machines[m], combined.scene.events[t])
                       for i, e, m, t in combined.routing.outgoing}
    context.players = []
    scene = next(s for s in bundle.scenes if s['scene_id'] == scene_id)
    from .tilemap_wire import HEADER
    grid = HEADER.unpack_from(world.map.data)[5:7]
    definitions = [_behavior(bundle, scene, row, version=source['version'], grid=grid) for row in source['behaviors']]
    global_bindings, _, _ = decode_operands(world.operands, len(world.machine_sources), len(world.flow_sources))
    for instance in combined.instances.instances:
        definition = definitions[instance.behavior]
        behavior = combined.behaviors[instance.behavior]
        local, guards, actions = decode_operands(behavior.operands, 1)
        order = sorted(range(len(local)), key=lambda i: global_bindings[instance.bindings[i]][:2])
        remap = {old: new for new, old in enumerate(order)}
        bindings = [(*global_bindings[instance.bindings[i]][:3], local[i][3]) for i in order]
        guards = [(remap[b] if b < len(local) else b, op, v) for b, op, v in guards]
        actions = [(remap[b], op, remap[v] if op in (3, 6) else v) for b, op, v in actions]
        if int.from_bytes(behavior.operands[4:8], 'little') in (2, 3, 4, 5, 6):
            decoded = decode_query_operands(behavior.operands, 1)
            kinds = decoded[4] if len(decoded) == 5 else [0] * len(decoded[3])
            queries = [(remap[x], remap[y], w, h, remap[dx] if kinds[i] in (2, 3, 4) else dx,
                        remap[dy] if kinds[i] == 2 else dy)
                       for i,(x,y,w,h,dx,dy) in enumerate(decoded[3])]
            operands = compile_query_operands(bindings, guards, actions, queries, 1,
                occupancy=decoded[4] if len(decoded) == 5 else None)
        else:
            operands = compile_operands(bindings, guards, actions, 1)
        lowered = CompiledWorldReferences(world.map, operands,
            tuple(world.binding_sources[instance.bindings[i]] for i in order),
            tuple(g[0] for g in definition.guards), tuple(a[0] for a in definition.actions),
            behavior.logic.machines, ())
        # The host evaluator requires a presentation shell. Its inherited wait
        # interests are not behavior inputs; only addressed events run here.
        local_scene = deepcopy(definition.bundle.scenes[0])
        local_scene['reactive_wait_default']['event_interests'] = []
        local_scene['interaction_policy']['meaningful_activity_actions'] = []
        local_scene['entry_state'] = local_scene['machine_logic']['machines'][0]['entry_state']
        local_project = deepcopy(definition.bundle.project)
        local_project['entry_scene'] = local_scene['scene_id']
        if definition.terminal_programs is not None:
            local_project['execution_semantics'] = 'api120_v1'
            local_project.pop('authoring_mode', None)
        local_bundle = replace(definition.bundle, project=local_project, scenes=(local_scene,))
        context.players.append(create_world_preview(local_bundle, definition.scene_id, lowered,
            definition.attachments, write_capacity=write_capacity, camera=camera))
        if definition.terminal_programs is not None:
            context.players[-1]._scene['_terminal_order'] = True
            context.players[-1]._scene['_terminal_programs'] = definition.terminal_programs
        context.players[-1]._world_context.debug_properties = {prop.name:remap[i] for i,prop in enumerate(behavior.bindings.properties)}
        context.players[-1]._world_context.spatial = spatial
    context.spatial = spatial
    return context


def create_instance_preview(bundle, scene_id, world, attachments, source, **kwargs):
    context = create_instance_context(bundle, scene_id, world, attachments, source, **kwargs)
    return MachinePreview(build_preview_package(bundle), scene_id, _world_context=context)
