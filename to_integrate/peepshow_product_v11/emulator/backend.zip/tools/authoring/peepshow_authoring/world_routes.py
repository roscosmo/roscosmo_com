"""Private SMW1 route attachments; no source-schema or installed-export change."""
import struct

from .machine_wire import compile_machine_logic, require
from .world_references import CompiledWorldReferences
from .world_operands_wire import decode_typed_operands as decode_operands


class _Routes:
    def __init__(self, graph, lowered, attachments, flow_attachments=None):
        require(isinstance(lowered, CompiledWorldReferences), 'compiled world references required')
        machines = tuple(m['machine_id'] for m in graph['machines'])
        flows = tuple(f['flowchart_id'] for f in graph.get('flowcharts', []))
        require((machines, flows) == (lowered.machine_sources, lowered.flow_sources),
                'world and route machine/flow identities must match in order')
        bindings, guards, actions = decode_operands(lowered.operands, len(machines), len(flows))
        require(len(guards) == len(lowered.guard_sources) and len(actions) == len(lowered.action_sources),
                'world operand source counts differ')
        gi = {name: i for i, name in enumerate(lowered.guard_sources)}
        ai = {name: i for i, name in enumerate(lowered.action_sources)}
        routes = {r['route_id']: r for r in graph['routes']}
        require(type(attachments) is dict and not attachments.keys() - routes.keys(), 'unknown world route')
        self._guards, self._actions = {}, {}
        for name, addition in attachments.items():
            require(type(addition) is dict and set(addition) == {'guards', 'actions'}, 'invalid world route attachment')
            route = routes[name]
            outcomes = route.get('outcomes', [route])
            predicate_ids, per_outcome = addition['guards'], addition['actions']
            require(isinstance(predicate_ids, (list, tuple)) and
                    all(type(g) is str and g in gi for g in predicate_ids), 'unknown world guard')
            require(len(route['guards']) + len(predicate_ids) <= 8, 'guard capacity exceeded')
            require(isinstance(per_outcome, (list, tuple)) and len(per_outcome) == len(outcomes),
                    'world actions must explicitly address each outcome')
            self._guards[name] = tuple(gi[g] for g in predicate_ids)
            for oi, (outcome, inserts) in enumerate(zip(outcomes, per_outcome)):
                require(isinstance(inserts, (list, tuple)), 'world insertions must be a sequence')
                previous = -1
                checked = []
                for insert in inserts:
                    require(isinstance(insert, (list, tuple)) and len(insert) == 2, 'invalid world insertion')
                    position, identity = insert
                    require(type(position) is int and previous <= position <= len(outcome['actions']) and position >= 0,
                            'world action positions must be ordered original-action boundaries')
                    require(type(identity) is str and identity in ai, 'unknown world action')
                    operand = ai[identity]
                    require(route['machine_ref'] in machines and
                            bindings[actions[operand][0]][3] == machines.index(route['machine_ref']),
                            'world action attached to the wrong writer')
                    checked.append((position, operand))
                    previous = position
                require(len(outcome['actions']) + len(checked) + int('target_scene' in outcome) <= 8,
                        'action capacity exceeded')
                self._actions[name, oi] = tuple(checked)
        from .world_flows import WorldFlows
        self.flows = WorldFlows(graph, lowered, {} if flow_attachments is None else flow_attachments)

    def guards(self, route):
        return self._guards.get(route, ())

    def actions(self, route, outcome, ordinary):
        inserts = self.insertions(route, outcome)
        result, cursor = [], 0
        for position in range(len(ordinary) + 1):
            while cursor < len(inserts) and inserts[cursor][0] == position:
                result.append(struct.pack('<3Bxi', 10, 0, 0, inserts[cursor][1]))
                cursor += 1
            if position < len(ordinary):
                result.append(ordinary[position])
        return result

    def insertions(self, route, outcome):
        return self._actions.get((route, outcome), ())


def compile_world_machine_logic(bundle, scene_id, lowered, attachments, *, flow_attachments=None, **options):
    """Keep ordinary validated source unchanged; private attachments use route IDs.

    Each attachment has guards=[operand IDs] and actions=[insertions per outcome].
    Each insertion is (original action boundary, operand ID), in execution order.
    World guards AND with existing route guards. Insertions can precede SEND;
    a generated Scene-exit action stays last. Optional flow attachments address nodes.
    The returned payload borrows the separately compiled WOP1 identity contract.
    """
    scene = next((s for s in bundle.scenes if s['scene_id'] == scene_id), None)
    require(scene is not None and 'machine_logic' in scene, 'machine scene required')
    require('_world_routes' not in options, 'private route adapter cannot be overridden')
    adapter = _Routes(scene['machine_logic'], lowered, attachments, flow_attachments)
    return compile_machine_logic(bundle, scene_id, _world_routes=adapter, **options)
