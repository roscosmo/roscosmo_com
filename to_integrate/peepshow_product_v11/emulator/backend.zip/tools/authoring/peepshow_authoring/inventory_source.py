"""Bounded item catalog and placed pickups, using existing atomic preview work."""
from copy import deepcopy
from .inventory_conditions import CAPABILITY as CONDITION_CAPABILITY

COMMAND_FIELDS = {
    'project.inventory.set': ('inventory',),
    'project.inventory.configure': ('inventory_id', 'reset_on_restart', 'reset_variables'),
    'project.inventory.item.upsert': ('item',),
    'project.inventory.item.remove': ('item_id',),
    'project.inventory.remove': (),
    'scene.pickup.upsert': ('scene_id', 'pickup'),
    'scene.pickup.remove': ('scene_id', 'pickup_id'),
}
COMMANDS = tuple(COMMAND_FIELDS)
CAPABILITY = dict(source_version=1, commands=list(COMMANDS),
    schema='schemas/authoring/inventory-v1.schema.json',
    pickup_schema='schemas/authoring/pickup-v1.schema.json',
    command_schema='schemas/authoring/inventory-command-v1.schema.json',
    command_fields={kind: list(fields) for kind, fields in COMMAND_FIELDS.items()},
    inspection=dict(operation='project.inventory.inspect', references='authored_source_only',
        reference_kinds=['pickup', 'menu_entry', 'menu_quantity', 'condition'], includes_live_counts=False),
    conditions=CONDITION_CAPABILITY,
    editing=dict(empty_catalog=True, item_update='replace_one_record',
        configure_preserves_items=True, inventory_identity_change='explicit_whole_catalog_edit',
        item_identity_change='explicit_new_item_and_rebinding',
        deletion='reject_references_after_complete_batch', implicit_rebinding=False),
    items=32, pickups_per_scene=64, collection='accepted_position_change',
    full_inventory='leave_pickup', persistence='between_scenes_in_preview_session',
    restart='explicit_inventory_and_selected_package_variable_reset',
    host_editing=True, persisted=True, undo_redo=True, host_preview=True,
    preview_requires='scope_host_v1', preview_scene_model='scene_machines_v1', runtime=False, export=False,
    runtime_collections=False, consumption=False)


def fail(message):
    from .project import ProjectCommandError
    raise ProjectCommandError('INVENTORY_INVALID', message)


def record(value, required, optional=()):
    if type(value) is not dict or not set(required) <= value.keys() or value.keys()-set(required)-set(optional):
        fail('inventory: expected '+str(required))


def identity(value):
    from .project import STABLE_ID
    if type(value) is not str or not STABLE_ID.fullmatch(value):
        fail('inventory: expected stable identity')


def editable_catalog(project):
    """Shape-check intermediate batches without resolving forward references."""
    value = project['inventory']
    record(value, ('version','inventory_id','items','reset_on_restart','reset_variables'))
    if type(value['items']) is not list:
        fail('inventory.items must be an array')
    for item in value['items']:
        record(item, ('item_id','display_name','initial_count','max_count'))
        identity(item['item_id'])
    return value


def catalog(project):
    if 'inventory' not in project:
        return {}
    value = project['inventory']
    record(value, ('version','inventory_id','items','reset_on_restart','reset_variables'))
    if type(value['version']) is not int or value['version'] != 1 or type(value['reset_on_restart']) is not bool:
        fail('inventory: requires version 1 and Boolean restart policy')
    identity(value['inventory_id'])
    if type(value['items']) is not list or not 0 <= len(value['items']) <= 32:
        fail('inventory: supports at most 32 predefined items')
    result = {}
    for item in value['items']:
        record(item, ('item_id','display_name','initial_count','max_count'))
        identity(item['item_id'])
        if item['item_id'] in result or type(item['display_name']) is not str or not 1 <= len(item['display_name']) <= 96:
            fail('inventory: duplicate item or invalid display name')
        if any(type(item[k]) is not int for k in ('initial_count','max_count')) or not 0 <= item['initial_count'] <= item['max_count'] <= 65535 or item['max_count'] == 0:
            fail('inventory: invalid bounded counts')
        result[item['item_id']] = item
    resets = value['reset_variables']
    variables = {v['variable_id'] for v in project.get('package_variables', [])}
    if type(resets) is not list or any(type(v) is not str or v not in variables for v in resets) or len(set(resets)) != len(resets):
        fail('inventory: reset_variables must name unique package variables')
    if resets and not value['reset_on_restart']:
        fail('inventory: reset_variables requires reset_on_restart')
    return result


def validate_scene(project, scene):
    items = catalog(project)
    pickups = scene.get('pickups', [])
    if type(pickups) is not list or len(pickups) > 64:
        fail('pickups: requires at most 64 placements')
    positions = {p['object_ref'] for p in scene.get('machine_logic', {}).get('world_positions', [])}
    objects = {o['object_id']: o for o in scene.get('objects', [])}
    seen, bound = set(), set()
    for p in pickups:
        record(p, ('pickup_id','object_ref','collector_ref','item_ref','quantity'))
        for key in ('pickup_id','object_ref','collector_ref','item_ref'): identity(p[key])
        if p['pickup_id'] in seen or p['object_ref'] in bound:
            fail('pickups: duplicate identity or object')
        seen.add(p['pickup_id']); bound.add(p['object_ref'])
        if p['item_ref'] not in items:
            fail(f"Scene {scene['scene_id']} pickup {p['pickup_id']}: unknown item {p['item_ref']}")
        if p['object_ref'] not in positions or p['collector_ref'] not in positions or p['object_ref'] == p['collector_ref']:
            fail('pickups: requires known item and distinct world-bound pickup/collector objects')
        if type(p['quantity']) is not int or not 1 <= p['quantity'] <= items[p['item_ref']]['max_count']:
            fail('pickups: quantity must fit the item capacity')
    menu = scene.get('menu_component', {})
    for page in menu.get('pages', []):
        for entry in page['entries']:
            if entry.get('kind') == 'inventory':
                record(entry, ('entry_id','label','kind','inventory_item_ref'),
                       ('visible_when','enabled_when','disabled_reason'))
            if 'inventory_item_ref' in entry:
                if (menu.get('version') != 2 or type(entry['inventory_item_ref']) is not str
                        or entry['inventory_item_ref'] not in items or entry['kind'] not in ('choice','inventory')):
                    fail(f"Scene {scene['scene_id']} menu {menu.get('menu_id')} page {page['page_id']} entry {entry['entry_id']}: requires V2 choice/inventory entry and known item {entry['inventory_item_ref']}")
    for b in menu.get('presentation', {}).get('bindings', []):
        if 'quantity_item_ref' not in b:
            continue
        obj = objects.get(b['object_ref'], {})
        if type(b['quantity_item_ref']) is not str or b['quantity_item_ref'] not in items or obj.get('kind') != 'text':
            fail(f"Scene {scene['scene_id']} menu quantity object {b['object_ref']}: requires known item {b['quantity_item_ref']} and ordinary text object")
        from .system_fonts import runtime_text_layout, SystemFontError
        try:
            runtime_text_layout(str(items[b['quantity_item_ref']]['max_count']),
                obj.get('font_id'), obj.get('scale'), obj.get('alignment'), obj.get('width'), obj.get('height'))
        except SystemFontError as exc:
            fail('menu quantity binding: maximum count does not fit: '+str(exc))


def apply_command(project, scenes, command):
    from .project import _command_scene, _require_command_fields
    kind = command['kind']
    fields = set(COMMAND_FIELDS[kind]) | {'kind'}
    _require_command_fields(command, fields, fields | {'command_id'})
    if kind == 'project.inventory.set':
        project['inventory'] = deepcopy(command['inventory'])
    elif kind == 'project.inventory.configure':
        value = editable_catalog(project) if 'inventory' in project else None
        if value is not None and value['inventory_id'] != command['inventory_id']:
            fail('inventory.configure cannot change inventory identity; use an explicit whole-catalog edit')
        project['inventory'] = dict(version=1, inventory_id=command['inventory_id'],
            reset_on_restart=command['reset_on_restart'], reset_variables=deepcopy(command['reset_variables']),
            items=deepcopy(value['items']) if value is not None else [])
    elif kind == 'project.inventory.remove':
        if 'inventory' not in project:
            fail('inventory does not exist')
        del project['inventory']
    elif kind.startswith('project.inventory.item.'):
        if 'inventory' not in project:
            fail('configure an inventory before editing items')
        rows = editable_catalog(project)['items']
        value = command.get('item')
        ref = value.get('item_id') if type(value) is dict else command.get('item_id')
        identity(ref)
        index = next((i for i, item in enumerate(rows) if item['item_id'] == ref), None)
        if kind.endswith('upsert'):
            if index is None:
                rows.append(deepcopy(value))
            else:
                rows[index] = deepcopy(value)
        elif index is None:
            fail('item does not exist: ' + ref)
        else:
            rows.pop(index)
    else:
        scene = _command_scene(scenes, command['scene_id'])
        rows = scene.setdefault('pickups', [])
        value = command.get('pickup')
        ref = value.get('pickup_id') if type(value) is dict else command.get('pickup_id')
        identity(ref)
        index = next((i for i,p in enumerate(rows) if p['pickup_id']==ref), None)
        if kind.endswith('upsert'):
            if index is None: rows.append(deepcopy(value))
            else: rows[index] = deepcopy(value)
        elif index is None: fail('pickup does not exist')
        else: rows.pop(index)
    return deepcopy(command)


def inspect_source(project, scenes):
    """Read actual authored references; never infer connections from artwork."""
    value = project.get('inventory')
    result = dict(inventory_id=value['inventory_id'] if value is not None else None,
                  configuration=({key: deepcopy(value[key]) for key in
                      ('version', 'reset_on_restart', 'reset_variables')} if value is not None else None),
                  items=[])
    if value is None:
        return result
    references = {item['item_id']: [] for item in value['items']}
    for scene in scenes:
        sid = scene['scene_id']
        from .inventory_conditions import locations
        for path, condition in locations(scene):
            references[condition['item_ref']].append(dict(kind='condition', scene_id=sid,
                source_path=list(path), operator=condition['operator'], value=condition['value']))
        for pickup in scene.get('pickups', []):
            references[pickup['item_ref']].append(dict(kind='pickup', scene_id=sid,
                pickup_id=pickup['pickup_id'], object_ref=pickup['object_ref'],
                collector_ref=pickup['collector_ref'], quantity=pickup['quantity']))
        menu = scene.get('menu_component', {})
        for page in menu.get('pages', []):
            for entry in page['entries']:
                if 'inventory_item_ref' in entry:
                    references[entry['inventory_item_ref']].append(dict(kind='menu_entry',
                        scene_id=sid, menu_id=menu['menu_id'], page_id=page['page_id'],
                        entry_id=entry['entry_id'], entry_kind=entry['kind']))
        for binding in menu.get('presentation', {}).get('bindings', []):
            if 'quantity_item_ref' in binding:
                references[binding['quantity_item_ref']].append(dict(kind='menu_quantity',
                    scene_id=sid, menu_id=menu['menu_id'], page_id=binding['page_ref'],
                    object_ref=binding['object_ref'], entry_id=binding.get('entry_ref')))
    result['items'] = [dict(definition=deepcopy(item), references=references[item['item_id']])
                       for item in value['items']]
    return result


def collect(player, previous):
    """Called on the private event candidate after all deliveries succeeded."""
    source = player._scope_sources.get(player.scene_id, {})
    if not source.get('pickups') or previous._world_context is None:
        return
    if (previous.scene_id != player.scene_id or player._scope_input.scope != 'gameplay'
            or player._scope_input.generation != previous._scope_input.generation):
        return  # Scene entry/restart is not a walk onto a pickup.
    def position(p, ref):
        w = p._world_context
        entity = w.positions[ref][0]
        return w.values[3,entity], w.values[4,entity]
    items = {i['item_id']:i for i in source['_inventory_catalog']['items']}
    for pickup in source['pickups']:
        key = player.scene_id + '/' + pickup['pickup_id']
        if key in player._inventory_state['collected']:
            continue
        ref = pickup['collector_ref']
        if position(previous, ref) == position(player, ref) or position(player, ref) != position(player, pickup['object_ref']):
            continue
        item, amount = pickup['item_ref'], pickup['quantity']
        count = player._inventory_state['counts'][item]
        if count + amount > items[item]['max_count']:
            continue
        player._inventory_state['counts'][item] = count + amount
        player._inventory_state['collected'].append(key)


def masked(player, object_ref):
    return any(p['object_ref']==object_ref and player.scene_id+'/'+p['pickup_id'] in player._inventory_state['collected']
               for p in player._scope_sources.get(player.scene_id, {}).get('pickups', []))
