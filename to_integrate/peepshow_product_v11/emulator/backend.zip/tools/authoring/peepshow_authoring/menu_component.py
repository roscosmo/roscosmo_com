"""Versioned Menu source, public edits and negotiated host preview admission.

No generated navigation machines are written into authored source. The existing
scope lifecycle supplies input/audio ownership. Device execution stays refused.
"""
from copy import deepcopy

COMMANDS = ('scene.menu.set', 'scene.menu.clear', 'scene.menu.page.upsert',
            'scene.menu.page.remove', 'scene.menu.entry.upsert',
            'scene.menu.entry.remove', 'scene.menu.entry.move',
            'scene.menu.scope.set', 'scene.menu.binding.upsert', 'scene.menu.binding.remove')
LIMITS = dict(pages=32, entries=256, entries_per_page=64, depth=8, drafts=16,
              label_characters=96, visible_rows=24)
CAPABILITY = dict(status='host_preview_opt_in', source_version=1, field='menu_component',
    schema='schemas/authoring/menu-component-v1.schema.json', commands=list(COMMANDS),
    host_editing=True, persisted=True, undo_redo=True, host_preview=False,
    runtime=False, export=False, hardware_validation='not_qualified',
    modes=['pause'], entry_kinds=['submenu', 'choice', 'action'],
    action_operations=['confirm', 'cancel'], hierarchy='rooted_tree',
    maximum_components_per_scene=1, draft_types=['bool', 'int32'],
    choice_modes=['highlight', 'stage_on_navigation'], choice_results=['stay', 'back', 'confirm'],
    source_limits=LIMITS, source_limits_are_device_capacity=False,
    conditions='boolean_or_state_variable_inventory_predicate_without_world_operands',
    arbitrary_activation_actions=False, live_overlay=False,
    requires_for_execution=['device_navigation_and_presentation', 'device_qualification'],
    validation_error='MENU_COMPONENT_INVALID', preview_error='MENU_COMPONENT_PREVIEW_UNAVAILABLE',
    readiness_error='MENU_COMPONENT_DEVICE_UNAVAILABLE')

CAPABILITY['preview_adapter'] = dict(version=1, host_preview=True,
    reset_option={'scope_host': {'version': 1}}, requires_machine_scene=True,
    ownership='all_authored_gameplay_paused_component_owns_menu',
    input='existing_scope_host_generations_and_held_snapshots',
    audio='existing_scope_host_stop_receipts', navigation=True, scrolling=True,
    drafts=True, atomic_apply=True, system_shell_resume=True,
    render='bounded_system_font_list', snapshot='menu_component',
    menu_audio=True, menu_audio_operations=['navigation_sfx'], navigation_sfx=True,
    menu_timers=False, live_overlay=False, runtime=False, export=False)
CAPABILITY['opening'] = dict(action_kind='menu.open', target_field='menu_ref',
    placement='ordinary_machine_root_route', legacy_input_binding=True,
    component_visibility_policy=True, sole_route_action=True,
    state_or_scene_change=False, flow_or_queued_event=False,
    action_example={'kind':'menu.open', 'menu_ref':'equipment'})

CAPABILITY.update(source_version=2, source_versions=[1,2],
    entry_kinds=['submenu','choice','action','event','inventory'],
    entry_kinds_by_version={'1':['submenu','choice','action'],'2':['submenu','choice','action','event','inventory']},
    schemas_by_version={'1':'schemas/authoring/menu-component-v1.schema.json','2':'schemas/authoring/menu-component-v2.schema.json'},
    schema='schemas/authoring/menu-component-v2.schema.json')
CAPABILITY['navigation_wrapper']=dict(source_version=2, presentation=['legacy_list','scene_objects'],
    graphic_text_required=False, entry_event=True, event_recipient='menu_owned_machine',
    appearance_overrides=['when_chosen','when_selected','when_disabled'],
    appearance_order=['base','when_chosen','when_selected','when_disabled'],
    chosen_value='menu_draft_not_applied_gameplay_value', chosen_requires='choice_entry',
    directional_neighbors=True, conditional_catalog=True, runtime_collections=False,
    inventory_item_binding=True, inventory_quantity_text=True,
    menu_owned_machines=True, menu_owned_objects=True, menu_owned_timers=True,
    host_preview=True,runtime=False,export=False)
from .inventory_conditions import CAPABILITY as INVENTORY_CONDITION_CAPABILITY
CAPABILITY['inventory_conditions'] = INVENTORY_CONDITION_CAPABILITY
CAPABILITY['preview_adapter'].update(ownership='declared_gameplay_and_menu_scopes',
    render='list_or_scene_objects',menu_timers=True,
    menu_behavior_audio='source_v2_existing_actions_on_menu_owned_machine',
    menu_timer_requires='source_v2_menu_owned_machine')
CAPABILITY['object_editing'] = dict(source_version=2,
    commands=['scene.menu.scope.set', 'scene.menu.binding.upsert', 'scene.menu.binding.remove'],
    command_schema='schemas/authoring/menu-object-command-v1.schema.json',
    binding_identity='object_ref', scope_change='explicit',
    remove_binding='keep_object_and_menu_ownership', validation='atomic_batch',
    host_preview=True, runtime=False, export=False)


def fail(path, message):
    from .project import ProjectCommandError
    raise ProjectCommandError('MENU_COMPONENT_INVALID', f'{path}: {message}')


def record(value, required, optional, path):
    if type(value) is not dict or not set(required) <= value.keys() or value.keys() - set(required) - set(optional):
        fail(path, f'expected {sorted(required)}; optional {sorted(optional)}')


def ident(value, path):
    from .project import STABLE_ID
    if type(value) is not str or not STABLE_ID.fullmatch(value):
        fail(path, 'expected a stable identity')
    return value


def text(value, path):
    if type(value) is not str or not 1 <= len(value) <= LIMITS['label_characters']:
        fail(path, f"expected 1..{LIMITS['label_characters']} characters")


def rows(value, key, maximum, path):
    if type(value) is not list or len(value) > maximum:
        fail(path, f'expected an array of at most {maximum} records (source limit, not device capacity)')
    result = {}
    for index, row in enumerate(value):
        if type(row) is not dict:
            fail(f'{path}[{index}]', 'expected an object')
        name = ident(row.get(key), f'{path}[{index}].{key}')
        if name in result:
            fail(path, f'duplicate {key} {name!r}')
        result[name] = row
    return result


def validate(project, scene, audio_cue_ids=()):
    if 'menu_component' not in scene:
        return
    path = f"scenes[{scene.get('scene_id', '?')}].menu_component"
    if scene.get('schema_version') != 2:
        fail(path, 'requires a version 2 Scene')
    menu = scene['menu_component']
    if type(menu) is dict and menu.get('version') == 2:
        from .menu_navigation import validation_view
        try:
            validate(project, validation_view(project,scene), audio_cue_ids)
        except (KeyError,TypeError,AttributeError) as exc:
            fail(path,'malformed V2 navigation source: '+str(exc))
        return
    record(menu, ('version', 'menu_id', 'mode', 'root_page', 'input_map',
        'hide_world', 'wrap', 'root_back', 'presentation', 'drafts', 'pages'), ('open', 'apply_owner', 'navigation_sfx'), path)
    if type(menu['version']) is not int or menu['version'] != 1 or menu['mode'] != 'pause':
        fail(path, 'requires version 1 and mode pause; Live Overlay is not implemented')
    ident(menu['menu_id'], path+'.menu_id')
    if 'navigation_sfx' in menu:
        cue = ident(menu['navigation_sfx'], path+'.navigation_sfx')
        if cue not in audio_cue_ids:
            fail(path+'.navigation_sfx', 'unknown audio cue')
    if menu['root_back'] != 'cancel':
        fail(path+'.root_back', 'only cancel is supported; confirm must be explicit')
    for key in ('hide_world', 'wrap'):
        if type(menu[key]) is not bool:
            fail(path+'.'+key, 'expected Boolean')
    graph = scene.get('machine_logic', {})
    if 'execution_scopes' in graph:
        fail(path, 'cannot combine a component with an authored menu scope; migrate explicitly in one transaction')
    machines = {m['machine_id']: m for m in graph.get('machines', [])}
    states = {s['state_id']: s for s in scene.get('states', [])}
    from .presentation_selectors import predicate_tokens, variable_definitions
    from .project import ProjectCommandError
    variables = variable_definitions(project, scene)
    from .inventory_source import catalog
    inventory_items = catalog(project)

    def condition(value, at):
        if type(value) is bool:
            return
        try:
            predicate_tokens(value, machines, states, variables=variables, inventory_items=inventory_items)
        except (ProjectCommandError, KeyError, TypeError, ValueError) as exc:
            fail(at, str(exc))

    inputs = {a['action_id']: a['logical_source'] for a in scene.get('input_actions', [])}
    if 'open' in menu:
        record(menu['open'], ('action_ref',), ('when',), path+'.open')
        action = ident(menu['open']['action_ref'], path+'.open.action_ref')
        if action not in inputs:
            fail(path+'.open', 'unknown Scene input action')
        condition(menu['open'].get('when', True), path+'.open.when')
    mapping = menu['input_map']
    record(mapping, ('previous', 'next', 'activate', 'back'), (), path+'.input_map')
    used = set()
    for operation, refs in mapping.items():
        at = path+'.input_map.'+operation
        if type(refs) is not list or not 1 <= len(refs) <= 8:
            fail(at, 'expected one to eight Scene input action identities')
        for ref in refs:
            ident(ref, at)
            if ref not in inputs or inputs[ref] in used:
                fail(at, 'unknown or duplicate input binding within the Menu focus')
            used.add(inputs[ref])

    display = menu['presentation']
    record(display, ('x', 'y', 'width', 'height', 'row_height', 'visible_rows', 'font_id'), (), path+'.presentation')
    for key in ('x', 'y', 'width', 'height', 'row_height', 'visible_rows'):
        if type(display[key]) is not int or not (0 if key in ('x','y') else 1) <= display[key] <= 512:
            fail(path+'.presentation.'+key, 'expected a bounded integer')
    if display['visible_rows'] > LIMITS['visible_rows'] or display['visible_rows'] * display['row_height'] > display['height']:
        fail(path+'.presentation', 'visible rows exceed source limit or configured height')
    if display['font_id'] != 'peepshow.system.8x8.basic.v1' or display['row_height'] < 8:
        fail(path+'.presentation', 'initial source supports system 8x8 font and rows at least eight pixels high')

    drafts = rows(menu['drafts'], 'draft_id', LIMITS['drafts'], path+'.drafts')
    owner = menu.get('apply_owner')
    if drafts or 'apply_owner' in menu:
        ident(owner, path+'.apply_owner')
        if owner not in machines:
            fail(path+'.apply_owner', 'expected the declared gameplay apply machine')
    writes = {(v['scope'], v['variable_ref']) for v in machines.get(owner, {}).get('variable_writes', [])}
    sources = set()
    for name, draft in drafts.items():
        at = path+f'.drafts[{name}]'
        record(draft, ('draft_id', 'source'), (), at)
        ref = draft['source']
        record(ref, ('variable_scope', 'variable_ref'), (), at+'.source')
        scope = ref['variable_scope']
        if scope not in ('scene','package'):
            fail(at, 'expected scene or package variable scope')
        ident(ref['variable_ref'], at+'.source.variable_ref')
        key = (scope, ref['variable_ref'])
        if key not in variables or key not in writes or key in sources:
            fail(at, 'draft requires a unique existing variable written by the declared apply owner')
        other = [m['machine_id'] for m in machines.values() if m['machine_id'] != owner and
                 any((v['scope'], v['variable_ref']) == key for v in m.get('variable_writes', []))]
        if other:
            fail(at, f'conflicting gameplay writer: {other}')
        sources.add(key)

    pages = rows(menu['pages'], 'page_id', LIMITS['pages'], path+'.pages')
    root = ident(menu['root_page'], path+'.root_page')
    if root not in pages:
        fail(path+'.root_page', 'unknown root page')
    parents, children, total = {}, {p: [] for p in pages}, 0
    for name, page in pages.items():
        at = path+f'.pages[{name}]'
        record(page, ('page_id','title','entries'), ('initial_entry','initial_draft','choice_mode','choice_result'), at)
        text(page['title'], at+'.title')
        entries = rows(page['entries'], 'entry_id', LIMITS['entries_per_page'], at+'.entries')
        total += len(entries)
        if total > LIMITS['entries']:
            fail(path+'.pages', f"requires {total} entries, source capacity {LIMITS['entries']}")
        mode, result = page.get('choice_mode','highlight'), page.get('choice_result','stay')
        if mode not in ('highlight','stage_on_navigation') or result not in ('stay','back','confirm'):
            fail(at, 'unsupported choice mode/result')
        if result == 'back' and name == root:
            fail(at, 'root choice page has no parent to return to')
        if 'initial_entry' in page and 'initial_draft' in page:
            fail(at, 'choose initial_entry or initial_draft, not both')
        if 'initial_entry' in page and ident(page['initial_entry'], at+'.initial_entry') not in entries:
            fail(at+'.initial_entry', 'unknown entry')
        values, choice_bindings = set(), set()
        for eid, entry in entries.items():
            ep = at+f'.entries[{eid}]'
            kind = entry.get('kind')
            fields = {'submenu': ('page_ref',), 'choice': ('draft_ref','value'), 'action': ('operation',)}
            if type(kind) is not str or kind not in fields:
                fail(ep, 'supported entry kinds are submenu, choice and action')
            record(entry, ('entry_id','label','kind', *fields[kind]), ('visible_when','enabled_when','disabled_reason'), ep)
            text(entry['label'], ep+'.label')
            if 'disabled_reason' in entry:
                text(entry['disabled_reason'], ep+'.disabled_reason')
            for field in ('visible_when','enabled_when'):
                condition(entry.get(field, True), ep+'.'+field)
            if kind == 'submenu':
                target = ident(entry['page_ref'], ep+'.page_ref')
                if target not in pages or target == root or target in parents:
                    fail(ep+'.page_ref', 'expected a non-root page with exactly one parent')
                parents[target] = name
                children[name].append(target)
            elif kind == 'choice':
                ref = ident(entry['draft_ref'], ep+'.draft_ref')
                if ref not in drafts:
                    fail(ep+'.draft_ref', 'unknown draft binding')
                binding = drafts[ref]['source']
                definition = variables[(binding['variable_scope'],binding['variable_ref'])]
                value = entry['value']
                if type(value) is not (bool if definition['value_type'] == 'bool' else int):
                    fail(ep+'.value', 'choice value type must match the bound variable')
                if definition['value_type'] == 'int32' and not definition['minimum'] <= value <= definition['maximum']:
                    fail(ep+'.value', 'choice is outside the declared variable range')
                key = (ref, value)
                if key in values:
                    fail(ep+'.value', 'duplicate choice value for the same draft on this page')
                values.add(key)
                choice_bindings.add(ref)
            elif entry['operation'] not in ('confirm','cancel'):
                fail(ep+'.operation', 'only explicit confirm/cancel close operations are supported in this source increment')
            if kind == 'action' and entry['operation'] == 'confirm' and not drafts:
                fail(ep, 'confirm requires draft bindings and an apply owner')
        if 'initial_draft' in page and ident(page['initial_draft'], at+'.initial_draft') not in choice_bindings:
            fail(at+'.initial_draft', 'initial draft requires choice entries on this page')
        if mode == 'stage_on_navigation' and (len(choice_bindings) != 1 or any(e['kind'] != 'choice' for e in entries.values())):
            fail(at, 'stage-on-navigation requires a choice-only page with one draft binding')
        if result != 'stay' and not choice_bindings:
            fail(at, 'choice_result requires choice entries')
    # Iterative bounded traversal; unique parentage above excludes shared pages.
    visited, pending = set(), [(root, 1)]
    while pending:
        page, depth = pending.pop()
        if page in visited or depth > LIMITS['depth']:
            fail(path+'.pages', f"cyclic hierarchy or depth exceeds source limit {LIMITS['depth']}")
        visited.add(page)
        pending.extend((child, depth+1) for child in children[page])
    if visited != set(pages):
        fail(path+'.pages', f'unreachable pages or disconnected cycle: {sorted(set(pages)-visited)}')


def apply_command(scenes, command):
    from .project import _command_scene, _require_command_fields
    kind = command['kind']
    fields = {'scene.menu.set': {'menu'}, 'scene.menu.clear': set(),
        'scene.menu.page.upsert': {'page'}, 'scene.menu.page.remove': {'page_id'},
        'scene.menu.entry.upsert': {'page_id','entry'},
        'scene.menu.entry.remove': {'page_id','entry_id'},
        'scene.menu.entry.move': {'page_id','entry_id','before_entry'},
        'scene.menu.scope.set': {'scope'},
        'scene.menu.binding.upsert': {'binding'},
        'scene.menu.binding.remove': {'object_ref'}}[kind]
    required = {'kind','scene_id'} | fields
    _require_command_fields(command, required, required | {'command_id'})
    scene = _command_scene(scenes, command['scene_id'])
    if kind == 'scene.menu.set':
        scene['menu_component'] = deepcopy(command['menu'])
    elif kind == 'scene.menu.clear':
        scene.pop('menu_component', None)
    else:
        menu = scene.get('menu_component')
        if type(menu) is not dict:
            fail('command', 'create the Menu component first')
        if kind in CAPABILITY['object_editing']['commands']:
            if menu.get('version') != 2:
                fail('command', 'requires an explicitly authored V2 Menu; no automatic conversion')
            if kind == 'scene.menu.scope.set':
                menu['scope'] = deepcopy(command['scope'])
            else:
                view = menu['presentation']
                if view.get('kind') != 'objects':
                    fail('command', 'requires object presentation; no automatic conversion')
                value = command.get('binding')
                ref = value.get('object_ref') if type(value) is dict else command.get('object_ref')
                ident(ref, 'command.object_ref')
                bindings = view['bindings']
                index = next((i for i,b in enumerate(bindings) if b['object_ref'] == ref), None)
                if kind.endswith('.upsert'):
                    if index is None:
                        bindings.append(deepcopy(value))
                    else:
                        bindings[index] = deepcopy(value)
                elif index is None:
                    fail('command.object_ref', 'unknown menu binding')
                else:
                    bindings.pop(index)
            return deepcopy(command)
        rows(menu.get('pages'), 'page_id', LIMITS['pages'], 'command.menu.pages')
        if kind.startswith('scene.menu.page.'):
            collection, key, value = menu['pages'], 'page_id', command.get('page')
        else:
            matches = [p for p in menu['pages'] if p['page_id'] == command['page_id']]
            if not matches:
                fail('command.page_id', 'unknown page')
            rows(matches[0].get('entries'), 'entry_id', LIMITS['entries_per_page'], 'command.page.entries')
            collection, key, value = matches[0]['entries'], 'entry_id', command.get('entry')
        ref = value.get(key) if type(value) is dict else command.get(key)
        ident(ref, 'command.'+key)
        index = next((i for i,r in enumerate(collection) if r[key] == ref), None)
        if kind.endswith('.upsert'):
            if index is None:
                collection.append(deepcopy(value))
            else:
                collection[index] = deepcopy(value)
        else:
            if index is None:
                fail('command.'+key, 'unknown identity')
            if kind.endswith('.move'):
                before = command['before_entry']
                if before is not None:
                    ident(before, 'command.before_entry')
                    if before == ref or not any(r[key] == before for r in collection):
                        fail('command.before_entry', 'expected another existing entry or null for end')
                moved = collection.pop(index)
                target = len(collection) if before is None else next(i for i,r in enumerate(collection) if r[key] == before)
                collection.insert(target, moved)
            else:
                collection.pop(index)
    return deepcopy(command)


def preview_reason(scene, *, _graphics=False):
    """A stored source is not automatically a renderable executable preview."""
    menu = scene['menu_component']
    if menu.get('version') == 2:
        from .menu_navigation import validation_view
        return preview_reason(validation_view({},scene), _graphics=menu['presentation'].get('kind')=='objects')
    graph = scene.get('machine_logic')
    if graph is None:
        return 'component preview currently requires ordinary Scene machines; legacy route Scenes remain source-only'
    if graph.get('time_reconcile') or any(b['event_type'] == 'time.local_schedule' for b in scene.get('event_bindings', [])):
        return 'calendar reconciliation is not connected to component pause'
    if 'map_scene' in graph and 'visibility' not in graph['map_scene']:
        return 'map component preview requires explicit map visibility'
    from .preview import DISPLAY_WIDTH, DISPLAY_HEIGHT
    view = menu['presentation']
    if (view['x']+view['width'] > DISPLAY_WIDTH or view['y']+view['height'] > DISPLAY_HEIGHT
            or view['width'] < 24 or 8+view['visible_rows']*view['row_height'] > view['height']):
        return 'presentation requires on-screen bounds, a title row and the declared visible rows'
    from .system_fonts import runtime_text_layout, SystemFontError
    for page in ([] if _graphics else menu['pages']):
        for location, label in [(f"pages[{page['page_id']}].title", page['title'])] + [
                (f"pages[{page['page_id']}].entries[{e['entry_id']}].label", e['label']) for e in page['entries']]:
            try:
                runtime_text_layout(label, view['font_id'], 1, 'left', view['width']-16, 8)
            except SystemFontError as exc:
                return location+': '+str(exc)
    inputs = {a['action_id']: a for a in scene['input_actions']}
    refs = ({menu['open']['action_ref']} if 'open' in menu else set()) | {r for refs in menu['input_map'].values() for r in refs}
    if any(inputs[r].get('logical_event', 'press') != 'press' for r in refs):
        return 'component controls require press input bindings; directional repeat is handled by the component'
    return None


def readiness_issues(bundle, *, preview=False, scope_host=False):
    code = 'MENU_COMPONENT_PREVIEW_UNAVAILABLE' if preview else 'MENU_COMPONENT_DEVICE_UNAVAILABLE'
    issues = []
    for scene in bundle.scenes:
        if 'menu_component' not in scene:
            continue
        reason = (preview_reason(scene) if scope_host else 'negotiate scope_host version 1 for Menu input and audio ownership') if preview else 'Menu device execution is not connected'
        if reason:
            issues.append(dict(code=code, path=f"scenes[{scene['scene_id']}].menu_component", message=code+': '+reason))
    return issues


def require_execution_ready(bundle, *, preview=False):
    problems = readiness_issues(bundle, preview=preview)
    if problems:
        from .compiler import EggCompileError
        raise EggCompileError(problems[0]['message'])
