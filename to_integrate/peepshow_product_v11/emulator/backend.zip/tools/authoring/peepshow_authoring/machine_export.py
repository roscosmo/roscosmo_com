"""Restricted flash-backed HW6 machine export; exact working-set admission remains required."""
from copy import deepcopy
from itertools import product
from math import prod
import struct

from .v2_export import LIMITS, issue, animation_admission, public_object_clipping_profile, public_object_inversion_profile
from .machine_limits import MACHINES, STATES, ROUTES, EVENTS, NAMED_EVENTS, INPUTS, FLOWCHARTS, TIMERS
from .target_profile import TARGET_PROFILE
from .presentation_selectors import variable_comparison_capability

PROFILE_ID = 'hw6_machines_resident_v1'
# Work bound only: larger families use conservative resource envelopes, not a
# package rejection. This is deliberately not exposed as a target capability.
MAX_EXACT_ANIMATION_PROFILES = 256
MAX_SCENES = 8
MAX_EFFECT_TARGETS = 8
MAX_PACKAGE_BYTES = TARGET_PROFILE['package']['maximum_bytes']
SCENE_EXIT_TRIGGERS = ['direct_input', 'timer', 'addressed_named_event', 'animation_completion']
ACTION_KINDS = ['scene.set_inversion', 'set_variable', 'send_event', 'play_sfx', 'request_render',
                'start_timer', 'restart_timer', 'cancel_timer', 'object.set_position',
                'object.move_by', 'object.set_visibility', 'object.set_frame', 'object.clear_frame',
                'object.set_inversion', 'run_flowchart', 'object.play_effect',
                'object.play_clip', 'object.cancel_clip']


def public_profile():
    from .presentation_working_set import capability
    return {
        'profile_id': PROFILE_ID, 'profile_revision': 22, 'container_version': 2,
        'bound_text': capability(),
        'selector_variable_comparison': variable_comparison_capability(),
        'object_clipping': public_object_clipping_profile(),
        'object_inversion': public_object_inversion_profile(),
        'immediate_send_graph': 'machine_event_address',
        'object_clips': True, 'maximum_object_clip_targets': 8, 'maximum_object_clip_instances': 8,
        'object_clip_hardware_validation': 'pending',
        'local_time_conditions': True, 'time_reconciliation': True,
        'local_time_hardware_validation': 'pending',
        'random_delay_timers': True, 'random_delay_hardware_validation': 'pending',
        'scene_inversion': True, 'scene_inversion_hardware_validation': 'pending',
        'execution_model': 'scene_machines_v1', 'status': 'development_restricted',
        'maximum_scenes': MAX_SCENES, 'maximum_objects': LIMITS['objects'], 'maximum_states': STATES,
        'maximum_machines': MACHINES, 'maximum_routes': ROUTES, 'maximum_guards_per_route': 8,
        'maximum_outcomes_per_route': 8, 'maximum_actions_per_outcome': 8,
        'maximum_variables': 32, 'maximum_timers': TIMERS, 'maximum_events': EVENTS,
        'maximum_named_events': NAMED_EVENTS, 'maximum_inputs': INPUTS,
        'maximum_effects': 32,
        'object_effects': True, 'maximum_object_effect_targets': MAX_EFFECT_TARGETS,
        'maximum_object_effect_instances': MAX_EFFECT_TARGETS,
        'object_effect_kinds': ['invert', 'shake'],
        'object_effect_hardware_evidence': 'internal_bench_cadence_replace_exit_shell_resume_confirmed',
        'object_effect_public_artifact_validation': 'pending',
        'maximum_package_bytes': MAX_PACKAGE_BYTES,
        'package_loading': 'verified_flash_reader',
        'flash_backed_package_hardware_validation': 'pending',
        'timer_modes': ['time.scene_elapsed', 'time.state_entry_elapsed', 'time.local_schedule'],
        'relative_timer_modes': ['one_shot', 'periodic'],
        'periodic_hardware_evidence': 'counter_f9ed0904_cadence_controls_shell_scene_sleep_confirmed',
        'interaction_modes': ['continuous'], 'calendar_schedules': True,
        'scene_replacement': True, 'mixed_execution_models': False, 'scene_activated': True,
        'retain_state': True, 'scene_exit_triggers': list(SCENE_EXIT_TRIGGERS),
        'scene_exit_action_kinds': list(ACTION_KINDS), 'maximum_scene_exit_actions': 7,
        'scene_exit_transaction': 'settled_event_chain',
        'scene_exit_conflict_policy': 'reject_entire_transaction',
        'scene_exit_hardware_validation': 'pending',
        'maximum_exit_startup_audio_cues': 8,
        'authored_shell_exit': False, 'system_shell_pause_resume': True,
        'action_kinds': list(ACTION_KINDS),
        'callable_flowcharts': True, 'maximum_flowcharts': FLOWCHARTS, 'maximum_flowchart_nodes': 128,
        'resident_audio': True, 'maximum_audio_assets': LIMITS['audio_assets'],
        'maximum_audio_cues': LIMITS['audio_cues'],
        'shipping_build': False, 'device_exact_admission_required': True,
        'budget_method': 'animation_profiles_with_resource_envelope',
        'static_appearance_combinations': False,
        'analysis_work_fallback': 'conservative_per_object_animation_envelope',
        'flowchart_hardware_evidence': 'explicit_call_pet_cbeff66_confirmed',
        'hardware_evidence': 'studio_pet_11e1bac4_internal_path_confirmed',
        'public_artifact_hardware_validation': 'pending',
        'expanded_capacity_hardware_validation': 'pending',
        'retention_hardware_evidence': 'retained_pet_178e1fa6_scene_return_local_reset_shell_resume_reset_confirmed',
    }


def source_issues(bundle):
    from .tiled_assets import build_issues
    from .instance_project import readiness_issues
    from .execution_scope_source import readiness_issues as scope_issues
    problems = scope_issues(bundle) + readiness_issues(bundle) + build_issues(bundle)
    if problems:
        # Match compiler.build_readiness_issues: unsupported source has not been
        # lowered to the legacy device route shape used by the analysis below.
        return problems
    if not 1 <= len(bundle.scenes) <= MAX_SCENES or any('machine_logic' not in s for s in bundle.scenes):
        problems.append(issue('MACHINE_SCENE_PROFILE', 'scenes', 'Machine export requires one to eight machine scenes; mixed execution models are not supported.'))
    if bundle.project.get('validation', {}).get('build_profile') == 'shipping':
        problems.append(issue('V2_SHIPPING_UNAVAILABLE', 'validation.build_profile', 'Machine export is development-only.'))
    for scene in bundle.scenes:
        path = f"scenes[{scene['scene_id']}]"
        if scene['interaction_policy']['mode'] != 'continuous':
            problems.append(issue('MACHINE_INTERACTION_UNSUPPORTED', path, 'Machine export requires continuous interaction.'))
        graph = scene.get('machine_logic', {})
        from .object_clips import actions
        if len({a['object_ref'] for a in actions(scene) if a.get('kind') == 'object.play_clip'}) > 8:
            problems.append(issue('MACHINE_OBJECT_CLIP_CAPACITY', path,
                                  'Device clips support at most eight distinct target sprites per scene.'))
        effect_targets = {a['object_ref'] for r in graph.get('routes', [])
                          for o in r.get('outcomes', [r]) for a in o['actions']
                          if a.get('kind') == 'object.play_effect'}
        if len(effect_targets) > MAX_EFFECT_TARGETS:
            problems.append(issue('MACHINE_OBJECT_EFFECT_CAPACITY', path,
                                  f'Device effects support at most {MAX_EFFECT_TARGETS} distinct target sprites per scene.'))
        for route in graph.get('routes', []):
            for outcome in route.get('outcomes', [route]):
                if outcome.get('target_scene') == scene['scene_id']:
                    problems.append(issue('MACHINE_RESTART_UNAVAILABLE', path,
                        'Scene restart is currently available only in private map fixtures.'))
                if 'target_scene' not in outcome and 'scene_exit_ref' not in outcome:
                    continue
                if (route['machine_ref'] is None or 'target_state' in outcome or
                        len(outcome['actions']) > 7 or
                        any(a['kind'] == 'exit_to_shell' for a in outcome['actions'])):
                    problems.append(issue('MACHINE_SCENE_EXIT_UNSUPPORTED', path + '.machine_logic.routes',
                                          'Scene exits require a machine receiver and at most seven ordinary actions; no simultaneous State target or shell suspension.'))
        from .scene_exit_analysis import definite_conflicts
        for route_id, destinations in (definite_conflicts(graph) if graph else []):
            problems.append(issue('MACHINE_SCENE_EXIT_CONFLICT', path + f'.machine_logic.routes[{route_id}]',
                                  'One event chain requests different Scenes: ' + ', '.join(destinations)))
        for binding in scene.get('event_bindings', []):
            if binding['event_type'] not in ('time.scene_elapsed', 'time.state_entry_elapsed', 'time.local_schedule'):
                problems.append(issue('MACHINE_TIMER_UNSUPPORTED', path + '.event_bindings', 'Unsupported machine timer event type.'))
    return problems


def package_admission(package, size):
    problems, budgets = [], {}
    if not 1 <= len(package.scenes) <= MAX_SCENES or any(s.get('execution_model') != 3 for s in package.scenes):
        problems.append(issue('MACHINE_SCENE_PROFILE', 'scenes', 'Only one to eight all-machine scenes are supported.'))
        return dict(issues=problems, animation_budget=None, scene_animation_budgets={})
    for name, used, limit in (('bytes', size, MAX_PACKAGE_BYTES), ('strings', len(package.strings), LIMITS['strings']),
                              ('audio_assets', len(package.audio_assets), LIMITS['audio_assets']), ('audio_cues', len(package.audio_cues), LIMITS['audio_cues'])):
        if used > limit:
            problems.append(issue('MACHINE_CAPACITY', 'package.' + name, f'Machine {name} use {used}, limit {limit}.'))
    scene_ids = set(range(1, len(package.scenes) + 1))
    for scene in package.scenes:
        graph = scene['graph']
        if len({c['object_index'] for c in graph.get('clips', [])}) > 8:
            problems.append(issue('MACHINE_OBJECT_CLIP_CAPACITY', 'scenes', 'Too many clip targets.'))
        if len({e['object_index'] for e in graph.get('transients', [])}) > MAX_EFFECT_TARGETS:
            problems.append(issue('MACHINE_OBJECT_EFFECT_CAPACITY', 'scenes',
                                  f'Device effects support at most {MAX_EFFECT_TARGETS} distinct target sprites per scene.'))
        effects = graph['effects']
        exits = {i for i, (kind, _) in enumerate(effects) if kind == 5}
        used = set()
        for route in graph['routes']:
            for _, target, actions in route['outcomes']:
                refs = [a[1] for a in actions if a[0] == 8 and a[1] in exits]
                if not refs:
                    continue
                used.update(refs)
                if (route['machine'] >= graph['machine_count'] or route['event'] >= graph['event_count'] or target != 255 or
                        len(refs) != 1 or actions[-1][0:2] != (8, refs[0]) or
                        len(actions) > 8):
                    problems.append(issue('MACHINE_SCENE_EXIT_UNSUPPORTED', 'scenes', 'Invalid Scene exit receiver, target or ordered action list.'))
        if exits != used or any(effects[i][1] not in scene_ids or graph['effect_owners'][i] >= graph['machine_count'] for i in exits):
            problems.append(issue('MACHINE_SCENE_EXIT_UNSUPPORTED', 'scenes', 'Invalid scene-exit destination or owner.'))
        result = scene_admission(package, scene)
        problems.extend(result['issues'])
        budgets.update(result['scene_animation_budgets'])
    unique = {tuple(sorted(p.items())): p for p in problems}
    entry = package.manifest['entry_scene']
    return dict(issues=list(unique.values()), animation_budget=budgets.get(entry), scene_animation_budgets=budgets)


def _animation_options(scene):
    """All possible loop selections per object; static readings are one case.

    Static pixels still participate in composition and shared-row payloads. They
    are fixed during any autonomous program, so their different frame IDs cannot
    increase the number of recurring payload variants within that program.
    """
    options = [{obj['clip_index']} for obj in scene['objects']]
    for selector in scene['graph']['selectors']:
        options[selector['object_index']].update(rule['clip_index'] for rule in selector['rules'])
    for visual in scene['graph']['visuals']:
        options[visual['object_index']].add(visual['clip_index'])
    for clip in scene['graph'].get('clips', []):
        # A held one-shot frame suppresses a base loop. Active one-shots are live
        # work, not a new autonomous loop; the settled proof handles exclusions.
        options[clip['object_index']].add(65535)
    return options


def scene_admission(package, scene):
    problems, budgets = [], {}
    options = _animation_options(scene)
    profile_count = prod(len(values) for values in options)
    exact = profile_count <= MAX_EXACT_ANIMATION_PROFILES
    candidates = []
    if exact:
        for selection in product(*(sorted(values) for values in options)):
            variant = deepcopy(scene)
            for obj, clip in zip(variant['objects'], selection):
                obj['clip_index'] = clip
            candidates.append((variant, animation_admission(package, variant, distinct_bound=True)))
    else:
        candidates.append((scene, animation_admission(package, scene, distinct_bound=True, clip_options=options)))

    proof = None
    flow_objects = sorted({v['object_index'] for v in scene['graph']['visuals']})
    if exact and flow_objects and scene['graph'].get('clips') and any(r['issues'] for _, r in candidates):
        from .machine_waiting_analysis import autonomous_visuals
        proof = autonomous_visuals(scene)
    allowed = ({tuple(v[i] for i in flow_objects) for v in proof['autonomous_visuals']}
               if proof and proof['complete'] else None)
    analyses, live_only = [], 0
    for index, (variant, result) in enumerate(candidates):
        analysis = result['animation_budget']
        analysis.update(choice_id=f"{scene['scene_id']}:{index}", scene_id=scene['scene_id'],
            animation_choices=[dict(object_id=obj['object_id'],
                animation_ref=package.animations[obj['clip_index']]['animation_id']
                              if obj['clip_index'] != 65535 else None)
                for i, obj in enumerate(variant['objects']) if len(options[i]) > 1] if exact else [])
        key = tuple(variant['objects'][i]['clip_index'] for i in flow_objects)
        if allowed is not None and key not in allowed:
            analysis['mode'] = 'live_only'
            for resource in analysis['resources'].values():
                resource['status'] = 'not_applicable_live_only'
            live_only += 1
            # Timing, per-clip and ordinary object limits remain mandatory.
            choice_issues = [p for p in result['issues'] if not (
                p['code'] == 'V2_LPBAM_BUDGET' or
                p['code'] == 'V2_CAPACITY' and p['path'].endswith('.objects.animation_ref'))]
        else:
            analysis['mode'] = 'autonomous_or_unproven'
            choice_issues = result['issues']
        analysis['issues'] = choice_issues
        analysis['status'] = 'blocked' if choice_issues else 'passed_conservative'
        problems.extend(choice_issues)
        analyses.append(analysis)
    budgets[scene['scene_id']] = {
        'status': 'blocked' if problems else 'passed_conservative',
        'method': 'animation_profiles_with_resource_envelope',
        'analysis_strategy': 'individual_animation_profiles' if exact else 'per_object_animation_envelope',
        'animation_profile_count_upper_bound': profile_count, 'profiles_evaluated': len(candidates),
        'static_appearance_combinations': False,
        'choices': analyses, 'exact_device_admission_required': True,
        'live_only_profiles': live_only,
        'settled_analysis': ({k: v for k, v in proof.items() if k != 'autonomous_visuals'}
                             if proof else {'complete': False, 'reason': 'not_required' if exact else 'resource_envelope'}),
    }
    if scene['graph'].get('text_bindings'):
        from .presentation_working_set import scene_working_set
        working = scene_working_set(package, scene)
        budgets[scene['scene_id']]['working_set'] = working
        if working['status'] == 'blocked':
            problems.append(issue('MACHINE_TEXT_WORKING_SET', f"scenes[{scene['scene_id']}].objects",
                f"Conservative sprite working set uses {working['graphics_bytes_upper_bound']} bytes; "
                f"{working['graphics_capacity_bytes']} remain after frame descriptors and both text banks.", scene['scene_id']))
            budgets[scene['scene_id']]['status'] = 'blocked'
    unique = {tuple(sorted(p.items())): p for p in problems}
    return dict(issues=list(unique.values()), animation_budget=budgets.get(scene['scene_id']), scene_animation_budgets=budgets)


def build_checked(bundle):
    from .asset_library import package_assets
    bundle = package_assets(bundle)
    from .compiler import EggCompileError
    from .machine_package import encode_machine_package
    from .egg_format import parse_egg
    if not bundle.valid:
        raise EggCompileError('project must validate before machine export')
    problems = source_issues(bundle)
    if problems:
        raise EggCompileError('; '.join(p['message'] for p in problems))
    blob = encode_machine_package(bundle, _flowcharts=True, _object_effects=True, _calendars=True, _periodic=True)
    parse_egg(blob)
    return blob


def readiness_issues(bundle):
    return analyze_readiness(bundle)['issues']


def analyze_readiness(bundle):
    """Analyse structurally valid candidate bytes without admitting/exporting them."""
    from .asset_library import package_assets
    bundle = package_assets(bundle)
    from .compiler import EggCompileError
    from .egg_format import EggFormatError, parse_egg
    from .machine_package import encode_machine_package
    if not bundle.valid:
        return dict(issues=[], admission=None, reason='invalid_source')
    problems = source_issues(bundle)
    if problems:
        return dict(issues=problems, admission=None, reason='unsupported_source')
    try:
        blob = encode_machine_package(bundle, _flowcharts=True, _object_effects=True, _calendars=True, _periodic=True)
        package = parse_egg(blob, _development_v2=True)
        admission = package_admission(package, len(blob))
    except (EggCompileError, EggFormatError, ValueError, KeyError, struct.error) as exc:
        return dict(issues=[issue('MACHINE_ENCODING_UNSUPPORTED', 'machine_logic', str(exc))],
                    admission=None, reason='encoding_failed')
    return dict(issues=admission['issues'], admission=admission, reason=None)
