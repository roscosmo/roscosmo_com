"""Finite frame playback mirrored by the native ps_object_clip timeline."""
from dataclasses import dataclass

from .object_effects import OK, ARGUMENT, EXHAUSTED, EMPTY, STALE, U32_MAX, unsigned

IDLE, RUNNING, FINISHED = range(3)
RESTORE, HOLD_LAST = range(2)


@dataclass(frozen=True)
class ClipSpec:
    steps: tuple
    end: int = RESTORE
    completion: int = 0

    @property
    def duration_ms(self):
        return sum(duration for _, duration in self.steps)

    def valid(self):
        return (isinstance(self.steps, tuple) and 1 <= len(self.steps) <= 12
                and unsigned(self.end, 1) and unsigned(self.completion, 1)
                and all(isinstance(step, tuple) and len(step) == 2
                        and unsigned(step[1]) and step[1] > 0 for step in self.steps)
                and self.duration_ms <= U32_MAX)


class ClipTimeline:
    def __init__(self, activation):
        if not unsigned(activation) or not activation:
            raise ValueError('nonzero scene activation required')
        self.activation = activation
        self.generation = self.elapsed_ms = self.state = self.paused = self.pending = 0
        self.spec = None

    def start(self, spec):
        if not isinstance(spec, ClipSpec) or not spec.valid():
            return ARGUMENT
        if self.generation == U32_MAX:
            return EXHAUSTED
        self.spec = spec
        self.generation += 1
        self.elapsed_ms = self.pending = 0
        self.state = RUNNING
        return OK

    def advance(self, elapsed_ms):
        if not unsigned(elapsed_ms):
            return ARGUMENT
        if self.state == RUNNING and not self.paused:
            self.elapsed_ms = min(self.spec.duration_ms, self.elapsed_ms + elapsed_ms)
            if self.elapsed_ms == self.spec.duration_ms:
                self.state, self.pending = FINISHED, self.spec.completion
        return OK

    def pause(self, paused):
        if not unsigned(paused, 1):
            return ARGUMENT
        self.paused = paused
        return OK

    def cancel(self):
        self.spec = None
        self.state = self.pending = 0

    def sample(self):
        if self.state == IDLE or (self.state == FINISHED and self.spec.end == RESTORE):
            return None
        if self.state == FINISHED:
            return self.spec.steps[-1][0]
        elapsed = self.elapsed_ms
        for frame, duration in self.spec.steps:
            if elapsed < duration:
                return frame
            elapsed -= duration
        raise AssertionError('running clip beyond duration')

    def next_ms(self):
        if self.state != RUNNING or self.paused:
            return 0
        elapsed = self.elapsed_ms
        for _, duration in self.spec.steps:
            if elapsed < duration:
                return duration - elapsed
            elapsed -= duration
        return 0

    def awake(self):
        return int(self.state == RUNNING and not self.paused)

    def take(self, activation, generation):
        if (activation, generation) != (self.activation, self.generation):
            return STALE, None
        if not self.pending or self.paused:
            return EMPTY, None
        self.pending = 0
        return OK, (activation, generation)


def actions(scene):
    from .flowcharts import charts, actions as flow_actions
    for route in scene.get('machine_logic', {}).get('routes', []):
        for outcome in route.get('outcomes', [route]):
            yield from outcome.get('actions', [])
    for chart in charts(scene):
        yield from flow_actions(chart)


def validate_assets(scene, frames, animations):
    from .scene_machines import fail
    objects = {o['object_id']: o for o in scene.get('objects', [])}
    for action in actions(scene):
        if action.get('kind') not in ('object.play_clip', 'object.cancel_clip'):
            continue
        obj = objects.get(action['object_ref'])
        if not obj or obj['kind'] != 'sprite':
            fail('one-shot clips require a sprite object')
        if any('visual_ref' in override for state in scene['states']
               for override in state.get('object_overrides', []) if override['object_ref'] == obj['object_id']):
            fail('one-shot target cannot have state visual overrides')
        if action['kind'] == 'object.cancel_clip':
            continue
        clip = animations.get(action['animation_ref'])
        if clip is None or not ClipSpec(tuple(zip(clip['frame_refs'], clip['frame_duration_ms']))).valid():
            fail('one-shot animation requires one to twelve positive-duration frames')
        if any(ref not in frames or (frames[ref].width, frames[ref].height) != (obj['width'], obj['height'])
               for ref in clip['frame_refs']):
            fail('one-shot frames must exist and match the sprite dimensions')
