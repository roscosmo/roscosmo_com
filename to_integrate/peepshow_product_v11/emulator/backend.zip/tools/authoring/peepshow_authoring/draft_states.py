"""Readiness diagnostics for intentionally incomplete Scene State connections."""
def issues(scene, *, require_scene_entry=True):
    from .project import ValidationIssue
    result = []
    root = f"scenes[{scene['scene_id']}]"
    states = {s['state_id'] for s in scene['states']}
    def problem(path):
        result.append(ValidationIssue('AUTHORING_STATE_UNRESOLVED', path,
            'Connect an existing State before Run/build; the authored reference is preserved'))
    if require_scene_entry and scene.get('entry_state') not in states:
        problem(root+'.entry_state')
    for i, machine in enumerate(scene.get('machine_logic', {}).get('machines', [])):
        if machine.get('entry_state') not in machine['states']:
            problem(root+f'.machine_logic.machines[{i}].entry_state')
    def walk(value, path):
        if isinstance(value, dict):
            for key, child in value.items():
                if key == 'instance_behaviors':
                    continue  # These States belong to reusable definitions, not the Scene.
                where = path+'.'+key
                if key in ('target_state', 'state_ref') and isinstance(child, str) and child not in states:
                    problem(where)
                elif key == 'from_states' and isinstance(child, list):
                    for index, target in enumerate(child):
                        if target not in states:
                            problem(where+f'[{index}]')
                else:
                    walk(child, where)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                walk(child, path+f'[{index}]')
    walk(scene, root)
    return result
