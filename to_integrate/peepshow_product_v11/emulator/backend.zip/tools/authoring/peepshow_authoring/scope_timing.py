"""Private Scene clock domains; not a menu lifecycle or public preview grant."""
from .execution_scope_source import report
from .preview import PreviewError


class ScopeTiming:
    def __init__(self, source):
        declaration = report(source)
        if declaration is None:
            raise PreviewError('scope timing requires explicit ownership')
        self.owners = declaration['owners']
        self.elapsed = dict(gameplay=0, menu=0)
        self.active = dict(gameplay=True, menu=False)

    def scope(self, kind, ref):
        try:
            return self.owners[kind][ref]
        except KeyError:
            raise PreviewError(f'scope timing has no {kind} owner for {ref!r}') from None

    def now(self, kind, ref):
        return self.elapsed[self.scope(kind, ref)]

    def held(self, kind, ref):
        return not self.active[self.scope(kind, ref)]

    def advance(self, elapsed_ms):
        for scope, active in self.active.items():
            if active:
                self.elapsed[scope] += elapsed_ms

    def set_activity(self, gameplay, menu):
        if type(gameplay) is not bool or type(menu) is not bool:
            raise PreviewError('scope activity requires Boolean values')
        self.active = dict(gameplay=gameplay, menu=menu)

    def snapshot(self):
        return {scope:dict(elapsed_ms=self.elapsed[scope], active=self.active[scope])
                for scope in self.elapsed}
