"""V2 menu navigation over ordinary Scene objects and menu-owned machines."""
from copy import deepcopy


def validation_view(project, scene):
    from .menu_component import fail, record, ident
    menu=scene['menu_component']
    scope=menu.get('scope')
    record(scope, ('machines','objects'), (), 'menu.scope')
    graph=scene.get('machine_logic', {})
    machines={m['machine_id']:m for m in graph.get('machines', [])}
    objects={o['object_id']:o for o in scene.get('objects', [])}
    for kind, known in (('machines',machines),('objects',objects)):
        values=scope[kind]
        if type(values) is not list or any(type(v) is not str or v not in known for v in values) or len(set(values))!=len(values):
            fail('menu.scope.'+kind,'requires unique existing identities')
    if menu.get('apply_owner') in scope['machines']:
        fail('menu.apply_owner','must remain a gameplay owner')
    world={p['object_ref'] for p in graph.get('world_positions', [])}
    if world & set(scope['objects']):
        fail('menu.scope.objects','menu presentation must use screen-space objects')
    # Menu presentation must not hide objects whose mutable state is gameplay-owned.
    for machine in machines.values():
        if any((w['object_ref'] in scope['objects']) != (machine['machine_id'] in scope['machines'])
               for w in machine.get('object_writes', [])):
            fail('menu.scope','object writers must belong to the same scope as their objects')
        if any((ref in scope['objects']) != (machine['machine_id'] in scope['machines'])
               for ref in machine.get('effect_writes',[])):
            fail('menu.scope','effect writers must belong to their objects scope')
    pages={p['page_id']:p for p in menu.get('pages', [])}
    result=deepcopy(scene)
    adapted=result['menu_component']
    adapted['version']=1
    adapted.pop('scope')
    graphics=menu['presentation'].get('kind')=='objects'
    if graphics:
        view=menu['presentation']
        record(view,('kind','bindings'),(), 'menu.presentation')
        if type(view['bindings']) is not list or len(view['bindings'])>64:
            fail('menu.presentation.bindings','requires at most 64 bindings')
        used=set()
        for binding in view['bindings']:
            record(binding,('object_ref','page_ref'),('entry_ref','when_chosen','when_selected','when_disabled','quantity_item_ref'), 'menu.presentation.binding')
            obj=ident(binding['object_ref'],'binding.object_ref')
            page=ident(binding['page_ref'],'binding.page_ref')
            if obj not in scope['objects'] or obj in used or page not in pages:
                fail('menu.presentation.binding','requires a unique menu object and an existing page')
            used.add(obj)
            if 'entry_ref' in binding and binding['entry_ref'] not in {e['entry_id'] for e in pages[page]['entries']}:
                fail('menu.presentation.binding','unknown entry')
            if 'when_chosen' in binding and not any(
                    e['entry_id']==binding.get('entry_ref') and e['kind']=='choice'
                    for e in pages[page]['entries']):
                fail('menu.presentation.when_chosen','requires entry_ref naming a choice')
            for field in ('when_chosen','when_selected','when_disabled'):
                if field not in binding: continue
                if 'entry_ref' not in binding: fail('menu.presentation.binding','entry appearance requires entry_ref')
                override=binding[field]
                record(override,(),('visible','inverted','x','y'), 'menu.presentation.'+field)
                for key,value in override.items():
                    if key in ('visible','inverted'):
                        if type(value) is not bool: fail('menu.presentation.'+field,'appearance flag must be Boolean')
                    elif type(value) is not int or not -512<=value<=512:
                        fail('menu.presentation.'+field,'position must be within -512..512')
        # Only reused source validation sees this inert V1 presentation.
        adapted['presentation']=dict(x=0,y=0,width=168,height=144,row_height=8,visible_rows=16,font_id='peepshow.system.8x8.basic.v1')
    for page in adapted['pages']:
        neighbors=page.pop('neighbors',{})
        if type(neighbors) is not dict: fail('menu.neighbors','requires entry-to-direction mappings')
        ids={e['entry_id'] for e in page['entries']}
        for entry,edges in neighbors.items():
            if entry not in ids or type(edges) is not dict or set(edges)-{'left','right','up','down'}:
                fail('menu.neighbors','unknown entry or direction')
            if any(type(v) is not str or v not in ids for v in edges.values()):
                fail('menu.neighbors','destination must be on the same page')
        for entry in page['entries']:
            entry.pop('inventory_item_ref', None)  # Validated against the project catalog.
            if entry.get('kind') == 'inventory':
                entry.update(kind='action', operation='cancel')  # Validation adapter only.
            if entry.get('kind')=='event':
                record(entry,('entry_id','label','kind','machine_ref','event_ref'),('visible_when','enabled_when','disabled_reason'), 'menu.entry')
                if entry['machine_ref'] not in scope['machines'] or entry['event_ref'] not in {e['event_id'] for e in graph['events']}:
                    fail('menu.entry','activation must address a menu-owned machine and declared event')
                entry.pop('machine_ref'); entry.pop('event_ref')
                entry.update(kind='action',operation='cancel')
    return result


def resolve_object(session, player, ref, resolved):
    """Overlay chosen, selected, then disabled appearance; never mutate objects."""
    if session.source['presentation'].get('kind')!='objects': return resolved
    binding=next((b for b in session.source['presentation']['bindings'] if b['object_ref']==ref),None)
    if binding is None: return resolved
    result=dict(resolved)
    if 'quantity_item_ref' in binding:
        result['text'] = str(player._inventory_state['counts'].get(binding['quantity_item_ref'], 0))
    if not session.visible or not session.stack or session.stack[-1]!=binding['page_ref']:
        result['visible']=0
        return result
    if 'entry_ref' in binding:
        _, frame, rows=session.settle(player)
        row=next((r for r in rows if r['entry_id']==binding['entry_ref']),None)
        if row is None:
            result['visible']=0
            return result
        if row['kind']=='choice' and session.drafts[row['draft_ref']]==row['value']:
            result.update(binding.get('when_chosen',{}))
        if frame['selected']==row['entry_id']: result.update(binding.get('when_selected',{}))
        if not row['enabled']: result.update(binding.get('when_disabled',{}))
    return result
