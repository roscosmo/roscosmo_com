"""Public map Scene bindings and host preview profile; device export is separate."""
from copy import deepcopy
from .camera_source import CAPABILITY as CAMERA_CAPABILITY
from .visibility_source import CAPABILITY as VISIBILITY_CAPABILITY
from .map_colour import CAPABILITY as MAP_COLOUR_CAPABILITY

CAPABILITY = {
    'status': 'host_preview', 'host_editing': True, 'persisted': True,
    'undo_redo': True, 'host_preview': True, 'runtime': False, 'export': False,
    'preview_requires': 'all_scenes_have_map_scene_bindings',
    'preview_profile': 'layered_grid_instances_v1',
    'preview_diagnostic': 'MAP_PREVIEW_PROFILE',
    'preview_proves_device_timing': False,
    'field': 'machine_logic.map_scene', 'source_version': 1,
    'schema': 'schemas/authoring/map-scene-v1.schema.json',
    'commands': ['scene.machines.set', 'scene.machines.clear'],
    'validation_error': 'MAP_SCENE_INVALID', 'readiness_error': 'MAP_SCENE_RUNTIME_UNAVAILABLE',
    'background_layers': 2, 'collision': 'painted_cell_bitmap',
    'base_colour': dict(field='machine_logic.map_scene.base_colour',
        legacy_override=True, preferred_asset_field='map_assets[].base_colour',
        values=['white', 'black'], default='white', commands=['scene.machines.set'],
        persisted=True, undo_redo=True, host_preview=True, runtime=True, export=True,
        hardware_validation='reference_black_white_maps_operator_tested_edited_projects_require_testing',
        black_requires_binding_version=4),
    'asset_base_colour': MAP_COLOUR_CAPABILITY,
    'occupancy': 'explicit_entities_with_optional_boolean_condition',
    'camera': 'initial_position_then_authored_world_writes',
    'camera_component': CAMERA_CAPABILITY,
    'visibility': VISIBILITY_CAPABILITY,
}


def visual_record(record, source):
    from .scene_map_entities import materialize
    result = deepcopy(materialize(record, source))
    ids = [*source['background_layers'], source['object_layer']]
    layers = {layer['id']: layer for layer in result['snapshot']['layers']}
    result['snapshot']['layers'] = [layers[i] for i in ids]
    return result


def validate_scene(bundle, scene):
    from .machine_wire import require
    graph = scene.get('machine_logic', {})
    source = graph.get('map_scene')
    spatial = graph.get('instance_behaviors', {}).get('version') in (2, 3)
    if source is None:
        require(not spatial, 'Spatial instance source requires map_scene bindings')
        return
    required = {'version', 'asset_ref', 'background_layers', 'object_layer',
                'collision_layer', 'cell_width', 'cell_height', 'occupancy'}
    require(type(source) is dict and ('camera' in source) != ('initial_camera' in source),
            'Choose camera component or legacy initial_camera')
    required.add('camera' if 'camera' in source else 'initial_camera')
    if 'visibility' in source:
        required.add('visibility')
    if 'local_entities' in source:
        required.add('local_entities')
    if 'base_colour' in source:
        required.add('base_colour')
    require(source.get('base_colour', 'white') in ('white', 'black'),
            'map_scene.base_colour must be white or black')
    from .visibility_source import configuration as visibility_configuration
    visibility_configuration(graph)
    require(type(source) is dict and set(source) == required and
            type(source['version']) is int and source['version'] == 1,
            'Invalid map_scene fields/version')
    records = [r for c in bundle.asset_catalogs for r in c.get('map_assets', [])
               if r['asset_id'] == source['asset_ref']]
    require(len(records) == 1, 'map_scene requires an existing unique map asset')
    from .scene_map_entities import materialize
    record = materialize(records[0], source)
    from .layered_map import compile_layered_map
    compile_layered_map(record, bundle.root, background_layers=source['background_layers'],
                        object_layer=source['object_layer'], collision_layer=source['collision_layer'])
    snap = record['snapshot']
    for axis in ('width', 'height'):
        value = source['cell_' + axis]
        require(type(value) is int and value > 0 and value == snap['tile' + axis],
                'Collision grid must match the authored tile grid')
    from .camera_source import configuration, origin
    component = configuration(graph)
    if component is None:
        camera = source['initial_camera']
        require(type(camera) is dict and set(camera) == {'x', 'y'}, 'Initial camera requires x/y')
        for axis, dim, viewport in (('x', 'width', 168), ('y', 'height', 144)):
            value = camera[axis]
            require(type(value) is int and 0 <= value <= max(0, snap[dim]*snap['tile'+dim]-viewport),
                    'Initial camera is outside the viewport bounds')
    refs = {r['reference_id']: r['target'] for r in graph.get('world_references', [])}
    require(all(r['asset_id'] == source['asset_ref'] for r in refs.values()),
            'Map Scene references must belong to its selected map')
    entities = {f"object:{o['id']}": o for layer in snap['layers'] if layer['id'] == source['object_layer']
                for o in layer['objects']}
    occupied = set()
    require(type(source['occupancy']) is list, 'occupancy requires an array')
    for row in source['occupancy']:
        require(type(row) is dict and set(row) in (
            {'entity_ref', 'x_ref', 'y_ref'}, {'entity_ref', 'x_ref', 'y_ref', 'solid_when'}),
            'Invalid occupancy fields')
        entity = row['entity_ref']
        require(entity in entities and entity not in occupied, 'Unknown/duplicate occupancy entity')
        occupied.add(entity)
        for axis in ('x', 'y'):
            ref = refs.get(row[axis+'_ref'], {})
            require(ref.get('asset_id') == source['asset_ref'] and ref.get('owner_id') == entity and
                    ref.get('field') == 'entity_'+axis, 'Occupancy coordinates must reference that entity')
            require(entities[entity][axis] % source['cell_'+('width' if axis == 'x' else 'height')] == 0,
                    'Occupancy entity must align to the world grid')
        if 'solid_when' in row:
            condition = row['solid_when']
            require(type(condition) is dict and set(condition) == {'reference_ref', 'equals'} and
                    type(condition['equals']) is bool, 'Solidity condition requires a Boolean comparison')
            ref = refs.get(condition['reference_ref'], {})
            require(ref.get('value_type') == 'bool' and ref.get('asset_id') == source['asset_ref'],
                    'Solidity condition requires a Boolean reference in this map')
    if component is not None:
        focus = entities[component['target_ref']] if component['mode'] == 'follow' else component['position']
        origin((focus['x'], focus['y']), component['offset'] if component['mode'] == 'follow' else dict(x=0,y=0),
               component['clamp'], snap['width']*snap['tilewidth'], snap['height']*snap['tileheight'])
    instance_source = graph.get('instance_behaviors', {})
    if spatial:
        behaviors = {b['behavior_id']: b for b in instance_source['behaviors']}
        for instance in instance_source['instances']:
            behavior = behaviors[instance['behavior_ref']]
            require(instance['entity']['asset_id'] == source['asset_ref'], 'Instance belongs to another map')
            require(not behavior.get('destinations') or instance['entity']['owner_id'] in occupied,
                    'Behavior checked destinations require registered Self occupancy')
            for query in behavior['collision_queries']:
                require((query['cell_width'], query['cell_height']) ==
                        (source['cell_width'], source['cell_height']), 'Collision query grid differs from map grid')
                require(not query['include_actors'] or instance['entity']['owner_id'] in occupied,
                        'Actor-aware collision requires registered querying actor')


def readiness_issues(bundle):
    from .interaction_source import present as interaction_present
    return [dict(code='ACTOR_ASSEMBLY_DEVICE_UNAVAILABLE',
                 path=f"scenes[{s['scene_id']}].machine_logic.map_scene.local_entities",
                 message='Scene-local actor placements support host preview; device export is not qualified.')
            for s in bundle.scenes if s.get('machine_logic', {}).get('map_scene', {}).get('local_entities')] + [dict(code='VISIBILITY_DEVICE_UNAVAILABLE',
                 path=f"scenes[{s['scene_id']}].machine_logic.map_scene.visibility",
                 message='Map visibility supports host preview only; device export is not qualified.')
            for s in bundle.scenes if 'visibility' in s.get('machine_logic', {}).get('map_scene', {})] + [dict(code='CAMERA_DEVICE_UNAVAILABLE',
                 path=f"scenes[{s['scene_id']}].machine_logic.map_scene.camera",
                 message='Camera components support host preview only; device export is not qualified.')
            for s in bundle.scenes if 'camera' in s.get('machine_logic', {}).get('map_scene', {})] + [dict(code='INTERACTION_DEVICE_UNAVAILABLE',
                 path=f"scenes[{s['scene_id']}].machine_logic.interactables",
                 message='Approach-aware interaction supports host preview only; device export is not qualified.')
            for s in bundle.scenes if interaction_present(s.get('machine_logic', {}))] + [dict(code='DESTINATION_DEVICE_UNAVAILABLE',
                 path=f"scenes[{s['scene_id']}].machine_logic.destinations",
                 message='Checked destinations support host preview; public device export is not qualified.')
            for s in bundle.scenes if s.get('machine_logic', {}).get('destinations')] + [dict(code='SCENE_COLLISION_DEVICE_UNAVAILABLE',
                 path=f"scenes[{s['scene_id']}].machine_logic.collision_queries",
                 message='Ordinary Scene collision checks support host preview; installed Runtime query storage is not connected.')
            for s in bundle.scenes if s.get('machine_logic', {}).get('collision_queries')] + [dict(code='MAP_SCENE_RUNTIME_UNAVAILABLE',
                 path=f"scenes[{s['scene_id']}].machine_logic.map_scene",
                 message='Map bindings support host preview; public device package export remains unavailable.')
            for s in bundle.scenes if 'map_scene' in s.get('machine_logic', {})]
