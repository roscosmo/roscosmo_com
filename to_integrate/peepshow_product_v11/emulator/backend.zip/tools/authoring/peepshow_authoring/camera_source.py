"""First-class map camera source and host transaction state, not a new executor."""
from copy import deepcopy

from .imported_properties import ImportedPropertyError

CAPABILITY = dict(host_editing=True, host_preview=True, persisted=True, undo_redo=True,
    runtime=False, export=False, hardware_validation='not_qualified',
    field='machine_logic.map_scene.camera', schema='schemas/authoring/map-camera-v1.schema.json',
    commands=['scene.machines.set', 'scene.flowcharts.set'],
    action_kinds=['camera.follow', 'camera.look_at'],
    locations=['scene_transition_actions', 'scene_flowchart_actions'],
    modes=['manual', 'follow'], maximum_cameras=1, clamp_default=True,
    target_namespace='map_occupancy_entity', position_units='world_pixels',
    anchor='viewport_center_on_actor_origin_plus_offset', offset_default=dict(x=0,y=0),
    resolve='after_accepted_event_chain_before_presentation',
    action_order='ordered_last_camera_command_wins', raw_camera_writers=False,
    timed_pan=False, validation_error='CAMERA_INVALID', readiness_error='CAMERA_DEVICE_UNAVAILABLE')


class CameraError(ImportedPropertyError):
    code = 'CAMERA_INVALID'


def point(value, path):
    if (type(value) is not dict or set(value) != {'x', 'y'} or
            any(type(value[a]) is not int or not -2**31 <= value[a] < 2**31 for a in ('x', 'y'))):
        raise CameraError(f'{path}: requires signed integer world-pixel x/y')
    return dict(value)


def target(value, graph, path):
    source = graph.get('map_scene', {})
    if type(value) is not str or sum(o.get('entity_ref') == value for o in source.get('occupancy', [])) != 1:
        raise CameraError(f'{path}: target_ref must identify one registered map actor')
    return value


def configuration(graph):
    source = graph.get('map_scene', {})
    if 'camera' not in source:
        return None
    if 'initial_camera' in source:
        raise CameraError('map_scene: choose camera component or legacy initial_camera, not both')
    config = source['camera']
    if type(config) is not dict or config.get('mode') not in ('manual', 'follow'):
        raise CameraError('camera: requires manual or follow mode')
    required = {'mode', 'target_ref' if config['mode'] == 'follow' else 'position'}
    if not required <= set(config) or set(config) - required - {'offset', 'clamp'}:
        raise CameraError('camera: invalid mode-specific fields')
    if type(config.get('clamp', True)) is not bool:
        raise CameraError('camera.clamp: requires Boolean')
    result = dict(mode=config['mode'], clamp=config.get('clamp', True),
        offset=point(config.get('offset', dict(x=0,y=0)), 'camera.offset'))
    if result['mode'] == 'follow':
        result['target_ref'] = target(config['target_ref'], graph, 'camera')
    else:
        result['position'] = point(config['position'], 'camera.position')
    for ref in graph.get('world_references', []):
        if ref.get('target', {}).get('field') in ('camera_x', 'camera_y') and ref.get('writer') is not None:
            raise CameraError('camera component owns camera coordinates; remove legacy camera writers explicitly')
    return result


def action(value, graph, path):
    if configuration(graph) is None:
        raise CameraError(f'{path}: camera action requires a map camera component')
    kind = value['kind']
    required = {'kind', 'target_ref' if kind == 'camera.follow' else 'position'}
    optional = {'offset'} if kind == 'camera.follow' else set()
    if kind not in CAPABILITY['action_kinds'] or not required <= set(value) or set(value) - required - optional:
        raise CameraError(f'{path}: invalid camera action fields')
    result = dict(kind=kind)
    if kind == 'camera.follow':
        result['target_ref'] = target(value['target_ref'], graph, path)
        if 'offset' in value:
            result['offset'] = point(value['offset'], path+'.offset')
    else:
        result['position'] = point(value['position'], path+'.position')
    return result


def origin(focus, offset, clamp, width, height):
    from .preview import DISPLAY_WIDTH, DISPLAY_HEIGHT
    values = [focus[0]+offset['x']-DISPLAY_WIDTH//2, focus[1]+offset['y']-DISPLAY_HEIGHT//2]
    if clamp:
        values = [max(0,min(value,maximum)) for value,maximum in zip(values,
            (max(0,width-DISPLAY_WIDTH), max(0,height-DISPLAY_HEIGHT)))]
    if any(not -2**31 <= value < 2**31 for value in values):
        raise CameraError('camera viewport coordinate overflow')
    return tuple(values)


def attach(context, source, graph):
    """Attach to the existing world transaction; no extra events or machine."""
    context.camera = deepcopy(source.camera)
    context.camera_actions = deepcopy(source.camera_actions)
    context.camera_targets = {}
    if context.camera is None:
        return
    refs = {r['reference_id']: r['target'] for r in graph['world_references']}
    from .world_reference_source import parse_reference
    for row in graph['map_scene']['occupancy']:
        context.camera_targets[row['entity_ref']] = tuple(context.sources.index(parse_reference(refs[row[a+'_ref']])[0])
                                                          for a in ('x','y'))
    resolve(context)


def execute(context, command):
    if context.camera is None:
        raise CameraError('camera command has no component')
    if command['kind'] == 'camera.follow':
        context.camera.update(mode='follow', target_ref=command['target_ref'])
        context.camera.pop('position', None)
        if 'offset' in command:
            context.camera['offset'] = dict(command['offset'])
    else:
        context.camera.update(mode='manual', position=dict(command['position']))
        context.camera.pop('target_ref', None)


def resolve(context):
    camera = context.camera
    if camera is None:
        return
    if camera['mode'] == 'follow':
        focus = tuple(context.read(i) for i in context.camera_targets[camera['target_ref']])
        offset = camera['offset']
    else:
        focus = camera['position']['x'], camera['position']['y']
        offset = dict(x=0,y=0)
    if any(type(v) is not int or not -2**31 <= v < 2**31 for v in focus):
        raise CameraError('invalid camera target position')
    spatial = context.spatial
    x,y = origin(focus, offset, camera['clamp'], spatial.width*spatial.cell_width, spatial.height*spatial.cell_height)
    # Derived presentation coordinates belong to the component, not gameplay's
    # property journal. They live in the same cloned candidate and commit once.
    context.values[1,0], context.values[2,0] = x,y
