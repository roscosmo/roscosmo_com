"""Scene-local placed entities layered over an unchanged imported map snapshot."""
from copy import deepcopy
from .imported_properties import ImportedPropertyError


def materialize(record, source):
    if source is None:
        return record
    if type(source) is not dict:
        raise ImportedPropertyError('map_scene must be an object')
    if source.get('asset_ref') != record['asset_id'] or 'local_entities' not in source:
        return record
    rows = source['local_entities']
    if type(rows) is not list or len(rows) > 64:
        raise ImportedPropertyError('map_scene.local_entities requires at most 64 placements')
    result = deepcopy(record)
    layers = result['snapshot']['layers']
    layer = next((r for r in layers if r['id'] == source['object_layer'] and r['type'] == 'objectgroup'), None)
    if layer is None:
        raise ImportedPropertyError('Scene placements require the selected object layer')
    used = {o['id'] for r in layers if r['type'] == 'objectgroup' for o in r['objects']}
    for row in rows:
        if (type(row) is not dict or set(row) != {'id', 'name', 'x', 'y', 'width', 'height', 'properties'}
                or type(row['id']) is not int or row['id'] <= 0 or row['id'] in used
                or type(row['name']) is not str):
            raise ImportedPropertyError('Invalid/conflicting Scene entity identity; reimport must not replace a local placement')
        for axis, size in (('x', 'width'), ('y', 'height')):
            value, cell = row[axis], source['cell_' + size]
            if type(value) is not int or type(cell) is not int or cell <= 0 or value % cell or not 0 <= value < result['snapshot'][size] * cell:
                raise ImportedPropertyError('Scene entity position must be an in-bounds world-grid cell')
        used.add(row['id'])
        layer['objects'].append(deepcopy(row))
    from .tiled_assets import definitions
    definitions(result['asset_id'], result['snapshot'])
    return result
