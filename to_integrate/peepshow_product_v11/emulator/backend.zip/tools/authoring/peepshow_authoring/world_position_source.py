"""Authoring-only bindings for the existing private world-position projection."""
from copy import deepcopy
import re

from .imported_properties import ImportedPropertyError
from .tilemap_wire import HEADER, ENTITY


def declarations(scene):
    graph = scene.get('machine_logic', {})
    rows = graph.get('world_positions', [])
    if type(rows) is not list:
        raise ImportedPropertyError('world_positions must be an array')
    objects = {o['object_id']: o for o in scene.get('objects', [])}
    seen = set()
    for row in rows:
        if type(row) is not dict or set(row) != {'object_ref', 'asset_id', 'entity_ref', 'offset_x', 'offset_y'}:
            raise ImportedPropertyError('world position requires object_ref, asset_id, entity_ref and signed offsets')
        ref = row['object_ref']
        if type(ref) is not str or ref not in objects or objects[ref]['kind'] != 'sprite' or ref in seen:
            raise ImportedPropertyError('world position must uniquely bind an existing sprite')
        seen.add(ref)
        if (type(row['asset_id']) is not str or not row['asset_id'] or
            type(row['entity_ref']) is not str or not re.fullmatch(r'object:[1-9][0-9]*', row['entity_ref'])):
            raise ImportedPropertyError('world position requires map asset and stable Tiled object identity')
        if any(type(row[k]) is not int or not -2**31 <= row[k] < 2**31 for k in ('offset_x','offset_y')):
            raise ImportedPropertyError('world position offsets must fit int32')
        for owner in [*graph.get('machines', []), *graph.get('flowcharts', [])]:
            if any(w.get('object_ref') == ref and any(p in ('x','y') for p in w.get('properties', []))
                   for w in owner.get('object_writes', [])):
                raise ImportedPropertyError('world position owns both axes; competing writer')
        if any(o.get('object_ref') == ref and ('x' in o or 'y' in o)
               for state in scene.get('states', []) for o in state.get('object_overrides', [])):
            raise ImportedPropertyError('world position conflicts with State position override')
    return deepcopy(rows)


def lower(scene, compiled_map, rows):
    """Return immutable numeric tuples matching ps_world_position_t, not a chunk."""
    header = HEADER.unpack_from(compiled_map.data)
    entities = {f'object:{ENTITY.unpack_from(compiled_map.data, header[14]+i*ENTITY.size)[0]}': i
                for i in range(header[11])}
    objects = {o['object_id']: i for i,o in enumerate(scene['objects'])}
    try:
        return tuple(sorted((objects[r['object_ref']], entities[r['entity_ref']], r['offset_x'], r['offset_y'])
                            for r in rows))
    except KeyError as exc:
        raise ImportedPropertyError('world position target is unavailable') from exc
