"""Bounded private focus admission over normalized inputs, never hardware policy."""
from copy import deepcopy
from .preview import LOGICAL_SOURCES, LOGICAL_EVENTS, PreviewError


class ScopeInput:
    def __init__(self):
        self.scope = 'gameplay'
        self.generation = 0
        self.held = set()
        self.suppressed = set()
        self.joystick_quarantine = False
        self.needs_snapshot = False
        self.actions = {}
        self.last_event = None
        self.last_handoff = None

    @staticmethod
    def _snapshot_sources(sources):
        if (type(sources) not in (list, tuple, set, frozenset) or len(sources) > len(LOGICAL_SOURCES)
                or any(type(s) is not str or s not in LOGICAL_SOURCES or s == 'BUTTON_START' for s in sources)
                or len(set(sources)) != len(sources)):
            raise PreviewError('focus snapshot requires unique normal held sources; START is a release-qualified pulse')
        return set(sources)

    def _handoff(self, target, reason):
        previous = self.scope
        cancelled = [dict(logical_source=s, **action) for s, action in sorted(self.actions.items())]
        self.actions.clear()
        self.generation += 1
        self.scope = target
        self.suppressed = {s for s in self.held if not s.startswith('JOY_')}
        self.joystick_quarantine = self.joystick_quarantine or any(s.startswith('JOY_') for s in self.held)
        # One bounded notification record, not a growing history or authored sends.
        self.last_handoff = dict(generation=self.generation, reason=reason, lost=previous,
                                 gained=None if reason == 'system_preempted' else target, cancelled=cancelled)

    def enter_scene(self):
        self._handoff('gameplay', 'scene_entry')

    def transfer(self, target, held_sources):
        if target not in ('gameplay', 'menu'):
            raise PreviewError('focus target must be gameplay or menu')
        held = self._snapshot_sources(held_sources)
        if self.needs_snapshot:
            raise PreviewError('focus requires a fresh post-system input snapshot')
        if target == self.scope:
            return  # Idempotence must not suppress a still-owned gesture.
        self.held = held
        self._handoff(target, 'scope_change')

    def preempt(self):
        self._handoff(self.scope, 'system_preempted')
        self.needs_snapshot = True

    def pause_for_menu(self, held_sources):
        self.held = self._snapshot_sources(held_sources)
        self._handoff(self.scope, 'menu_transition')
        self.needs_snapshot = True

    def observe_snapshot(self, sources, generation):
        held = self._snapshot_sources(sources)
        if type(generation) is not int or generation != self.generation:
            raise PreviewError('stale focus snapshot')
        if self.needs_snapshot:
            self.suppressed = {s for s in held if not s.startswith('JOY_')}
            self.joystick_quarantine = any(s.startswith('JOY_') for s in held)
        else:
            self.suppressed.intersection_update(held)
            if not any(s.startswith('JOY_') for s in held):
                self.joystick_quarantine = False
        self.held = held
        self.actions = {s:a for s,a in self.actions.items() if s in held}
        self.needs_snapshot = False

    def observe(self, source, event, generation, system_preempted):
        if (type(source) is not str or type(event) is not str
                or source not in LOGICAL_SOURCES or event not in LOGICAL_EVENTS):
            raise PreviewError('unsupported logical input source or event')
        if source == 'BUTTON_START' and event != 'press':
            raise PreviewError('START hold/repeat/release are Platform-reserved')
        self.last_event = dict(logical_source=source, event=event, generation=generation, scope=self.scope)
        if type(generation) is not int or generation != self.generation:
            return self.finish('stale_generation')
        if system_preempted:
            return self.finish('system_preempted')
        if self.needs_snapshot:
            return self.finish('snapshot_required')
        was_held = source in self.held
        suppressed = source in self.suppressed or (source.startswith('JOY_') and self.joystick_quarantine)
        if event == 'press' and source != 'BUTTON_START':
            self.held.add(source)
        elif event == 'release':
            self.held.discard(source)
            self.suppressed.discard(source)
            self.actions.pop(source, None)
        if suppressed:
            return self.finish('held_suppressed')
        if event != 'press' and not was_held:
            return self.finish('orphan_lifecycle')
        return None

    def begin_action(self, source, event, action_id):
        if event == 'press' and source != 'BUTTON_START':
            self.actions[source] = dict(scope=self.scope, action_id=action_id)

    def finish(self, status):
        if self.last_event is not None:
            self.last_event['status'] = status
        return status

    def snapshot(self):
        return dict(scope=self.scope, generation=self.generation, held=sorted(self.held),
            suppressed=sorted(self.suppressed), joystick_neutral_required=self.joystick_quarantine,
            snapshot_required=self.needs_snapshot, active_actions=deepcopy(self.actions),
            last_event=deepcopy(self.last_event), last_handoff=deepcopy(self.last_handoff))
