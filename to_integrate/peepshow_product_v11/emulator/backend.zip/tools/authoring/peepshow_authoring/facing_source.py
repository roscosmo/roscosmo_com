"""Named cardinal semantics over existing typed property storage and operations."""
from copy import deepcopy
from .imported_properties import ImportedPropertyError, PropertyKey, effective_defaults

DIRECTIONS = dict(left=0, right=1, up=2, down=3)
CAPABILITY = dict(semantic='facing', directions=['up', 'down', 'left', 'right'],
    storage_values=DIRECTIONS, storage_type='int32',
    declaration_fields=['world_references[].semantic', 'behaviors[].properties[].semantic'],
    action='facing.set', guard='facing.compare', operators=['eq', 'ne'],
    direction_field='direction', scene_reference_field='reference_ref',
    behavior_reference_field='property_ref',
    schema='schemas/authoring/facing-operation-v1.schema.json',
    locations=['scene_transition', 'scene_flowchart', 'presentation_selector', 'behavior_route'],
    host_editing=True, host_preview=True, runtime=False, export=False,
    hardware_validation='not_qualified', preview_requires='all_scenes_have_map_scene_bindings',
    commands=['scene.machines.set', 'scene.flowcharts.set', 'scene.presentation_selectors.set'],
    persisted=True, undo_redo=True, legacy_integer_properties='unchanged')


def declaration(row, *, local=False):
    if 'semantic' not in row:
        return False
    target = row if local else row.get('target', {})
    if (row['semantic'] != 'facing' or target.get('value_type') != 'int32' or
            target.get('field') != 'property' or
            (local and target.get('owner') != 'self') or
            (not local and not target.get('owner_id', '').startswith('object:'))):
        raise ImportedPropertyError('facing semantic requires an integer actor property (Self for a behavior)')
    return True


def transform(value, names, *, local=False):
    """Transform a private action/predicate tree without adding execution work."""
    key, prefix = ('property_ref', 'property') if local else ('reference_ref', 'world')
    pending = [value]
    while pending:
        item = pending.pop()
        if type(item) is list:
            pending.extend(item)
        elif type(item) is dict:
            kind = item.get('kind')
            if kind in ('facing.set', 'facing.compare'):
                fields = {'kind', key, 'direction'} | ({'operator'} if kind == 'facing.compare' else set())
                ref, direction = item.get(key), item.get('direction')
                if (set(item) != fields or type(ref) is not str or ref not in names or
                        type(direction) is not str or direction not in DIRECTIONS or
                        (kind == 'facing.compare' and item['operator'] not in ('eq', 'ne'))):
                    raise ImportedPropertyError(f'invalid {kind}: requires a declared facing reference, cardinal direction and EQ/NE comparison')
                item['kind'] = prefix + ('.set' if kind == 'facing.set' else '.compare')
                item['value'] = DIRECTIONS[item.pop('direction')]
            elif type(kind) is str and kind.startswith(prefix + '.') and item.get(key) in names:
                # Declaring a semantic is opt-in; legacy numeric properties are
                # unchanged, but semantic fields cannot be corrupted by arithmetic.
                raise ImportedPropertyError(f'{item.get(key)}: use named facing operations, not {kind}')
            else:
                pending.extend(item.values())


def lower_scene(graph):
    names = {r['reference_id'] for r in graph.get('world_references', []) if declaration(r)}
    for row in graph.get('world_references', []):
        row.pop('semantic', None)
    for key in ('routes', 'flowcharts', 'presentation_selectors'):
        transform(graph.get(key, []), names)


def lower_behavior(behavior, version):
    result = deepcopy(behavior)
    names = {p['name'] for p in result['properties'] if declaration(p, local=True)}
    if names and version != 3:
        raise ImportedPropertyError('behavior facing semantic requires source version 3')
    for prop in result['properties']:
        prop.pop('semantic', None)
    transform(result['machine_logic']['routes'], names, local=True)
    return result


def validate_default(record, ref, definitions):
    from .tiled_assets import edit_map
    values = effective_defaults(definitions, edit_map(record))
    value = values.get(PropertyKey(ref.asset_id, ref.owner_id, ref.property_id))
    if type(value) is not int or value not in DIRECTIONS.values():
        raise ImportedPropertyError(f'{ref.owner_id}.{ref.property_id}: facing default/override must be a cardinal value')


def validate_links(graph):
    """A local writer or legacy ahead mapping cannot bypass opted-in semantics."""
    targets = [r['target'] for r in graph.get('world_references', []) if r.get('semantic') == 'facing']
    source = graph.get('instance_behaviors', {})
    if not targets or type(source) is not dict or any(type(source.get(k, [])) is not list for k in ('behaviors', 'instances', 'bridges')):
        return  # Shared-source validation reports its shape.
    for bridge in source.get('bridges', []):
        query = bridge.get('query') if type(bridge) is dict else None
        if type(query) is dict and query.get('facing') in targets and query.get('facings') != DIRECTIONS:
            raise ImportedPropertyError('ahead query mapping disagrees with named cardinal facing')
    behaviors = {b['behavior_id']: b for b in source.get('behaviors', []) if type(b) is dict and 'behavior_id' in b}
    for instance in source.get('instances', []):
        if type(instance) is not dict or type(instance.get('entity')) is not dict:
            continue
        entity = instance['entity']
        behavior = behaviors.get(instance.get('behavior_ref'), {})
        for prop in behavior.get('properties', []):
            if type(prop) is not dict or not prop.get('writable') or prop.get('field', 'property') != 'property':
                continue
            matches = any(t['asset_id'] == entity.get('asset_id') and t['owner_id'] == entity.get('owner_id')
                          and t['property_id'] == prop.get('name') for t in targets)
            if matches and prop.get('semantic') != 'facing':
                raise ImportedPropertyError(f"instance[{instance.get('instance_id')}].{prop.get('name')}: writer must declare facing semantic")


def validate_instances(world, source):
    """Check the exact compiled defaults used by preview/transport, offscreen too."""
    from .tilemap_wire import HEADER, PROPERTY
    definitions_by_id = {b['behavior_id']: b for b in source['behaviors']}
    header = HEADER.unpack_from(world.map.data)
    values = {key: PROPERTY.unpack_from(world.map.data, header[15] + i*PROPERTY.size)
              for i, key in enumerate(world.map.property_sources)}
    for instance in source['instances']:
        behavior = definitions_by_id.get(instance['behavior_ref'])
        if behavior is None:
            continue  # The binding compiler reports the missing definition.
        for prop in behavior['properties']:
            if declaration(prop, local=True):
                entity = instance['entity']
                record = values.get(PropertyKey(entity['asset_id'], entity['owner_id'], prop['name']))
                if record is None or record[4] != 2 or record[5] not in DIRECTIONS.values():
                    raise ImportedPropertyError(f"instance[{instance['instance_id']}].{prop['name']}: facing default/override must be a cardinal value")
