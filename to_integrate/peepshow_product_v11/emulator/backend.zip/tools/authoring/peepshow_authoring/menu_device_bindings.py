"""Resolve menu component bindings against exact compiled Scene identities.

This is a compiler intermediate, not an installed descriptor or export grant.
Predicates remain source expressions until their device encoding is connected.
"""
from copy import deepcopy
from dataclasses import dataclass

from .compiler import LOGICAL_SOURCES, LOGICAL_EVENTS
from .machine_wire import require
from .menu_navigation_wire import compile_navigation, NONE


@dataclass(frozen=True)
class MenuDeviceBindings:
    navigation: object
    menu_machines: int
    menu_objects: int
    apply_owner: int
    hide_world: bool
    inputs: tuple
    drafts: tuple
    entries: tuple
    presentation: dict
    navigation_cue: int


def bind_menu(project, scene, *, machines, events, objects, variables, inventory, cues):
    """Use caller-supplied compiled orders; refuse missing identities.

    Variables use (scope, identity) keys. Inventory/cue indices must come from
    their package-wide compiled tables. This function never mutates the source
    or fabricates a replacement machine for a component.
    """
    menu = scene['menu_component']
    path = f"scenes[{scene['scene_id']}].menu_component"

    def table(values, name, known, exact=False):
        values = tuple(values)
        require(len(values) < NONE and len(set(values)) == len(values),
                f'MENU_DEVICE_BINDING: {path}: invalid {name} identity table')
        require(set(known) == set(values) if exact else set(known) <= set(values),
                f'MENU_DEVICE_BINDING: {path}: compiled {name} table does not cover source')
        return {key:i for i,key in enumerate(values)}

    graph = scene['machine_logic']
    mi = table(machines,'machines',[m['machine_id'] for m in graph['machines']])
    oi = table(objects,'objects',[o['object_id'] for o in scene['objects']],exact=True)
    vi = table(variables,'variables',[(scope,v['variable_id']) for scope,rows in
        (('scene',scene.get('variables',[])),('package',project.get('package_variables',[]))) for v in rows])
    ii = table(inventory,'inventory',[r['item_id'] for r in project.get('inventory',{}).get('items',[])],exact=True)
    ci = table(cues,'cues',[])
    require(len(mi) <= 16 and len(oi) <= 64,
            f'MENU_DEVICE_BINDING: {path}: scope masks exceed device representation')
    nav = compile_navigation(project,scene,machines=tuple(mi),events=tuple(events),audio_cues=tuple(ci))
    require(menu['version'] == 2 and menu['presentation']['kind'] == 'objects',
            f'MENU_DEVICE_BINDING: {path}: this device binding path requires V2 object presentation')
    page_index = {ref:i for i,ref in enumerate(nav.pages)}
    entry_index = {ref:i for i,ref in enumerate(nav.entries)}
    source_inputs = {a['action_id']:a for a in scene['input_actions']}
    inputs = []
    for operation, name in enumerate(('previous','next','activate','back')):
        for ref in menu['input_map'][name]:
            row = source_inputs[ref]
            inputs.append((LOGICAL_SOURCES[row['logical_source']],
                           LOGICAL_EVENTS[row.get('event_kind','press')],operation))
    inputs.sort()
    require(len({row[:2] for row in inputs}) == len(inputs),
            f'MENU_DEVICE_BINDING: {path}.input_map: duplicate physical input binding')
    drafts = tuple(vi[(d['source']['variable_scope'],d['source']['variable_ref'])] for d in menu['drafts'])
    entries = tuple(dict(visible=deepcopy(e.get('visible_when',True)),
                        enabled=deepcopy(e.get('enabled_when',True)),
                        inventory=ii[e['inventory_item_ref']] if 'inventory_item_ref' in e else NONE)
                    for p in menu['pages'] for e in p['entries'])
    bindings = []
    for row in menu['presentation']['bindings']:
        binding = dict(object=oi[row['object_ref']],page=page_index[row['page_ref']],
            entry=entry_index[(row['page_ref'],row['entry_ref'])] if 'entry_ref' in row else NONE,
            quantity=ii[row['quantity_item_ref']] if 'quantity_item_ref' in row else NONE)
        for field in ('when_chosen','when_selected','when_disabled'):
            if field in row: binding[field] = deepcopy(row[field])
        bindings.append(binding)
    return MenuDeviceBindings(nav,
        sum(1 << mi[m] for m in menu['scope']['machines']),
        sum(1 << oi[o] for o in menu['scope']['objects']),
        mi[menu['apply_owner']] if 'apply_owner' in menu else NONE,
        menu['hide_world'],tuple(inputs),drafts,entries,dict(kind='objects',bindings=bindings),
        ci[menu['navigation_sfx']] if 'navigation_sfx' in menu else NONE)
