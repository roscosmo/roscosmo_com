"""Private IVC1 catalog transport using the enclosing package's exact orders."""
import struct
from .inventory_source import catalog
from .machine_wire import require


def merge_text_bindings(text, quantities, object_count):
    """Merge BPT1 and BQT1 wrappers without changing their object identities."""
    rows = {}
    for data, magic in ((text, b'BPT1'), (quantities, b'BQT1')):
        offset, previous = 0, -1
        while offset < len(data):
            require(offset + 4 <= len(data), 'INVENTORY_DEVICE_BINDING: truncated text wrapper')
            obj, size = struct.unpack_from('<HH', data, offset)
            end = offset + 4 + size
            require(previous < obj < object_count and obj not in rows and size >= 4 and
                    end <= len(data) and data[offset+4:offset+8] == magic,
                    'INVENTORY_DEVICE_BINDING: conflicting or malformed text binding')
            rows[obj] = data[offset:end]
            previous, offset = obj, end
    return b''.join(rows[index] for index in sorted(rows))


def attach_catalog(presentation, catalog_bytes):
    """MPR1 v15 retains IVC1 with the existing text and scope sections.

    Enclosing verified package admission still owns catalog/table validation.
    This is transport only; it does not enable public export or playback.
    """
    require(len(presentation)>=32 and presentation[:4]==b'MPR1' and
            struct.unpack_from('<HHI',presentation,4)==(14,32,len(presentation)),
            'INVENTORY_DEVICE_BINDING: expected scoped MPR1 v14')
    text_size,scope_size=struct.unpack_from('<II',presentation,24)
    end=32+text_size+scope_size
    require(scope_size>=40 and end<=len(presentation),
            'INVENTORY_DEVICE_BINDING: invalid retained section bounds')
    require(20<=len(catalog_bytes)<=856 and catalog_bytes[:4]==b'IVC1' and
            struct.unpack_from('<HHI',catalog_bytes,4) in
            ((1,20,len(catalog_bytes)),(2,24,len(catalog_bytes))),
            'INVENTORY_DEVICE_BINDING: expected IVC1 catalog')
    result=bytearray(presentation[:32]+struct.pack('<I',len(catalog_bytes))+
                     presentation[32:end]+catalog_bytes+presentation[end:])
    struct.pack_into('<HHI',result,4,15,36,len(result))
    return bytes(result)


def compile_catalog(project, *, items, strings, scene=None, objects=None):
    definitions = catalog(project)
    items, strings = tuple(items), tuple(strings)
    require(len(items) == len(set(items)) and set(items) == set(definitions),
            'INVENTORY_DEVICE_BINDING: item order must cover the complete catalog')
    require(len(strings) <= 65535 and len(strings) == len(set(strings)),
            'INVENTORY_DEVICE_BINDING: invalid package string table')
    indices = {value: index for index, value in enumerate(strings)}
    config = project.get('inventory', {})
    resets = config.get('reset_variables', [])
    require(len(resets) <= 32, 'INVENTORY_DEVICE_BINDING: too many reset variables')
    require(all(ref in indices for ref in (*items, *resets)),
            'INVENTORY_DEVICE_BINDING: catalog identity missing from package strings')
    rows = b''.join(struct.pack('<4H', indices[ref], definitions[ref]['initial_count'],
                              definitions[ref]['max_count'], 0) for ref in items)
    rows += b''.join(struct.pack('<H', indices[ref]) for ref in resets)
    if scene is None:
        require(objects is None, 'INVENTORY_DEVICE_BINDING: objects require a Scene')
        return struct.pack('<4sHHI4H', b'IVC1', 1, 20, 20+len(rows), len(items), len(resets),
                           int(config.get('reset_on_restart', False)), len(strings)) + rows
    from .inventory_source import validate_scene
    validate_scene(project, scene)
    objects=tuple(objects or ())
    require(len(objects)<=64 and len(set(objects))==len(objects) and
            set(objects)=={o['object_id'] for o in scene.get('objects',[])},
            'INVENTORY_DEVICE_BINDING: exact Scene object table required')
    pickups=scene.get('pickups',[])
    rows+=b''.join(struct.pack('<4H',objects.index(p['object_ref']),objects.index(p['collector_ref']),
                              items.index(p['item_ref']),p['quantity']) for p in pickups)
    return struct.pack('<4sHHI6H',b'IVC1',2,24,24+len(rows),len(items),len(resets),
                       int(config.get('reset_on_restart',False)),len(strings),len(pickups),len(objects))+rows


def compile_quantity(project, *, item, items):
    """BQT1 content record; enclosing text-binding wrapper supplies the object."""
    definitions = catalog(project)
    items = tuple(items)
    require(len(items) == len(set(items)) and set(items) == set(definitions) and item in items,
            'INVENTORY_DEVICE_BINDING: quantity requires the exact admitted item order')
    return struct.pack('<4s4H', b'BQT1', 1, items.index(item), definitions[item]['max_count'], 0)


def compile_quantity_bindings(project, scene, *, items, objects):
    """Ordinary resolved-text wrappers in exact enclosing Scene object order.

    The package encoder must merge these with BPT1 records, rejecting duplicate
    object ownership, and admit IVC1 against the same verified package tables.
    This helper alone is not public export or installed activation.
    """
    objects=tuple(objects)
    source={obj['object_id']: obj for obj in scene.get('objects', [])}
    require(len(objects)==len(set(objects)) and set(objects)==set(source),
            'INVENTORY_DEVICE_BINDING: quantity requires the exact Scene object order')
    rows={}
    for binding in scene.get('menu_component', {}).get('presentation', {}).get('bindings', []):
        if 'quantity_item_ref' not in binding:
            continue
        ref=binding['object_ref']
        require(ref in source and source[ref]['kind']=='text' and ref not in rows,
                'INVENTORY_DEVICE_BINDING: quantity requires a unique text object')
        rows[ref]=compile_quantity(project,item=binding['quantity_item_ref'],items=items)
    return b''.join(struct.pack('<HH',index,len(rows[ref]))+rows[ref]
                    for index,ref in enumerate(objects) if ref in rows)
