"""Private SCP1 scope descriptor; not an executable menu or export grant.

Caller supplies identities in the exact order used by the enclosing compiled
Scene/instance image. No source-list order is assumed and no actions are removed.
The parent must associate this record with that same verified Scene image.
"""
import struct

from .compiler import LOGICAL_SOURCES, LOGICAL_EVENTS
from .execution_scope_source import configuration
from .machine_limits import MACHINES, EVENTS, INPUTS
from .machine_wire import require, NONE

HEADER = struct.Struct('<4sHHI4BHHQ4BII')


def compile_execution_scopes(scene, *, machines, events, objects, instances):
    scope = configuration(scene)
    require(scope is not None, 'SCP1: Scene has no execution scopes')
    graph = scene['machine_logic']
    require(not graph.get('time_reconcile') and not any(
        row['event_type'] == 'time.local_schedule' for row in scene.get('event_bindings', [])),
        'SCP1: scoped calendar reconciliation is not connected')

    def index(values, known, label, maximum, *, exact=True):
        values = tuple(values)
        require(all(type(value) is str for value in values) and len(set(values)) == len(values)
                and len(values) <= maximum, f'SCP1: invalid compiled {label} identities')
        require(set(known) == set(values) if exact else set(known) <= set(values),
                f'SCP1: compiled {label} identities do not cover authored Scene')
        return {ref: i for i, ref in enumerate(values)}

    mi = index(machines, [m['machine_id'] for m in graph['machines']], 'machines', MACHINES)
    ei = index(events, [*(a['action_id'] for a in scene['input_actions']),
        *(b['binding_id'] for b in scene.get('event_bindings', [])),
        *(e['event_id'] for e in graph['events'])], 'events', EVENTS, exact=False)
    oi = index(objects, [o['object_id'] for o in scene['objects']], 'objects', 64)
    ii = index(instances, [i['instance_id'] for i in graph.get('instance_behaviors', {}).get('instances', [])],
               'instances', 65535)
    menu = scope['menu']
    machine_mask = sum(1 << mi[ref] for ref in menu['machines'])
    object_mask = sum(1 << oi[ref] for ref in menu['objects'])
    instance_scopes = bytes(int(ref in menu['instances']) for ref in ii)
    named = {e['event_id'] for e in graph['events']}

    def address(value):
        if value is None:
            return NONE, NONE
        require(value['event_ref'] in named,
                'SCP1: menu inputs and lifecycle receivers require named events')
        return mi[value['machine_ref']], ei[value['event_ref']]

    inputs = {a['action_id']: a for a in scene['input_actions']}
    records = []
    for action, receiver in menu['input_receivers'].items():
        row = inputs[action]
        records.append((LOGICAL_SOURCES[row['logical_source']],
                        LOGICAL_EVENTS[row.get('event_kind', 'press')], *address(receiver)))
    records.sort()
    require(len(records) <= INPUTS and len({row[:2] for row in records}) == len(records),
            'SCP1: duplicate or excessive menu input bindings')
    body = instance_scopes + b''.join(bytes(row) for row in records)
    return HEADER.pack(b'SCP1', 1, HEADER.size, HEADER.size + len(body),
        len(mi), len(ei), len(oi), len(records), len(ii), machine_mask, object_mask,
        *address(menu.get('confirm_receiver')), *address(menu.get('entry_receiver')), 0, 0) + body


def decode_execution_scopes(data):
    """Bounded structural reader. Native admission also checks Scene recipients."""
    require(isinstance(data, bytes) and len(data) >= HEADER.size, 'SCP1: truncated header')
    (magic, version, header, size, nm, ne, no, ni, nx, mm, om,
     cm, ce, em, ee, flags, reserved) = HEADER.unpack_from(data)
    require((magic, version, header, size) == (b'SCP1', 1, HEADER.size, len(data))
            and 2 <= nm <= MACHINES and 0 < ne <= EVENTS and 0 < no <= 64
            and ni <= INPUTS and not flags and not reserved
            and len(data) == HEADER.size + nx + ni * 4,
            'SCP1: invalid header/counts')
    require(0 < mm < (1 << nm) - 1 and om < 1 << no, 'SCP1: invalid scope masks')
    for machine, event, menu in ((cm, ce, False), (em, ee, True)):
        require((machine, event) == (NONE, NONE) or
                machine < nm and event < ne and bool(mm & (1 << machine)) == menu,
                'SCP1: invalid lifecycle receiver')
    memberships = tuple(data[header:header + nx])
    require(all(value <= 1 for value in memberships), 'SCP1: invalid instance membership')
    records = tuple(tuple(data[i:i+4]) for i in range(header + nx, len(data), 4))
    previous = (0, 0)
    for source, kind, machine, event in records:
        require(1 <= source <= 13 and 1 <= kind <= 4 and (source, kind) > previous
                and machine < nm and mm & (1 << machine) and event < ne,
                'SCP1: invalid menu input')
        previous = source, kind
    return dict(machine_count=nm, event_count=ne, object_count=no,
                menu_machines=mm, menu_objects=om, instances=memberships, inputs=records,
                confirm=(cm, ce), entry=(em, ee))
