"""Private cell-ahead descriptor lowering; no package opcode/public capability.

Consumes validated world-reference output. The first slice admits stationary
interactables only: writable target positions would invalidate the build-time
non-overlap proof. Actor movement remains ordinary staged world writes.
"""
from dataclasses import dataclass

from .imported_properties import ImportedPropertyError
from .tilemap_wire import HEADER, ENTITY
from .world_operands_wire import HEADER as WOP_HEADER, BINDING
from .world_references import WorldReference


@dataclass(frozen=True)
class CellQuery:
    actor_x: int
    actor_y: int
    width: int
    height: int
    value_type: int
    targets: tuple


def compile_cell_query(world, actor, properties, width, height, value_type):
    """Properties explicitly enumerate eligible instances, not all render objects.

    Every target must be a property on the same map, with declared X/Y bindings.
    Overlap uses grid cells relative to the actor's initial grid origin. Off-grid
    targets are refused, not silently snapped. Names survive only in diagnostics.
    The returned descriptor is private build data, not an installed wire record.
    """
    def fail(message):
        raise ImportedPropertyError(message)

    if (not isinstance(actor, WorldReference) or actor.field != 'entity_x' or
            actor.property_id or value_type not in ('bool', 'int32') or
            any(type(v) is not int or not 0 < v <= 0x7fffffff for v in (width, height))):
        fail('invalid cell query actor, type or grid spacing')
    if not isinstance(properties, (tuple, list)):
        fail('cell query targets must be an array')
    slots = {ref: i for i, ref in enumerate(world.binding_sources)}

    def binding(ref, kind):
        if ref not in slots:
            fail(f'undeclared interaction binding: {ref}')
        index = slots[ref]
        record = BINDING.unpack_from(world.operands, WOP_HEADER.size + index*BINDING.size)
        if record[2] != kind:
            fail(f'interaction binding has wrong type: {ref}')
        return index, record

    ax, _ = binding(actor, 0)
    ay, _ = binding(WorldReference(actor.asset_id, 'entity_y', actor.owner_id), 0)
    header = HEADER.unpack_from(world.map.data)
    entities = {}
    for i in range(header[11]):
        row = ENTITY.unpack_from(world.map.data, header[14] + i*ENTITY.size)
        entities[f'object:{row[0]}'] = row[2:4]
    if actor.owner_id not in entities:
        fail('interaction actor is absent from compiled map')
    ox, oy = entities[actor.owner_id]
    occupied, targets = {}, []
    for prop in properties:
        if (not isinstance(prop, WorldReference) or prop.asset_id != actor.asset_id or
                prop.field != 'property' or prop.owner_id == actor.owner_id or
                prop.owner_id not in entities):
            fail('interaction requires a property on another entity in the same map')
        p, _ = binding(prop, int(value_type == 'bool'))
        x, bx = binding(WorldReference(actor.asset_id, 'entity_x', prop.owner_id), 0)
        y, by = binding(WorldReference(actor.asset_id, 'entity_y', prop.owner_id), 0)
        if bx[3] != 255 or by[3] != 255:
            fail(f'interactable {prop.owner_id} must have read-only positions in this slice')
        px, py = entities[prop.owner_id]
        if (px-ox) % width or (py-oy) % height:
            fail(f'interactable {prop.owner_id} is not aligned to the interaction grid')
        cell = ((px-ox)//width, (py-oy)//height)
        if cell in occupied:
            fail(f'overlapping interactables {occupied[cell]} and {prop.owner_id} at cell {cell}')
        occupied[cell] = prop.owner_id
        targets.append((x, y, p))
    return CellQuery(ax, ay, width, height, int(value_type == 'bool'), tuple(targets))
