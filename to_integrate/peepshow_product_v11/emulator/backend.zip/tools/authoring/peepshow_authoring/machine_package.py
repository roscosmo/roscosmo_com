"""Shared model-3 encoder; public exports additionally enforce machine_export."""
from copy import deepcopy
import struct

from .compiler import (_string_table, _compile_manifest, _compile_scene_table,
                       _compile_audio_chunks)
from .egg_format import EggChunkSpec, build_container
from .machine_scene import compile_machine_scene
from .machine_wire import require
from .target_profile import target_profile_for_id


def encode_machine_package(bundle, *, _flowcharts=False, _object_effects=False, _calendars=False, _periodic=False,
                           _selector_encoder=None, _graph_encoder=None, _map_chunks=(), _scope_encoder=None,
                           _component_sources=None):
    """Emit model-3 bytes; callers enforce the applicable export profile.

    Public export admits bounded resident multi-scene packages through
    machine_export; this encoder alone is not a readiness check.
    """
    require(bundle.valid, "project must validate")
    scenes = tuple(sorted(bundle.scenes, key=lambda scene: scene["scene_id"]))
    require(1 <= len(scenes) <= 8 and all("machine_logic" in s for s in scenes),
            "only all-machine packages are supported")
    require(all(s["interaction_policy"]["mode"] == "continuous" for s in scenes),
            "machine inactivity policy transport is not integrated")
    # Include package names without changing source declarations or scene scopes.
    string_scenes = deepcopy(scenes)
    string_scenes[0]["variables"].extend(bundle.project.get("package_variables", []))
    require(_component_sources is None or _scope_encoder is None,
            'component and legacy scope encoders cannot both own a Scene')
    if _component_sources is not None:
        require(set(_component_sources) == {s['scene_id'] for s in scenes},
                'component source association must cover every Scene')
    items = tuple(r['item_id'] for r in bundle.project.get('inventory', {}).get('items', []))
    table = _string_table(bundle, string_scenes,
                         _extra_strings=items if _component_sources is not None else ())
    _, indexes, strings = table
    chunk_indexes = {s["scene_id"]: (3 + i * 3, 4 + i * 3, 5 + i * 3) for i, s in enumerate(scenes)}
    scene_table = bytearray(_compile_scene_table(scenes, indexes, chunk_indexes, _development_v2=True))
    for i in range(len(scenes)):
        struct.pack_into("<H", scene_table, 12 + 20 * i + 14, 3)
    chunks = [EggChunkSpec("strings", 2, strings),
              EggChunkSpec("manifest", 1, _compile_manifest(bundle.project, indexes, len(scenes))),
              EggChunkSpec("scenes", 3, bytes(scene_table))]
    ids = [indexes[v["variable_id"]] for v in bundle.project.get("package_variables", [])]
    package_ids = struct.pack(f"<{len(ids)}H", *ids)
    for scene in scenes:
        sections = compile_machine_scene(bundle, scene["scene_id"], sprite_chunk_index=4 + len(scenes) * 3,
                                         animation_chunk_index=5 + len(scenes) * 3, string_table=table,
                                         _flowcharts=_flowcharts, _object_effects=_object_effects, _calendars=_calendars, _periodic=_periodic,
                                         _selector_encoder=_selector_encoder,
                                         _execution_scopes=_scope_encoder is not None or _component_sources is not None,
                                         _scope_encoder=(lambda payload: _scope_encoder(scene['scene_id'], payload))
                                             if _scope_encoder is not None else None,
                                         _component=_component_sources[scene['scene_id']]
                                             if _component_sources is not None else None,
                                         _inventory_items=items)
        body = package_ids + sections.logic + sections.presentation
        graph = struct.pack("<4sHHIIIHH", b"MGS1", 1, 24, 24 + len(body),
                            len(sections.logic), len(sections.presentation), len(ids), 0) + body
        if _graph_encoder is not None:
            graph = _graph_encoder(scene['scene_id'], sections, ids)
        ref = scene["scene_id"]
        chunks.extend((EggChunkSpec(f"machines.{ref}", 4, graph),
                       EggChunkSpec(f"objects.{ref}", 13, sections.objects),
                       EggChunkSpec(f"controls.{ref}", 14, sections.controls)))
    if bundle.frames:
        chunks.extend((EggChunkSpec("assets", 7, sections.assets),
                       EggChunkSpec("sprites", 8, sections.sprites),
                       EggChunkSpec("animations", 9, sections.animations)))
    if bundle.audio_assets:
        assets, bank, cues = _compile_audio_chunks(bundle, indexes, len(chunks) + 2)
        chunks.extend((EggChunkSpec("audio.assets", 10, assets), EggChunkSpec("audio.cues", 12, cues),
                       EggChunkSpec("audio.bank", 11, bank)))
    require(not _map_chunks or _graph_encoder is not None, 'map chunks require associated graph encoder')
    chunks.extend(_map_chunks)
    blob = build_container(bundle.project["package"]["package_id"], chunks,
                           manifest_chunk_index=1, _development_v2=True,
                           _qualification_maps=bool(_map_chunks))
    require(len(blob) <= target_profile_for_id(bundle.project["selected_target_profile"])["package"]["maximum_bytes"],
            "package byte capacity exceeded")
    return blob


def build_machine_test_egg(bundle, *, _flowcharts=False, _object_effects=False, _calendars=False, _periodic=False,
                           _selector_encoder=None):
    """Internal decoder-test entry, including non-installable multiscene data."""
    return encode_machine_package(bundle, _flowcharts=_flowcharts, _object_effects=_object_effects, _calendars=_calendars, _periodic=_periodic,
                                  _selector_encoder=_selector_encoder)
