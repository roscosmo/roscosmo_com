"""Shared dense tile ordering for validated private map/graphics exports."""


def used_tiles(snapshot):
    """Return source GIDs in wire order, including currently hidden layers.

    Source identities stay unchanged in the authoring snapshot. Zero remains
    the empty cell; wire IDs are one-based indices into this tuple.
    """
    return tuple(sorted({gid for layer in snapshot['layers']
                         if layer['type'] == 'tilelayer'
                         for gid in layer['data'] if gid}))


def source_ranges(gids):
    """Compact provenance runs: (first wire ID, first source GID, count)."""
    ranges = []
    for wire_id, gid in enumerate(gids, 1):
        if ranges and ranges[-1][1] + ranges[-1][2] == gid:
            first, source, count = ranges[-1]
            ranges[-1] = (first, source, count + 1)
        else:
            ranges.append((wire_id, gid, 1))
    return tuple(ranges)
