"""Placed actor output responses lowered to the existing bounded Scene FIFO."""
from copy import deepcopy
from .imported_properties import ImportedPropertyError

COMMANDS = ('scene.actor.output_response.set', 'scene.actor.output_response.remove')
ACTION_KINDS = ('object.play_clip', 'object.cancel_clip', 'object.play_effect',
                'object.set_visibility', 'play_sfx', 'send_event')
CONDITION_KINDS = ('world.compare', 'facing.compare', 'collision.compare')
CAPABILITY = dict(field='instances[].output_responses', commands=list(COMMANDS),
    schema='schemas/authoring/actor-output-response-v1.schema.json',
    response_grammar='event_response_v1', terminals=['stay'], maximum_responses=32,
    action_kinds=list(ACTION_KINDS), visual_targets='own_world_objects',
    condition_kinds=[*CONDITION_KINDS, 'variable_compare'],
    external_connections='explicit_send_event', writer='instance.writer_ref',
    delivery='existing_mixed_event_fifo', synchronous=False,
    outgoing_binding_conflict='reject_same_output', host_editing=True,
    host_preview=True, persisted=True, undo_redo=True, runtime=False, export=False,
    preview_context='actor_output')


def lower(scene):
    """Return a private copy plus generated-route -> authored-output identities."""
    graph = scene.get('machine_logic', {})
    source = graph.get('instance_behaviors', {})
    if not any('output_responses' in i for i in source.get('instances', [])):
        return scene, {}
    result = deepcopy(scene)
    graph = result['machine_logic']
    source = graph['instance_behaviors']
    if source.get('version') != 3:
        raise ImportedPropertyError('Actor output responses require instance source version 3')
    used, pending = set(), [graph]
    while pending:
        value = pending.pop()
        if type(value) is str:
            used.add(value)
        elif type(value) is dict:
            pending.extend(value.values())
        elif type(value) is list:
            pending.extend(value)
    origins = {}
    from .behavior_interface_source import ports
    for instance in source['instances']:
        rows = instance.pop('output_responses', [])
        path = f"instance[{instance['instance_id']}].output_responses"

        def require(ok, message):
            if not ok:
                raise ImportedPropertyError(f'{path}: {message}')

        require(type(rows) is list and len(rows) <= 32, 'requires at most 32 responses')
        definition = next((b for b in source['behaviors'] if b['behavior_id'] == instance['behavior_ref']), None)
        declared = ports(definition) if definition else None
        owner = next((m for m in graph['machines'] if m['machine_id'] == instance['writer_ref']), None)
        visuals = {r['object_ref'] for r in graph.get('world_positions', [])
                   if r['entity_ref'] == instance['entity']['owner_id']}
        seen = set()
        for row in rows:
            require(type(row) is dict and set(row) == {'event_ref', 'response'}, 'requires event_ref and response')
            event = row['event_ref']
            require(type(event) is str and declared is not None and event in declared['outputs'], 'requires a declared output')
            path = f"instance[{instance['instance_id']}].output_responses[{event}]"
            require(event not in seen, 'duplicate output response')
            seen.add(event)
            require(owner is not None, 'unknown declared writer')
            require(not any(r['instance_ref'] == instance['instance_id'] and r['event_ref'] == event
                            for r in source.get('outgoing', [])),
                    'remove the direct outgoing binding before adding a response for this output')
            response = row['response']
            require(type(response) is dict and type(response.get('nodes')) is list, 'requires an event response graph')
            for node in response['nodes']:
                require(type(node) is dict, 'invalid response node')
                if node.get('kind') == 'decision':
                    condition = node.get('condition')
                    require(type(condition) is dict and (condition.get('kind') in CONDITION_KINDS or
                            ('kind' not in condition and 'variable_ref' in condition)), 'unsupported output condition')
                if node.get('kind') == 'return':
                    require(set(node) == {'node_id', 'kind'}, 'output response returns without changing a machine State or Scene')
                if node.get('kind') == 'actions':
                    require(type(node.get('actions')) is list, 'requires an action array')
                    for action in node['actions']:
                        require(type(action) is dict and action.get('kind') in ACTION_KINDS, 'unsupported output action')
                        if action['kind'].startswith('object.'):
                            require(action.get('object_ref') in visuals, 'visual actions must address this actor\'s own world objects')
            ordinal = len(origins)
            name = f'ps_actor_output_{ordinal}'
            while name in used:
                ordinal += 1
                name = f'ps_actor_output_{ordinal}'
            used.add(name)
            origins[name] = dict(context='actor_output', instance_ref=instance['instance_id'],
                behavior_ref=instance['behavior_ref'], event_ref=event, route_id=event)
            graph['events'].append(dict(event_id=name, display_name=f"{instance['instance_id']} output {event}"))
            graph['routes'].append(dict(route_id=name, machine_ref=owner['machine_id'], event_ref=name,
                from_states=list(owner['states']), response=deepcopy(response)))
            source.setdefault('outgoing', []).append(dict(instance_ref=instance['instance_id'],
                event_ref=event, machine_ref=owner['machine_id'], target_event_ref=name))
    return result, origins


def edit(instance, command):
    rows = instance.setdefault('output_responses', [])
    event = command['event_ref']
    if type(event) is not str or not event:
        raise ImportedPropertyError('Output event_ref must be a nonempty name')
    index = next((i for i, row in enumerate(rows) if row['event_ref'] == event), None)
    if command['kind'].endswith('.set'):
        row = dict(event_ref=event, response=deepcopy(command['response']))
        if index is None:
            rows.append(row)
        else:
            rows[index] = row
    elif index is None:
        raise ImportedPropertyError('Unknown actor output response: ' + event)
    else:
        rows.pop(index)
    if not rows:
        instance.pop('output_responses')


def describe_error(scene, message):
    """Translate private route/event addresses in later validation diagnostics."""
    try:
        _, origins = lower(scene)
    except (ImportedPropertyError, KeyError, TypeError, AttributeError):
        return message  # Malformed source already carries its authored location.
    for name in sorted(origins, key=len, reverse=True):
        origin = origins[name]
        message = message.replace(name,
            f"instance[{origin['instance_ref']}].output_responses[{origin['event_ref']}]")
    return message
