"""Private bounded SFX command admission; not a mixer or proof of audible stop."""
from copy import deepcopy
from .preview import PreviewError


class ScopeAudio:
    # The existing executor admits at most eight cues per transaction. The
    # qualification consumer must drain this bounded outbox between transactions.
    capacity = 8

    def __init__(self):
        self.focus = 'gameplay'
        self.epochs = dict(gameplay=0, menu=0)
        self.admission = dict(gameplay=True, menu=False)
        self.may_be_playing = dict(gameplay=False, menu=False)
        self.queued = []
        self.sequence = 0
        self.stop_sequence = 0
        self.pending_stop = None
        self.last_stop = None

    def stage(self, scope, cue):
        if scope not in self.admission or not self.admission[scope]:
            raise PreviewError('scope_audio_admission_closed')
        if len(self.queued) >= self.capacity:
            raise PreviewError('scope_audio_outbox_capacity')
        self.sequence += 1
        command = dict(cue, audio_scope=scope, audio_epoch=self.epochs[scope], audio_sequence=self.sequence)
        self.queued.append(command)
        return deepcopy(command)

    def take(self):
        commands = tuple(deepcopy(self.queued))
        for command in commands:
            self.may_be_playing[command['audio_scope']] = True
        self.queued.clear()
        return commands

    def current(self, command):
        scope = command.get('audio_scope')
        return (scope in self.admission and self.admission[scope]
                and command.get('audio_epoch') == self.epochs[scope])

    def stop(self, scopes):
        scopes = set(scopes)
        if not scopes or not scopes <= self.admission.keys():
            raise PreviewError('invalid scope audio stop')
        # Shell preemption may supersede a pending one-scope stop. The new
        # acknowledgement must cover the union; the old token cannot release it.
        if self.pending_stop is not None:
            scopes.update(self.pending_stop['scopes'])
        self.stop_sequence += 1
        for scope in scopes:
            self.admission[scope] = False
            self.epochs[scope] += 1
        self.queued = [c for c in self.queued if c['audio_scope'] not in scopes]
        required = any(self.may_be_playing[scope] for scope in scopes)
        record = dict(kind='stop_scope_sfx', token=self.stop_sequence, scopes=sorted(scopes),
                      epochs={s:self.epochs[s] for s in sorted(scopes)},
                      status='pending' if required else 'no_submitted_requests')
        self.pending_stop = deepcopy(record) if required else None
        self.last_stop = record
        return deepcopy(record)

    def complete_stop(self, token, success):
        if type(success) is not bool:
            raise PreviewError('scope audio stop result requires Boolean success')
        if (type(token) is not int or self.pending_stop is None
                or token != self.pending_stop['token']):
            raise PreviewError('stale scope audio stop completion')
        record = self.pending_stop
        if success:
            for scope in record['scopes']:
                self.may_be_playing[scope] = False
        self.last_stop = dict(record, status='stopped' if success else 'failed')
        self.pending_stop = None
        # Success proves stop, but never reopens admission or replays a cue.

    def change_focus(self, target):
        if target not in self.admission:
            raise PreviewError('invalid scope audio focus')
        if target == self.focus:
            if not self.admission[target]:
                self.resume()
            return
        if self.pending_stop or any(self.may_be_playing.values()):
            raise PreviewError('scope audio stop acknowledgement required before focus transfer')
        self.stop([self.focus])
        self.focus = target
        self.admission = {s:s == target for s in self.admission}

    def resume(self):
        if self.pending_stop or any(self.may_be_playing.values()):
            raise PreviewError('scope audio stop acknowledgement required before resume')
        self.admission = {s:s == self.focus for s in self.admission}

    def snapshot(self):
        return dict(focus=self.focus, epochs=dict(self.epochs), admission=dict(self.admission),
            submitted_since_stop=dict(self.may_be_playing), queued=deepcopy(self.queued),
            capacity=self.capacity, pending_stop=deepcopy(self.pending_stop), last_stop=deepcopy(self.last_stop))
