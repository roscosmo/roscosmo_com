"""Load, validate, and normalize the first PeepShow STATE authoring subset."""

from __future__ import annotations

import base64
import hashlib
import json
import re
import shutil
from copy import deepcopy
from dataclasses import dataclass
from math import gcd
from pathlib import Path
from typing import Any, Iterable

from .audio_assets import (
    AUDIO_MAX_ASSETS,
    AUDIO_MAX_CUES,
    AudioAssetError,
    CompiledAudioAsset,
    import_sampled_sfx,
)
from .image_assets import (
    ImageAssetError,
    Masked1bppFrame,
    import_masked_1bpp,
    resolve_project_path,
)
from .system_fonts import SystemFontError, rasterize_system_font_text
from .target_profile import (
    SUPPORTED_TARGET_PROFILE_IDS,
    TARGET_PROFILE_ID,
    TARGET_STATE_SCENE_EVENTS,
    TARGET_STATE_TIMER,
)


STABLE_ID = re.compile(r"^[a-z][a-z0-9_.-]{0,63}$")
GUARD_OPERATORS = {"eq", "ne", "lt", "le", "gt", "ge"}
ACTION_OPERATIONS = {"assign", "add"}
LOGICAL_INPUT_SOURCES = {
    "BUTTON_A",
    "BUTTON_B",
    "BUTTON_L",
    "BUTTON_R",
    "BUTTON_START",
    "JOY_LEFT",
    "JOY_RIGHT",
    "JOY_UP",
    "JOY_DOWN",
    "JOY_UP_LEFT",
    "JOY_UP_RIGHT",
    "JOY_DOWN_LEFT",
    "JOY_DOWN_RIGHT",
}
STATE_WAITING_ANIMATION_QUANTUM_MS = 250
STATE_GRAPH_ROUTE_RAIL_MAX = 8
STATE_GRAPH_ROUTE_ACTION_TOKEN_MAX = 8
STATE_GRAPH_ROUTE_LAYOUT_VERSION = 3
STATE_GRAPH_HANDLER_LAYOUT_VERSION = 1
SCENE_FLOW_REFERENCE_MAX = 64
SCENE_FLOW_ROUTE_LAYOUT_VERSION = 1
STATE_GRAPH_SYSTEM_EXIT_NODE_ID = "system-exit"
STATE_GRAPH_ENTRY_HANDLES = {
    "entry-top-left",
    "entry-top-right",
    "entry-bottom-left",
    "entry-bottom-right",
}
STATE_GRAPH_ENTRY_SIDES = {"left", "right", "top", "bottom"}
STATE_GRAPH_ENTRY_HANDLE_SIDES = {
    "entry-top-left": {"top", "left"},
    "entry-top-right": {"top", "right"},
    "entry-bottom-left": {"bottom", "left"},
    "entry-bottom-right": {"bottom", "right"},
}
LOGICAL_INPUT_EVENT_KINDS = {"press", "release", "hold", "repeat"}
JOYSTICK_POLICIES = {"four_way", "eight_way"}
STATE_EVENT_BINDING_MAX = int(TARGET_STATE_SCENE_EVENTS["binding_count_max"])
STATE_TIMER_DELAY_SCHEMA = TARGET_STATE_TIMER["configuration_schema"]["delay_ms"]
STATE_TIMER_MIN_MS = int(STATE_TIMER_DELAY_SCHEMA["minimum"])
STATE_TIMER_MAX_MS = int(STATE_TIMER_DELAY_SCHEMA["maximum"])
PROJECT_KEYS = {
    "schema_id",
    "schema_version",
    "project_id",
    "project_name",
    "package",
    "selected_target_profile",
    "entry_scene",
    "scene_sources",
    "validation",
}
PROJECT_OPTIONAL_KEYS = {"execution_semantics", "asset_sources", "editor", "settings", "variable_model", "package_variables", "inventory", "actor_templates"}
SCENE_KEYS = {
    "schema_id",
    "schema_version",
    "scene_id",
    "display_name",
    "scene_type",
    "entry_state",
    "variables",
    "input_actions",
    "states",
    "routes",
    "render_models",
    "waiting_visuals",
    "reactive_wait_default",
    "interaction_policy",
}
SCENE_OPTIONAL_KEYS = {"joystick_policy", "scene_exits", "event_bindings", "event_handlers", "entry_graph", "menu_component", "pickups"}


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    path: str
    message: str


@dataclass(frozen=True)
class ProjectBundle:
    root: Path
    project: dict[str, Any]
    scenes: tuple[dict[str, Any], ...]
    scene_sources: tuple[str, ...]
    asset_catalogs: tuple[dict[str, Any], ...]
    asset_catalog_sources: tuple[str, ...]
    assets: tuple[dict[str, Any], ...]
    animations: tuple[dict[str, Any], ...]
    frames: tuple[Masked1bppFrame, ...]
    audio_assets: tuple[CompiledAudioAsset, ...]
    audio_cues: tuple[dict[str, Any], ...]
    issues: tuple[ValidationIssue, ...]

    @property
    def valid(self) -> bool:
        return not self.issues

    def normalized(self) -> dict[str, Any]:
        if not self.valid:
            raise ValueError("cannot normalize an invalid project")
        return {
            "format": "peepshow.normalized.authoring",
            "format_version": 1,
            "project": self.project,
            "scenes": list(self.scenes),
            "assets": list(self.assets),
            "map_assets": [deepcopy(record) for catalog in self.asset_catalogs
                           for record in catalog.get("map_assets", [])],
            "animations": list(self.animations),
            "audio_assets": [
                {
                    "asset_id": asset.asset_id,
                    "tags": next((record.get("tags", []) for catalog in self.asset_catalogs
                                  for record in catalog.get("audio_assets", [])
                                  if record["asset_id"] == asset.asset_id), []),
                    "source_path": asset.source_path,
                    "source_sample_rate_hz": asset.source_sample_rate_hz,
                    "source_channels": asset.source_channels,
                    "sample_rate_hz": asset.sample_rate_hz,
                    "channels": asset.channels,
                    "sample_count": asset.sample_count,
                    "duration_ms": asset.duration_ms,
                    "decoded_pcm_bytes": asset.decoded_pcm_bytes,
                    "block_samples": asset.block_samples,
                    "block_count": asset.block_count,
                    "adpcm_bytes": len(asset.adpcm),
                    "adpcm_sha256": hashlib.sha256(asset.adpcm).hexdigest(),
                }
                for asset in self.audio_assets
            ],
            "audio_cues": list(self.audio_cues),
            "compiled_asset_frames": [
                {
                    "asset_id": frame.asset_id,
                    "frame_id": frame.frame_id,
                    "width": frame.width,
                    "height": frame.height,
                    "row_stride_bytes": frame.row_stride_bytes,
                    "pivot_x": frame.pivot_x,
                    "pivot_y": frame.pivot_y,
                    "opaque": frame.opaque,
                    "pixels_base64": base64.b64encode(frame.pixels).decode("ascii"),
                    "mask_base64": base64.b64encode(frame.mask).decode("ascii"),
                    "pixels_sha256": hashlib.sha256(frame.pixels).hexdigest(),
                    "mask_sha256": hashlib.sha256(frame.mask).hexdigest(),
                }
                for frame in sorted(self.frames, key=lambda item: (item.asset_id, item.frame_id))
            ],
        }

    def canonical_bytes(self) -> bytes:
        return (
            json.dumps(
                self.normalized(),
                ensure_ascii=True,
                separators=(",", ":"),
                sort_keys=True,
            )
            + "\n"
        ).encode("ascii")


class ProjectCommandError(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


def _issue(issues: list[ValidationIssue], code: str, path: str, message: str) -> None:
    issues.append(ValidationIssue(code, path, message))


def _require_command_fields(command: dict[str, Any], required: set[str], allowed: set[str]) -> None:
    missing = required - command.keys()
    unknown = command.keys() - allowed
    if missing or unknown:
        raise ProjectCommandError(
            "COMMAND_SHAPE_INVALID",
            f"command fields do not match the command API: missing={sorted(missing)} unknown={sorted(unknown)}",
        )


def _command_scene(scenes: list[dict[str, Any]], scene_id: Any) -> dict[str, Any]:
    issues: list[ValidationIssue] = []
    _stable_id(scene_id, "command.scene_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    for scene in scenes:
        if isinstance(scene, dict) and scene.get("scene_id") == scene_id:
            return scene
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")


def _command_record(
    scene: dict[str, Any],
    collection: str,
    id_field: str,
    record_id: Any,
) -> dict[str, Any]:
    records = scene.get(collection)
    if not isinstance(records, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", f"scene.{collection} must be an array")
    for record in records:
        if isinstance(record, dict) and record.get(id_field) == record_id:
            return record
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown {id_field} '{record_id}'")


def _command_index(value: Any, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ProjectCommandError("COMMAND_INDEX_INVALID", f"{field} must be a non-negative integer")
    return value


def _command_move_index(value: Any, field: str, length: int) -> int:
    index = _command_index(value, field)
    if index >= length:
        raise ProjectCommandError("COMMAND_INDEX_INVALID", f"{field} does not select an existing entry")
    return index


def _apply_scene_add(
    root: Path,
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    scene_sources: list[str],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "display_name"},
        {"kind", "display_name", "scene_schema_version", "command_id"},
    )
    scene_schema_version = _scene_schema_version(command.get("scene_schema_version", 1))
    display_name = command.get("display_name")
    issues: list[ValidationIssue] = []
    _text(display_name, "command.display_name", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if len(scenes) >= 32:
        raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "project supports at most 32 scenes")

    manifest_sources = project.get("scene_sources")
    if not isinstance(manifest_sources, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.scene_sources must be an array")
    if len(scene_sources) != len(scenes) or manifest_sources != scene_sources:
        raise ProjectCommandError("PROJECT_SOURCE_MISMATCH", "loaded scene sources do not match the project manifest")

    existing_ids = {
        str(scene.get("scene_id"))
        for scene in scenes
        if isinstance(scene.get("scene_id"), str)
    }
    base_id = _new_project_slug(str(display_name))
    scene_id = base_id
    suffix = 2
    while True:
        source = f"scenes/{scene_id}.state.json"
        if (
            scene_id not in existing_ids
            and source not in scene_sources
            and not (root / source).exists()
        ):
            break
        scene_id = f"{base_id}_{suffix}"
        suffix += 1

    interaction_template = scenes[0].get("interaction_policy") if scenes else None
    scene = _new_state_scene(
        scene_id,
        str(display_name),
        interaction_template=interaction_template,
        scene_schema_version=scene_schema_version,
    )
    from .authoring_foundation import enabled, empty_scene
    if enabled(project):
        if scene_schema_version != 2:
            scene = _new_state_scene(scene_id, str(display_name), scene_schema_version=2)
        empty_scene(scene)
    scenes.append(scene)
    scene_sources.append(source)
    manifest_sources.append(source)
    return {
        "kind": "scene.add",
        "scene_id": scene_id,
        "display_name": display_name,
        "source": source,
    }


def _apply_scene_rename(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "display_name"},
        {"kind", "scene_id", "display_name", "command_id"},
    )
    scene_id = command.get("scene_id")
    display_name = command.get("display_name")
    issues: list[ValidationIssue] = []
    _stable_id(scene_id, "command.scene_id", issues)
    _text(display_name, "command.display_name", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    scene = _command_scene(scenes, scene_id)
    scene["display_name"] = display_name
    return {
        "kind": "scene.rename",
        "scene_id": scene_id,
        "display_name": display_name,
    }


def _apply_project_set_entry_scene(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id"},
        {"kind", "scene_id", "command_id"},
    )
    scene_id = command.get("scene_id")
    issues: list[ValidationIssue] = []
    _stable_id(scene_id, "command.scene_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    _command_scene(scenes, scene_id)
    project["entry_scene"] = scene_id
    return {"kind": "project.set_entry_scene", "scene_id": scene_id}


def _apply_state_add(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "state"},
        {"kind", "scene_id", "state", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    state = command.get("state")
    if not isinstance(state, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "state must be an object")
    states = scene.get("states")
    if not isinstance(states, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.states must be an array")
    if len(states) >= 64:
        raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "scene supports at most 64 states")
    state_id = state.get("state_id")
    issues: list[ValidationIssue] = []
    _stable_id(state_id, "command.state.state_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if any(isinstance(item, dict) and item.get("state_id") == state_id for item in states):
        raise ProjectCommandError("PROJECT_ID_DUPLICATE", f"state '{state_id}' already exists")
    normalized = deepcopy(state)
    states.append(normalized)
    return {"kind": "state.add", "scene_id": scene.get("scene_id"), "state": normalized}


def _apply_state_create(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "display_name", "x", "y"},
        {"kind", "scene_id", "display_name", "x", "y", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    display_name = command.get("display_name")
    issues: list[ValidationIssue] = []
    _text(display_name, "command.display_name", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)

    states = scene.get("states")
    if not isinstance(states, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.states must be an array")
    existing_ids = {
        str(state.get("state_id"))
        for state in states
        if isinstance(state, dict) and isinstance(state.get("state_id"), str)
    }
    base_id = _new_project_slug(str(display_name))
    state_id = base_id
    suffix = 2
    while state_id in existing_ids:
        state_id = f"{base_id}_{suffix}"
        suffix += 1

    x = _layout_coordinate(command.get("x"), "command.x")
    y = _layout_coordinate(command.get("y"), "command.y")
    state = {"state_id": state_id, "display_name": display_name}
    if scene.get("schema_version") == 2:
        state["object_overrides"] = []
    else:
        waiting_visual_ids = [
            waiting.get("waiting_visual_id")
            for waiting in scene.get("waiting_visuals", [])
            if isinstance(waiting, dict) and isinstance(waiting.get("waiting_visual_id"), str)
        ]
        entry_state_id = scene.get("entry_state")
        entry_state = next(
            (state for state in states if isinstance(state, dict) and state.get("state_id") == entry_state_id),
            None,
        )
        waiting_visual_ref = entry_state.get("waiting_visual_ref") if isinstance(entry_state, dict) else None
        if waiting_visual_ref not in waiting_visual_ids:
            waiting_visual_ref = waiting_visual_ids[0] if waiting_visual_ids else None
        if waiting_visual_ref is None:
            raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", "scene has no waiting presentation for a new state")
        state["waiting_visual_ref"] = waiting_visual_ref
    added = _apply_state_add(
        scenes,
        {"kind": "state.add", "scene_id": scene.get("scene_id"), "state": state},
    )
    positioned = _apply_state_graph_node_position(
        project,
        scenes,
        {
            "kind": "editor.state_graph.set_node_position",
            "scene_id": scene.get("scene_id"),
            "state_id": state_id,
            "x": x,
            "y": y,
        },
    )
    return {
        "kind": "state.create",
        "scene_id": scene.get("scene_id"),
        "state": added["state"],
        "x": positioned["x"],
        "y": positioned["y"],
    }


def _apply_state_delete(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "state_id"},
        {"kind", "scene_id", "state_id", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    state_id = command.get("state_id")
    issues: list[ValidationIssue] = []
    _stable_id(state_id, "command.state_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    states = scene.get("states")
    if not isinstance(states, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.states must be an array")
    from .authoring_foundation import enabled
    incremental = enabled(project)
    if incremental:
        if not any(s.get('state_id') == state_id for s in states):
            raise ProjectCommandError('COMMAND_TARGET_UNKNOWN', f"unknown state '{state_id}'")
        states[:] = [s for s in states if s.get('state_id') != state_id]
        if scene.get('entry_state') == state_id:
            scene['entry_state'] = None
        for machine in scene.get('machine_logic', {}).get('machines', []):
            machine['states'] = [s for s in machine['states'] if s != state_id]
            if machine.get('entry_state') == state_id:
                machine['entry_state'] = None
        return dict(kind='state.delete', scene_id=scene['scene_id'], state_id=state_id)
    if len(states) <= 1:
        raise ProjectCommandError("COMMAND_TARGET_IN_USE", "the last state cannot be deleted")
    if scene.get("entry_state") == state_id:
        raise ProjectCommandError("COMMAND_TARGET_IN_USE", "entry state must be changed before deletion")
    if scene.get("schema_version") == 2:
        for handler in scene.get("event_handlers", []):
            if isinstance(handler, dict) and handler.get("target_state") == state_id:
                raise ProjectCommandError("COMMAND_TARGET_IN_USE", f"state '{state_id}' is referenced by handler '{handler.get('handler_id')}'")
    for route in scene.get("routes", []):
        if not isinstance(route, dict):
            continue
        if route.get("target_state") == state_id or state_id in route.get("from_states", []):
            raise ProjectCommandError("COMMAND_TARGET_IN_USE", f"state '{state_id}' is referenced by route '{route.get('route_id')}'")
    for index, state in enumerate(states):
        if isinstance(state, dict) and state.get("state_id") == state_id:
            states.pop(index)
            editor = project.get("editor")
            if isinstance(editor, dict):
                graph = editor.get("state_graph")
                graph_scenes = graph.get("scenes") if isinstance(graph, dict) else None
                layout = graph_scenes.get(scene.get("scene_id")) if isinstance(graph_scenes, dict) else None
                nodes = layout.get("nodes") if isinstance(layout, dict) else None
                if isinstance(nodes, dict):
                    nodes.pop(state_id, None)
            return {"kind": "state.delete", "scene_id": scene.get("scene_id"), "state_id": state_id}
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown state '{state_id}'")


def _apply_state_set_reference(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
    incremental: bool = False,
) -> dict[str, Any]:
    kind = command.get("kind")
    if kind != "state.set_entry":
        raise ProjectCommandError("COMMAND_KIND_UNKNOWN", f"unknown command kind '{kind}'")
    _require_command_fields(command, {"kind", "scene_id", "state_id"}, {"kind", "scene_id", "state_id", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    if incremental and command['state_id'] is None:
        scene['entry_state'] = None
        return dict(kind=kind, scene_id=scene['scene_id'], state_id=None)
    state = _command_record(scene, "states", "state_id", command.get("state_id"))
    scene["entry_state"] = state.get("state_id")
    return {"kind": kind, "scene_id": scene.get("scene_id"), "state_id": state.get("state_id")}


def _apply_render_model_add(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "scene_id", "render_model"}, {"kind", "scene_id", "render_model", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    model = command.get("render_model")
    if not isinstance(model, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "render_model must be an object")
    models = scene.get("render_models")
    if not isinstance(models, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.render_models must be an array")
    if len(models) >= 64:
        raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "scene supports at most 64 render models")
    visual_id = model.get("visual_id")
    issues: list[ValidationIssue] = []
    _stable_id(visual_id, "command.render_model.visual_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if any(isinstance(item, dict) and item.get("visual_id") == visual_id for item in models):
        raise ProjectCommandError("PROJECT_ID_DUPLICATE", f"render model '{visual_id}' already exists")
    normalized = deepcopy(model)
    models.append(normalized)
    return {"kind": "render_model.add", "scene_id": scene.get("scene_id"), "render_model": normalized}


def _apply_render_model_delete(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "scene_id", "visual_id"}, {"kind", "scene_id", "visual_id", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    visual_id = command.get("visual_id")
    models = scene.get("render_models")
    if not isinstance(models, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.render_models must be an array")
    if len(models) <= 1:
        raise ProjectCommandError("COMMAND_TARGET_IN_USE", "STATE_SCENE must keep one scene placement model")
    for index, model in enumerate(models):
        if isinstance(model, dict) and model.get("visual_id") == visual_id:
            models.pop(index)
            return {"kind": "render_model.delete", "scene_id": scene.get("scene_id"), "visual_id": visual_id}
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown render model '{visual_id}'")


def _apply_render_model_set_focus(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "scene_id", "visual_id", "focus_index"}, {"kind", "scene_id", "visual_id", "focus_index", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    model = _command_record(scene, "render_models", "visual_id", command.get("visual_id"))
    focus_index = command.get("focus_index")
    if isinstance(focus_index, bool) or not isinstance(focus_index, int) or not 0 <= focus_index <= 255:
        raise ProjectCommandError("RENDER_FOCUS_INVALID", "focus_index must be in 0..255")
    model["focus_index"] = focus_index
    return {"kind": "render_model.set_focus_index", "scene_id": scene.get("scene_id"), "visual_id": model.get("visual_id"), "focus_index": focus_index}


def _apply_variable_upsert(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    kind = command.get("kind")
    _require_command_fields(command, {"kind", "scene_id", "variable"}, {"kind", "scene_id", "variable", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    variable = command.get("variable")
    if not isinstance(variable, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "variable must be an object")
    variables = scene.get("variables")
    if not isinstance(variables, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.variables must be an array")
    variable_id = variable.get("variable_id")
    issues: list[ValidationIssue] = []
    _stable_id(variable_id, "command.variable.variable_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    existing = next((item for item in variables if isinstance(item, dict) and item.get("variable_id") == variable_id), None)
    normalized = deepcopy(variable)
    if kind == "variable.add":
        if existing is not None:
            raise ProjectCommandError("PROJECT_ID_DUPLICATE", f"variable '{variable_id}' already exists")
        if len(variables) >= 32:
            raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "scene supports at most 32 variables")
        variables.append(normalized)
    else:
        if existing is None:
            raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown variable '{variable_id}'")
        variables[variables.index(existing)] = normalized
    return {"kind": kind, "scene_id": scene.get("scene_id"), "variable": normalized}


def _apply_variable_delete(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "scene_id", "variable_id"}, {"kind", "scene_id", "variable_id", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    variable_id = command.get("variable_id")
    references = list(scene.get("routes", []))
    from .scene_entry import references as entry_references
    references.extend(entry_references(scene))
    if scene.get("schema_version") == 2:
        references.extend(scene.get("event_handlers", []))
    for route in references:
        if not isinstance(route, dict):
            continue
        used = any(isinstance(guard, dict) and guard.get("variable_scope", "scene") == "scene" and guard.get("variable_ref") == variable_id for guard in route.get("guards", []))
        used = used or any(isinstance(action, dict) and action.get("variable_scope", "scene") == "scene" and action.get("variable_ref") == variable_id for action in route.get("actions", []))
        if used:
            owner = f"handler '{route['handler_id']}'" if "handler_id" in route else f"route '{route.get('route_id')}'"
            raise ProjectCommandError("COMMAND_TARGET_IN_USE", f"variable '{variable_id}' is referenced by {owner}")
    variables = scene.get("variables")
    if not isinstance(variables, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.variables must be an array")
    for index, variable in enumerate(variables):
        if isinstance(variable, dict) and variable.get("variable_id") == variable_id:
            variables.pop(index)
            return {"kind": "variable.delete", "scene_id": scene.get("scene_id"), "variable_id": variable_id}
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown variable '{variable_id}'")


def _apply_input_action_upsert(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    kind = command.get("kind")
    _require_command_fields(command, {"kind", "scene_id", "input_action"}, {"kind", "scene_id", "input_action", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    action = command.get("input_action")
    if not isinstance(action, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "input_action must be an object")
    actions = scene.get("input_actions")
    if not isinstance(actions, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.input_actions must be an array")
    action_id = action.get("action_id")
    issues: list[ValidationIssue] = []
    _stable_id(action_id, "command.input_action.action_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    existing = next((item for item in actions if isinstance(item, dict) and item.get("action_id") == action_id), None)
    event_bindings = scene.get("event_bindings", [])
    if any(
        isinstance(item, dict) and item.get("binding_id") == action_id
        for item in event_bindings
    ):
        raise ProjectCommandError(
            "PROJECT_ID_DUPLICATE",
            f"binding ID '{action_id}' is already used by an event binding",
        )
    normalized = deepcopy(action)
    if kind == "input_action.add":
        if existing is not None:
            raise ProjectCommandError("PROJECT_ID_DUPLICATE", f"input action '{action_id}' already exists")
        from .machine_limits import INPUTS
        machine_scene = scene.get('machine_logic', {}).get('model') == 'scene_machines_v1'
        if (len(actions) >= INPUTS if machine_scene else len(actions) + len(event_bindings) >= STATE_EVENT_BINDING_MAX):
            raise ProjectCommandError(
                "PROJECT_LIMIT_EXCEEDED",
                f"scene supports at most {INPUTS if machine_scene else STATE_EVENT_BINDING_MAX} input/event bindings",
            )
        actions.append(normalized)
    else:
        if existing is None:
            raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown input action '{action_id}'")
        actions[actions.index(existing)] = normalized
    return {"kind": kind, "scene_id": scene.get("scene_id"), "input_action": normalized}


def _apply_input_action_delete(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "scene_id", "action_id"}, {"kind", "scene_id", "action_id", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    action_id = command.get("action_id")
    for route in scene.get("routes", []):
        if isinstance(route, dict) and (
            route.get("action_ref") == action_id or route.get("event_ref") == action_id
        ):
            raise ProjectCommandError("COMMAND_TARGET_IN_USE", f"input action '{action_id}' is referenced by route '{route.get('route_id')}'")
    wait_policy = scene.get("reactive_wait_default")
    if isinstance(wait_policy, dict) and action_id in wait_policy.get("event_interests", []):
        raise ProjectCommandError("COMMAND_TARGET_IN_USE", f"input action '{action_id}' is a reactive wait interest")
    interaction = scene.get("interaction_policy")
    if isinstance(interaction, dict) and action_id in interaction.get("meaningful_activity_actions", []):
        raise ProjectCommandError("COMMAND_TARGET_IN_USE", f"input action '{action_id}' is meaningful activity")
    actions = scene.get("input_actions")
    if not isinstance(actions, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.input_actions must be an array")
    for index, action in enumerate(actions):
        if isinstance(action, dict) and action.get("action_id") == action_id:
            actions.pop(index)
            return {"kind": "input_action.delete", "scene_id": scene.get("scene_id"), "action_id": action_id}
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown input action '{action_id}'")


def _unique_generated_record_id(
    records: list[dict[str, Any]],
    id_field: str,
    base: str,
) -> str:
    normalized = _route_id_component(base)[:64].rstrip("_.-")
    existing = {
        record.get(id_field)
        for record in records
        if isinstance(record, dict)
    }
    if normalized not in existing:
        return normalized
    for suffix in range(2, len(records) + 3):
        suffix_text = f"_{suffix}"
        candidate = f"{normalized[:64 - len(suffix_text)].rstrip('_.-')}{suffix_text}"
        if candidate not in existing:
            return candidate
    raise ProjectCommandError("COMMAND_TARGET_INVALID", f"could not generate a unique {id_field}")


def _append_input_policy_reference(
    scene: dict[str, Any],
    policy_field: str,
    references_field: str,
    action_id: str,
) -> None:
    policy = scene.get(policy_field)
    references = policy.get(references_field) if isinstance(policy, dict) else None
    if not isinstance(references, list):
        raise ProjectCommandError(
            "PROJECT_TYPE_INVALID",
            f"scene.{policy_field}.{references_field} must be an array",
        )
    if action_id not in references:
        references.append(action_id)


def _remove_input_policy_reference(
    scene: dict[str, Any],
    policy_field: str,
    references_field: str,
    action_id: str,
) -> None:
    policy = scene.get(policy_field)
    references = policy.get(references_field) if isinstance(policy, dict) else None
    if isinstance(references, list):
        policy[references_field] = [value for value in references if value != action_id]


def _validate_logical_input_binding(
    scene: dict[str, Any],
    logical_source: Any,
    event_kind: Any,
) -> None:
    if logical_source not in LOGICAL_INPUT_SOURCES:
        raise ProjectCommandError("INPUT_SOURCE_INVALID", "unsupported logical source")
    if event_kind not in LOGICAL_INPUT_EVENT_KINDS:
        raise ProjectCommandError("INPUT_EVENT_INVALID", "event_kind must be press, release, hold, or repeat")
    if logical_source == "BUTTON_START" and event_kind != "press":
        raise ProjectCommandError("INPUT_EVENT_SYSTEM_OWNED", "START supports package press only")
    if logical_source in {
        "JOY_UP_LEFT",
        "JOY_UP_RIGHT",
        "JOY_DOWN_LEFT",
        "JOY_DOWN_RIGHT",
    } and scene.get("joystick_policy", "four_way") != "eight_way":
        raise ProjectCommandError("JOYSTICK_POLICY_REQUIRED", "diagonal bindings require eight_way")


def _apply_route_create_trigger(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "source_state", "logical_source"},
        {
            "kind",
            "scene_id",
            "source_state",
            "logical_source",
            "event_kind",
            "target_state",
            "scene_exit_ref",
            "system_exit",
            "target_handle",
            "target_side",
            "command_id",
        },
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    source_state = command.get("source_state")
    _command_record(scene, "states", "state_id", source_state)

    logical_source = command.get("logical_source")
    event_kind = command.get("event_kind", "press")
    _validate_logical_input_binding(scene, logical_source, event_kind)

    has_target_state = "target_state" in command
    has_scene_exit = "scene_exit_ref" in command
    has_system_exit = "system_exit" in command
    if sum((has_target_state, has_scene_exit, has_system_exit)) != 1:
        raise ProjectCommandError(
            "COMMAND_SHAPE_INVALID",
            "route.create_trigger requires exactly one destination",
        )
    if has_system_exit and command.get("system_exit") is not True:
        raise ProjectCommandError("COMMAND_SHAPE_INVALID", "system_exit must be true")

    route_target: dict[str, str]
    if has_target_state:
        target_state = command.get("target_state")
        _command_record(scene, "states", "state_id", target_state)
        route_target = {"target_state": str(target_state)}
    elif has_scene_exit:
        scene_exit = _command_record(
            scene,
            "scene_exits",
            "scene_exit_id",
            command.get("scene_exit_ref"),
        )
        route_target = {
            "scene_exit_ref": str(scene_exit.get("scene_exit_id")),
            "target_scene": str(scene_exit.get("target_scene")),
        }
    else:
        route_target = {"target_state": str(source_state)}

    input_actions = scene.get("input_actions")
    routes = scene.get("routes")
    if not isinstance(input_actions, list) or not isinstance(routes, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene input actions and routes must be arrays")
    input_action = next(
        (
            action
            for action in input_actions
            if isinstance(action, dict)
            and action.get("logical_source") == logical_source
            and action.get("event_kind", "press") == event_kind
        ),
        None,
    )
    input_action_created = input_action is None
    if input_action is None:
        if len(input_actions) >= 32:
            raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "scene supports at most 32 input actions")
        action_id = _unique_generated_record_id(
            input_actions,
            "action_id",
            f"{str(logical_source).lower()}_{event_kind}",
        )
        input_action = {
            "action_id": action_id,
            "logical_source": logical_source,
            "event_kind": event_kind,
        }
        input_actions.append(input_action)
    else:
        action_id = str(input_action.get("action_id"))

    if any(
        isinstance(route, dict)
        and route.get("action_ref") == action_id
        and source_state in route.get("from_states", [])
        for route in routes
    ):
        raise ProjectCommandError(
            "ROUTE_TRIGGER_IN_USE",
            f"{logical_source} {event_kind} already has a transition from state '{source_state}'",
        )
    if len(routes) >= 128:
        raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "scene supports at most 128 routes")

    route_id = _unique_generated_record_id(
        routes,
        "route_id",
        f"{source_state}_{action_id}",
    )
    route = {
        "route_id": route_id,
        "action_ref": action_id,
        "from_states": [source_state],
        "guards": [],
        "actions": [{"kind": "exit_to_shell"}] if has_system_exit else [],
        **route_target,
    }
    routes.append(route)
    _append_input_policy_reference(
        scene,
        "reactive_wait_default",
        "event_interests",
        action_id,
    )
    _append_input_policy_reference(
        scene,
        "interaction_policy",
        "meaningful_activity_actions",
        action_id,
    )

    result: dict[str, Any] = {
        "kind": "route.create_trigger",
        "scene_id": scene.get("scene_id"),
        "source_state": source_state,
        "input_action": deepcopy(input_action),
        "input_action_created": input_action_created,
        "route": deepcopy(route),
    }
    if "target_handle" in command or "target_side" in command:
        if not has_target_state:
            raise ProjectCommandError(
                "COMMAND_SHAPE_INVALID",
                "scene-exit transitions cannot select a state entry socket",
            )
        layout = _apply_state_graph_route_layout(
            project,
            scenes,
            {
                "kind": "editor.state_graph.set_route_layout",
                "scene_id": scene.get("scene_id"),
                "route_id": route_id,
                "source_state": source_state,
                "rails": [],
                "target_handle": command.get("target_handle"),
                "target_side": command.get("target_side"),
            },
        )
        result["route_layout"] = layout
    return result


def _apply_event_binding_upsert(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    kind = command.get("kind")
    _require_command_fields(
        command,
        {"kind", "scene_id", "event_binding"},
        {"kind", "scene_id", "event_binding", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    binding = command.get("event_binding")
    if not isinstance(binding, dict):
        raise ProjectCommandError(
            "PROJECT_TYPE_INVALID", "event_binding must be an object"
        )
    bindings = scene.setdefault("event_bindings", [])
    if not isinstance(bindings, list):
        raise ProjectCommandError(
            "PROJECT_TYPE_INVALID", "scene.event_bindings must be an array"
        )
    binding_id = binding.get("binding_id")
    issues: list[ValidationIssue] = []
    _stable_id(binding_id, "command.event_binding.binding_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if any(
        isinstance(item, dict) and item.get("action_id") == binding_id
        for item in scene.get("input_actions", [])
    ):
        raise ProjectCommandError(
            "PROJECT_ID_DUPLICATE",
            f"binding ID '{binding_id}' is already used by an input action",
        )
    existing = next(
        (
            item
            for item in bindings
            if isinstance(item, dict) and item.get("binding_id") == binding_id
        ),
        None,
    )
    normalized = deepcopy(binding)
    if kind == "event_binding.add":
        if existing is not None:
            raise ProjectCommandError(
                "PROJECT_ID_DUPLICATE",
                f"event binding '{binding_id}' already exists",
            )
        from .machine_limits import TIMERS
        machine_scene = scene.get('machine_logic', {}).get('model') == 'scene_machines_v1'
        if (len(bindings) >= TIMERS if machine_scene else len(scene.get("input_actions", [])) + len(bindings) >= STATE_EVENT_BINDING_MAX):
            raise ProjectCommandError(
                "PROJECT_LIMIT_EXCEEDED",
                f"scene supports at most {TIMERS if machine_scene else STATE_EVENT_BINDING_MAX} timer/event bindings",
            )
        bindings.append(normalized)
    else:
        if existing is None:
            raise ProjectCommandError(
                "COMMAND_TARGET_UNKNOWN", f"unknown event binding '{binding_id}'"
            )
        bindings[bindings.index(existing)] = normalized
    return {
        "kind": kind,
        "scene_id": scene.get("scene_id"),
        "event_binding": normalized,
    }


def _apply_route_rebind_trigger(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "route_id", "logical_source"},
        {"kind", "scene_id", "route_id", "logical_source", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    route = _command_record(scene, "routes", "route_id", command.get("route_id"))
    input_actions = scene.get("input_actions")
    routes = scene.get("routes")
    if not isinstance(input_actions, list) or not isinstance(routes, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene input actions and routes must be arrays")
    previous_action = _command_record(scene, "input_actions", "action_id", route.get("action_ref"))
    previous_action_id = str(previous_action.get("action_id"))
    event_kind = previous_action.get("event_kind", "press")
    logical_source = command.get("logical_source")
    _validate_logical_input_binding(scene, logical_source, event_kind)

    input_action = next(
        (
            action
            for action in input_actions
            if isinstance(action, dict)
            and action.get("logical_source") == logical_source
            and action.get("event_kind", "press") == event_kind
        ),
        None,
    )
    input_action_created = input_action is None
    if input_action is None:
        if len(input_actions) >= 32:
            raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "scene supports at most 32 input actions")
        action_id = _unique_generated_record_id(
            input_actions,
            "action_id",
            f"{str(logical_source).lower()}_{event_kind}",
        )
        input_action = {
            "action_id": action_id,
            "logical_source": logical_source,
            "event_kind": event_kind,
        }
        input_actions.append(input_action)
    else:
        action_id = str(input_action.get("action_id"))

    source_states = set(route.get("from_states", []))
    if any(
        isinstance(candidate, dict)
        and candidate is not route
        and candidate.get("action_ref") == action_id
        and source_states.intersection(candidate.get("from_states", []))
        for candidate in routes
    ):
        raise ProjectCommandError(
            "ROUTE_TRIGGER_IN_USE",
            f"{logical_source} {event_kind} already has a transition from this route's state",
        )

    route["action_ref"] = action_id
    _append_input_policy_reference(scene, "reactive_wait_default", "event_interests", action_id)
    _append_input_policy_reference(scene, "interaction_policy", "meaningful_activity_actions", action_id)
    previous_action_removed = False
    if previous_action_id != action_id and not any(
        isinstance(candidate, dict) and (candidate.get("action_ref") == previous_action_id
            or (scene.get("schema_version") == 2 and candidate.get("event_ref") == previous_action_id))
        for candidate in routes
    ):
        input_actions.remove(previous_action)
        _remove_input_policy_reference(scene, "reactive_wait_default", "event_interests", previous_action_id)
        _remove_input_policy_reference(scene, "interaction_policy", "meaningful_activity_actions", previous_action_id)
        previous_action_removed = True

    return {
        "kind": "route.rebind_trigger",
        "scene_id": scene.get("scene_id"),
        "route_id": route.get("route_id"),
        "input_action": deepcopy(input_action),
        "input_action_created": input_action_created,
        "previous_action_id": previous_action_id,
        "previous_action_removed": previous_action_removed,
        "route": deepcopy(route),
    }


def _apply_event_binding_delete(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "binding_id"},
        {"kind", "scene_id", "binding_id", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    binding_id = command.get("binding_id")
    for route in [*scene.get("routes", []), *scene.get("event_handlers", [])]:
        if isinstance(route, dict) and (route.get("event_ref") == binding_id or any(
            isinstance(action, dict) and action.get("timer_ref") == binding_id
            for action in route.get("actions", [])
        )):
            raise ProjectCommandError(
                "COMMAND_TARGET_IN_USE",
                f"event binding '{binding_id}' is referenced by '{route.get('handler_id', route.get('route_id'))}'",
            )
    wait_policy = scene.get("reactive_wait_default")
    if isinstance(wait_policy, dict) and binding_id in wait_policy.get(
        "event_interests", []
    ):
        raise ProjectCommandError(
            "COMMAND_TARGET_IN_USE",
            f"event binding '{binding_id}' is a reactive wait interest",
        )
    bindings = scene.get("event_bindings")
    if not isinstance(bindings, list):
        raise ProjectCommandError(
            "PROJECT_TYPE_INVALID", "scene.event_bindings must be an array"
        )
    for index, binding in enumerate(bindings):
        if isinstance(binding, dict) and binding.get("binding_id") == binding_id:
            bindings.pop(index)
            editor = project.get("editor")
            state_graph = editor.get("state_graph") if isinstance(editor, dict) else None
            graph_scenes = state_graph.get("scenes") if isinstance(state_graph, dict) else None
            scene_layout = graph_scenes.get(scene.get("scene_id")) if isinstance(graph_scenes, dict) else None
            nodes = scene_layout.get("nodes") if isinstance(scene_layout, dict) else None
            if isinstance(nodes, dict):
                nodes.pop(f"timer-{binding_id}", None)
            return {
                "kind": "event_binding.delete",
                "scene_id": scene.get("scene_id"),
                "binding_id": binding_id,
            }
    raise ProjectCommandError(
        "COMMAND_TARGET_UNKNOWN", f"unknown event binding '{binding_id}'"
    )


def _apply_event_handler_command(
    project: dict[str, Any], scenes: list[dict[str, Any]], command: dict[str, Any]
) -> dict[str, Any]:
    kind = command["kind"]
    deleting = kind == "event_handler.delete"
    field = "handler_id" if deleting else "event_handler"
    required = {"kind", "scene_id", field}
    _require_command_fields(command, required, required | {"command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    handler = command.get(field)
    if not deleting and not isinstance(handler, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "event_handler must be an object")
    handler_id = handler if deleting else handler.get("handler_id")
    if not deleting and "target_scene" in handler:
        if handler["target_scene"] not in {item.get("scene_id") for item in scenes}:
            raise ProjectCommandError("SCENE_TRANSITION_TARGET_UNKNOWN", "handler target scene does not exist")
    issues: list[ValidationIssue] = []
    _stable_id(handler_id, "command.handler_id", issues)
    if issues:
        raise ProjectCommandError(issues[0].code, issues[0].message)
    handlers = scene.setdefault("event_handlers", [])
    if not isinstance(handlers, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "event_handlers must be an array")
    index = next((i for i, item in enumerate(handlers)
                  if isinstance(item, dict) and item.get("handler_id") == handler_id), None)
    if kind == "event_handler.add":
        if index is not None or any(route.get("route_id") == handler_id for route in scene.get("routes", [])):
            raise ProjectCommandError("PROJECT_ID_DUPLICATE", f"handler ID '{handler_id}' already exists")
        if len(handlers) >= STATE_EVENT_BINDING_MAX:
            raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "scene handler limit exceeded")
        handlers.append(deepcopy(handler))
    elif index is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown handler '{handler_id}'")
    elif deleting:
        handlers.pop(index)
        _handler_layout_records(project, scene["scene_id"]).pop(handler_id, None)
    else:
        old = handlers[index]
        layout = _handler_layout_records(project, scene["scene_id"]).get(handler_id)
        if isinstance(layout, dict):
            if any(old.get(key) != handler.get(key) for key in ("target_state", "target_scene")):
                for key in ("termination", "target_handle", "target_side"):
                    layout.pop(key, None)
            if any(old.get(key) != handler.get(key) for key in ("guards", "actions")):
                layout.pop("token_positions", None)
        handlers[index] = deepcopy(handler)
    return {"kind": kind, "scene_id": scene["scene_id"], field: deepcopy(handler)}


def _apply_route_add(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "scene_id", "route"}, {"kind", "scene_id", "route", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    route = command.get("route")
    if not isinstance(route, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "route must be an object")
    routes = scene.get("routes")
    if not isinstance(routes, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.routes must be an array")
    if len(routes) >= 128:
        raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "scene supports at most 128 routes")
    route_id = route.get("route_id")
    issues: list[ValidationIssue] = []
    _stable_id(route_id, "command.route.route_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if any(isinstance(item, dict) and item.get("route_id") == route_id for item in routes):
        raise ProjectCommandError("PROJECT_ID_DUPLICATE", f"route '{route_id}' already exists")
    normalized = deepcopy(route)
    routes.append(normalized)
    return {"kind": "route.add", "scene_id": scene.get("scene_id"), "route": normalized}


def _remove_state_graph_route_layout(
    project: dict[str, Any],
    scene_id: Any,
    route_id: Any,
) -> None:
    editor = project.get("editor")
    state_graph = editor.get("state_graph") if isinstance(editor, dict) else None
    graph_scenes = state_graph.get("scenes") if isinstance(state_graph, dict) else None
    scene_layout = graph_scenes.get(scene_id) if isinstance(graph_scenes, dict) else None
    routes = scene_layout.get("routes") if isinstance(scene_layout, dict) else None
    if isinstance(routes, dict):
        routes.pop(route_id, None)
        if not routes:
            scene_layout.pop("routes", None)


def _retain_state_graph_route_sources(
    project: dict[str, Any],
    scene_id: Any,
    route_id: Any,
    source_states: list[Any],
) -> None:
    editor = project.get("editor")
    state_graph = editor.get("state_graph") if isinstance(editor, dict) else None
    graph_scenes = state_graph.get("scenes") if isinstance(state_graph, dict) else None
    scene_layout = graph_scenes.get(scene_id) if isinstance(graph_scenes, dict) else None
    routes = scene_layout.get("routes") if isinstance(scene_layout, dict) else None
    route_layout = routes.get(route_id) if isinstance(routes, dict) else None
    sources = route_layout.get("sources") if isinstance(route_layout, dict) else None
    if not isinstance(sources, dict):
        return
    retained = set(source_states)
    for source_state in list(sources):
        if source_state not in retained:
            sources.pop(source_state, None)
    if not sources:
        routes.pop(route_id, None)
    if not routes:
        scene_layout.pop("routes", None)


def _apply_route_delete(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "scene_id", "route_id"}, {"kind", "scene_id", "route_id", "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    route_id = command.get("route_id")
    routes = scene.get("routes")
    if not isinstance(routes, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.routes must be an array")
    for index, route in enumerate(routes):
        if isinstance(route, dict) and route.get("route_id") == route_id:
            routes.pop(index)
            _remove_state_graph_route_layout(project, scene.get("scene_id"), route_id)
            _set_scene_flow_exit_reference(
                project,
                str(scene.get("scene_id")),
                "route",
                str(route_id),
                None,
            )
            _remove_scene_flow_route_layout(
                project,
                str(scene.get("scene_id")),
                "route",
                str(route_id),
            )
            return {"kind": "route.delete", "scene_id": scene.get("scene_id"), "route_id": route_id}
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown route '{route_id}'")


def _apply_route_set_binding(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    kind = command.get("kind")
    if kind == "route.set_sources":
        field = "from_states"
    elif kind == "route.set_event_ref":
        field = "event_ref"
    else:
        field = "action_ref"
    _require_command_fields(command, {"kind", "scene_id", "route_id", field}, {"kind", "scene_id", "route_id", field, "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    route = _command_record(scene, "routes", "route_id", command.get("route_id"))
    value = command.get(field)
    if field == "from_states":
        if not isinstance(value, list) or not value:
            raise ProjectCommandError("ROUTE_SOURCE_MISSING", "from_states must be a non-empty array")
        value = list(value)
    elif field == "action_ref":
        _command_record(scene, "input_actions", "action_id", value)
        route.pop("event_ref", None)
    else:
        input_match = any(
            isinstance(item, dict) and item.get("action_id") == value
            for item in scene.get("input_actions", [])
        )
        event_match = any(
            isinstance(item, dict) and item.get("binding_id") == value
            for item in scene.get("event_bindings", [])
        )
        if not input_match and not event_match:
            raise ProjectCommandError(
                "COMMAND_TARGET_UNKNOWN", f"unknown event binding '{value}'"
            )
        route.pop("action_ref", None)
    route[field] = value
    if field == "from_states":
        _retain_state_graph_route_sources(project, scene.get("scene_id"), route.get("route_id"), value)
    return {"kind": kind, "scene_id": scene.get("scene_id"), "route_id": route.get("route_id"), field: value}


def _apply_scene_policy(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    kind = command.get("kind")
    if kind == "scene.set_reactive_wait_default":
        field = "reactive_wait_default"
    elif kind == "scene.set_interaction_policy":
        field = "interaction_policy"
    else:
        field = "joystick_policy"
    _require_command_fields(command, {"kind", "scene_id", field}, {"kind", "scene_id", field, "command_id"})
    scene = _command_scene(scenes, command.get("scene_id"))
    policy = command.get(field)
    if field == "joystick_policy":
        if policy not in JOYSTICK_POLICIES:
            raise ProjectCommandError("JOYSTICK_POLICY_INVALID", "joystick_policy must be four_way or eight_way")
    elif not isinstance(policy, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", f"{field} must be an object")
    normalized = deepcopy(policy)
    scene[field] = normalized
    return {"kind": kind, "scene_id": scene.get("scene_id"), field: normalized}


def _apply_state_rename(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "state_id", "display_name"},
        {"kind", "scene_id", "state_id", "display_name", "command_id"},
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    state_id = command.get("state_id")
    display_name = command.get("display_name")
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(state_id, "command.state_id", issues)
    _text(display_name, "command.display_name", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)

    for scene in scenes:
        if scene.get("scene_id") != scene_id:
            continue
        for state in scene.get("states", []):
            if isinstance(state, dict) and state.get("state_id") == state_id:
                state["display_name"] = display_name
                return {
                    "kind": "state.rename",
                    "scene_id": scene_id,
                    "state_id": state_id,
                    "display_name": display_name,
                }
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown state '{state_id}'")
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")


def _apply_route_set_target(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "route_id"},
        {"kind", "scene_id", "route_id", "target_state", "target_scene", "scene_exit_ref", "command_id"},
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    route_id = command.get("route_id")
    target_state = command.get("target_state")
    target_scene = command.get("target_scene")
    scene_exit_ref = command.get("scene_exit_ref")
    has_target_state = "target_state" in command
    has_target_scene = "target_scene" in command
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(route_id, "command.route_id", issues)
    if has_target_state == has_target_scene:
        raise ProjectCommandError(
            "COMMAND_SHAPE_INVALID",
            "route.set_target requires exactly one of target_state or target_scene",
        )
    if has_target_state:
        _stable_id(target_state, "command.target_state", issues)
    else:
        _stable_id(target_scene, "command.target_scene", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)

    scene_ids = {
        scene.get("scene_id")
        for scene in scenes
        if isinstance(scene, dict)
    }
    for scene in scenes:
        if scene.get("scene_id") != scene_id:
            continue
        state_ids = {
            state.get("state_id")
            for state in scene.get("states", [])
            if isinstance(state, dict)
        }
        if has_target_state and target_state not in state_ids:
            raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown target state '{target_state}'")
        if has_target_scene and target_scene not in scene_ids:
            raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown target scene '{target_scene}'")
        if has_target_scene and scene_exit_ref is not None:
            matching_exit = next(
                (
                    scene_exit
                    for scene_exit in scene.get("scene_exits", [])
                    if isinstance(scene_exit, dict) and scene_exit.get("scene_exit_id") == scene_exit_ref
                ),
                None,
            )
            if matching_exit is None:
                raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene exit '{scene_exit_ref}'")
            if matching_exit.get("target_scene") != target_scene:
                raise ProjectCommandError("COMMAND_TARGET_INVALID", "scene exit target does not match target_scene")
        for route in scene.get("routes", []):
            if isinstance(route, dict) and route.get("route_id") == route_id:
                if has_target_scene and any(
                    not isinstance(action, dict) or action.get("kind") != "play_sfx"
                    for action in route.get("actions", [])
                ):
                    raise ProjectCommandError(
                        "SCENE_TRANSITION_ACTION_UNSUPPORTED",
                        "direct scene replacement supports only play_sfx actions",
                    )
                result = {
                    "kind": "route.set_target",
                    "scene_id": scene_id,
                    "route_id": route_id,
                }
                if has_target_state:
                    route.pop("target_scene", None)
                    route.pop("scene_exit_ref", None)
                    route["target_state"] = target_state
                    _set_scene_flow_exit_reference(project, str(scene_id), "route", str(route_id), None)
                    _remove_scene_flow_route_layout(project, str(scene_id), "route", str(route_id))
                    result["target_state"] = target_state
                else:
                    route.pop("target_state", None)
                    route["target_scene"] = target_scene
                    if scene_exit_ref is None:
                        route.pop("scene_exit_ref", None)
                    else:
                        route["scene_exit_ref"] = scene_exit_ref
                    result["target_scene"] = target_scene
                    if scene_exit_ref is not None:
                        result["scene_exit_ref"] = scene_exit_ref
                    scene_flow = project.get("editor", {}).get("scene_flow", {}) if isinstance(project.get("editor"), dict) else {}
                    references = scene_flow.get("references", {}) if isinstance(scene_flow, dict) else {}
                    groups = scene_flow.get("exit_references", {}) if isinstance(scene_flow, dict) else {}
                    scene_group = groups.get(scene_id, {}) if isinstance(groups, dict) else {}
                    reference_id = scene_group.get(_scene_flow_endpoint_key("route", str(route_id))) if isinstance(scene_group, dict) else None
                    reference = references.get(reference_id) if isinstance(references, dict) else None
                    if not isinstance(reference, dict) or reference.get("target_scene") != target_scene:
                        _set_scene_flow_exit_reference(project, str(scene_id), "route", str(route_id), None)
                return result
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown route '{route_id}'")
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")


def _route_id_component(value: str) -> str:
    return re.sub(r"[^a-z0-9_.-]+", "_", value.lower()).strip("_") or "exit"


def _scene_flow_data(project: dict[str, Any]) -> dict[str, Any]:
    editor = project.setdefault("editor", {})
    if not isinstance(editor, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor must be an object")
    scene_flow = editor.setdefault("scene_flow", {})
    if not isinstance(scene_flow, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.scene_flow must be an object")
    return scene_flow


def _scene_flow_references(project: dict[str, Any]) -> dict[str, Any]:
    references = _scene_flow_data(project).setdefault("references", {})
    if not isinstance(references, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.scene_flow.references must be an object")
    return references


def _scene_flow_reference(project: dict[str, Any], reference_id: Any) -> dict[str, Any]:
    issues: list[ValidationIssue] = []
    _stable_id(reference_id, "command.reference_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    reference = _scene_flow_references(project).get(reference_id)
    if not isinstance(reference, dict):
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene-flow reference '{reference_id}'")
    return reference


def _scene_flow_endpoint_key(endpoint_kind: str, endpoint_id: str) -> str:
    return f"{endpoint_kind}:{endpoint_id}"


def _scene_flow_exit_reference_groups(project: dict[str, Any]) -> dict[str, Any]:
    groups = _scene_flow_data(project).setdefault("exit_references", {})
    if not isinstance(groups, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.scene_flow.exit_references must be an object")
    return groups


def _scene_flow_route_groups(project: dict[str, Any]) -> dict[str, Any]:
    groups = _scene_flow_data(project).setdefault("routes", {})
    if not isinstance(groups, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.scene_flow.routes must be an object")
    return groups


def _remove_scene_flow_route_layout(
    project: dict[str, Any],
    scene_id: str,
    endpoint_kind: str,
    endpoint_id: str,
) -> None:
    editor = project.get("editor")
    scene_flow = editor.get("scene_flow") if isinstance(editor, dict) else None
    groups = scene_flow.get("routes") if isinstance(scene_flow, dict) else None
    if not isinstance(groups, dict):
        return
    scene_group = groups.get(scene_id)
    if isinstance(scene_group, dict):
        scene_group.pop(_scene_flow_endpoint_key(endpoint_kind, endpoint_id), None)
        if not scene_group:
            groups.pop(scene_id, None)
    if not groups:
        scene_flow.pop("routes", None)


def _set_scene_flow_exit_reference(
    project: dict[str, Any],
    scene_id: str,
    endpoint_kind: str,
    endpoint_id: str,
    reference_id: str | None,
) -> None:
    endpoint_key = _scene_flow_endpoint_key(endpoint_kind, endpoint_id)
    if reference_id is None:
        editor = project.get("editor")
        scene_flow = editor.get("scene_flow") if isinstance(editor, dict) else None
        groups = scene_flow.get("exit_references") if isinstance(scene_flow, dict) else None
        if not isinstance(groups, dict):
            return
        scene_group = groups.get(scene_id)
        if isinstance(scene_group, dict):
            scene_group.pop(endpoint_key, None)
            if not scene_group:
                groups.pop(scene_id, None)
        if not groups:
            scene_flow.pop("exit_references", None)
        return
    groups = _scene_flow_exit_reference_groups(project)
    scene_group = groups.setdefault(scene_id, {})
    if not isinstance(scene_group, dict):
        raise ProjectCommandError(
            "PROJECT_TYPE_INVALID",
            f"project.editor.scene_flow.exit_references[{scene_id}] must be an object",
        )
    scene_group[endpoint_key] = reference_id


def _scene_flow_endpoint(
    scenes: list[dict[str, Any]],
    scene_id: str,
    endpoint_kind: str,
    endpoint_id: str,
) -> dict[str, Any]:
    scene = _command_scene(scenes, scene_id)
    if endpoint_kind == "scene_exit":
        return _command_record(scene, "scene_exits", "scene_exit_id", endpoint_id)
    if endpoint_kind == "route":
        return _command_record(scene, "routes", "route_id", endpoint_id)
    raise ProjectCommandError(
        "PROJECT_VALUE_INVALID",
        "command.endpoint_kind must be scene_exit or route",
    )


def _set_scene_flow_endpoint_target(
    scenes: list[dict[str, Any]],
    scene_id: str,
    endpoint_kind: str,
    endpoint_id: str,
    target_scene: str,
) -> None:
    if scene_id == target_scene:
        raise ProjectCommandError("COMMAND_TARGET_INVALID", "scene exits must target another scene")
    _command_scene(scenes, target_scene)
    endpoint = _scene_flow_endpoint(scenes, scene_id, endpoint_kind, endpoint_id)
    endpoint["target_scene"] = target_scene
    if endpoint_kind == "scene_exit":
        source_scene = _command_scene(scenes, scene_id)
        for route in [*source_scene.get("routes", []), *source_scene.get("event_handlers", [])]:
            if isinstance(route, dict) and route.get("scene_exit_ref") == endpoint_id:
                route["target_scene"] = target_scene
    else:
        endpoint.pop("target_state", None)
        endpoint.pop("scene_exit_ref", None)


def _unique_generated_scene_exit_id(scene: dict[str, Any], target_scene: str) -> str:
    base = f"to_{_route_id_component(target_scene)}"[:64].rstrip("_.-")
    existing = {
        scene_exit.get("scene_exit_id")
        for scene_exit in scene.get("scene_exits", [])
        if isinstance(scene_exit, dict)
    }
    if base not in existing:
        return base
    for suffix in range(2, 100):
        suffix_text = f"_{suffix}"
        candidate = f"{base[:64 - len(suffix_text)].rstrip('_.-')}{suffix_text}"
        if candidate not in existing:
            return candidate
    raise ProjectCommandError("COMMAND_TARGET_INVALID", "could not generate a unique scene exit ID")


def _apply_scene_exit_add(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    restart = command.get('kind') == 'scene.restart.add'
    _require_command_fields(
        command,
        {"kind", "scene_id"} if restart else {"kind", "scene_id", "target_scene"},
        ({"kind", "scene_id", "display_name", "command_id"} if restart else
         {"kind", "scene_id", "target_scene", "display_name", "scene_flow_reference_id", "command_id"}),
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    target_scene = scene_id if restart else command.get("target_scene")
    display_name = command.get("display_name")
    reference_id = command.get("scene_flow_reference_id")
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(target_scene, "command.target_scene", issues)
    if display_name is not None:
        _text(display_name, "command.display_name", issues)
    if scene_id == target_scene and not restart:
        raise ProjectCommandError("COMMAND_TARGET_INVALID", "scene exits must target another scene")
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)

    target = next(
        (
            scene
            for scene in scenes
            if isinstance(scene, dict) and scene.get("scene_id") == target_scene
        ),
        None,
    )
    if target is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown target scene '{target_scene}'")
    if reference_id is not None:
        reference = _scene_flow_reference(project, reference_id)
        if reference.get("target_scene") != target_scene:
            raise ProjectCommandError(
                "COMMAND_TARGET_INVALID",
                "scene-flow reference does not point to command.target_scene",
            )

    for scene in scenes:
        if scene.get("scene_id") != scene_id:
            continue
        scene_exits = scene.setdefault("scene_exits", [])
        if not isinstance(scene_exits, list):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.scene_exits must be an array")
        if len(scene_exits) >= 32:
            raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "scene supports at most 32 scene exits")
        scene_exit_id = _unique_generated_scene_exit_id(scene, 'restart' if restart else str(target_scene))
        scene_exit = {
            "scene_exit_id": scene_exit_id,
            "display_name": display_name or ('Restart Scene' if restart else str(target.get("display_name") or target_scene)),
            "target_scene": target_scene,
        }
        scene_exits.append(scene_exit)
        if isinstance(reference_id, str):
            _set_scene_flow_exit_reference(
                project,
                str(scene_id),
                "scene_exit",
                scene_exit_id,
                reference_id,
            )

        return {
            "kind": command['kind'],
            "scene_id": scene_id,
            "scene_exit": deepcopy(scene_exit),
        }
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")


def _scene_exit_users(scene):
    """Authored destination holders, including response terminals; no lowering."""
    for route in [*scene.get('routes', []), *scene.get('event_handlers', [])]:
        yield route.get('handler_id', route.get('route_id')), route
    for route in scene.get('machine_logic', {}).get('routes', []):
        for outcome in route.get('outcomes', [route]):
            yield route['route_id'], outcome
        for node in route.get('response', {}).get('nodes', []):
            if node.get('kind') == 'return':
                yield route['route_id'] + '/' + node['node_id'], node


def _apply_scene_exit_set_target(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "scene_exit_id", "target_scene"},
        {"kind", "scene_id", "scene_exit_id", "target_scene", "command_id"},
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    scene_exit_id = command.get("scene_exit_id")
    target_scene = command.get("target_scene")
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(scene_exit_id, "command.scene_exit_id", issues)
    _stable_id(target_scene, "command.target_scene", issues)
    if scene_id == target_scene:
        raise ProjectCommandError("COMMAND_TARGET_INVALID", "scene exits must target another scene")
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if not any(isinstance(scene, dict) and scene.get("scene_id") == target_scene for scene in scenes):
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown target scene '{target_scene}'")

    for scene in scenes:
        if scene.get("scene_id") != scene_id:
            continue
        for scene_exit in scene.get("scene_exits", []):
            if not isinstance(scene_exit, dict) or scene_exit.get("scene_exit_id") != scene_exit_id:
                continue
            scene_exit["target_scene"] = target_scene
            for _, route in _scene_exit_users(scene):
                if isinstance(route, dict) and route.get("scene_exit_ref") == scene_exit_id:
                    route["target_scene"] = target_scene
            scene_flow = project.get("editor", {}).get("scene_flow", {}) if isinstance(project.get("editor"), dict) else {}
            references = scene_flow.get("references", {}) if isinstance(scene_flow, dict) else {}
            groups = scene_flow.get("exit_references", {}) if isinstance(scene_flow, dict) else {}
            scene_group = groups.get(scene_id, {}) if isinstance(groups, dict) else {}
            reference_id = scene_group.get(_scene_flow_endpoint_key("scene_exit", str(scene_exit_id))) if isinstance(scene_group, dict) else None
            reference = references.get(reference_id) if isinstance(references, dict) else None
            if not isinstance(reference, dict) or reference.get("target_scene") != target_scene:
                _set_scene_flow_exit_reference(project, str(scene_id), "scene_exit", str(scene_exit_id), None)
            return {
                "kind": "scene_exit.set_target",
                "scene_id": scene_id,
                "scene_exit_id": scene_exit_id,
                "target_scene": target_scene,
            }
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene exit '{scene_exit_id}'")
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")


def _apply_scene_exit_delete(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "scene_exit_id"},
        {"kind", "scene_id", "scene_exit_id", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    scene_exit_id = command.get("scene_exit_id")
    scene_exits = scene.get("scene_exits")
    if not isinstance(scene_exits, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.scene_exits must be an array")
    for location, route in _scene_exit_users(scene):
        if isinstance(route, dict) and route.get("scene_exit_ref") == scene_exit_id:
            raise ProjectCommandError(
                "COMMAND_TARGET_IN_USE",
                f"scene exit '{scene_exit_id}' is referenced by handler '{location}'",
            )
    for index, scene_exit in enumerate(scene_exits):
        if isinstance(scene_exit, dict) and scene_exit.get("scene_exit_id") == scene_exit_id:
            scene_exits.pop(index)
            nodes = (
                project.get("editor", {})
                .get("state_graph", {})
                .get("scenes", {})
                .get(scene.get("scene_id"), {})
                .get("nodes", {})
            )
            if isinstance(nodes, dict):
                nodes.pop(f"scene-exit-{scene_exit_id}", None)
            _set_scene_flow_exit_reference(
                project,
                str(scene.get("scene_id")),
                "scene_exit",
                str(scene_exit_id),
                None,
            )
            _remove_scene_flow_route_layout(
                project,
                str(scene.get("scene_id")),
                "scene_exit",
                str(scene_exit_id),
            )
            return {
                "kind": "scene_exit.delete",
                "scene_id": scene.get("scene_id"),
                "scene_exit_id": scene_exit_id,
            }
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene exit '{scene_exit_id}'")


def _render_coordinate(value: Any, path: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ProjectCommandError("RENDER_BOUNDS_INVALID", f"{path} must be an integer")
    if value < 0:
        raise ProjectCommandError("RENDER_BOUNDS_INVALID", f"{path} must be non-negative")
    return value


def _render_dimension(value: Any, path: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ProjectCommandError("RENDER_BOUNDS_INVALID", f"{path} must be a positive integer")
    return value


def _render_z_order(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 255:
        raise ProjectCommandError("RENDER_BOUNDS_INVALID", "command.z_order must be in 0..255")
    return value


def _target_render_model(
    scenes: list[dict[str, Any]],
    scene_id: Any,
    render_model_id: Any,
) -> dict[str, Any]:
    issues: list[ValidationIssue] = []
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(render_model_id, "command.render_model_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    scene = next((item for item in scenes if item.get("scene_id") == scene_id), None)
    if scene is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")
    render_models = scene.get("render_models")
    if not isinstance(render_models, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.render_models must be an array")
    render_model = next(
        (
            item
            for item in render_models
            if isinstance(item, dict) and item.get("visual_id") == render_model_id
        ),
        None,
    )
    if render_model is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown render model '{render_model_id}'")
    return render_model


def _target_render_element(render_model: dict[str, Any], element_id: Any) -> dict[str, Any]:
    issues: list[ValidationIssue] = []
    _stable_id(element_id, "command.element_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    elements = render_model.get("elements")
    if not isinstance(elements, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "render_model.elements must be an array")
    element = next(
        (
            item
            for item in elements
            if isinstance(item, dict) and item.get("element_id") == element_id
        ),
        None,
    )
    if element is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown render element '{element_id}'")
    return element


def _scene_placement_model(scene: dict[str, Any]) -> dict[str, Any]:
    render_models = scene.get("render_models")
    if not isinstance(render_models, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.render_models must be an array")
    if len(render_models) != 1 or not isinstance(render_models[0], dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "STATE_SCENE must have exactly one placement render model")
    return render_models[0]


def _state_placement_overrides(state: dict[str, Any]) -> list[dict[str, Any]]:
    overrides = state.setdefault("placement_overrides", [])
    if not isinstance(overrides, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "state.placement_overrides must be an array")
    return overrides


def _validate_state_override_visual_ref(
    frames: list[Masked1bppFrame],
    element: dict[str, Any],
    visual_ref: Any,
) -> str:
    issues: list[ValidationIssue] = []
    _stable_id(visual_ref, "command.visual_ref", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if element.get("kind") != "sprite":
        raise ProjectCommandError("RENDER_VISUAL_REF_INVALID", "only sprites can override visual_ref")
    frame = _frame_map(frames).get(str(visual_ref))
    if frame is None:
        raise ProjectCommandError("ASSET_FRAME_UNKNOWN", f"unknown sprite visual '{visual_ref}'")
    if frame.width != element.get("width") or frame.height != element.get("height"):
        raise ProjectCommandError("RENDER_VISUAL_REF_INVALID", "override frame must match the placed sprite size")
    return str(visual_ref)


def _validate_render_bounds(x: int, y: int, width: int, height: int) -> None:
    if x + width > 168 or y + height > 144:
        raise ProjectCommandError("RENDER_BOUNDS_INVALID", "element would be outside the 168x144 display")


def _apply_render_element_add(
    scenes: list[dict[str, Any]],
    frames: list[Masked1bppFrame],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "render_model_id", "element"},
        {"kind", "scene_id", "render_model_id", "element", "command_id"},
    )
    element = command.get("element")
    if not isinstance(element, dict):
        raise ProjectCommandError("COMMAND_SHAPE_INVALID", "command.element must be an object")
    required = {"element_id", "kind", "x", "y", "width", "height", "z_order"}
    allowed = required | {"visual_ref", "focus_role", "layer", "visible", "line_direction"}
    _require_command_fields(element, required, allowed)
    element_id = element.get("element_id")
    issues: list[ValidationIssue] = []
    _stable_id(element_id, "command.element.element_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    kind = element.get("kind")
    if kind not in {"sprite", "line", "outline_rect", "filled_rect", "circle", "ellipse", "filled_circle", "filled_ellipse"}:
        raise ProjectCommandError("RENDER_KIND_INVALID", "unsupported retained element type")
    if (("line_direction" in element and kind != "line")
            or element.get("line_direction", "down_right") not in {"down_right", "up_right"}):
        raise ProjectCommandError("RENDER_LINE_DIRECTION_INVALID", "line_direction must be down_right or up_right on a line")
    x = _render_coordinate(element.get("x"), "command.element.x")
    y = _render_coordinate(element.get("y"), "command.element.y")
    width = _render_dimension(element.get("width"), "command.element.width")
    height = _render_dimension(element.get("height"), "command.element.height")
    _validate_render_bounds(x, y, width, height)
    _render_z_order(element.get("z_order"))
    layer = element.get("layer", "UI" if element.get("focus_role", "none") == "focus" else "SCENE")
    visible = element.get("visible", True)
    focus_role = element.get("focus_role", "none")
    if layer not in {"BACKGROUND", "SCENE", "UI"}:
        raise ProjectCommandError("RENDER_LAYER_INVALID", "layer must be BACKGROUND, SCENE, or UI")
    if not isinstance(visible, bool):
        raise ProjectCommandError("RENDER_VISIBILITY_INVALID", "visible must be boolean")
    if focus_role not in {"none", "focus"}:
        raise ProjectCommandError("RENDER_FOCUS_INVALID", "focus_role must be none or focus")
    visual_ref = element.get("visual_ref")
    available_visuals = {frame.frame_id for frame in frames}
    if kind == "sprite":
        if visual_ref not in available_visuals:
            raise ProjectCommandError("ASSET_FRAME_UNKNOWN", f"unknown sprite visual '{visual_ref}'")
    elif "visual_ref" in element:
        raise ProjectCommandError("RENDER_VISUAL_REF_INVALID", "primitives do not reference assets")
    line_direction = element.get("line_direction", "down_right")
    if kind == "line":
        if not isinstance(line_direction, str) or line_direction not in {"down_right", "up_right"}:
            raise ProjectCommandError(
                "RENDER_LINE_DIRECTION_INVALID",
                "line_direction must be down_right or up_right",
            )
    elif "line_direction" in element:
        raise ProjectCommandError(
            "RENDER_LINE_DIRECTION_INVALID",
            "line_direction is only valid for line elements",
        )
    if focus_role == "focus" and (kind != "sprite" or layer != "UI" or not visible):
        raise ProjectCommandError("RENDER_FOCUS_INVALID", "focus must be a visible UI sprite")

    render_model = _target_render_model(
        scenes,
        command.get("scene_id"),
        command.get("render_model_id"),
    )
    elements = render_model.setdefault("elements", [])
    if any(isinstance(item, dict) and item.get("element_id") == element_id for item in elements):
        raise ProjectCommandError("PROJECT_ID_DUPLICATE", f"render element '{element_id}' already exists")
    elements.append(deepcopy(element))
    return {
        "kind": "render_element.add",
        "scene_id": command.get("scene_id"),
        "render_model_id": command.get("render_model_id"),
        "element_id": element_id,
    }


def _placement_scope_state_ids(
    scene: dict[str, Any],
    scope: Any,
) -> tuple[str, ...] | None:
    if not isinstance(scope, dict):
        raise ProjectCommandError("COMMAND_SHAPE_INVALID", "command.scope must be an object")
    scope_kind = scope.get("kind")
    if scope_kind == "scene_base":
        _require_command_fields(scope, {"kind"}, {"kind"})
        return None
    if scope_kind != "states":
        raise ProjectCommandError(
            "COMMAND_SHAPE_INVALID",
            "command.scope.kind must be scene_base or states",
        )
    _require_command_fields(scope, {"kind", "state_ids"}, {"kind", "state_ids"})
    state_ids = scope.get("state_ids")
    if not isinstance(state_ids, list) or not state_ids or len(state_ids) > 64:
        raise ProjectCommandError(
            "COMMAND_LIST_INVALID",
            "command.scope.state_ids must contain 1..64 state IDs",
        )
    known_state_ids = {
        state.get("state_id")
        for state in scene.get("states", [])
        if isinstance(state, dict) and isinstance(state.get("state_id"), str)
    }
    resolved: list[str] = []
    for state_id in state_ids:
        issues: list[ValidationIssue] = []
        _stable_id(state_id, "command.scope.state_ids", issues)
        if issues:
            issue = issues[0]
            raise ProjectCommandError(issue.code, issue.message)
        if state_id in resolved:
            raise ProjectCommandError(
                "PROJECT_ID_DUPLICATE",
                f"command.scope.state_ids contains duplicate state '{state_id}'",
            )
        if state_id not in known_state_ids:
            raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown state '{state_id}'")
        resolved.append(state_id)
    return tuple(resolved)


def _apply_placement_object_add(
    scenes: list[dict[str, Any]],
    frames: list[Masked1bppFrame],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "scope", "element"},
        {"kind", "scene_id", "scope", "element", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    placement_model = _scene_placement_model(scene)
    state_ids = _placement_scope_state_ids(scene, command.get("scope"))
    element = command.get("element")
    if not isinstance(element, dict):
        raise ProjectCommandError("COMMAND_SHAPE_INVALID", "command.element must be an object")
    if state_ids is not None and element.get("visible", True) is not True:
        raise ProjectCommandError(
            "RENDER_VISIBILITY_INVALID",
            "an object added to selected states must be visible in those states",
        )

    base_element = deepcopy(element)
    if state_ids is not None:
        base_element["visible"] = False
    added = _apply_render_element_add(
        scenes,
        frames,
        {
            "kind": "render_element.add",
            "scene_id": scene.get("scene_id"),
            "render_model_id": placement_model.get("visual_id"),
            "element": base_element,
        },
    )
    element_id = added["element_id"]
    if state_ids is not None:
        for state_id in state_ids:
            _apply_state_placement_set_override(
                scenes,
                frames,
                {
                    "kind": "state_placement.set_override",
                    "scene_id": scene.get("scene_id"),
                    "state_id": state_id,
                    "render_model_id": placement_model.get("visual_id"),
                    "element_id": element_id,
                    "visible": True,
                },
            )
    return {
        "kind": "placement_object.add",
        "scene_id": scene.get("scene_id"),
        "render_model_id": placement_model.get("visual_id"),
        "element_id": element_id,
        "scope": {
            "kind": "scene_base" if state_ids is None else "states",
            **({} if state_ids is None else {"state_ids": list(state_ids)}),
        },
    }


def _apply_render_element_delete(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "render_model_id", "element_id"},
        {"kind", "scene_id", "render_model_id", "element_id", "command_id"},
    )
    scene_id = command.get("scene_id")
    element_id = command.get("element_id")
    render_model = _target_render_model(scenes, scene_id, command.get("render_model_id"))
    element = _target_render_element(render_model, element_id)
    scene = next(item for item in scenes if item.get("scene_id") == scene_id)
    for waiting in scene.get("waiting_visuals", []):
        elements = waiting.get("elements")
        if isinstance(elements, list):
            elements[:] = [
                animated
                for animated in elements
                if not (isinstance(animated, dict) and animated.get("source_element_ref") == element_id)
            ]
            _rebuild_waiting_visual_steps(waiting)
    for state in scene.get("states", []):
        if not isinstance(state, dict):
            continue
        overrides = state.get("placement_overrides")
        if isinstance(overrides, list):
            overrides[:] = [
                override
                for override in overrides
                if not (isinstance(override, dict) and override.get("element_ref") == element_id)
            ]
    render_model["elements"].remove(element)
    return {
        "kind": "render_element.delete",
        "scene_id": scene_id,
        "render_model_id": command.get("render_model_id"),
        "element_id": element_id,
    }


def _apply_render_element_set_bounds(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "render_model_id", "element_id", "x", "y", "width", "height"},
        {"kind", "scene_id", "render_model_id", "element_id", "x", "y", "width", "height", "command_id"},
    )
    x = _render_coordinate(command.get("x"), "command.x")
    y = _render_coordinate(command.get("y"), "command.y")
    width = _render_dimension(command.get("width"), "command.width")
    height = _render_dimension(command.get("height"), "command.height")
    _validate_render_bounds(x, y, width, height)
    render_model = _target_render_model(scenes, command.get("scene_id"), command.get("render_model_id"))
    element = _target_render_element(render_model, command.get("element_id"))
    previous = {key: element.get(key) for key in ("x", "y", "width", "height")}
    element.update({"x": x, "y": y, "width": width, "height": height})
    return {
        "kind": "render_element.set_bounds",
        "scene_id": command.get("scene_id"),
        "render_model_id": command.get("render_model_id"),
        "element_id": command.get("element_id"),
        "previous": previous,
        "bounds": {"x": x, "y": y, "width": width, "height": height},
    }


def _apply_render_element_set_kind(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "render_model_id", "element_id", "element_kind"},
        {"kind", "scene_id", "render_model_id", "element_id", "element_kind", "command_id"},
    )
    render_model = _target_render_model(scenes, command.get("scene_id"), command.get("render_model_id"))
    element = _target_render_element(render_model, command.get("element_id"))
    element_kind = command.get("element_kind")
    families = (
        {"outline_rect", "filled_rect"},
        {"circle", "filled_circle"},
        {"ellipse", "filled_ellipse"},
    )
    if not isinstance(element_kind, str) or not any(
        element.get("kind") in family and element_kind in family for family in families
    ):
        raise ProjectCommandError(
            "RENDER_KIND_INVALID",
            "element_kind must select the outline or filled variant of the same shape",
        )
    previous = element.get("kind")
    element["kind"] = element_kind
    return {
        "kind": "render_element.set_kind",
        "scene_id": command.get("scene_id"),
        "render_model_id": command.get("render_model_id"),
        "element_id": command.get("element_id"),
        "previous": previous,
        "element_kind": element_kind,
    }


def _apply_render_element_set_property(
    scenes: list[dict[str, Any]],
    frames: list[Masked1bppFrame],
    command: dict[str, Any],
) -> dict[str, Any]:
    kind = command.get("kind")
    property_by_kind = {
        "render_element.set_layer": "layer",
        "render_element.set_visibility": "visible",
        "render_element.set_z_order": "z_order",
        "render_element.set_visual_ref": "visual_ref",
    }
    property_name = property_by_kind[kind]
    _require_command_fields(
        command,
        {"kind", "scene_id", "render_model_id", "element_id", property_name},
        {"kind", "scene_id", "render_model_id", "element_id", property_name, "command_id"},
    )
    render_model = _target_render_model(scenes, command.get("scene_id"), command.get("render_model_id"))
    element = _target_render_element(render_model, command.get("element_id"))
    value = command.get(property_name)
    if property_name == "layer":
        if value not in {"BACKGROUND", "SCENE", "UI"}:
            raise ProjectCommandError("RENDER_LAYER_INVALID", "layer must be BACKGROUND, SCENE, or UI")
        if element.get("focus_role", "none") == "focus" and value != "UI":
            raise ProjectCommandError("RENDER_FOCUS_INVALID", "the focus element must remain on UI")
    elif property_name == "visible":
        if not isinstance(value, bool):
            raise ProjectCommandError("RENDER_VISIBILITY_INVALID", "visible must be boolean")
        if element.get("focus_role", "none") == "focus" and not value:
            raise ProjectCommandError("RENDER_FOCUS_INVALID", "the focus element must remain visible")
    elif property_name == "z_order":
        value = _render_z_order(value)
    elif property_name == "visual_ref":
        if element.get("kind") != "sprite":
            raise ProjectCommandError("RENDER_VISUAL_REF_INVALID", "only sprites reference visuals")
        available_visuals = {frame.frame_id for frame in frames}
        if value not in available_visuals:
            raise ProjectCommandError("ASSET_FRAME_UNKNOWN", f"unknown sprite visual '{value}'")
    previous = element.get(property_name)
    element[property_name] = value
    return {
        "kind": kind,
        "scene_id": command.get("scene_id"),
        "render_model_id": command.get("render_model_id"),
        "element_id": command.get("element_id"),
        "previous": previous,
        property_name: value,
    }


def _apply_render_element_set_position(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "render_model_id", "element_id", "x", "y"},
        {"kind", "scene_id", "render_model_id", "element_id", "x", "y", "command_id"},
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    render_model_id = command.get("render_model_id")
    element_id = command.get("element_id")
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(render_model_id, "command.render_model_id", issues)
    _stable_id(element_id, "command.element_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    x = _render_coordinate(command.get("x"), "command.x")
    y = _render_coordinate(command.get("y"), "command.y")

    for scene in scenes:
        if scene.get("scene_id") != scene_id:
            continue
        render_models = scene.get("render_models")
        if not isinstance(render_models, list):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.render_models must be an array")
        for render_model in render_models:
            if not isinstance(render_model, dict) or render_model.get("visual_id") != render_model_id:
                continue
            elements = render_model.get("elements")
            if not isinstance(elements, list):
                raise ProjectCommandError("PROJECT_TYPE_INVALID", "render_model.elements must be an array")
            for element in elements:
                if not isinstance(element, dict) or element.get("element_id") != element_id:
                    continue
                width = element.get("width")
                height = element.get("height")
                if not isinstance(width, int) or width < 1 or not isinstance(height, int) or height < 1:
                    raise ProjectCommandError("RENDER_BOUNDS_INVALID", "element size is invalid")
                if x + width > 168 or y + height > 144:
                    raise ProjectCommandError("RENDER_BOUNDS_INVALID", "element would be outside the 168x144 display")
                previous_x = element.get("x")
                previous_y = element.get("y")
                element["x"] = x
                element["y"] = y
                return {
                    "kind": "render_element.set_position",
                    "scene_id": scene_id,
                    "render_model_id": render_model_id,
                    "element_id": element_id,
                    "previous_x": previous_x,
                    "previous_y": previous_y,
                    "x": x,
                    "y": y,
                }
            raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown render element '{element_id}'")
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown render model '{render_model_id}'")
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")


def _apply_state_placement_set_override(
    scenes: list[dict[str, Any]],
    frames: list[Masked1bppFrame],
    command: dict[str, Any],
) -> dict[str, Any]:
    allowed = {
        "kind",
        "scene_id",
        "state_id",
        "render_model_id",
        "element_id",
        "x",
        "y",
        "visible",
        "visual_ref",
        "command_id",
    }
    _require_command_fields(
        command,
        {"kind", "scene_id", "state_id", "render_model_id", "element_id"},
        allowed,
    )
    supplied = {key for key in ("x", "y", "visible", "visual_ref") if key in command}
    if not supplied:
        raise ProjectCommandError("COMMAND_SHAPE_INVALID", "state placement override must set at least one field")
    if ("x" in supplied) != ("y" in supplied):
        raise ProjectCommandError("RENDER_BOUNDS_INVALID", "position overrides must set both x and y")

    scene = _command_scene(scenes, command.get("scene_id"))
    state = _command_record(scene, "states", "state_id", command.get("state_id"))
    render_model = _target_render_model(scenes, command.get("scene_id"), command.get("render_model_id"))
    placement_model = _scene_placement_model(scene)
    if render_model.get("visual_id") != placement_model.get("visual_id"):
        raise ProjectCommandError("COMMAND_TARGET_INVALID", "state placement overrides must target the scene placement model")
    element = _target_render_element(render_model, command.get("element_id"))
    element_id = str(element["element_id"])
    overrides = _state_placement_overrides(state)
    existing = next(
        (
            item
            for item in overrides
            if isinstance(item, dict) and item.get("element_ref") == element_id
        ),
        None,
    )
    override = deepcopy(existing) if isinstance(existing, dict) else {"element_ref": element_id}

    if "x" in supplied:
        x = _render_coordinate(command.get("x"), "command.x")
        y = _render_coordinate(command.get("y"), "command.y")
        width = _render_dimension(element.get("width"), "element.width")
        height = _render_dimension(element.get("height"), "element.height")
        _validate_render_bounds(x, y, width, height)
        if x == element.get("x") and y == element.get("y"):
            override.pop("x", None)
            override.pop("y", None)
        else:
            override["x"] = x
            override["y"] = y
    if "visible" in supplied:
        visible = command.get("visible")
        if not isinstance(visible, bool):
            raise ProjectCommandError("RENDER_VISIBILITY_INVALID", "visible must be boolean")
        if visible == element.get("visible", True):
            override.pop("visible", None)
        else:
            override["visible"] = visible
    if "visual_ref" in supplied:
        visual_ref = _validate_state_override_visual_ref(frames, element, command.get("visual_ref"))
        if visual_ref == element.get("visual_ref"):
            override.pop("visual_ref", None)
        else:
            override["visual_ref"] = visual_ref

    if set(override.keys()) == {"element_ref"}:
        if existing is not None:
            overrides.remove(existing)
        removed = True
    elif existing is None:
        if len(overrides) >= 32:
            raise ProjectCommandError("PROJECT_COUNT_INVALID", "state already has 32 placement overrides")
        overrides.append(override)
        removed = False
    else:
        overrides[overrides.index(existing)] = override
        removed = False

    return {
        "kind": "state_placement.set_override",
        "scene_id": command.get("scene_id"),
        "state_id": command.get("state_id"),
        "render_model_id": command.get("render_model_id"),
        "element_id": element_id,
        "removed": removed,
    }


def _apply_state_placement_clear_override(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "state_id", "element_id"},
        {"kind", "scene_id", "state_id", "element_id", "properties", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    state = _command_record(scene, "states", "state_id", command.get("state_id"))
    placement_model = _scene_placement_model(scene)
    element = _target_render_element(placement_model, command.get("element_id"))
    element_id = str(element["element_id"])
    overrides = _state_placement_overrides(state)
    existing = next(
        (
            item
            for item in overrides
            if isinstance(item, dict) and item.get("element_ref") == element_id
        ),
        None,
    )

    requested = command.get("properties")
    if requested is None:
        properties = ("position", "visible", "visual_ref")
    else:
        if not isinstance(requested, list) or not requested:
            raise ProjectCommandError(
                "COMMAND_LIST_INVALID",
                "command.properties must be a non-empty array when provided",
            )
        properties_list: list[str] = []
        for value in requested:
            if value not in {"position", "visible", "visual_ref"}:
                raise ProjectCommandError(
                    "COMMAND_SHAPE_INVALID",
                    "command.properties entries must be position, visible, or visual_ref",
                )
            if value in properties_list:
                raise ProjectCommandError(
                    "COMMAND_SHAPE_INVALID",
                    f"command.properties contains duplicate '{value}'",
                )
            properties_list.append(value)
        properties = tuple(properties_list)

    cleared: list[str] = []
    removed = False
    if existing is not None:
        if "position" in properties and ("x" in existing or "y" in existing):
            existing.pop("x", None)
            existing.pop("y", None)
            cleared.append("position")
        for property_name in ("visible", "visual_ref"):
            if property_name in properties and property_name in existing:
                existing.pop(property_name)
                cleared.append(property_name)
        if set(existing) == {"element_ref"}:
            overrides.remove(existing)
            removed = True

    return {
        "kind": "state_placement.clear_override",
        "scene_id": scene.get("scene_id"),
        "state_id": state.get("state_id"),
        "render_model_id": placement_model.get("visual_id"),
        "element_id": element_id,
        "cleared": cleared,
        "removed": removed,
    }


def _apply_waiting_visual_upsert(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "waiting_visual"},
        {"kind", "scene_id", "waiting_visual", "command_id"},
    )
    scene_id = command.get("scene_id")
    waiting_visual = command.get("waiting_visual")
    issues: list[ValidationIssue] = []
    _stable_id(scene_id, "command.scene_id", issues)
    if not isinstance(waiting_visual, dict):
        raise ProjectCommandError("COMMAND_SHAPE_INVALID", "command.waiting_visual must be an object")
    waiting_visual_id = waiting_visual.get("waiting_visual_id")
    _stable_id(waiting_visual_id, "command.waiting_visual.waiting_visual_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    scene = next((item for item in scenes if item.get("scene_id") == scene_id), None)
    if scene is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")
    waiting_visuals = scene.setdefault("waiting_visuals", [])
    existing = next(
        (
            item
            for item in waiting_visuals
            if isinstance(item, dict) and item.get("waiting_visual_id") == waiting_visual_id
        ),
        None,
    )
    created = existing is None
    if created:
        if len(waiting_visuals) >= 32:
            raise ProjectCommandError("PROJECT_COUNT_INVALID", "scene already has 32 waiting visuals")
        waiting_visuals.append(deepcopy(waiting_visual))
    else:
        waiting_visuals[waiting_visuals.index(existing)] = deepcopy(waiting_visual)
    return {
        "kind": "waiting_visual.upsert",
        "scene_id": scene_id,
        "waiting_visual_id": waiting_visual_id,
        "created": created,
    }


def _apply_waiting_visual_delete(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "waiting_visual_id"},
        {"kind", "scene_id", "waiting_visual_id", "command_id"},
    )
    scene_id = command.get("scene_id")
    waiting_visual_id = command.get("waiting_visual_id")
    issues: list[ValidationIssue] = []
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(waiting_visual_id, "command.waiting_visual_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    scene = next((item for item in scenes if item.get("scene_id") == scene_id), None)
    if scene is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")
    if any(state.get("waiting_visual_ref") == waiting_visual_id for state in scene.get("states", [])):
        raise ProjectCommandError("WAIT_VISUAL_IN_USE", "waiting visual is referenced by a state")
    wait_default = scene.get("reactive_wait_default")
    if isinstance(wait_default, dict) and wait_default.get("waiting_visual_ref") == waiting_visual_id:
        raise ProjectCommandError("WAIT_VISUAL_IN_USE", "waiting visual is the reactive wait default")
    waiting_visuals = scene.get("waiting_visuals")
    if not isinstance(waiting_visuals, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.waiting_visuals must be an array")
    target = next(
        (
            item
            for item in waiting_visuals
            if isinstance(item, dict) and item.get("waiting_visual_id") == waiting_visual_id
        ),
        None,
    )
    if target is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown waiting visual '{waiting_visual_id}'")
    waiting_visuals.remove(target)
    return {
        "kind": "waiting_visual.delete",
        "scene_id": scene_id,
        "waiting_visual_id": waiting_visual_id,
    }


def _apply_state_set_waiting_visual(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "state_id", "waiting_visual_id"},
        {"kind", "scene_id", "state_id", "waiting_visual_id", "command_id"},
    )
    scene_id = command.get("scene_id")
    state_id = command.get("state_id")
    waiting_visual_id = command.get("waiting_visual_id")
    issues: list[ValidationIssue] = []
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(state_id, "command.state_id", issues)
    _stable_id(waiting_visual_id, "command.waiting_visual_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    scene = next((item for item in scenes if item.get("scene_id") == scene_id), None)
    if scene is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")
    if waiting_visual_id not in {
        item.get("waiting_visual_id")
        for item in scene.get("waiting_visuals", [])
        if isinstance(item, dict)
    }:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown waiting visual '{waiting_visual_id}'")
    state = next(
        (
            item
            for item in scene.get("states", [])
            if isinstance(item, dict) and item.get("state_id") == state_id
        ),
        None,
    )
    if state is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown state '{state_id}'")
    previous = state.get("waiting_visual_ref")
    state["waiting_visual_ref"] = waiting_visual_id
    return {
        "kind": "state.set_waiting_visual",
        "scene_id": scene_id,
        "state_id": state_id,
        "previous": previous,
        "waiting_visual_id": waiting_visual_id,
    }


def _lcm(left: int, right: int) -> int:
    return abs(left * right) // gcd(left, right)


def _generated_waiting_visual_id(scene: dict[str, Any], state_id: str) -> str:
    waiting_visuals = scene.get("waiting_visuals")
    if not isinstance(waiting_visuals, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.waiting_visuals must be an array")
    existing = {
        item.get("waiting_visual_id")
        for item in waiting_visuals
        if isinstance(item, dict)
    }
    base = f"{state_id}_wait"
    if len(base) > 64:
        base = f"{state_id[:59]}_wait"
    candidate = base
    index = 2
    while candidate in existing:
        suffix = f"_{index}"
        candidate = f"{base[:64 - len(suffix)]}{suffix}"
        index += 1
    return candidate


def _waiting_visual_is_private_to_state(scene: dict[str, Any], state_id: str, waiting_visual_id: Any) -> bool:
    users = [
        state.get("state_id")
        for state in scene.get("states", [])
        if isinstance(state, dict) and state.get("waiting_visual_ref") == waiting_visual_id
    ]
    wait_default = scene.get("reactive_wait_default")
    default_uses_wait = isinstance(wait_default, dict) and wait_default.get("waiting_visual_ref") == waiting_visual_id
    return users == [state_id] and not default_uses_wait


def _waiting_visual_for_state_edit(scene: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    waiting_visuals = scene.get("waiting_visuals")
    if not isinstance(waiting_visuals, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene.waiting_visuals must be an array")
    state_id = str(state.get("state_id"))
    waiting_visual_id = state.get("waiting_visual_ref")
    current = next(
        (
            item
            for item in waiting_visuals
            if isinstance(item, dict) and item.get("waiting_visual_id") == waiting_visual_id
        ),
        None,
    )
    if current is not None and _waiting_visual_is_private_to_state(scene, state_id, waiting_visual_id):
        return current

    cloned = deepcopy(current) if current is not None else {"elements": []}
    cloned_id = _generated_waiting_visual_id(scene, state_id)
    cloned.update(
        {
            "waiting_visual_id": cloned_id,
            "presentation_id": f"{scene.get('scene_id')}.{state_id}.waiting",
        }
    )
    cloned.setdefault("phase_quantum_ms", STATE_WAITING_ANIMATION_QUANTUM_MS)
    cloned.setdefault("combined_step_count", 1)
    cloned.setdefault("settled_step", 0)
    cloned.setdefault("cycle_policy", "loop")
    cloned.setdefault("elements", [])
    if len(waiting_visuals) >= 32:
        raise ProjectCommandError("PROJECT_COUNT_INVALID", "scene already has 32 waiting visuals")
    waiting_visuals.append(cloned)
    state["waiting_visual_ref"] = cloned_id
    return cloned


def _waiting_element_id(waiting_visual: dict[str, Any], element_id: str) -> str:
    elements = waiting_visual.get("elements")
    if not isinstance(elements, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "waiting_visual.elements must be an array")
    base = f"{element_id}_wait"
    if len(base) > 64:
        base = f"{element_id[:59]}_wait"
    existing = {
        item.get("element_id")
        for item in elements
        if isinstance(item, dict)
    }
    candidate = base
    index = 2
    while candidate in existing:
        suffix = f"_{index}"
        candidate = f"{base[:64 - len(suffix)]}{suffix}"
        index += 1
    return candidate


def _frame_map(frames: list[Masked1bppFrame]) -> dict[str, Masked1bppFrame]:
    return {frame.frame_id: frame for frame in frames}


def _command_phase_visual_refs(
    frames: list[Masked1bppFrame],
    value: Any,
    element: dict[str, Any],
) -> list[str]:
    if not isinstance(value, list) or not 2 <= len(value) <= 4:
        raise ProjectCommandError("WAIT_PHASE_COUNT_INVALID", "STATE sprite animation must use 2..4 frames")
    lookup = _frame_map(frames)
    result: list[str] = []
    issues: list[ValidationIssue] = []
    for index, frame_id in enumerate(value):
        _stable_id(frame_id, f"command.phase_visual_refs[{index}]", issues)
        if issues:
            issue = issues[0]
            raise ProjectCommandError(issue.code, issue.message)
        frame = lookup.get(frame_id)
        if frame is None:
            raise ProjectCommandError("ASSET_FRAME_UNKNOWN", f"unknown frame '{frame_id}'")
        if frame.width != element.get("width") or frame.height != element.get("height"):
            raise ProjectCommandError("WAIT_FRAME_SIZE_INVALID", "all animation frames must match the placed sprite size")
        if frame_id in result:
            raise ProjectCommandError("WAIT_PHASE_DUPLICATE", "animation frames must be unique")
        result.append(frame_id)
    return result


def _rebuild_waiting_visual_steps(
    waiting_visual: dict[str, Any],
    desired_phase_by_source: dict[str, int] | None = None,
) -> None:
    elements = waiting_visual.get("elements")
    if not isinstance(elements, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "waiting_visual.elements must be an array")
    phase_counts: list[int] = []
    for element in elements:
        if not isinstance(element, dict):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "waiting_visual.elements entries must be objects")
        refs = element.get("phase_visual_refs")
        if not isinstance(refs, list) or not 1 <= len(refs) <= 4:
            raise ProjectCommandError("WAIT_PHASE_COUNT_INVALID", "waiting visual phases must contain 1..4 frames")
        phase_counts.append(len(refs))

    combined_step_count = 1
    for phase_count in phase_counts:
        combined_step_count = _lcm(combined_step_count, phase_count)
    if combined_step_count > 12:
        raise ProjectCommandError("WAIT_STEP_COUNT_INVALID", "combined waiting animation would exceed 12 steps")

    previous_settled = waiting_visual.get("settled_step")
    settled_step = previous_settled if isinstance(previous_settled, int) and 0 <= previous_settled < combined_step_count else 0
    desired_phase_by_source = desired_phase_by_source or {}
    for element in elements:
        refs = element["phase_visual_refs"]
        phase_count = len(refs)
        source_ref = str(element["source_element_ref"])
        desired_phase = desired_phase_by_source.get(source_ref)
        old_indices = element.get("step_phase_indices")
        if desired_phase is None and isinstance(old_indices, list) and isinstance(previous_settled, int) and 0 <= previous_settled < len(old_indices):
            previous_phase = old_indices[previous_settled]
            if isinstance(previous_phase, int) and 0 <= previous_phase < phase_count:
                desired_phase = previous_phase
        if desired_phase is None:
            desired_phase = 0
        offset = (desired_phase - settled_step) % phase_count
        element["step_phase_indices"] = [(step + offset) % phase_count for step in range(combined_step_count)]

    waiting_visual["phase_quantum_ms"] = STATE_WAITING_ANIMATION_QUANTUM_MS
    waiting_visual["combined_step_count"] = combined_step_count
    waiting_visual["settled_step"] = settled_step
    waiting_visual["cycle_policy"] = "loop"


def _apply_render_element_bind_waiting_animation(
    scenes: list[dict[str, Any]],
    frames: list[Masked1bppFrame],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "state_id", "render_model_id", "element_id", "phase_visual_refs"},
        {"kind", "scene_id", "state_id", "render_model_id", "element_id", "phase_visual_refs", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    state = _command_record(scene, "states", "state_id", command.get("state_id"))
    render_model = _target_render_model(scenes, command.get("scene_id"), command.get("render_model_id"))
    placement_model = _scene_placement_model(scene)
    if render_model.get("visual_id") != placement_model.get("visual_id"):
        raise ProjectCommandError("COMMAND_TARGET_INVALID", "animations must target the scene placement model")
    element = _target_render_element(render_model, command.get("element_id"))
    if element.get("kind") != "sprite":
        raise ProjectCommandError("WAIT_ELEMENT_TYPE_INVALID", "only placed sprites can be animated")
    phase_visual_refs = _command_phase_visual_refs(frames, command.get("phase_visual_refs"), element)
    waiting_visual = _waiting_visual_for_state_edit(scene, state)
    elements = waiting_visual.get("elements")
    if not isinstance(elements, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "waiting_visual.elements must be an array")
    element_id = str(element["element_id"])
    previous_visual_ref = element.get("visual_ref")
    desired_phase = phase_visual_refs.index(previous_visual_ref) if previous_visual_ref in phase_visual_refs else 0
    existing = next(
        (
            item
            for item in elements
            if isinstance(item, dict) and item.get("source_element_ref") == element_id
        ),
        None,
    )
    waiting_element = {
        "element_id": existing.get("element_id") if isinstance(existing, dict) else _waiting_element_id(waiting_visual, element_id),
        "source_element_ref": element_id,
        "phase_visual_refs": phase_visual_refs,
        "step_phase_indices": [],
    }
    if existing is None:
        elements.append(waiting_element)
    else:
        elements[elements.index(existing)] = waiting_element
    if previous_visual_ref not in phase_visual_refs:
        element["visual_ref"] = phase_visual_refs[0]
    _rebuild_waiting_visual_steps(waiting_visual, {element_id: desired_phase})
    return {
        "kind": "render_element.bind_waiting_animation",
        "scene_id": command.get("scene_id"),
        "state_id": command.get("state_id"),
        "render_model_id": command.get("render_model_id"),
        "element_id": command.get("element_id"),
        "waiting_visual_id": waiting_visual["waiting_visual_id"],
        "phase_count": len(phase_visual_refs),
        "combined_step_count": waiting_visual["combined_step_count"],
    }


def _apply_render_element_clear_waiting_animation(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "state_id", "render_model_id", "element_id"},
        {"kind", "scene_id", "state_id", "render_model_id", "element_id", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    state = _command_record(scene, "states", "state_id", command.get("state_id"))
    render_model = _target_render_model(scenes, command.get("scene_id"), command.get("render_model_id"))
    placement_model = _scene_placement_model(scene)
    if render_model.get("visual_id") != placement_model.get("visual_id"):
        raise ProjectCommandError("COMMAND_TARGET_INVALID", "animations must target the scene placement model")
    element = _target_render_element(render_model, command.get("element_id"))
    if element.get("kind") != "sprite":
        raise ProjectCommandError("WAIT_ELEMENT_TYPE_INVALID", "only placed sprites can have sprite animation")
    waiting_visual = _waiting_visual_for_state_edit(scene, state)
    elements = waiting_visual.get("elements")
    if not isinstance(elements, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "waiting_visual.elements must be an array")
    before = len(elements)
    element_id = str(element["element_id"])
    elements[:] = [
        item
        for item in elements
        if not (isinstance(item, dict) and item.get("source_element_ref") == element_id)
    ]
    _rebuild_waiting_visual_steps(waiting_visual)
    return {
        "kind": "render_element.clear_waiting_animation",
        "scene_id": command.get("scene_id"),
        "state_id": command.get("state_id"),
        "render_model_id": command.get("render_model_id"),
        "element_id": command.get("element_id"),
        "waiting_visual_id": waiting_visual["waiting_visual_id"],
        "removed": before != len(elements),
    }


def _primary_asset_catalog(
    project: dict[str, Any],
    catalogs: list[dict[str, Any]],
    sources: list[str],
) -> dict[str, Any]:
    if catalogs:
        return catalogs[0]
    source = "assets/catalog.json"
    catalog = {
        "schema_id": "peepshow.authoring.assets",
        "schema_version": 1,
        "assets": [],
        "animations": [],
        "audio_assets": [],
        "audio_cues": [],
    }
    catalogs.append(catalog)
    sources.append(source)
    project.setdefault("asset_sources", []).append(source)
    return catalog


def _catalog_record(
    catalogs: list[dict[str, Any]],
    collection: str,
    id_field: str,
    record_id: Any,
) -> tuple[dict[str, Any], dict[str, Any]] | None:
    for catalog in catalogs:
        records = catalog.get(collection)
        if not isinstance(records, list):
            continue
        for record in records:
            if isinstance(record, dict) and record.get(id_field) == record_id:
                return catalog, record
    return None


def _check_asset_tags(tags, path, issues):
    if (not isinstance(tags, list) or len(tags) > 16
            or any(not isinstance(tag, str) or not 1 <= len(tag) <= 32
                   or tag != tag.strip() or not tag.strip() for tag in tags)
            or len(set(tags)) != len(tags)):
        _issue(issues, "ASSET_TAGS_INVALID", path,
               "tags must be at most 16 distinct, trimmed strings of 1..32 characters")


def _apply_asset_tags(catalogs, command):
    _require_command_fields(command, {"kind", "asset_id", "tags"},
                            {"kind", "asset_id", "tags", "command_id"})
    issues = []
    _stable_id(command["asset_id"], "command.asset_id", issues)
    _check_asset_tags(command["tags"], "command.tags", issues)
    if issues:
        raise ProjectCommandError(issues[0].code, issues[0].message)
    collection = "audio_assets" if command["kind"] == "audio_asset.set_tags" else "assets"
    located = _catalog_record(catalogs, collection, "asset_id", command["asset_id"])
    if located is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", "asset does not exist")
    located[1]["tags"] = deepcopy(command["tags"])
    return {"kind": command["kind"], "asset_id": command["asset_id"]}


def _apply_asset_upsert(
    project: dict[str, Any],
    catalogs: list[dict[str, Any]],
    sources: list[str],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "asset"}, {"kind", "asset", "command_id"})
    asset = command.get("asset")
    if not isinstance(asset, dict):
        raise ProjectCommandError("COMMAND_SHAPE_INVALID", "command.asset must be an object")
    asset_id = asset.get("asset_id")
    issues: list[ValidationIssue] = []
    _stable_id(asset_id, "command.asset.asset_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    located = _catalog_record(catalogs, "assets", "asset_id", asset_id)
    created = located is None
    if located is None:
        catalog = _primary_asset_catalog(project, catalogs, sources)
        records = catalog.setdefault("assets", [])
        if len(records) >= 128:
            raise ProjectCommandError("PROJECT_COUNT_INVALID", "asset catalog already has 128 assets")
        records.append(deepcopy(asset))
    else:
        catalog, previous = located
        records = catalog["assets"]
        records[records.index(previous)] = deepcopy(asset)
    return {"kind": "asset.upsert", "asset_id": asset_id, "created": created}


def _apply_asset_delete(
    catalogs: list[dict[str, Any]],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "asset_id"}, {"kind", "asset_id", "command_id"})
    asset_id = command.get("asset_id")
    issues: list[ValidationIssue] = []
    _stable_id(asset_id, "command.asset_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    located = _catalog_record(catalogs, "assets", "asset_id", asset_id)
    if located is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown asset '{asset_id}'")
    catalog, asset = located
    frame_ids = {
        frame.get("frame_id")
        for frame in asset.get("frames", [])
        if isinstance(frame, dict)
    }
    for animation_catalog in catalogs:
        for animation in animation_catalog.get("animations", []):
            if frame_ids.intersection(animation.get("frame_refs", [])):
                raise ProjectCommandError("ASSET_IN_USE", "asset frames are referenced by an animation")
    for scene in scenes:
        for model in scene.get("render_models", []):
            for element in model.get("elements", []):
                if element.get("visual_ref") in frame_ids:
                    raise ProjectCommandError("ASSET_IN_USE", "asset frame is referenced by a render element")
        for waiting in scene.get("waiting_visuals", []):
            for element in waiting.get("elements", []):
                if frame_ids.intersection(element.get("phase_visual_refs", [])):
                    raise ProjectCommandError("ASSET_IN_USE", "asset frame is referenced by a waiting visual")
    catalog["assets"].remove(asset)
    return {"kind": "asset.delete", "asset_id": asset_id}


def _apply_animation_upsert(
    project: dict[str, Any],
    catalogs: list[dict[str, Any]],
    sources: list[str],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(command, {"kind", "animation"}, {"kind", "animation", "command_id"})
    animation = command.get("animation")
    if not isinstance(animation, dict):
        raise ProjectCommandError("COMMAND_SHAPE_INVALID", "command.animation must be an object")
    animation_id = animation.get("animation_id")
    issues: list[ValidationIssue] = []
    _stable_id(animation_id, "command.animation.animation_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    located = _catalog_record(catalogs, "animations", "animation_id", animation_id)
    created = located is None
    if located is None:
        catalog = _primary_asset_catalog(project, catalogs, sources)
        records = catalog.setdefault("animations", [])
        if len(records) >= 128:
            raise ProjectCommandError("PROJECT_COUNT_INVALID", "asset catalog already has 128 animations")
        records.append(deepcopy(animation))
    else:
        catalog, previous = located
        records = catalog["animations"]
        records[records.index(previous)] = deepcopy(animation)
    return {"kind": "animation.upsert", "animation_id": animation_id, "created": created}


def _apply_animation_delete(
    catalogs: list[dict[str, Any]],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "animation_id"},
        {"kind", "animation_id", "command_id"},
    )
    animation_id = command.get("animation_id")
    issues: list[ValidationIssue] = []
    _stable_id(animation_id, "command.animation_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    located = _catalog_record(catalogs, "animations", "animation_id", animation_id)
    if located is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown animation '{animation_id}'")
    for scene in scenes:
        for model in scene.get("render_models", []):
            for element in model.get("elements", []):
                if element.get("visual_ref") == animation_id:
                    raise ProjectCommandError("ASSET_IN_USE", "animation is referenced by a render element")
    catalog, animation = located
    catalog["animations"].remove(animation)
    return {"kind": "animation.delete", "animation_id": animation_id}


def _apply_audio_asset_upsert(
    project: dict[str, Any],
    catalogs: list[dict[str, Any]],
    sources: list[str],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "audio_asset"},
        {"kind", "audio_asset", "command_id"},
    )
    asset = command.get("audio_asset")
    if not isinstance(asset, dict):
        raise ProjectCommandError(
            "COMMAND_SHAPE_INVALID", "command.audio_asset must be an object"
        )
    asset_id = asset.get("asset_id")
    issues: list[ValidationIssue] = []
    _stable_id(asset_id, "command.audio_asset.asset_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    located = _catalog_record(catalogs, "audio_assets", "asset_id", asset_id)
    created = located is None
    if located is None:
        catalog = _primary_asset_catalog(project, catalogs, sources)
        records = catalog.setdefault("audio_assets", [])
        if len(records) >= AUDIO_MAX_ASSETS:
            raise ProjectCommandError(
                "PROJECT_COUNT_INVALID",
                f"asset catalog already has {AUDIO_MAX_ASSETS} audio assets",
            )
        records.append(deepcopy(asset))
    else:
        catalog, previous = located
        records = catalog.setdefault("audio_assets", [])
        records[records.index(previous)] = deepcopy(asset)
    return {
        "kind": "audio_asset.upsert",
        "asset_id": asset_id,
        "created": created,
    }


def _apply_audio_asset_delete(
    catalogs: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "asset_id"},
        {"kind", "asset_id", "command_id"},
    )
    asset_id = command.get("asset_id")
    located = _catalog_record(catalogs, "audio_assets", "asset_id", asset_id)
    if located is None:
        raise ProjectCommandError(
            "COMMAND_TARGET_UNKNOWN", f"unknown audio asset '{asset_id}'"
        )
    for catalog in catalogs:
        for cue in catalog.get("audio_cues", []):
            if isinstance(cue, dict) and cue.get("asset_ref") == asset_id:
                raise ProjectCommandError(
                    "ASSET_IN_USE", "audio asset is referenced by an audio cue"
                )
    catalog, asset = located
    catalog["audio_assets"].remove(asset)
    return {"kind": "audio_asset.delete", "asset_id": asset_id}


def _apply_audio_cue_upsert(
    project: dict[str, Any],
    catalogs: list[dict[str, Any]],
    sources: list[str],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "audio_cue"},
        {"kind", "audio_cue", "command_id"},
    )
    cue = command.get("audio_cue")
    if not isinstance(cue, dict):
        raise ProjectCommandError(
            "COMMAND_SHAPE_INVALID", "command.audio_cue must be an object"
        )
    cue_id = cue.get("cue_id")
    issues: list[ValidationIssue] = []
    _stable_id(cue_id, "command.audio_cue.cue_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    located = _catalog_record(catalogs, "audio_cues", "cue_id", cue_id)
    created = located is None
    if located is None:
        catalog = _primary_asset_catalog(project, catalogs, sources)
        records = catalog.setdefault("audio_cues", [])
        if len(records) >= AUDIO_MAX_CUES:
            raise ProjectCommandError(
                "PROJECT_COUNT_INVALID",
                f"asset catalog already has {AUDIO_MAX_CUES} audio cues",
            )
        records.append(deepcopy(cue))
    else:
        catalog, previous = located
        records = catalog.setdefault("audio_cues", [])
        records[records.index(previous)] = deepcopy(cue)
    return {"kind": "audio_cue.upsert", "cue_id": cue_id, "created": created}


def _apply_audio_cue_delete(
    catalogs: list[dict[str, Any]],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "cue_id"},
        {"kind", "cue_id", "command_id"},
    )
    cue_id = command.get("cue_id")
    located = _catalog_record(catalogs, "audio_cues", "cue_id", cue_id)
    if located is None:
        raise ProjectCommandError(
            "COMMAND_TARGET_UNKNOWN", f"unknown audio cue '{cue_id}'"
        )
    for scene in scenes:
        for route in scene.get("routes", []):
            for action in route.get("actions", []):
                if (
                    isinstance(action, dict)
                    and action.get("kind") == "play_sfx"
                    and action.get("cue_ref") == cue_id
                ):
                    raise ProjectCommandError(
                        "ASSET_IN_USE", "audio cue is referenced by a STATE action"
                    )
    catalog, cue = located
    catalog["audio_cues"].remove(cue)
    return {"kind": "audio_cue.delete", "cue_id": cue_id}


def _layout_coordinate(value: Any, path: str) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", f"{path} must be a number")
    if not -100000 <= value <= 100000:
        raise ProjectCommandError("PROJECT_TYPE_INVALID", f"{path} is outside the supported editor layout range")
    return int(round(value))


def _layout_fraction(value: Any, path: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", f"{path} must be a number")
    fraction = round(float(value), 4)
    if not 0.02 <= fraction <= 0.98:
        raise ProjectCommandError("PROJECT_VALUE_INVALID", f"{path} must be between 0.02 and 0.98")
    return fraction


def _normalize_route_token_positions(value: Any, path: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", f"{path} must be an object")
    _require_command_fields(value, set(), {"condition", "actions"})
    normalized: dict[str, Any] = {}
    ordered: list[float] = []
    if "condition" in value:
        condition = _layout_fraction(value.get("condition"), f"{path}.condition")
        normalized["condition"] = condition
        ordered.append(condition)
    if "actions" in value:
        action_values = value.get("actions")
        if not isinstance(action_values, list):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", f"{path}.actions must be an array")
        if len(action_values) > STATE_GRAPH_ROUTE_ACTION_TOKEN_MAX:
            raise ProjectCommandError(
                "PROJECT_LIMIT_EXCEEDED",
                f"{path}.actions contains more than {STATE_GRAPH_ROUTE_ACTION_TOKEN_MAX} positions",
            )
        actions = [
            _layout_fraction(action, f"{path}.actions[{index}]")
            for index, action in enumerate(action_values)
        ]
        if actions:
            normalized["actions"] = actions
            ordered.extend(actions)
    if any(current <= previous for previous, current in zip(ordered, ordered[1:])):
        raise ProjectCommandError(
            "PROJECT_VALUE_INVALID",
            f"{path} positions must follow transition execution order",
        )
    return normalized


def _validate_route_token_positions(
    value: Any,
    path: str,
    issues: list[ValidationIssue],
) -> None:
    try:
        _normalize_route_token_positions(value, path)
    except ProjectCommandError as exc:
        _issue(issues, exc.code, path, exc.message)


def _apply_scene_flow_node_position(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "x", "y"},
        {"kind", "scene_id", "x", "y", "command_id"},
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    _stable_id(scene_id, "command.scene_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if scene_id not in {
        scene.get("scene_id")
        for scene in scenes
        if isinstance(scene, dict)
    }:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")

    x = _layout_coordinate(command.get("x"), "command.x")
    y = _layout_coordinate(command.get("y"), "command.y")
    editor = project.setdefault("editor", {})
    if not isinstance(editor, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor must be an object")
    scene_flow = editor.setdefault("scene_flow", {})
    if not isinstance(scene_flow, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.scene_flow must be an object")
    nodes = scene_flow.setdefault("nodes", {})
    if not isinstance(nodes, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.scene_flow.nodes must be an object")
    nodes[scene_id] = {"x": x, "y": y}
    return {
        "kind": "editor.scene_flow.set_node_position",
        "scene_id": scene_id,
        "x": x,
        "y": y,
    }


def _apply_scene_flow_package_entry_position(
    project: dict[str, Any],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "x", "y"},
        {"kind", "x", "y", "command_id"},
    )
    position = {
        "x": _layout_coordinate(command.get("x"), "command.x"),
        "y": _layout_coordinate(command.get("y"), "command.y"),
    }
    _scene_flow_data(project)["package_entry"] = position
    return {"kind": "editor.scene_flow.set_package_entry_position", **position}


def _unique_scene_flow_reference_id(references: dict[str, Any], target_scene: str) -> str:
    base = f"go_to_{_route_id_component(target_scene)}"[:64].rstrip("_.-")
    if base not in references:
        return base
    for suffix in range(2, 100):
        suffix_text = f"_{suffix}"
        candidate = f"{base[:64 - len(suffix_text)].rstrip('_.-')}{suffix_text}"
        if candidate not in references:
            return candidate
    raise ProjectCommandError("COMMAND_TARGET_INVALID", "could not generate a unique scene-flow reference ID")


def _apply_scene_flow_reference_add(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "target_scene", "x", "y"},
        {"kind", "target_scene", "x", "y", "command_id"},
    )
    target_scene = command.get("target_scene")
    issues: list[ValidationIssue] = []
    _stable_id(target_scene, "command.target_scene", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    _command_scene(scenes, target_scene)
    references = _scene_flow_references(project)
    if len(references) >= SCENE_FLOW_REFERENCE_MAX:
        raise ProjectCommandError(
            "PROJECT_LIMIT_EXCEEDED",
            f"scene flow supports at most {SCENE_FLOW_REFERENCE_MAX} Go To references",
        )
    reference_id = _unique_scene_flow_reference_id(references, str(target_scene))
    reference = {
        "target_scene": target_scene,
        "x": _layout_coordinate(command.get("x"), "command.x"),
        "y": _layout_coordinate(command.get("y"), "command.y"),
    }
    references[reference_id] = reference
    return {
        "kind": "editor.scene_flow.add_reference",
        "reference_id": reference_id,
        **reference,
    }


def _apply_scene_flow_reference_position(
    project: dict[str, Any],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "reference_id", "x", "y"},
        {"kind", "reference_id", "x", "y", "command_id"},
    )
    reference_id = command.get("reference_id")
    reference = _scene_flow_reference(project, reference_id)
    position = {
        "x": _layout_coordinate(command.get("x"), "command.x"),
        "y": _layout_coordinate(command.get("y"), "command.y"),
    }
    reference.update(position)
    return {
        "kind": "editor.scene_flow.set_reference_position",
        "reference_id": reference_id,
        **position,
    }


def _apply_scene_flow_reference_target(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "reference_id", "target_scene"},
        {"kind", "reference_id", "target_scene", "command_id"},
    )
    reference_id = command.get("reference_id")
    target_scene = command.get("target_scene")
    issues: list[ValidationIssue] = []
    _stable_id(target_scene, "command.target_scene", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    _command_scene(scenes, target_scene)
    reference = _scene_flow_reference(project, reference_id)
    scene_flow = _scene_flow_data(project)
    groups = scene_flow.get("exit_references", {})
    attached: list[tuple[str, str, str]] = []
    if isinstance(groups, dict):
        for source_scene, scene_group in groups.items():
            if not isinstance(scene_group, dict):
                continue
            for endpoint_key, mapped_reference in scene_group.items():
                if mapped_reference != reference_id or not isinstance(endpoint_key, str) or ":" not in endpoint_key:
                    continue
                endpoint_kind, endpoint_id = endpoint_key.split(":", 1)
                if source_scene == target_scene:
                    raise ProjectCommandError(
                        "COMMAND_TARGET_INVALID",
                        "a Go To reference cannot retarget an attached exit back to its own scene",
                    )
                _scene_flow_endpoint(scenes, source_scene, endpoint_kind, endpoint_id)
                attached.append((source_scene, endpoint_kind, endpoint_id))
    for source_scene, endpoint_kind, endpoint_id in attached:
        _set_scene_flow_endpoint_target(
            scenes,
            source_scene,
            endpoint_kind,
            endpoint_id,
            str(target_scene),
        )
    reference["target_scene"] = target_scene
    return {
        "kind": "editor.scene_flow.set_reference_target",
        "reference_id": reference_id,
        "target_scene": target_scene,
        "updated_exit_count": len(attached),
    }


def _apply_scene_flow_reference_delete(
    project: dict[str, Any],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "reference_id"},
        {"kind", "reference_id", "command_id"},
    )
    reference_id = command.get("reference_id")
    references = _scene_flow_references(project)
    if reference_id not in references:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene-flow reference '{reference_id}'")
    references.pop(reference_id)
    scene_flow = _scene_flow_data(project)
    groups = scene_flow.get("exit_references", {})
    detached = 0
    if isinstance(groups, dict):
        for source_scene in list(groups):
            scene_group = groups.get(source_scene)
            if not isinstance(scene_group, dict):
                continue
            for endpoint_key in list(scene_group):
                if scene_group.get(endpoint_key) == reference_id:
                    scene_group.pop(endpoint_key)
                    detached += 1
            if not scene_group:
                groups.pop(source_scene, None)
        if not groups:
            scene_flow.pop("exit_references", None)
    if not references:
        scene_flow.pop("references", None)
    return {
        "kind": "editor.scene_flow.delete_reference",
        "reference_id": reference_id,
        "detached_exit_count": detached,
    }


def _apply_scene_flow_exit_reference(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "endpoint_kind", "endpoint_id", "reference_id"},
        {"kind", "scene_id", "endpoint_kind", "endpoint_id", "reference_id", "command_id"},
    )
    scene_id = command.get("scene_id")
    endpoint_kind = command.get("endpoint_kind")
    endpoint_id = command.get("endpoint_id")
    reference_id = command.get("reference_id")
    issues: list[ValidationIssue] = []
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(endpoint_id, "command.endpoint_id", issues)
    if reference_id is not None:
        _stable_id(reference_id, "command.reference_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if endpoint_kind not in {"scene_exit", "route"}:
        raise ProjectCommandError(
            "PROJECT_VALUE_INVALID",
            "command.endpoint_kind must be scene_exit or route",
        )
    _scene_flow_endpoint(scenes, str(scene_id), endpoint_kind, str(endpoint_id))
    target_scene = None
    if reference_id is not None:
        reference = _scene_flow_reference(project, reference_id)
        target_scene = reference.get("target_scene")
        if not isinstance(target_scene, str):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "scene-flow reference target_scene must be a string")
        _set_scene_flow_endpoint_target(
            scenes,
            str(scene_id),
            endpoint_kind,
            str(endpoint_id),
            target_scene,
        )
    _set_scene_flow_exit_reference(
        project,
        str(scene_id),
        endpoint_kind,
        str(endpoint_id),
        reference_id,
    )
    return {
        "kind": "editor.scene_flow.set_exit_reference",
        "scene_id": scene_id,
        "endpoint_kind": endpoint_kind,
        "endpoint_id": endpoint_id,
        "reference_id": reference_id,
        "target_scene": target_scene,
    }


def _apply_scene_flow_route_layout(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "endpoint_kind", "endpoint_id", "rails"},
        {"kind", "scene_id", "endpoint_kind", "endpoint_id", "rails", "command_id"},
    )
    scene_id = command.get("scene_id")
    endpoint_kind = command.get("endpoint_kind")
    endpoint_id = command.get("endpoint_id")
    issues: list[ValidationIssue] = []
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(endpoint_id, "command.endpoint_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    if endpoint_kind not in {"scene_exit", "route"}:
        raise ProjectCommandError(
            "PROJECT_VALUE_INVALID",
            "command.endpoint_kind must be scene_exit or route",
        )
    _scene_flow_endpoint(scenes, str(scene_id), endpoint_kind, str(endpoint_id))

    rail_values = command.get("rails")
    if not isinstance(rail_values, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "command.rails must be an array")
    if len(rail_values) > STATE_GRAPH_ROUTE_RAIL_MAX:
        raise ProjectCommandError(
            "PROJECT_LIMIT_EXCEEDED",
            f"command.rails contains more than {STATE_GRAPH_ROUTE_RAIL_MAX} rails",
        )
    rails: list[dict[str, Any]] = []
    previous_axis: str | None = None
    for index, rail in enumerate(rail_values):
        path = f"command.rails[{index}]"
        if not isinstance(rail, dict):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", f"{path} must be an object")
        _require_command_fields(rail, {"axis", "value"}, {"axis", "value"})
        axis = rail.get("axis")
        if axis not in {"x", "y"}:
            raise ProjectCommandError("PROJECT_VALUE_INVALID", f"{path}.axis must be 'x' or 'y'")
        if axis == previous_axis:
            raise ProjectCommandError("PROJECT_VALUE_INVALID", f"{path}.axis must alternate")
        rails.append({"axis": axis, "value": _layout_coordinate(rail.get("value"), f"{path}.value")})
        previous_axis = axis

    endpoint_key = _scene_flow_endpoint_key(endpoint_kind, str(endpoint_id))
    if not rails:
        _remove_scene_flow_route_layout(project, str(scene_id), endpoint_kind, str(endpoint_id))
    else:
        groups = _scene_flow_route_groups(project)
        scene_group = groups.setdefault(scene_id, {})
        if not isinstance(scene_group, dict):
            raise ProjectCommandError(
                "PROJECT_TYPE_INVALID",
                f"project.editor.scene_flow.routes[{scene_id}] must be an object",
            )
        scene_group[endpoint_key] = {
            "routing_version": SCENE_FLOW_ROUTE_LAYOUT_VERSION,
            "rails": rails,
        }
    return {
        "kind": "editor.scene_flow.set_route_layout",
        "scene_id": scene_id,
        "endpoint_kind": endpoint_kind,
        "endpoint_id": endpoint_id,
        "rails": rails,
    }


def _state_graph_node_ids(scene: dict[str, Any]) -> set[str]:
    node_ids = {
        state.get("state_id")
        for state in scene.get("states", [])
        if isinstance(state, dict) and isinstance(state.get("state_id"), str)
    }
    node_ids.add("scene-entry")
    node_ids.add(STATE_GRAPH_SYSTEM_EXIT_NODE_ID)
    node_ids.update(
        f"scene-exit-{scene_exit.get('scene_exit_id')}"
        for scene_exit in scene.get("scene_exits", [])
        if isinstance(scene_exit, dict) and isinstance(scene_exit.get("scene_exit_id"), str)
    )
    node_ids.update(
        f"timer-{binding.get('binding_id')}"
        for binding in scene.get("event_bindings", [])
        if isinstance(binding, dict)
        and isinstance(binding.get("binding_id"), str)
        and binding.get("event_type") in {"time.scene_elapsed", "time.state_entry_elapsed"}
    )
    return node_ids


def _apply_state_graph_node_position(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "x", "y"},
        {"kind", "scene_id", "state_id", "node_id", "x", "y", "command_id"},
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    has_state_id = "state_id" in command
    has_node_id = "node_id" in command
    if has_state_id == has_node_id:
        raise ProjectCommandError(
            "COMMAND_SHAPE_INVALID",
            "state graph position requires exactly one of state_id or node_id",
        )
    node_id = command.get("state_id") if has_state_id else command.get("node_id")
    _stable_id(scene_id, "command.scene_id", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)

    target_scene = next(
        (
            scene
            for scene in scenes
            if isinstance(scene, dict) and scene.get("scene_id") == scene_id
        ),
        None,
    )
    if target_scene is None:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")
    valid_node_ids = _state_graph_node_ids(target_scene)
    if node_id not in valid_node_ids:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown state graph node '{node_id}'")

    x = _layout_coordinate(command.get("x"), "command.x")
    y = _layout_coordinate(command.get("y"), "command.y")
    editor = project.setdefault("editor", {})
    if not isinstance(editor, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor must be an object")
    state_graph = editor.setdefault("state_graph", {})
    if not isinstance(state_graph, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.state_graph must be an object")
    graph_scenes = state_graph.setdefault("scenes", {})
    if not isinstance(graph_scenes, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.state_graph.scenes must be an object")
    scene_layout = graph_scenes.setdefault(scene_id, {})
    if not isinstance(scene_layout, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", f"project.editor.state_graph.scenes[{scene_id}] must be an object")
    nodes = scene_layout.setdefault("nodes", {})
    if not isinstance(nodes, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", f"project.editor.state_graph.scenes[{scene_id}].nodes must be an object")
    nodes[node_id] = {"x": x, "y": y}
    result = {
        "kind": "editor.state_graph.set_node_position",
        "scene_id": scene_id,
        "node_id": node_id,
        "x": x,
        "y": y,
    }
    if has_state_id:
        result["state_id"] = node_id
    return result


def _apply_state_graph_entry_layout(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "target_handle", "target_side"},
        {"kind", "scene_id", "target_handle", "target_side", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    target_handle = command.get("target_handle")
    target_side = command.get("target_side")
    if target_handle not in STATE_GRAPH_ENTRY_HANDLES:
        raise ProjectCommandError("PROJECT_VALUE_INVALID", "target_handle must name a state entry socket")
    if target_side not in STATE_GRAPH_ENTRY_SIDES:
        raise ProjectCommandError("PROJECT_VALUE_INVALID", "target_side must name a card side")
    if target_side not in STATE_GRAPH_ENTRY_HANDLE_SIDES[target_handle]:
        raise ProjectCommandError(
            "PROJECT_VALUE_INVALID",
            "target_side is not available on the selected corner entry",
        )

    editor = project.setdefault("editor", {})
    if not isinstance(editor, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor must be an object")
    state_graph = editor.setdefault("state_graph", {})
    if not isinstance(state_graph, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.state_graph must be an object")
    graph_scenes = state_graph.setdefault("scenes", {})
    if not isinstance(graph_scenes, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.state_graph.scenes must be an object")
    scene_id = str(scene.get("scene_id"))
    scene_layout = graph_scenes.setdefault(scene_id, {})
    if not isinstance(scene_layout, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", f"project.editor.state_graph.scenes[{scene_id}] must be an object")
    scene_layout["entry"] = {
        "target_handle": target_handle,
        "target_side": target_side,
    }
    return {
        "kind": "editor.state_graph.set_entry_layout",
        "scene_id": scene_id,
        "target_handle": target_handle,
        "target_side": target_side,
    }


def _apply_state_graph_system_exit_delete(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id"},
        {"kind", "scene_id", "command_id"},
    )
    scene = _command_scene(scenes, command.get("scene_id"))
    if any(
        isinstance(route, dict)
        and any(
            isinstance(action, dict) and action.get("kind") == "exit_to_shell"
            for action in route.get("actions", [])
        )
        for route in scene.get("routes", [])
    ):
        raise ProjectCommandError(
            "COMMAND_TARGET_IN_USE",
            "delete Exit to PeepOS transitions before deleting the terminal",
        )
    editor = project.get("editor")
    state_graph = editor.get("state_graph") if isinstance(editor, dict) else None
    graph_scenes = state_graph.get("scenes") if isinstance(state_graph, dict) else None
    scene_layout = graph_scenes.get(scene.get("scene_id")) if isinstance(graph_scenes, dict) else None
    nodes = scene_layout.get("nodes") if isinstance(scene_layout, dict) else None
    if isinstance(nodes, dict):
        nodes.pop(STATE_GRAPH_SYSTEM_EXIT_NODE_ID, None)
        if not nodes:
            scene_layout.pop("nodes", None)
    return {
        "kind": "editor.state_graph.delete_system_exit",
        "scene_id": scene.get("scene_id"),
    }


def _handler_layout_records(project: dict[str, Any], scene_id: str, *, create: bool = False) -> dict[str, Any]:
    current = project
    for key in ("editor", "state_graph", "scenes", scene_id, "handlers"):
        current = current.setdefault(key, {}) if create else current.get(key, {})
        if not isinstance(current, dict):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "handler layout containers must be objects")
    return current


def _normalize_handler_layout(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "handler layout must be an object or null")
    _require_command_fields(value, set(), {
        "routing_version", "termination", "rails", "target_handle", "target_side", "token_positions"})
    version = value.get("routing_version", STATE_GRAPH_HANDLER_LAYOUT_VERSION)
    if isinstance(version, bool) or version != STATE_GRAPH_HANDLER_LAYOUT_VERSION:
        raise ProjectCommandError("PROJECT_VALUE_INVALID", "unsupported handler routing_version")
    result: dict[str, Any] = {"routing_version": STATE_GRAPH_HANDLER_LAYOUT_VERSION, "rails": []}
    rails = value.get("rails", [])
    if not isinstance(rails, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "handler rails must be an array")
    if len(rails) > STATE_GRAPH_ROUTE_RAIL_MAX:
        raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "handler layout supports at most eight rails")
    previous = None
    for rail in rails:
        if not isinstance(rail, dict):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "handler rail must be an object")
        _require_command_fields(rail, {"axis", "value"}, {"axis", "value"})
        axis = rail["axis"]
        if axis not in ("x", "y") or axis == previous:
            raise ProjectCommandError("PROJECT_VALUE_INVALID", "handler rail axes must alternate x/y")
        result["rails"].append({"axis": axis, "value": _layout_coordinate(rail["value"], "rail.value")})
        previous = axis
    if "termination" in value:
        position = value["termination"]
        if not isinstance(position, dict):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "termination must be an x/y position")
        _require_command_fields(position, {"x", "y"}, {"x", "y"})
        result["termination"] = {axis: _layout_coordinate(position[axis], f"termination.{axis}")
                                 for axis in ("x", "y")}
    handle, side = value.get("target_handle"), value.get("target_side")
    if handle is not None or side is not None:
        if not isinstance(handle, str) or handle not in STATE_GRAPH_ENTRY_HANDLE_SIDES:
            raise ProjectCommandError("PROJECT_VALUE_INVALID", "target_handle must name a state entry socket")
        if not isinstance(side, str) or side not in STATE_GRAPH_ENTRY_HANDLE_SIDES[handle]:
            raise ProjectCommandError("PROJECT_VALUE_INVALID", "target_side must match target_handle")
        result.update(target_handle=handle, target_side=side)
    if "token_positions" in value:
        tokens = value["token_positions"]
        if isinstance(tokens, dict) and "guards" in tokens:
            _require_command_fields(tokens, {"guards"}, {"guards", "actions"})
            guards = tokens["guards"]
            if not isinstance(guards, list):
                raise ProjectCommandError("PROJECT_TYPE_INVALID", "guard positions must be an array")
            if len(guards) > 8:
                raise ProjectCommandError("PROJECT_LIMIT_EXCEEDED", "at most eight guard positions")
            normalized = _normalize_route_token_positions({"actions": tokens.get("actions", [])}, "token_positions")
            normalized["guards"] = [_layout_fraction(item, "token_positions.guards") for item in guards]
            ordered = normalized["guards"] + normalized.get("actions", [])
            if any(b <= a for a, b in zip(ordered, ordered[1:])):
                raise ProjectCommandError("PROJECT_VALUE_INVALID", "token positions must follow execution order")
        else:
            normalized = _normalize_route_token_positions(tokens, "token_positions")
        result["token_positions"] = normalized
    return result


def _check_handler_layout_target(scene: dict[str, Any], handler_id: str, layout: dict[str, Any]) -> None:
    handler = _command_record(scene, "event_handlers", "handler_id", handler_id)
    binding = _command_record(scene, "event_bindings", "binding_id", handler.get("event_ref"))
    if binding.get("event_type") not in {"time.scene_elapsed", "time.local_schedule"}:
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", "layout requires a scene-timer handler")
    if "termination" in layout and ("target_state" in handler or "target_scene" in handler):
        raise ProjectCommandError("PROJECT_VALUE_INVALID", "termination position requires a targetless handler")
    if layout.get("target_handle") is not None and "target_state" not in handler:
        raise ProjectCommandError("PROJECT_VALUE_INVALID", "state entry socket requires a local target_state")


def _apply_state_graph_handler_layout(project: dict[str, Any], scenes: list[dict[str, Any]],
                                      command: dict[str, Any]) -> dict[str, Any]:
    required = {"kind", "scene_id", "handler_id", "layout"}
    _require_command_fields(command, required, required | {"command_id"})
    scene = _command_scene(scenes, command["scene_id"])
    handler_id = command["handler_id"]
    issues: list[ValidationIssue] = []
    _stable_id(handler_id, "command.handler_id", issues)
    if issues:
        raise ProjectCommandError(issues[0].code, issues[0].message)
    layout = None if command["layout"] is None else _normalize_handler_layout(command["layout"])
    _check_handler_layout_target(scene, handler_id, layout or {})
    records = _handler_layout_records(project, scene["scene_id"], create=layout is not None)
    if layout is None:
        records.pop(handler_id, None)
    else:
        records[handler_id] = layout
    return {"kind": command["kind"], "scene_id": scene["scene_id"], "handler_id": handler_id,
            "layout": deepcopy(layout)}


def _apply_state_graph_route_layout(
    project: dict[str, Any],
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "route_id", "source_state", "rails", "target_handle", "target_side"},
        {
            "kind",
            "scene_id",
            "route_id",
            "source_state",
            "rails",
            "target_handle",
            "target_side",
            "token_positions",
            "command_id",
        },
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    route_id = command.get("route_id")
    source_state = command.get("source_state")
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(route_id, "command.route_id", issues)
    _stable_id(source_state, "command.source_state", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)

    scene = _command_scene(scenes, scene_id)
    route = _command_record(scene, "routes", "route_id", route_id)
    if source_state not in route.get("from_states", []):
        raise ProjectCommandError(
            "COMMAND_TARGET_UNKNOWN",
            f"state '{source_state}' is not a source of route '{route_id}'",
        )
    rail_values = command.get("rails")
    if not isinstance(rail_values, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "command.rails must be an array")
    if len(rail_values) > STATE_GRAPH_ROUTE_RAIL_MAX:
        raise ProjectCommandError(
            "PROJECT_LIMIT_EXCEEDED",
            f"command.rails contains more than {STATE_GRAPH_ROUTE_RAIL_MAX} rails",
        )
    rails: list[dict[str, Any]] = []
    previous_axis: str | None = None
    for index, rail in enumerate(rail_values):
        path = f"command.rails[{index}]"
        if not isinstance(rail, dict):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", f"{path} must be an object")
        _require_command_fields(rail, {"axis", "value"}, {"axis", "value"})
        axis = rail.get("axis")
        if axis not in {"x", "y"}:
            raise ProjectCommandError("PROJECT_VALUE_INVALID", f"{path}.axis must be 'x' or 'y'")
        if axis == previous_axis:
            raise ProjectCommandError("PROJECT_VALUE_INVALID", f"{path}.axis must alternate")
        rails.append({"axis": axis, "value": _layout_coordinate(rail.get("value"), f"{path}.value")})
        previous_axis = axis

    target_handle = command.get("target_handle")
    if target_handle is not None and target_handle not in STATE_GRAPH_ENTRY_HANDLES:
        raise ProjectCommandError(
            "PROJECT_VALUE_INVALID",
            "command.target_handle must name a state entry socket or be null",
        )
    target_side = command.get("target_side")
    if target_side is not None and target_side not in STATE_GRAPH_ENTRY_SIDES:
        raise ProjectCommandError(
            "PROJECT_VALUE_INVALID",
            "command.target_side must name a card side or be null",
        )
    if (target_handle is None) != (target_side is None):
        raise ProjectCommandError(
            "PROJECT_VALUE_INVALID",
            "command.target_handle and command.target_side must both be set or both be null",
        )
    if target_handle is not None and target_side not in STATE_GRAPH_ENTRY_HANDLE_SIDES[target_handle]:
        raise ProjectCommandError(
            "PROJECT_VALUE_INVALID",
            "command.target_side is not available on the selected corner entry",
        )

    editor = project.get("editor")
    state_graph = editor.get("state_graph") if isinstance(editor, dict) else None
    graph_scenes = state_graph.get("scenes") if isinstance(state_graph, dict) else None
    scene_layout = graph_scenes.get(scene_id) if isinstance(graph_scenes, dict) else None
    routes = scene_layout.get("routes") if isinstance(scene_layout, dict) else None
    route_layout = routes.get(route_id) if isinstance(routes, dict) else None
    sources = route_layout.get("sources") if isinstance(route_layout, dict) else None
    existing_source_layout = sources.get(source_state) if isinstance(sources, dict) else None
    if "token_positions" in command:
        token_positions = _normalize_route_token_positions(
            command.get("token_positions"), "command.token_positions"
        )
    elif isinstance(existing_source_layout, dict):
        token_positions = deepcopy(existing_source_layout.get("token_positions", {}))
    else:
        token_positions = {}

    if not rails and target_handle is None and target_side is None and not token_positions:
        if isinstance(sources, dict):
            sources.pop(source_state, None)
            if not sources:
                routes.pop(route_id, None)
            if not routes:
                scene_layout.pop("routes", None)
    else:
        editor = project.setdefault("editor", {})
        if not isinstance(editor, dict):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor must be an object")
        state_graph = editor.setdefault("state_graph", {})
        if not isinstance(state_graph, dict):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.state_graph must be an object")
        graph_scenes = state_graph.setdefault("scenes", {})
        if not isinstance(graph_scenes, dict):
            raise ProjectCommandError("PROJECT_TYPE_INVALID", "project.editor.state_graph.scenes must be an object")
        scene_layout = graph_scenes.setdefault(scene_id, {})
        if not isinstance(scene_layout, dict):
            raise ProjectCommandError(
                "PROJECT_TYPE_INVALID",
                f"project.editor.state_graph.scenes[{scene_id}] must be an object",
            )
        routes = scene_layout.setdefault("routes", {})
        if not isinstance(routes, dict):
            raise ProjectCommandError(
                "PROJECT_TYPE_INVALID",
                f"project.editor.state_graph.scenes[{scene_id}].routes must be an object",
            )
        route_layout = routes.setdefault(route_id, {})
        if not isinstance(route_layout, dict):
            raise ProjectCommandError(
                "PROJECT_TYPE_INVALID",
                f"project.editor.state_graph.scenes[{scene_id}].routes[{route_id}] must be an object",
            )
        sources = route_layout.setdefault("sources", {})
        if not isinstance(sources, dict):
            raise ProjectCommandError(
                "PROJECT_TYPE_INVALID",
                f"project.editor.state_graph.scenes[{scene_id}].routes[{route_id}].sources must be an object",
            )
        source_layout = {
            "routing_version": STATE_GRAPH_ROUTE_LAYOUT_VERSION,
            "rails": rails,
        }
        if target_handle is not None:
            source_layout["target_handle"] = target_handle
            source_layout["target_side"] = target_side
        if token_positions:
            source_layout["token_positions"] = token_positions
        sources[source_state] = source_layout
    return {
        "kind": "editor.state_graph.set_route_layout",
        "scene_id": scene_id,
        "route_id": route_id,
        "source_state": source_state,
        "rails": rails,
        "target_handle": target_handle,
        "target_side": target_side,
        "token_positions": token_positions,
    }


def _normalize_guard(scene: dict[str, Any], guard: Any) -> dict[str, Any]:
    if not isinstance(guard, dict):
        raise ProjectCommandError("GUARD_TYPE_MISMATCH", "guard must be an object")
    _require_command_fields(guard, {"variable_ref", "operator", "value"}, {"variable_ref", "operator", "value", "variable_scope"})
    variable_ref = guard.get("variable_ref")
    operator = guard.get("operator")
    value = guard.get("value")
    issues: list[ValidationIssue] = []
    _stable_id(variable_ref, "command.guard.variable_ref", issues)
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)
    variable_ids = {
        variable.get("variable_id")
        for variable in scene.get("variables", [])
        if isinstance(variable, dict)
    }
    if variable_ref not in variable_ids and guard.get("variable_scope") != "package":
        raise ProjectCommandError("GUARD_VARIABLE_UNKNOWN", f"unknown variable '{variable_ref}'")
    if operator not in GUARD_OPERATORS:
        raise ProjectCommandError("GUARD_OPERATOR_INVALID", "unsupported comparison")
    if not isinstance(value, int):
        raise ProjectCommandError("GUARD_TYPE_MISMATCH", "guard value must be an integer")
    return deepcopy(guard)


def _route_target_elements(
    scene: dict[str, Any],
    route: dict[str, Any],
) -> dict[str, dict[str, Any]]:
    target_state = route.get("target_state")
    state = next(
        (
            item
            for item in scene.get("states", [])
            if isinstance(item, dict) and item.get("state_id") == target_state
        ),
        None,
    )
    if state is None:
        raise ProjectCommandError(
            "GRAPH_TRANSITION_TARGET_UNKNOWN",
            "element actions require a valid target_state",
        )
    render_model = _scene_placement_model(scene)
    return {
        str(item.get("element_id")): item
        for item in render_model.get("elements", [])
        if isinstance(item, dict) and isinstance(item.get("element_id"), str)
    }


def _normalize_action(
    scene: dict[str, Any],
    route: dict[str, Any],
    action: Any,
) -> dict[str, Any]:
    if not isinstance(action, dict):
        raise ProjectCommandError("ACTION_TYPE_INVALID", "action must be an object")
    action_kind = action.get("kind")
    if action_kind == "set_variable":
        _require_command_fields(action, {"kind", "variable_ref", "operation", "value"}, {"kind", "variable_ref", "operation", "value"})
        variable_ref = action.get("variable_ref")
        operation = action.get("operation")
        value = action.get("value")
        issues: list[ValidationIssue] = []
        _stable_id(variable_ref, "command.action.variable_ref", issues)
        if issues:
            issue = issues[0]
            raise ProjectCommandError(issue.code, issue.message)
        variable_ids = {
            variable.get("variable_id")
            for variable in scene.get("variables", [])
            if isinstance(variable, dict)
        }
        if variable_ref not in variable_ids:
            raise ProjectCommandError("ACTION_VARIABLE_UNKNOWN", f"unknown variable '{variable_ref}'")
        if operation not in ACTION_OPERATIONS:
            raise ProjectCommandError("ACTION_OPERATION_INVALID", "action operation must be assign or add")
        if isinstance(value, bool) or not isinstance(value, int):
            raise ProjectCommandError("ACTION_TYPE_INVALID", "action value must be an integer")
        return {"kind": "set_variable", "variable_ref": variable_ref, "operation": operation, "value": value}
    if action_kind == "request_render":
        _require_command_fields(action, {"kind"}, {"kind"})
        return {"kind": "request_render"}
    if action_kind == "play_sfx":
        _require_command_fields(
            action,
            {"kind", "cue_ref"},
            {"kind", "cue_ref"},
        )
        cue_ref = action.get("cue_ref")
        issues: list[ValidationIssue] = []
        _stable_id(cue_ref, "command.action.cue_ref", issues)
        if issues:
            issue = issues[0]
            raise ProjectCommandError(issue.code, issue.message)
        return {"kind": "play_sfx", "cue_ref": cue_ref}
    if action_kind == "exit_to_shell":
        _require_command_fields(action, {"kind"}, {"kind"})
        return {"kind": "exit_to_shell"}
    if action_kind in {
        "set_element_visibility",
        "set_element_position",
        "set_element_frame",
        "set_element_waiting_animation",
    }:
        elements = _route_target_elements(scene, route)
        element_ref = action.get("element_ref")
        issues: list[ValidationIssue] = []
        _stable_id(element_ref, "command.action.element_ref", issues)
        if issues:
            issue = issues[0]
            raise ProjectCommandError(issue.code, issue.message)
        element = elements.get(element_ref)
        if element is None:
            raise ProjectCommandError(
                "ACTION_ELEMENT_UNKNOWN",
                f"target state has no element '{element_ref}'",
            )
        if action_kind == "set_element_visibility":
            _require_command_fields(
                action,
                {"kind", "element_ref", "visible"},
                {"kind", "element_ref", "visible"},
            )
            visible = action.get("visible")
            if not isinstance(visible, bool):
                raise ProjectCommandError(
                    "ACTION_TYPE_INVALID", "visible must be true or false"
                )
            if not visible and element.get("focus_role", "none") == "focus":
                raise ProjectCommandError(
                    "RENDER_FOCUS_INVALID", "the focus element must remain visible"
                )
            return {
                "kind": action_kind,
                "element_ref": element_ref,
                "visible": visible,
            }
        if action_kind == "set_element_position":
            _require_command_fields(
                action,
                {"kind", "element_ref", "x", "y"},
                {"kind", "element_ref", "x", "y"},
            )
            x = action.get("x")
            y = action.get("y")
            if (
                isinstance(x, bool)
                or not isinstance(x, int)
                or isinstance(y, bool)
                or not isinstance(y, int)
            ):
                raise ProjectCommandError(
                    "ACTION_TYPE_INVALID", "position must use integer x and y"
                )
            if (
                x < 0
                or y < 0
                or x + int(element.get("width", 0)) > 168
                or y + int(element.get("height", 0)) > 144
            ):
                raise ProjectCommandError(
                    "RENDER_BOUNDS_INVALID",
                    "element action would move outside the 168x144 display",
                )
            return {
                "kind": action_kind,
                "element_ref": element_ref,
                "x": x,
                "y": y,
            }
        if action_kind == "set_element_waiting_animation":
            _require_command_fields(
                action,
                {
                    "kind",
                    "element_ref",
                    "waiting_visual_ref",
                    "waiting_element_ref",
                    "timeline_policy",
                },
                {
                    "kind",
                    "element_ref",
                    "waiting_visual_ref",
                    "waiting_element_ref",
                    "timeline_policy",
                },
            )
            waiting_visual_ref = action.get("waiting_visual_ref")
            waiting_element_ref = action.get("waiting_element_ref")
            timeline_policy = action.get("timeline_policy")
            issues = []
            _stable_id(
                waiting_visual_ref,
                "command.action.waiting_visual_ref",
                issues,
            )
            _stable_id(
                waiting_element_ref,
                "command.action.waiting_element_ref",
                issues,
            )
            if issues:
                issue = issues[0]
                raise ProjectCommandError(issue.code, issue.message)
            waiting_visual = next(
                (
                    item
                    for item in scene.get("waiting_visuals", [])
                    if isinstance(item, dict)
                    and item.get("waiting_visual_id") == waiting_visual_ref
                ),
                None,
            )
            if waiting_visual is None:
                raise ProjectCommandError(
                    "WAIT_VISUAL_UNKNOWN",
                    f"unknown waiting visual '{waiting_visual_ref}'",
                )
            waiting_element = next(
                (
                    item
                    for item in waiting_visual.get("elements", [])
                    if isinstance(item, dict)
                    and item.get("element_id") == waiting_element_ref
                ),
                None,
            )
            if waiting_element is None:
                raise ProjectCommandError(
                    "WAIT_ELEMENT_UNKNOWN",
                    f"waiting visual has no element '{waiting_element_ref}'",
                )
            if waiting_element.get("source_element_ref") != element_ref:
                raise ProjectCommandError(
                    "ACTION_WAIT_ELEMENT_MISMATCH",
                    "waiting animation must target the same retained element",
                )
            target_state = next(
                item
                for item in scene.get("states", [])
                if isinstance(item, dict)
                and item.get("state_id") == route.get("target_state")
            )
            target_waiting = next(
                item
                for item in scene.get("waiting_visuals", [])
                if isinstance(item, dict)
                and item.get("waiting_visual_id")
                == target_state.get("waiting_visual_ref")
            )
            if (
                waiting_visual.get("phase_quantum_ms")
                != target_waiting.get("phase_quantum_ms")
                or waiting_visual.get("combined_step_count")
                != target_waiting.get("combined_step_count")
            ):
                raise ProjectCommandError(
                    "ACTION_WAIT_TIMELINE_INCOMPATIBLE",
                    "waiting animation cadence and step count must match the target state",
                )
            if timeline_policy not in {"preserve", "rebase"}:
                raise ProjectCommandError(
                    "ACTION_TIMELINE_POLICY_INVALID",
                    "timeline_policy must be preserve or rebase",
                )
            if element.get("kind") != "sprite":
                raise ProjectCommandError(
                    "ACTION_ELEMENT_TYPE_INVALID",
                    "waiting animation selection requires a sprite element",
                )
            return {
                "kind": action_kind,
                "element_ref": element_ref,
                "waiting_visual_ref": waiting_visual_ref,
                "waiting_element_ref": waiting_element_ref,
                "timeline_policy": timeline_policy,
            }
        _require_command_fields(
            action,
            {"kind", "element_ref", "frame_ref"},
            {"kind", "element_ref", "frame_ref"},
        )
        frame_ref = action.get("frame_ref")
        issues = []
        _stable_id(frame_ref, "command.action.frame_ref", issues)
        if issues:
            issue = issues[0]
            raise ProjectCommandError(issue.code, issue.message)
        if element.get("kind") != "sprite":
            raise ProjectCommandError(
                "ACTION_ELEMENT_TYPE_INVALID",
                "frame selection requires a sprite element",
            )
        return {
            "kind": action_kind,
            "element_ref": element_ref,
            "frame_ref": frame_ref,
        }
    raise ProjectCommandError("ACTION_KIND_INVALID", "unsupported V1 action")


def _apply_route_guard_list(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    kind = command.get("kind")
    required = {"kind", "scene_id", "route_id", "guard_index"}
    allowed = required | {"guard", "target_index", "command_id"}
    if kind == "route.guard.add":
        required.add("guard")
    elif kind == "route.guard.move":
        required.add("target_index")
    _require_command_fields(command, required, allowed)
    scene = _command_scene(scenes, command.get("scene_id"))
    route = _command_record(scene, "routes", "route_id", command.get("route_id"))
    guards = route.get("guards")
    if not isinstance(guards, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "route.guards must be an array")
    guard_index = _command_index(command.get("guard_index"), "guard_index")
    if kind == "route.guard.add":
        if len(guards) >= 8:
            raise ProjectCommandError("GUARD_LIMIT_EXCEEDED", "route supports at most 8 guards")
        if guard_index > len(guards):
            raise ProjectCommandError("COMMAND_INDEX_INVALID", "guard_index must select an insertion position")
        guard = _normalize_guard(scene, command.get("guard"))
        guards.insert(guard_index, guard)
        return {"kind": kind, "scene_id": scene.get("scene_id"), "route_id": route.get("route_id"), "guard_index": guard_index, "guard": guard}
    source_index = _command_move_index(guard_index, "guard_index", len(guards))
    if kind == "route.guard.delete":
        guard = guards.pop(source_index)
        return {"kind": kind, "scene_id": scene.get("scene_id"), "route_id": route.get("route_id"), "guard_index": source_index, "guard": guard}
    target_index = _command_move_index(command.get("target_index"), "target_index", len(guards))
    guard = guards.pop(source_index)
    guards.insert(target_index, guard)
    return {"kind": kind, "scene_id": scene.get("scene_id"), "route_id": route.get("route_id"), "guard_index": source_index, "target_index": target_index}


def _apply_route_action_list(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    kind = command.get("kind")
    required = {"kind", "scene_id", "route_id", "action_index"}
    allowed = required | {"action", "target_index", "command_id"}
    if kind == "route.action.add":
        required.add("action")
    elif kind == "route.action.move":
        required.add("target_index")
    _require_command_fields(command, required, allowed)
    scene = _command_scene(scenes, command.get("scene_id"))
    route = _command_record(scene, "routes", "route_id", command.get("route_id"))
    actions = route.get("actions")
    if not isinstance(actions, list):
        raise ProjectCommandError("PROJECT_TYPE_INVALID", "route.actions must be an array")
    action_index = _command_index(command.get("action_index"), "action_index")
    if kind == "route.action.add":
        if len(actions) >= 8:
            raise ProjectCommandError("ACTION_BUDGET_EXCEEDED", "route supports at most 8 actions")
        if action_index > len(actions):
            raise ProjectCommandError("COMMAND_INDEX_INVALID", "action_index must select an insertion position")
        action = _normalize_action(scene, route, command.get("action"))
        if "target_scene" in route and action.get("kind") != "play_sfx":
            raise ProjectCommandError(
                "SCENE_TRANSITION_ACTION_UNSUPPORTED",
                "direct scene replacement supports only play_sfx actions",
            )
        actions.insert(action_index, action)
        return {"kind": kind, "scene_id": scene.get("scene_id"), "route_id": route.get("route_id"), "action_index": action_index, "action": action}
    source_index = _command_move_index(action_index, "action_index", len(actions))
    if kind == "route.action.delete":
        action = actions.pop(source_index)
        return {"kind": kind, "scene_id": scene.get("scene_id"), "route_id": route.get("route_id"), "action_index": source_index, "action": action}
    target_index = _command_move_index(command.get("target_index"), "target_index", len(actions))
    action = actions.pop(source_index)
    actions.insert(target_index, action)
    return {"kind": kind, "scene_id": scene.get("scene_id"), "route_id": route.get("route_id"), "action_index": source_index, "target_index": target_index}


def _apply_route_set_guard(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "route_id", "guard_index", "variable_ref", "operator", "value"},
        {"kind", "scene_id", "route_id", "guard_index", "variable_ref", "operator", "value", "command_id"},
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    route_id = command.get("route_id")
    guard_index = command.get("guard_index")
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(route_id, "command.route_id", issues)
    if isinstance(guard_index, bool) or not isinstance(guard_index, int) or guard_index < 0:
        raise ProjectCommandError("COMMAND_INDEX_INVALID", "guard_index must be a non-negative integer")
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)

    for scene in scenes:
        if scene.get("scene_id") != scene_id:
            continue
        normalized_guard = _normalize_guard(
            scene,
            {
                "variable_ref": command.get("variable_ref"),
                "operator": command.get("operator"),
                "value": command.get("value"),
            },
        )
        for route in scene.get("routes", []):
            if not isinstance(route, dict) or route.get("route_id") != route_id:
                continue
            guards = route.get("guards")
            if not isinstance(guards, list) or guard_index >= len(guards):
                raise ProjectCommandError("COMMAND_INDEX_INVALID", "guard_index does not select an existing guard")
            guards[guard_index] = normalized_guard
            return {
                "kind": "route.set_guard",
                "scene_id": scene_id,
                "route_id": route_id,
                "guard_index": guard_index,
                **normalized_guard,
            }
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown route '{route_id}'")
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")


def _apply_route_set_action(
    scenes: list[dict[str, Any]],
    command: dict[str, Any],
) -> dict[str, Any]:
    _require_command_fields(
        command,
        {"kind", "scene_id", "route_id", "action_index", "action"},
        {"kind", "scene_id", "route_id", "action_index", "action", "command_id"},
    )
    issues: list[ValidationIssue] = []
    scene_id = command.get("scene_id")
    route_id = command.get("route_id")
    action_index = command.get("action_index")
    action = command.get("action")
    _stable_id(scene_id, "command.scene_id", issues)
    _stable_id(route_id, "command.route_id", issues)
    if isinstance(action_index, bool) or not isinstance(action_index, int) or action_index < 0:
        raise ProjectCommandError("COMMAND_INDEX_INVALID", "action_index must be a non-negative integer")
    if not isinstance(action, dict):
        raise ProjectCommandError("ACTION_TYPE_INVALID", "action must be an object")
    if issues:
        issue = issues[0]
        raise ProjectCommandError(issue.code, issue.message)

    for scene in scenes:
        if scene.get("scene_id") != scene_id:
            continue
        for route in scene.get("routes", []):
            if not isinstance(route, dict) or route.get("route_id") != route_id:
                continue
            normalized_action = _normalize_action(scene, route, action)
            if (
                "target_scene" in route
                and normalized_action.get("kind") != "play_sfx"
            ):
                raise ProjectCommandError(
                    "SCENE_TRANSITION_ACTION_UNSUPPORTED",
                    "direct scene replacement supports only play_sfx actions",
                )
            actions = route.get("actions")
            if not isinstance(actions, list) or action_index >= len(actions):
                raise ProjectCommandError("COMMAND_INDEX_INVALID", "action_index does not select an existing action")
            actions[action_index] = normalized_action
            return {
                "kind": "route.set_action",
                "scene_id": scene_id,
                "route_id": route_id,
                "action_index": action_index,
                "action": normalized_action,
            }
        raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown route '{route_id}'")
    raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", f"unknown scene '{scene_id}'")


def _read_json(path: Path, issues: list[ValidationIssue], code: str) -> dict[str, Any] | None:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except OSError as exc:
        _issue(issues, code, str(path), f"could not read file: {exc}")
        return None
    except json.JSONDecodeError as exc:
        _issue(issues, code, str(path), f"invalid JSON at line {exc.lineno}, column {exc.colno}")
        return None
    if not isinstance(value, dict):
        _issue(issues, code, str(path), "root value must be an object")
        return None
    return value


def _check_keys(
    value: dict[str, Any],
    required: set[str],
    path: str,
    issues: list[ValidationIssue],
    allowed: set[str] | None = None,
) -> None:
    allowed_keys = required if allowed is None else allowed
    for key in sorted(required - value.keys()):
        _issue(issues, "PROJECT_FIELD_MISSING", f"{path}.{key}", "required field is missing")
    for key in sorted(value.keys() - allowed_keys):
        _issue(issues, "PROJECT_FIELD_UNKNOWN", f"{path}.{key}", "field is not part of the V1 subset")


def _stable_id(value: Any, path: str, issues: list[ValidationIssue]) -> bool:
    if not isinstance(value, str) or STABLE_ID.fullmatch(value) is None:
        _issue(issues, "PROJECT_ID_INVALID", path, "must be a lowercase stable ID")
        return False
    return True


def _editor_node_id(value: Any, path: str, issues: list[ValidationIssue]) -> bool:
    if (
        not isinstance(value, str)
        or not 1 <= len(value) <= 96
        or re.fullmatch(r"[a-z][a-z0-9_.-]*", value) is None
    ):
        _issue(issues, "PROJECT_ID_INVALID", path, "must be a lowercase editor node ID")
        return False
    return True


def _text(value: Any, path: str, issues: list[ValidationIssue], maximum: int = 96) -> bool:
    if not isinstance(value, str) or not 1 <= len(value) <= maximum:
        _issue(issues, "PROJECT_TEXT_INVALID", path, f"must be text with 1..{maximum} characters")
        return False
    return True


def _unique_ids(
    records: Any,
    field: str,
    path: str,
    issues: list[ValidationIssue],
    maximum: int,
) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    if not isinstance(records, list):
        _issue(issues, "PROJECT_TYPE_INVALID", path, "must be an array")
        return result
    if len(records) > maximum:
        _issue(issues, "PROJECT_LIMIT_EXCEEDED", path, f"contains more than {maximum} records")
    for index, record in enumerate(records):
        item_path = f"{path}[{index}]"
        if not isinstance(record, dict):
            _issue(issues, "PROJECT_TYPE_INVALID", item_path, "must be an object")
            continue
        record_id = record.get(field)
        if not _stable_id(record_id, f"{item_path}.{field}", issues):
            continue
        if record_id in result:
            _issue(issues, "PROJECT_ID_DUPLICATE", f"{item_path}.{field}", f"duplicate ID '{record_id}'")
            continue
        result[record_id] = record
    return result


def _check_project_settings(settings, issues):
    path = "project.settings"
    if not isinstance(settings, dict):
        _issue(issues, "PROJECT_SETTINGS_INVALID", path, "must be an object")
        return
    _check_keys(settings, set(), path, issues, {"sfx_import", "runtime_preferences"})
    for group, fields in (("sfx_import", {"normalization", "target_peak_dbfs"}),
                          ("runtime_preferences", {"inactivity_timeout_ms"})):
        if group not in settings:
            continue
        values = settings[group]
        if not isinstance(values, dict):
            _issue(issues, "PROJECT_SETTINGS_INVALID", f"{path}.{group}", "must be an object")
            continue
        _check_keys(values, fields, f"{path}.{group}", issues, fields)
        if group == "sfx_import":
            if values.get("normalization") not in ("none", "peak"):
                _issue(issues, "PROJECT_SETTINGS_INVALID", path, "normalization must be none or peak")
            value = values.get("target_peak_dbfs")
            if type(value) is not int or not -60 <= value <= 0:
                _issue(issues, "PROJECT_SETTINGS_INVALID", path, "target_peak_dbfs must be an integer from -60 to 0")
        else:
            value = values.get("inactivity_timeout_ms")
            if value is not None and (type(value) is not int or not 1000 <= value <= 86400000):
                _issue(issues, "PROJECT_SETTINGS_INVALID", path, "inactivity_timeout_ms must be null or an integer from 1000 to 86400000")


def _check_project(project: dict[str, Any], issues: list[ValidationIssue]) -> None:
    from .authoring_foundation import enabled, check_project
    from .execution_semantics import issues as semantics_issues
    for issue in semantics_issues(project):
        _issue(issues, issue["code"], issue["path"], issue["message"])
    if enabled(project):
        check_project(project, issues)
        return
    _check_keys(project, PROJECT_KEYS, "project", issues, PROJECT_KEYS | PROJECT_OPTIONAL_KEYS)
    from .scoped_variables import project_check
    try:
        project_check(project)
        from .inventory_source import catalog
        catalog(project)
    except ProjectCommandError as exc:
        _issue(issues, exc.code, "project", exc.message)
    if "settings" in project:
        _check_project_settings(project["settings"], issues)
    if project.get("schema_id") != "peepshow.authoring.project" or project.get("schema_version") != 1:
        _issue(issues, "PROJECT_SCHEMA_UNSUPPORTED", "project", "expected peepshow.authoring.project version 1")
    _stable_id(project.get("project_id"), "project.project_id", issues)
    _text(project.get("project_name"), "project.project_name", issues)
    selected_target_profile = project.get("selected_target_profile")
    _stable_id(selected_target_profile, "project.selected_target_profile", issues)
    if (
        isinstance(selected_target_profile, str)
        and STABLE_ID.fullmatch(selected_target_profile) is not None
        and selected_target_profile not in SUPPORTED_TARGET_PROFILE_IDS
    ):
        _issue(
            issues,
            "TARGET_PROFILE_UNSUPPORTED",
            "project.selected_target_profile",
            f"unsupported target profile: {selected_target_profile}",
        )
    _stable_id(project.get("entry_scene"), "project.entry_scene", issues)

    package = project.get("package")
    if not isinstance(package, dict):
        _issue(issues, "PROJECT_TYPE_INVALID", "project.package", "must be an object")
    else:
        expected = {"package_id", "display_name", "version"}
        _check_keys(package, expected, "project.package", issues)
        _stable_id(package.get("package_id"), "project.package.package_id", issues)
        _text(package.get("display_name"), "project.package.display_name", issues)
        version = package.get("version")
        if not isinstance(version, str) or re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version) is None:
            _issue(issues, "PROJECT_VERSION_INVALID", "project.package.version", "must be major.minor.patch")

    sources = project.get("scene_sources")
    if not isinstance(sources, list) or not sources:
        _issue(issues, "SCENE_SOURCE_MISSING", "project.scene_sources", "must contain at least one scene source")
    elif len(sources) > 32:
        _issue(issues, "PROJECT_LIMIT_EXCEEDED", "project.scene_sources", "contains more than 32 scene sources")
    else:
        seen_sources: set[str] = set()
        for index, source in enumerate(sources):
            if not isinstance(source, str) or not source:
                _issue(issues, "SCENE_SOURCE_INVALID", f"project.scene_sources[{index}]", "must be a non-empty path")
            elif source in seen_sources:
                _issue(issues, "SCENE_SOURCE_DUPLICATE", f"project.scene_sources[{index}]", "scene source path is duplicated")
            else:
                seen_sources.add(source)

    asset_sources = project.get("asset_sources", [])
    if not isinstance(asset_sources, list):
        _issue(issues, "PROJECT_TYPE_INVALID", "project.asset_sources", "must be an array")
    elif len(asset_sources) > 16:
        _issue(issues, "PROJECT_LIMIT_EXCEEDED", "project.asset_sources", "contains more than 16 asset catalogs")
    else:
        seen_asset_sources: set[str] = set()
        for index, source in enumerate(asset_sources):
            path = f"project.asset_sources[{index}]"
            if not isinstance(source, str) or not source:
                _issue(issues, "ASSET_SOURCE_INVALID", path, "must be a non-empty path")
            elif source in seen_asset_sources:
                _issue(issues, "ASSET_SOURCE_DUPLICATE", path, "asset catalog path is duplicated")
            else:
                seen_asset_sources.add(source)

    validation = project.get("validation")
    if not isinstance(validation, dict):
        _issue(issues, "PROJECT_TYPE_INVALID", "project.validation", "must be an object")
    else:
        _check_keys(validation, {"build_profile", "ruleset_version"}, "project.validation", issues)
        if validation.get("build_profile") not in {"development", "shipping"}:
            _issue(issues, "PROJECT_BUILD_PROFILE_INVALID", "project.validation.build_profile", "must be development or shipping")
        ruleset = validation.get("ruleset_version")
        if not isinstance(ruleset, int) or not 1 <= ruleset <= 65535:
            _issue(issues, "PROJECT_RULESET_INVALID", "project.validation.ruleset_version", "must be in 1..65535")

    editor = project.get("editor")
    if editor is not None:
        if not isinstance(editor, dict):
            _issue(issues, "PROJECT_TYPE_INVALID", "project.editor", "must be an object")
        else:
            _check_keys(editor, set(), "project.editor", issues, {"scene_flow", "state_graph"})
            scene_flow = editor.get("scene_flow")
            if scene_flow is not None:
                if not isinstance(scene_flow, dict):
                    _issue(issues, "PROJECT_TYPE_INVALID", "project.editor.scene_flow", "must be an object")
                else:
                    _check_keys(
                        scene_flow,
                        set(),
                        "project.editor.scene_flow",
                        issues,
                        {"nodes", "package_entry", "references", "exit_references", "routes"},
                    )
                    nodes = scene_flow.get("nodes")
                    if nodes is not None:
                        if not isinstance(nodes, dict):
                            _issue(issues, "PROJECT_TYPE_INVALID", "project.editor.scene_flow.nodes", "must be an object")
                        elif len(nodes) > 128:
                            _issue(issues, "PROJECT_LIMIT_EXCEEDED", "project.editor.scene_flow.nodes", "contains more than 128 nodes")
                        else:
                            for scene_id, position in nodes.items():
                                path = f"project.editor.scene_flow.nodes[{scene_id}]"
                                _stable_id(scene_id, path, issues)
                                if not isinstance(position, dict):
                                    _issue(issues, "PROJECT_TYPE_INVALID", path, "must be an object")
                                    continue
                                _check_keys(position, {"x", "y"}, path, issues)
                                for axis in ("x", "y"):
                                    value = position.get(axis)
                                    if isinstance(value, bool) or not isinstance(value, (int, float)):
                                        _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.{axis}", "must be a number")
                                    elif not -100000 <= value <= 100000:
                                        _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.{axis}", "outside supported editor layout range")
                    package_entry = scene_flow.get("package_entry")
                    if package_entry is not None:
                        path = "project.editor.scene_flow.package_entry"
                        if not isinstance(package_entry, dict):
                            _issue(issues, "PROJECT_TYPE_INVALID", path, "must be an object")
                        else:
                            _check_keys(package_entry, {"x", "y"}, path, issues)
                            for axis in ("x", "y"):
                                value = package_entry.get(axis)
                                if isinstance(value, bool) or not isinstance(value, (int, float)):
                                    _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.{axis}", "must be a number")
                                elif not -100000 <= value <= 100000:
                                    _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.{axis}", "outside supported editor layout range")
                    references = scene_flow.get("references")
                    if references is not None:
                        if not isinstance(references, dict):
                            _issue(issues, "PROJECT_TYPE_INVALID", "project.editor.scene_flow.references", "must be an object")
                        elif len(references) > SCENE_FLOW_REFERENCE_MAX:
                            _issue(
                                issues,
                                "PROJECT_LIMIT_EXCEEDED",
                                "project.editor.scene_flow.references",
                                f"contains more than {SCENE_FLOW_REFERENCE_MAX} references",
                            )
                        else:
                            for reference_id, reference in references.items():
                                path = f"project.editor.scene_flow.references[{reference_id}]"
                                _stable_id(reference_id, path, issues)
                                if not isinstance(reference, dict):
                                    _issue(issues, "PROJECT_TYPE_INVALID", path, "must be an object")
                                    continue
                                _check_keys(reference, {"target_scene", "x", "y"}, path, issues)
                                _stable_id(reference.get("target_scene"), f"{path}.target_scene", issues)
                                for axis in ("x", "y"):
                                    value = reference.get(axis)
                                    if isinstance(value, bool) or not isinstance(value, (int, float)):
                                        _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.{axis}", "must be a number")
                                    elif not -100000 <= value <= 100000:
                                        _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.{axis}", "outside supported editor layout range")
                    exit_references = scene_flow.get("exit_references")
                    if exit_references is not None:
                        if not isinstance(exit_references, dict):
                            _issue(issues, "PROJECT_TYPE_INVALID", "project.editor.scene_flow.exit_references", "must be an object")
                        else:
                            for scene_id, scene_group in exit_references.items():
                                path = f"project.editor.scene_flow.exit_references[{scene_id}]"
                                _stable_id(scene_id, path, issues)
                                if not isinstance(scene_group, dict):
                                    _issue(issues, "PROJECT_TYPE_INVALID", path, "must be an object")
                                    continue
                                for endpoint_key, reference_id in scene_group.items():
                                    endpoint_path = f"{path}[{endpoint_key}]"
                                    if not isinstance(endpoint_key, str) or not re.fullmatch(r"(?:scene_exit|route):[a-z0-9][a-z0-9_.-]*", endpoint_key):
                                        _issue(
                                            issues,
                                            "PROJECT_VALUE_INVALID",
                                            endpoint_path,
                                            "must identify a scene_exit or route endpoint",
                                        )
                                    _stable_id(reference_id, endpoint_path, issues)
                    scene_routes = scene_flow.get("routes")
                    if scene_routes is not None:
                        if not isinstance(scene_routes, dict):
                            _issue(issues, "PROJECT_TYPE_INVALID", "project.editor.scene_flow.routes", "must be an object")
                        elif len(scene_routes) > 128:
                            _issue(issues, "PROJECT_LIMIT_EXCEEDED", "project.editor.scene_flow.routes", "contains more than 128 scene groups")
                        else:
                            for scene_id, scene_group in scene_routes.items():
                                path = f"project.editor.scene_flow.routes[{scene_id}]"
                                _stable_id(scene_id, path, issues)
                                if not isinstance(scene_group, dict):
                                    _issue(issues, "PROJECT_TYPE_INVALID", path, "must be an object")
                                    continue
                                if len(scene_group) > 128:
                                    _issue(issues, "PROJECT_LIMIT_EXCEEDED", path, "contains more than 128 route layouts")
                                    continue
                                for endpoint_key, layout in scene_group.items():
                                    layout_path = f"{path}[{endpoint_key}]"
                                    if not isinstance(endpoint_key, str) or not re.fullmatch(r"(?:scene_exit|route):[a-z0-9][a-z0-9_.-]*", endpoint_key):
                                        _issue(
                                            issues,
                                            "PROJECT_VALUE_INVALID",
                                            layout_path,
                                            "must identify a scene_exit or route endpoint",
                                        )
                                    if not isinstance(layout, dict):
                                        _issue(issues, "PROJECT_TYPE_INVALID", layout_path, "must be an object")
                                        continue
                                    _check_keys(layout, {"routing_version", "rails"}, layout_path, issues)
                                    if layout.get("routing_version") != SCENE_FLOW_ROUTE_LAYOUT_VERSION:
                                        _issue(
                                            issues,
                                            "PROJECT_VALUE_INVALID",
                                            f"{layout_path}.routing_version",
                                            f"must be {SCENE_FLOW_ROUTE_LAYOUT_VERSION}",
                                        )
                                    rails = layout.get("rails")
                                    if not isinstance(rails, list):
                                        _issue(issues, "PROJECT_TYPE_INVALID", f"{layout_path}.rails", "must be an array")
                                        continue
                                    if len(rails) > STATE_GRAPH_ROUTE_RAIL_MAX:
                                        _issue(
                                            issues,
                                            "PROJECT_LIMIT_EXCEEDED",
                                            f"{layout_path}.rails",
                                            f"contains more than {STATE_GRAPH_ROUTE_RAIL_MAX} rails",
                                        )
                                        continue
                                    previous_axis = None
                                    for index, rail in enumerate(rails):
                                        rail_path = f"{layout_path}.rails[{index}]"
                                        if not isinstance(rail, dict):
                                            _issue(issues, "PROJECT_TYPE_INVALID", rail_path, "must be an object")
                                            continue
                                        _check_keys(rail, {"axis", "value"}, rail_path, issues)
                                        axis = rail.get("axis")
                                        if axis not in {"x", "y"}:
                                            _issue(issues, "PROJECT_VALUE_INVALID", f"{rail_path}.axis", "must be x or y")
                                        elif axis == previous_axis:
                                            _issue(issues, "PROJECT_VALUE_INVALID", f"{rail_path}.axis", "must alternate")
                                        previous_axis = axis
                                        value = rail.get("value")
                                        if isinstance(value, bool) or not isinstance(value, (int, float)):
                                            _issue(issues, "PROJECT_TYPE_INVALID", f"{rail_path}.value", "must be a number")
                                        elif not -100000 <= value <= 100000:
                                            _issue(issues, "PROJECT_TYPE_INVALID", f"{rail_path}.value", "outside supported editor layout range")
            state_graph = editor.get("state_graph")
            if state_graph is not None:
                if not isinstance(state_graph, dict):
                    _issue(issues, "PROJECT_TYPE_INVALID", "project.editor.state_graph", "must be an object")
                else:
                    _check_keys(state_graph, set(), "project.editor.state_graph", issues, {"scenes"})
                    graph_scenes = state_graph.get("scenes")
                    if graph_scenes is not None:
                        if not isinstance(graph_scenes, dict):
                            _issue(issues, "PROJECT_TYPE_INVALID", "project.editor.state_graph.scenes", "must be an object")
                        elif len(graph_scenes) > 128:
                            _issue(issues, "PROJECT_LIMIT_EXCEEDED", "project.editor.state_graph.scenes", "contains more than 128 scenes")
                        else:
                            for scene_id, scene_layout in graph_scenes.items():
                                scene_path = f"project.editor.state_graph.scenes[{scene_id}]"
                                _stable_id(scene_id, scene_path, issues)
                                if not isinstance(scene_layout, dict):
                                    _issue(issues, "PROJECT_TYPE_INVALID", scene_path, "must be an object")
                                    continue
                                _check_keys(scene_layout, set(), scene_path, issues, {"entry", "nodes", "routes", "handlers"})
                                handlers = scene_layout.get("handlers")
                                if handlers is not None:
                                    path = f"{scene_path}.handlers"
                                    if not isinstance(handlers, dict):
                                        _issue(issues, "PROJECT_TYPE_INVALID", path, "must be an object")
                                    elif len(handlers) > STATE_EVENT_BINDING_MAX:
                                        _issue(issues, "PROJECT_LIMIT_EXCEEDED", path, "too many handler layouts")
                                    else:
                                        for handler_id, layout in handlers.items():
                                            handler_path = f"{path}[{handler_id}]"
                                            _stable_id(handler_id, handler_path, issues)
                                            try:
                                                _normalize_handler_layout(layout)
                                            except ProjectCommandError as exc:
                                                _issue(issues, exc.code, handler_path, exc.message)
                                entry_layout = scene_layout.get("entry")
                                if entry_layout is not None:
                                    entry_path = f"{scene_path}.entry"
                                    if not isinstance(entry_layout, dict):
                                        _issue(issues, "PROJECT_TYPE_INVALID", entry_path, "must be an object")
                                    else:
                                        _check_keys(entry_layout, {"target_handle", "target_side"}, entry_path, issues)
                                        target_handle = entry_layout.get("target_handle")
                                        target_side = entry_layout.get("target_side")
                                        if target_handle not in STATE_GRAPH_ENTRY_HANDLES:
                                            _issue(
                                                issues,
                                                "PROJECT_VALUE_INVALID",
                                                f"{entry_path}.target_handle",
                                                "must name a state entry socket",
                                            )
                                        if target_side not in STATE_GRAPH_ENTRY_SIDES:
                                            _issue(
                                                issues,
                                                "PROJECT_VALUE_INVALID",
                                                f"{entry_path}.target_side",
                                                "must name a card side",
                                            )
                                        elif target_handle in STATE_GRAPH_ENTRY_HANDLE_SIDES and target_side not in STATE_GRAPH_ENTRY_HANDLE_SIDES[target_handle]:
                                            _issue(
                                                issues,
                                                "PROJECT_VALUE_INVALID",
                                                f"{entry_path}.target_side",
                                                "is not available on the selected corner entry",
                                            )
                                nodes = scene_layout.get("nodes")
                                if nodes is not None:
                                    if not isinstance(nodes, dict):
                                        _issue(issues, "PROJECT_TYPE_INVALID", f"{scene_path}.nodes", "must be an object")
                                    elif len(nodes) > 128:
                                        _issue(issues, "PROJECT_LIMIT_EXCEEDED", f"{scene_path}.nodes", "contains more than 128 nodes")
                                    else:
                                        for state_id, position in nodes.items():
                                            path = f"{scene_path}.nodes[{state_id}]"
                                            _editor_node_id(state_id, path, issues)
                                            if not isinstance(position, dict):
                                                _issue(issues, "PROJECT_TYPE_INVALID", path, "must be an object")
                                                continue
                                            _check_keys(position, {"x", "y"}, path, issues)
                                            for axis in ("x", "y"):
                                                value = position.get(axis)
                                                if isinstance(value, bool) or not isinstance(value, (int, float)):
                                                    _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.{axis}", "must be a number")
                                                elif not -100000 <= value <= 100000:
                                                    _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.{axis}", "outside supported editor layout range")
                                routes = scene_layout.get("routes")
                                if routes is not None:
                                    if not isinstance(routes, dict):
                                        _issue(issues, "PROJECT_TYPE_INVALID", f"{scene_path}.routes", "must be an object")
                                    elif len(routes) > 128:
                                        _issue(issues, "PROJECT_LIMIT_EXCEEDED", f"{scene_path}.routes", "contains more than 128 routes")
                                    else:
                                        for route_id, route_layout in routes.items():
                                            route_path = f"{scene_path}.routes[{route_id}]"
                                            _stable_id(route_id, route_path, issues)
                                            if not isinstance(route_layout, dict):
                                                _issue(issues, "PROJECT_TYPE_INVALID", route_path, "must be an object")
                                                continue
                                            _check_keys(route_layout, {"sources"}, route_path, issues)
                                            sources = route_layout.get("sources")
                                            if not isinstance(sources, dict):
                                                _issue(issues, "PROJECT_TYPE_INVALID", f"{route_path}.sources", "must be an object")
                                                continue
                                            if len(sources) > 64:
                                                _issue(
                                                    issues,
                                                    "PROJECT_LIMIT_EXCEEDED",
                                                    f"{route_path}.sources",
                                                    "contains more than 64 source states",
                                                )
                                                continue
                                            for source_state, source_layout in sources.items():
                                                source_path = f"{route_path}.sources[{source_state}]"
                                                _stable_id(source_state, source_path, issues)
                                                if not isinstance(source_layout, dict):
                                                    _issue(issues, "PROJECT_TYPE_INVALID", source_path, "must be an object")
                                                    continue
                                                routing_version = source_layout.get("routing_version")
                                                if routing_version == STATE_GRAPH_ROUTE_LAYOUT_VERSION:
                                                    _check_keys(
                                                        source_layout,
                                                        {"rails"},
                                                        source_path,
                                                        issues,
                                                        {"rails", "routing_version", "target_handle", "target_side", "token_positions"},
                                                    )
                                                    target_handle = source_layout.get("target_handle")
                                                    if target_handle is not None and target_handle not in STATE_GRAPH_ENTRY_HANDLES:
                                                        _issue(
                                                            issues,
                                                            "PROJECT_VALUE_INVALID",
                                                            f"{source_path}.target_handle",
                                                            "must name a state entry socket",
                                                        )
                                                    target_side = source_layout.get("target_side")
                                                    if target_side is not None and target_side not in STATE_GRAPH_ENTRY_SIDES:
                                                        _issue(
                                                            issues,
                                                            "PROJECT_VALUE_INVALID",
                                                            f"{source_path}.target_side",
                                                            "must name a card side",
                                                        )
                                                    elif target_side is not None and target_handle is None:
                                                        _issue(
                                                            issues,
                                                            "PROJECT_VALUE_INVALID",
                                                            f"{source_path}.target_side",
                                                            "requires target_handle",
                                                        )
                                                    elif target_handle in STATE_GRAPH_ENTRY_HANDLE_SIDES and target_side is not None and target_side not in STATE_GRAPH_ENTRY_HANDLE_SIDES[target_handle]:
                                                        _issue(
                                                            issues,
                                                            "PROJECT_VALUE_INVALID",
                                                            f"{source_path}.target_side",
                                                            "is not available on the selected corner entry",
                                                        )
                                                    token_positions = source_layout.get("token_positions")
                                                    if token_positions is not None:
                                                        _validate_route_token_positions(
                                                            token_positions,
                                                            f"{source_path}.token_positions",
                                                            issues,
                                                        )
                                                    rails = source_layout.get("rails")
                                                    if not isinstance(rails, list):
                                                        _issue(issues, "PROJECT_TYPE_INVALID", f"{source_path}.rails", "must be an array")
                                                        continue
                                                    if len(rails) > STATE_GRAPH_ROUTE_RAIL_MAX:
                                                        _issue(
                                                            issues,
                                                            "PROJECT_LIMIT_EXCEEDED",
                                                            f"{source_path}.rails",
                                                            f"contains more than {STATE_GRAPH_ROUTE_RAIL_MAX} rails",
                                                        )
                                                        continue
                                                    previous_axis = None
                                                    for index, rail in enumerate(rails):
                                                        rail_path = f"{source_path}.rails[{index}]"
                                                        if not isinstance(rail, dict):
                                                            _issue(issues, "PROJECT_TYPE_INVALID", rail_path, "must be an object")
                                                            continue
                                                        _check_keys(rail, {"axis", "value"}, rail_path, issues)
                                                        axis = rail.get("axis")
                                                        if axis not in {"x", "y"}:
                                                            _issue(issues, "PROJECT_VALUE_INVALID", f"{rail_path}.axis", "must be x or y")
                                                        elif axis == previous_axis:
                                                            _issue(issues, "PROJECT_VALUE_INVALID", f"{rail_path}.axis", "must alternate")
                                                        previous_axis = axis
                                                        value = rail.get("value")
                                                        if isinstance(value, bool) or not isinstance(value, (int, float)):
                                                            _issue(issues, "PROJECT_TYPE_INVALID", f"{rail_path}.value", "must be a number")
                                                        elif not -100000 <= value <= 100000:
                                                            _issue(issues, "PROJECT_TYPE_INVALID", f"{rail_path}.value", "outside supported editor layout range")
                                                else:
                                                    _check_keys(
                                                        source_layout,
                                                        {"waypoints"},
                                                        source_path,
                                                        issues,
                                                        {"waypoints", "routing_version"},
                                                    )
                                                    if routing_version not in {None, 2}:
                                                        _issue(
                                                            issues,
                                                            "PROJECT_VALUE_INVALID",
                                                            f"{source_path}.routing_version",
                                                            "must be 2 or 3",
                                                        )
                                                    waypoints = source_layout.get("waypoints")
                                                    if not isinstance(waypoints, list):
                                                        _issue(issues, "PROJECT_TYPE_INVALID", f"{source_path}.waypoints", "must be an array")
                                                        continue
                                                    if len(waypoints) > STATE_GRAPH_ROUTE_RAIL_MAX:
                                                        _issue(
                                                            issues,
                                                            "PROJECT_LIMIT_EXCEEDED",
                                                            f"{source_path}.waypoints",
                                                            f"contains more than {STATE_GRAPH_ROUTE_RAIL_MAX} points",
                                                        )
                                                        continue
                                                    for index, point in enumerate(waypoints):
                                                        point_path = f"{source_path}.waypoints[{index}]"
                                                        if not isinstance(point, dict):
                                                            _issue(issues, "PROJECT_TYPE_INVALID", point_path, "must be an object")
                                                            continue
                                                        _check_keys(point, {"x", "y"}, point_path, issues)
                                                        for axis in ("x", "y"):
                                                            value = point.get(axis)
                                                            if isinstance(value, bool) or not isinstance(value, (int, float)):
                                                                _issue(issues, "PROJECT_TYPE_INVALID", f"{point_path}.{axis}", "must be a number")
                                                            elif not -100000 <= value <= 100000:
                                                                _issue(issues, "PROJECT_TYPE_INVALID", f"{point_path}.{axis}", "outside supported editor layout range")


def _check_asset(
    asset: dict[str, Any],
    path: str,
    root: Path,
    issues: list[ValidationIssue],
) -> tuple[Masked1bppFrame, ...]:
    initial_issue_count = len(issues)
    source_format = asset.get("source_format")
    if source_format == "png":
        required = {"asset_id", "asset_type", "source_path", "source_format", "frames"}
    elif source_format == "system_font_text":
        required = {"asset_id", "asset_type", "source_format", "font_id", "text", "scale", "frames"}
    else:
        required = {"asset_id", "asset_type", "source_format", "frames"}
    _check_keys(asset, required, path, issues, required | {"display_name", "tags"})
    if "tags" in asset:
        _check_asset_tags(asset["tags"], f"{path}.tags", issues)
    _stable_id(asset.get("asset_id"), f"{path}.asset_id", issues)
    if asset.get("asset_type") != "masked_1bpp":
        _issue(issues, "ASSET_FORMAT_UNSUPPORTED", f"{path}.asset_type", "must be masked_1bpp")
    if source_format not in {"png", "system_font_text"}:
        _issue(issues, "ASSET_FORMAT_UNSUPPORTED", f"{path}.source_format", "must be png or system_font_text")
    if source_format == "png" and (not isinstance(asset.get("source_path"), str) or not asset.get("source_path")):
        _issue(issues, "ASSET_SOURCE_INVALID", f"{path}.source_path", "must be a non-empty relative path")
    if "display_name" in asset:
        _text(asset.get("display_name"), f"{path}.display_name", issues, 64)

    from .asset_library import MAX_SOURCE_FRAMES
    frame_records = _unique_ids(asset.get("frames"), "frame_id", f"{path}.frames", issues, MAX_SOURCE_FRAMES)
    if not frame_records:
        _issue(issues, "ASSET_FRAME_MISSING", f"{path}.frames", "must contain at least one frame")
    for frame_id, frame in frame_records.items():
        frame_path = f"{path}.frames[{frame_id}]"
        frame_keys = {"frame_id", "source_rect", "pivot_x", "pivot_y"} if source_format == "png" else {"frame_id", "pivot_x", "pivot_y"}
        _check_keys(frame, frame_keys, frame_path, issues, frame_keys | {"display_name"})
        if "display_name" in frame:
            _text(frame.get("display_name"), f"{frame_path}.display_name", issues, 64)

    if len(issues) == initial_issue_count and frame_records:
        try:
            compiled = (
                import_masked_1bpp(root, asset)
                if source_format == "png"
                else (rasterize_system_font_text(asset),)
            )
        except (ImageAssetError, SystemFontError, KeyError) as exc:
            _issue(issues, "ASSET_SOURCE_INVALID", path, str(exc))
        else:
            return compiled
    return ()


def _check_animation(animation: dict[str, Any], path: str, issues: list[ValidationIssue]) -> None:
    _check_keys(
        animation,
        {"animation_id", "frame_refs", "frame_duration_ms", "loop_policy"},
        path,
        issues,
        {"animation_id", "display_name", "frame_refs", "frame_duration_ms", "loop_policy"},
    )
    _stable_id(animation.get("animation_id"), f"{path}.animation_id", issues)
    if "display_name" in animation:
        _text(animation.get("display_name"), f"{path}.display_name", issues, 64)
    frame_refs = animation.get("frame_refs")
    durations = animation.get("frame_duration_ms")
    if not isinstance(frame_refs, list) or not 1 <= len(frame_refs) <= 256:
        _issue(issues, "ANIMATION_FRAME_COUNT_INVALID", f"{path}.frame_refs", "must contain 1..256 frame IDs")
    else:
        for index, frame_ref in enumerate(frame_refs):
            _stable_id(frame_ref, f"{path}.frame_refs[{index}]", issues)
    if not isinstance(durations, list) or not isinstance(frame_refs, list) or len(durations) != len(frame_refs):
        _issue(issues, "ANIMATION_DURATION_INVALID", f"{path}.frame_duration_ms", "must match frame_refs")
    else:
        for index, duration in enumerate(durations):
            if isinstance(duration, bool) or not isinstance(duration, int) or not 1 <= duration <= 60000:
                _issue(issues, "ANIMATION_DURATION_INVALID", f"{path}.frame_duration_ms[{index}]", "must be in 1..60000 ms")
    if animation.get("loop_policy") not in {"loop", "once", "hold_last", "ping_pong"}:
        _issue(issues, "ANIMATION_LOOP_INVALID", f"{path}.loop_policy", "unsupported loop policy")


def _check_variable(record: dict[str, Any], path: str, issues: list[ValidationIssue]) -> None:
    _check_keys(record, {"variable_id", "value_type", "initial", "minimum", "maximum"}, path, issues)
    if record.get("value_type") != "int32":
        _issue(issues, "VARIABLE_TYPE_INVALID", f"{path}.value_type", "V1 supports int32 only")
    values = (record.get("minimum"), record.get("initial"), record.get("maximum"))
    if any(isinstance(value, bool) or not isinstance(value, int) for value in values):
        _issue(issues, "VARIABLE_RANGE_INVALID", path, "minimum, initial, and maximum must be integers")
    elif not values[0] <= values[1] <= values[2]:
        _issue(issues, "VARIABLE_RANGE_INVALID", path, "must satisfy minimum <= initial <= maximum")


def _check_waiting_visual(
    record: dict[str, Any],
    path: str,
    element_kinds: dict[str, str],
    frame_ids: set[str],
    issues: list[ValidationIssue],
) -> None:
    required = {
        "waiting_visual_id",
        "presentation_id",
        "phase_quantum_ms",
        "combined_step_count",
        "settled_step",
        "cycle_policy",
        "elements",
    }
    _check_keys(record, required, path, issues)
    _stable_id(record.get("presentation_id"), f"{path}.presentation_id", issues)
    step_count = record.get("combined_step_count")
    settled_step = record.get("settled_step")
    quantum = record.get("phase_quantum_ms")
    if not isinstance(step_count, int) or not 1 <= step_count <= 12:
        _issue(issues, "WAIT_STEP_COUNT_INVALID", f"{path}.combined_step_count", "must be in 1..12")
        step_count = None
    if not isinstance(settled_step, int) or step_count is None or not 0 <= settled_step < step_count:
        _issue(issues, "WAIT_SETTLED_STEP_INVALID", f"{path}.settled_step", "must select a combined step")
    if not isinstance(quantum, int) or not 1 <= quantum <= 60000:
        _issue(issues, "WAIT_QUANTUM_INVALID", f"{path}.phase_quantum_ms", "must be in 1..60000 ms")
    if record.get("cycle_policy") != "loop":
        _issue(issues, "WAIT_CYCLE_INVALID", f"{path}.cycle_policy", "V1 supports loop only")
    waiting_elements = _unique_ids(record.get("elements"), "element_id", f"{path}.elements", issues, 32)
    for element_id, element in waiting_elements.items():
        item_path = f"{path}.elements[{element_id}]"
        required_element = {"element_id", "source_element_ref", "phase_visual_refs", "step_phase_indices"}
        _check_keys(element, required_element, item_path, issues)
        source_ref = element.get("source_element_ref")
        if source_ref not in element_kinds:
            _issue(issues, "WAIT_ELEMENT_UNKNOWN", f"{item_path}.source_element_ref", f"unknown render element '{source_ref}'")
        elif element_kinds[source_ref] != "sprite":
            _issue(issues, "WAIT_ELEMENT_TYPE_INVALID", f"{item_path}.source_element_ref", "waiting animation currently requires a sprite element")
        phase_refs = element.get("phase_visual_refs")
        if not isinstance(phase_refs, list) or not 1 <= len(phase_refs) <= 4:
            _issue(issues, "WAIT_PHASE_COUNT_INVALID", f"{item_path}.phase_visual_refs", "must contain 1..4 phases")
            phase_count = None
        else:
            phase_count = len(phase_refs)
            for index, phase_ref in enumerate(phase_refs):
                _stable_id(phase_ref, f"{item_path}.phase_visual_refs[{index}]", issues)
                if element_kinds.get(source_ref) == "sprite" and phase_ref not in frame_ids:
                    _issue(
                        issues,
                        "ASSET_FRAME_UNKNOWN",
                        f"{item_path}.phase_visual_refs[{index}]",
                        f"unknown frame '{phase_ref}'",
                    )
        indices = element.get("step_phase_indices")
        if not isinstance(indices, list) or step_count is None or len(indices) != step_count:
            _issue(issues, "WAIT_SEQUENCE_LENGTH_INVALID", f"{item_path}.step_phase_indices", "must match combined_step_count")
        elif phase_count is not None:
            for index, phase_index in enumerate(indices):
                if not isinstance(phase_index, int) or not 0 <= phase_index < phase_count:
                    _issue(issues, "WAIT_PHASE_INDEX_INVALID", f"{item_path}.step_phase_indices[{index}]", "does not select an authored phase")


def _check_state_placement_overrides(
    state: dict[str, Any],
    path: str,
    elements: dict[str, dict[str, Any]],
    frame_lookup: dict[str, Masked1bppFrame],
    issues: list[ValidationIssue],
) -> None:
    overrides = state.get("placement_overrides", [])
    if not isinstance(overrides, list):
        _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.placement_overrides", "must be an array")
        return
    if len(overrides) > 32:
        _issue(issues, "PROJECT_COUNT_INVALID", f"{path}.placement_overrides", "must contain at most 32 overrides")
    seen: set[str] = set()
    for index, override in enumerate(overrides):
        item_path = f"{path}.placement_overrides[{index}]"
        if not isinstance(override, dict):
            _issue(issues, "PROJECT_TYPE_INVALID", item_path, "must be an object")
            continue
        _check_keys(override, {"element_ref"}, item_path, issues, {"element_ref", "x", "y", "visible", "visual_ref"})
        element_ref = override.get("element_ref")
        _stable_id(element_ref, f"{item_path}.element_ref", issues)
        if isinstance(element_ref, str):
            if element_ref in seen:
                _issue(issues, "PROJECT_ID_DUPLICATE", f"{item_path}.element_ref", f"duplicate override for '{element_ref}'")
            seen.add(element_ref)
        element = elements.get(element_ref) if isinstance(element_ref, str) else None
        if element is None:
            _issue(issues, "RENDER_ELEMENT_UNKNOWN", f"{item_path}.element_ref", "state override must target a scene object")
            continue
        has_x = "x" in override
        has_y = "y" in override
        if has_x != has_y:
            _issue(issues, "RENDER_BOUNDS_INVALID", item_path, "position overrides must include both x and y")
        elif has_x and has_y:
            x = override.get("x")
            y = override.get("y")
            width = element.get("width")
            height = element.get("height")
            if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in (x, y)):
                _issue(issues, "RENDER_BOUNDS_INVALID", item_path, "override x and y must be non-negative integers")
            elif all(isinstance(value, int) for value in (width, height)) and (x + width > 168 or y + height > 144):
                _issue(issues, "RENDER_BOUNDS_INVALID", item_path, "override position places the object outside the 168x144 canvas")
        if "visible" in override and not isinstance(override.get("visible"), bool):
            _issue(issues, "RENDER_VISIBILITY_INVALID", f"{item_path}.visible", "must be boolean")
        if "visual_ref" in override:
            visual_ref = override.get("visual_ref")
            _stable_id(visual_ref, f"{item_path}.visual_ref", issues)
            if element.get("kind") != "sprite":
                _issue(issues, "RENDER_VISUAL_REF_INVALID", f"{item_path}.visual_ref", "only sprites can override visual_ref")
            elif isinstance(visual_ref, str):
                frame = frame_lookup.get(visual_ref)
                if frame is None:
                    _issue(issues, "ASSET_FRAME_UNKNOWN", f"{item_path}.visual_ref", f"unknown frame '{visual_ref}'")
                elif frame.width != element.get("width") or frame.height != element.get("height"):
                    _issue(issues, "RENDER_VISUAL_REF_INVALID", f"{item_path}.visual_ref", "override frame must match the placed sprite size")


def _check_scene(
    scene: dict[str, Any],
    source: str,
    frame_lookup: dict[str, Masked1bppFrame],
    animation_ids: set[str],
    audio_cue_ids: set[str],
    issues: list[ValidationIssue],
    animations: dict[str, dict[str, Any]] | None = None,
    *,
    allow_handler_scene_exits: bool = False,
    allow_calendar: bool = False,
    variable_project: dict[str, Any] | None = None,
    _machine_projection: bool = False,
) -> None:
    from .authoring_foundation import enabled, check_scene
    if variable_project is not None and enabled(variable_project):
        check_scene(scene, f"scenes[{scene.get('scene_id', source)}]", issues)
        return
    if variable_project is not None:
        from .scoped_variables import project_scene
        from .scene_entry import validate as validate_entry
        from .scene_machines import validate as validate_machines, project_scene as machine_scene
        try:
            validate_machines(variable_project, scene)
            from .menu_component import validate as validate_menu
            validate_menu(variable_project, scene, audio_cue_ids)
            from .inventory_source import validate_scene as validate_inventory
            validate_inventory(variable_project, scene)
            from .flowcharts import validate_visuals
            validate_visuals(scene, frame_lookup, animations or {})
            _machine_projection = "machine_logic" in scene
            scene = machine_scene(scene)
            validate_entry(variable_project, scene, audio_cue_ids)
            scene, _ = project_scene(variable_project, scene)
        except ProjectCommandError as exc:
            _issue(issues, exc.code, f"scene[{source}]", exc.message)
            return
    if scene.get("schema_version") == 2:
        from .scene_object_authoring import check_object_scene
        check_object_scene(scene, source, frame_lookup, animations or {}, audio_cue_ids, issues,
                           _machine_projection=_machine_projection)
        return
    binding_limit = STATE_EVENT_BINDING_MAX
    if _machine_projection:
        from .scene_machines import CAPABILITY
        binding_limit = CAPABILITY["maximum_lowered_bindings"]
    base = f"scene[{source}]"
    frame_ids = set(frame_lookup)
    _check_keys(scene, SCENE_KEYS, base, issues, SCENE_KEYS | SCENE_OPTIONAL_KEYS)
    if scene.get("schema_id") != "peepshow.authoring.state_scene" or scene.get("schema_version") != 1:
        _issue(issues, "SCENE_SCHEMA_UNSUPPORTED", base, "expected peepshow.authoring.state_scene version 1")
    _stable_id(scene.get("scene_id"), f"{base}.scene_id", issues)
    _text(scene.get("display_name"), f"{base}.display_name", issues)
    if scene.get("scene_type") != "STATE_SCENE":
        _issue(issues, "SCENE_TYPE_INVALID", f"{base}.scene_type", "the first authoring subset supports STATE_SCENE only")

    variables = _unique_ids(scene.get("variables"), "variable_id", f"{base}.variables", issues, 32)
    for variable_id, variable in variables.items():
        _check_variable(variable, f"{base}.variables[{variable_id}]", issues)

    input_actions = _unique_ids(scene.get("input_actions"), "action_id", f"{base}.input_actions", issues, 32)
    logical_bindings: set[tuple[str, str]] = set()
    for action_id, action in input_actions.items():
        path = f"{base}.input_actions[{action_id}]"
        _check_keys(
            action,
            {"action_id", "logical_source"},
            path,
            issues,
            {"action_id", "logical_source", "event_kind"},
        )
        source_value = action.get("logical_source")
        event_kind = action.get("event_kind", "press")
        if source_value not in LOGICAL_INPUT_SOURCES:
            _issue(issues, "INPUT_SOURCE_INVALID", f"{path}.logical_source", "unsupported logical source")
        if event_kind not in LOGICAL_INPUT_EVENT_KINDS:
            _issue(issues, "INPUT_EVENT_INVALID", f"{path}.event_kind", "must be press, release, hold, or repeat")
        elif source_value == "BUTTON_START" and event_kind != "press":
            _issue(issues, "INPUT_EVENT_SYSTEM_OWNED", f"{path}.event_kind", "START supports package press only")
        binding = (str(source_value), str(event_kind))
        if binding in logical_bindings:
            _issue(issues, "INPUT_BINDING_DUPLICATE", path, "logical source and event kind are already bound")
        else:
            logical_bindings.add(binding)

    event_bindings = _unique_ids(
        scene.get("event_bindings", []),
        "binding_id",
        f"{base}.event_bindings",
        issues,
        binding_limit,
    )
    duplicate_binding_ids = set(input_actions) & set(event_bindings)
    for binding_id in sorted(duplicate_binding_ids):
        _issue(
            issues,
            "PROJECT_ID_DUPLICATE",
            f"{base}.event_bindings[{binding_id}].binding_id",
            "binding ID is already used by an input action",
        )
    if len(input_actions) + len(event_bindings) > binding_limit:
        _issue(
            issues,
            "EVENT_BINDING_LIMIT_EXCEEDED",
            f"{base}.event_bindings",
            f"validation supports at most {binding_limit} compiled event bindings",
        )
    for binding_id, binding in event_bindings.items():
        path = f"{base}.event_bindings[{binding_id}]"
        _check_keys(
            binding,
            {"binding_id", "event_type", "configuration"},
            path,
            issues,
        )
        if binding.get("event_type") not in {"time.state_entry_elapsed", "time.scene_elapsed", "time.local_schedule"}:
            _issue(
                issues,
                "EVENT_TYPE_UNAVAILABLE",
                f"{path}.event_type",
                "target exposes state-entry and scene elapsed timers",
            )
        configuration = binding.get("configuration")
        if not isinstance(configuration, dict):
            _issue(
                issues,
                "EVENT_CONFIGURATION_INVALID",
                f"{path}.configuration",
                "must be an object",
            )
            continue
        if binding.get("event_type") == "time.local_schedule":
            if not allow_calendar:
                _issue(issues, "CALENDAR_V2_REQUIRED", path, "calendar schedules require V2 scene objects")
            _check_keys(configuration, {"mode", "time_of_day_seconds"},
                        f"{path}.configuration", issues,
                        {"mode", "time_of_day_seconds", "day_offset", "weekday", "weekdays"})
            from .calendar_schedule import valid_configuration
            if not valid_configuration(configuration, expanded=_machine_projection):
                _issue(issues, "CALENDAR_CONFIGURATION_INVALID", f"{path}.configuration",
                       "requires a supported calendar mode and valid local time/day selection; weekday modes require scene machines")
            continue
        allowed_config = {"delay_ms"}
        if _machine_projection:
            allowed_config.add('mode')
            allowed_config.add('delay_max_ms')
            if 'delay_max_ms' in configuration:
                maximum = configuration['delay_max_ms']
                minimum = configuration.get('delay_ms')
                if (type(maximum) is not int or type(minimum) is not int or
                        not STATE_TIMER_MIN_MS <= minimum <= maximum <= STATE_TIMER_MAX_MS or
                        configuration.get('mode', 'one_shot') != 'one_shot'):
                    _issue(issues, 'EVENT_TIMER_RANDOM_BOUNDS_INVALID', f'{path}.configuration',
                           'random delay requires one_shot and integer delay_ms <= delay_max_ms within timer bounds')
            if configuration.get('mode', 'one_shot') not in ('one_shot', 'periodic'):
                _issue(issues, 'EVENT_TIMER_MODE_INVALID', f'{path}.configuration.mode',
                       'must be one_shot or periodic')
        if binding.get("event_type") == "time.scene_elapsed":
            allowed_config.add("start_policy")
            if configuration.get("start_policy", "scene_entry") not in {"scene_entry", "action"}:
                _issue(issues, "EVENT_TIMER_START_INVALID", f"{path}.configuration.start_policy",
                       "must be scene_entry or action")
        _check_keys(configuration, {"delay_ms"}, f"{path}.configuration", issues, allowed_config)
        delay_ms = configuration.get("delay_ms")
        if (
            isinstance(delay_ms, bool)
            or not isinstance(delay_ms, int)
            or not STATE_TIMER_MIN_MS <= delay_ms <= STATE_TIMER_MAX_MS
        ):
            _issue(
                issues,
                "EVENT_TIMER_DELAY_INVALID",
                f"{path}.configuration.delay_ms",
                f"must be an integer in {STATE_TIMER_MIN_MS}..{STATE_TIMER_MAX_MS}",
            )

    all_event_bindings = set(input_actions) | set(event_bindings)
    calendar_bindings = {key for key, value in event_bindings.items()
                         if value.get("event_type") == "time.local_schedule"}
    from .machine_limits import TIMERS
    if len(calendar_bindings) > (TIMERS if _machine_projection else 1):
        _issue(issues, "CALENDAR_BINDING_LIMIT", f"{base}.event_bindings",
               "calendar schedule capacity exceeded")

    joystick_policy = scene.get("joystick_policy", "four_way")
    if joystick_policy not in JOYSTICK_POLICIES:
        _issue(issues, "JOYSTICK_POLICY_INVALID", f"{base}.joystick_policy", "must be four_way or eight_way")
    diagonal_sources = {
        "JOY_UP_LEFT", "JOY_UP_RIGHT", "JOY_DOWN_LEFT", "JOY_DOWN_RIGHT"
    }
    if joystick_policy != "eight_way" and any(
        action.get("logical_source") in diagonal_sources
        for action in input_actions.values()
    ):
        _issue(issues, "JOYSTICK_POLICY_REQUIRED", f"{base}.joystick_policy", "diagonal bindings require eight_way")

    states = _unique_ids(scene.get("states"), "state_id", f"{base}.states", issues, 64)
    scene_exits = _unique_ids(
        scene.get("scene_exits", []),
        "scene_exit_id",
        f"{base}.scene_exits",
        issues,
        32,
    )
    for scene_exit_id, scene_exit in scene_exits.items():
        path = f"{base}.scene_exits[{scene_exit_id}]"
        _check_keys(
            scene_exit,
            {"scene_exit_id", "display_name", "target_scene"},
            path,
            issues,
        )
        _text(scene_exit.get("display_name"), f"{path}.display_name", issues)
        _stable_id(scene_exit.get("target_scene"), f"{path}.target_scene", issues)
        if scene_exit.get("target_scene") == scene.get("scene_id") and not _machine_projection:
            _issue(
                issues,
                "SCENE_TRANSITION_TARGET_INVALID",
                f"{path}.target_scene",
                "scene exits must target another scene",
            )
    render_models = _unique_ids(scene.get("render_models"), "visual_id", f"{base}.render_models", issues, 64)
    waiting_visuals = _unique_ids(scene.get("waiting_visuals"), "waiting_visual_id", f"{base}.waiting_visuals", issues, 32)
    routes = _unique_ids(scene.get("routes"), "route_id", f"{base}.routes", issues, 128)
    handlers = _unique_ids(scene.get("event_handlers", []), "handler_id", f"{base}.event_handlers", issues,
                           binding_limit if _machine_projection else 16)
    scene_timers = {key for key, value in event_bindings.items()
                    if value.get("event_type") == "time.scene_elapsed"}
    for binding_id in scene_timers | calendar_bindings:
        if sum(handler.get("event_ref") == binding_id for handler in handlers.values()) != 1:
            _issue(issues, "EVENT_HANDLER_REQUIRED", f"{base}.event_handlers",
                   f"scene timer '{binding_id}' requires exactly one independent handler")
    if set(routes) & set(handlers):
        _issue(issues, "EVENT_HANDLER_ID_DUPLICATE", f"{base}.event_handlers",
               "handler IDs must not duplicate route IDs")
    if len(render_models) != 1:
        _issue(issues, "SCENE_PLACEMENT_INVALID", f"{base}.render_models", "STATE_SCENE must declare exactly one placement render model")

    entry_state = scene.get("entry_state")
    if entry_state not in states:
        _issue(issues, "GRAPH_ENTRY_MISSING", f"{base}.entry_state", f"unknown entry state '{entry_state}'")

    element_kinds: dict[str, str] = {}
    placement_elements: dict[str, dict[str, Any]] = {}
    for visual_id, render_model in render_models.items():
        path = f"{base}.render_models[{visual_id}]"
        _check_keys(render_model, {"visual_id", "focus_index", "elements"}, path, issues)
        focus_index = render_model.get("focus_index")
        if not isinstance(focus_index, int) or not 0 <= focus_index <= 255:
            _issue(issues, "RENDER_FOCUS_INVALID", f"{path}.focus_index", "must be in 0..255")
        elements = _unique_ids(render_model.get("elements"), "element_id", f"{path}.elements", issues, 64)
        for element_id, element in elements.items():
            item_path = f"{path}.elements[{element_id}]"
            required = {"element_id", "kind", "x", "y", "width", "height", "z_order"}
            allowed = required | {"visual_ref", "focus_role", "layer", "visible", "line_direction"}
            for key in sorted(required - element.keys()):
                _issue(issues, "PROJECT_FIELD_MISSING", f"{item_path}.{key}", "required field is missing")
            for key in sorted(element.keys() - allowed):
                _issue(issues, "PROJECT_FIELD_UNKNOWN", f"{item_path}.{key}", "field is not part of the V1 subset")
            kind = element.get("kind")
            if kind not in {"sprite", "line", "outline_rect", "filled_rect", "circle", "ellipse", "filled_circle", "filled_ellipse"}:
                _issue(issues, "RENDER_KIND_INVALID", f"{item_path}.kind", "unsupported retained element type")
            else:
                element_kinds[element_id] = kind
                placement_elements[element_id] = element
                if kind == "sprite":
                    _stable_id(element.get("visual_ref"), f"{item_path}.visual_ref", issues)
                    if element.get("visual_ref") not in frame_ids:
                        _issue(
                            issues,
                            "ASSET_FRAME_UNKNOWN",
                            f"{item_path}.visual_ref",
                            "STATE sprite visual_ref must select a compiled frame; STOP2 loops use waiting_visual phases",
                        )
                elif "visual_ref" in element:
                    _issue(issues, "RENDER_VISUAL_REF_INVALID", f"{item_path}.visual_ref", "primitives do not reference assets")
                line_direction = element.get("line_direction", "down_right")
                if kind == "line":
                    if not isinstance(line_direction, str) or line_direction not in {"down_right", "up_right"}:
                        _issue(
                            issues,
                            "RENDER_LINE_DIRECTION_INVALID",
                            f"{item_path}.line_direction",
                            "must be down_right or up_right",
                        )
                elif "line_direction" in element:
                    _issue(
                        issues,
                        "RENDER_LINE_DIRECTION_INVALID",
                        f"{item_path}.line_direction",
                        "is only valid for line elements",
                    )
            layer = element.get(
                "layer",
                "UI" if element.get("focus_role", "none") == "focus" else "SCENE",
            )
            if layer not in {"BACKGROUND", "SCENE", "UI"}:
                _issue(issues, "RENDER_LAYER_INVALID", f"{item_path}.layer", "must be BACKGROUND, SCENE, or UI")
            focus_role = element.get("focus_role", "none")
            if focus_role not in {"none", "focus"}:
                _issue(issues, "RENDER_FOCUS_INVALID", f"{item_path}.focus_role", "must be none or focus")
            elif focus_role == "focus" and (kind != "sprite" or layer != "UI" or element.get("visible", True) is not True):
                _issue(issues, "RENDER_FOCUS_INVALID", f"{item_path}.focus_role", "focus must be a visible UI sprite")
            if not isinstance(element.get("visible", True), bool):
                _issue(issues, "RENDER_VISIBILITY_INVALID", f"{item_path}.visible", "must be boolean")
            for field in ("x", "y", "z_order"):
                value = element.get(field)
                if not isinstance(value, int) or value < 0:
                    _issue(issues, "RENDER_BOUNDS_INVALID", f"{item_path}.{field}", "must be a non-negative integer")
            for field in ("width", "height"):
                value = element.get(field)
                if not isinstance(value, int) or value < 1:
                    _issue(issues, "RENDER_BOUNDS_INVALID", f"{item_path}.{field}", "must be a positive integer")
            z_order = element.get("z_order")
            if isinstance(z_order, int) and z_order > 255:
                _issue(issues, "RENDER_BOUNDS_INVALID", f"{item_path}.z_order", "must be in 0..255")
            x = element.get("x")
            y = element.get("y")
            width = element.get("width")
            height = element.get("height")
            if all(isinstance(value, int) and not isinstance(value, bool) for value in (x, y, width, height)):
                if x + width > 168 or y + height > 144:
                    _issue(issues, "RENDER_BOUNDS_INVALID", item_path, "element exceeds the 168x144 canvas")
                if kind in {"circle", "ellipse", "filled_circle", "filled_ellipse"} and (width < 3 or height < 3 or width % 2 == 0 or height % 2 == 0):
                    _issue(issues, "RENDER_GEOMETRY_INVALID", item_path, "circle and ellipse bounds must be odd and at least 3")
                if kind in {"circle", "filled_circle"} and width != height:
                    _issue(issues, "RENDER_GEOMETRY_INVALID", item_path, "circle bounds must be square")

    for waiting_id, waiting in waiting_visuals.items():
        _check_waiting_visual(
            waiting,
            f"{base}.waiting_visuals[{waiting_id}]",
            element_kinds,
            frame_ids,
            issues,
        )

    for state_id, state in states.items():
        path = f"{base}.states[{state_id}]"
        _check_keys(
            state,
            {"state_id", "display_name", "waiting_visual_ref"},
            path,
            issues,
            {"state_id", "display_name", "waiting_visual_ref", "placement_overrides", "render_model_ref"},
        )
        _text(state.get("display_name"), f"{path}.display_name", issues)
        if "render_model_ref" in state:
            only_render_model = next(iter(render_models), None)
            if state.get("render_model_ref") != only_render_model:
                _issue(
                    issues,
                    "STATE_RENDER_MODEL_INVALID",
                    f"{path}.render_model_ref",
                    "logic states must not select independent screen layouts",
                )
        if state.get("waiting_visual_ref") not in waiting_visuals:
            _issue(issues, "WAIT_VISUAL_UNKNOWN", f"{path}.waiting_visual_ref", "waiting visual does not exist")
        _check_state_placement_overrides(state, path, placement_elements, frame_lookup, issues)

    for route_id, route in [*routes.items(), *handlers.items()]:
        independent = route_id in handlers
        path = f"{base}.{'event_handlers' if independent else 'routes'}[{route_id}]"
        target_elements: dict[str, dict[str, Any]] = {}
        required = ({"handler_id", "event_ref", "guards", "actions"} if independent
                    else {"route_id", "from_states", "guards", "actions"})
        allowed = required | {
            "event_ref",
            "target_state",
            "target_scene",
        }
        if not independent:
            allowed.update({"action_ref", "scene_exit_ref"})
        elif allow_handler_scene_exits:
            allowed.add("scene_exit_ref")
        _check_keys(route, required, path, issues, allowed)
        if independent != (route.get("event_ref") in scene_timers | calendar_bindings):
            _issue(issues, "EVENT_HANDLER_SCOPE_INVALID", path,
                   "scene timers require independent handlers; state/input events require routes")
        has_action_ref = "action_ref" in route
        has_event_ref = "event_ref" in route
        if has_action_ref == has_event_ref:
            _issue(
                issues,
                "ROUTE_EVENT_REF_INVALID",
                path,
                "must declare exactly one of action_ref or event_ref",
            )
        elif has_action_ref and route.get("action_ref") not in input_actions:
            _issue(
                issues,
                "ROUTE_ACTION_UNKNOWN",
                f"{path}.action_ref",
                "input action does not exist",
            )
        elif has_event_ref and route.get("event_ref") not in all_event_bindings:
            _issue(
                issues,
                "ROUTE_EVENT_UNKNOWN",
                f"{path}.event_ref",
                "event binding does not exist",
            )
        from_states = route.get("from_states")
        if independent:
            pass
        elif not isinstance(from_states, list) or not from_states:
            _issue(issues, "ROUTE_SOURCE_MISSING", f"{path}.from_states", "must contain at least one state")
        else:
            for index, state_ref in enumerate(from_states):
                if state_ref not in states:
                    _issue(issues, "GRAPH_STATE_UNKNOWN", f"{path}.from_states[{index}]", f"unknown state '{state_ref}'")
        has_target_state = "target_state" in route
        has_target_scene = "target_scene" in route
        if (has_target_state and has_target_scene) or (not independent and not (has_target_state or has_target_scene)):
            _issue(
                issues,
                "GRAPH_TRANSITION_TARGET_INVALID",
                path,
                "must declare exactly one of target_state or target_scene",
            )
        elif has_target_state and route.get("target_state") not in states:
            _issue(issues, "GRAPH_TRANSITION_TARGET_UNKNOWN", f"{path}.target_state", "target state does not exist")
        elif has_target_state:
            if "scene_exit_ref" in route:
                _issue(
                    issues,
                    "SCENE_EXIT_TARGET_MISMATCH",
                    f"{path}.scene_exit_ref",
                    "local state routes cannot reference a scene exit",
                )
            target_state_record = states[route.get("target_state")]
            only_render_model = next(iter(render_models), None)
            target_model = render_models.get(target_state_record.get("render_model_ref") or only_render_model)
            if isinstance(target_model, dict):
                target_elements = {
                    str(item.get("element_id")): item
                    for item in target_model.get("elements", [])
                    if isinstance(item, dict)
                    and isinstance(item.get("element_id"), str)
                }
        elif has_target_scene:
            _stable_id(route.get("target_scene"), f"{path}.target_scene", issues)
            scene_exit_ref = route.get("scene_exit_ref")
            if scene_exit_ref is not None:
                if scene_exit_ref not in scene_exits:
                    _issue(
                        issues,
                        "SCENE_EXIT_UNKNOWN",
                        f"{path}.scene_exit_ref",
                        f"unknown scene exit '{scene_exit_ref}'",
                    )
                elif scene_exits[scene_exit_ref].get("target_scene") != route.get("target_scene"):
                    _issue(
                        issues,
                        "SCENE_EXIT_TARGET_MISMATCH",
                        f"{path}.scene_exit_ref",
                        "route target_scene must match its declared scene exit",
                    )
            route_actions = route.get("actions")
            if not _machine_projection and isinstance(route_actions, list) and any(
                not isinstance(action, dict) or action.get("kind") != "play_sfx"
                for action in route_actions
            ):
                _issue(
                    issues,
                    "SCENE_TRANSITION_ACTION_UNSUPPORTED",
                    f"{path}.actions",
                    "direct scene replacement supports only play_sfx actions",
                )
        guards = route.get("guards")
        if not isinstance(guards, list) or len(guards) > 8:
            _issue(issues, "GUARD_LIMIT_EXCEEDED", f"{path}.guards", "must contain at most 8 guards")
        else:
            for index, guard in enumerate(guards):
                guard_path = f"{path}.guards[{index}]"
                if not isinstance(guard, dict):
                    _issue(issues, "GUARD_TYPE_MISMATCH", guard_path, "must be an object")
                    continue
                _check_keys(guard, {"variable_ref", "operator", "value"}, guard_path, issues)
                if guard.get("variable_ref") not in variables:
                    _issue(issues, "GUARD_VARIABLE_UNKNOWN", f"{guard_path}.variable_ref", "variable does not exist")
                if guard.get("operator") not in {"eq", "ne", "lt", "le", "gt", "ge"}:
                    _issue(issues, "GUARD_OPERATOR_INVALID", f"{guard_path}.operator", "unsupported comparison")
                if isinstance(guard.get("value"), bool) or not isinstance(guard.get("value"), int):
                    _issue(issues, "GUARD_TYPE_MISMATCH", f"{guard_path}.value", "must be an integer")
        actions = route.get("actions")
        if not isinstance(actions, list) or len(actions) > 8:
            _issue(issues, "ACTION_BUDGET_EXCEEDED", f"{path}.actions", "must contain at most 8 actions")
        else:
            for index, action in enumerate(actions):
                action_path = f"{path}.actions[{index}]"
                if not isinstance(action, dict):
                    _issue(issues, "ACTION_TYPE_INVALID", action_path, "must be an object")
                    continue
                kind = action.get("kind")
                if kind == "set_variable":
                    _check_keys(action, {"kind", "variable_ref", "operation", "value"}, action_path, issues)
                    if action.get("variable_ref") not in variables:
                        _issue(issues, "ACTION_VARIABLE_UNKNOWN", f"{action_path}.variable_ref", "variable does not exist")
                    if action.get("operation") not in {"assign", "add"}:
                        _issue(issues, "ACTION_OPERATION_INVALID", f"{action_path}.operation", "must be assign or add")
                    if isinstance(action.get("value"), bool) or not isinstance(action.get("value"), int):
                        _issue(issues, "ACTION_TYPE_INVALID", f"{action_path}.value", "must be an integer")
                elif kind == "request_render":
                    _check_keys(action, {"kind"}, action_path, issues)
                elif kind in {"start_timer", "restart_timer", "cancel_timer"}:
                    _check_keys(action, {"kind", "timer_ref"}, action_path, issues)
                    if action.get("timer_ref") not in scene_timers:
                        _issue(issues, "ACTION_TIMER_UNKNOWN", f"{action_path}.timer_ref",
                               "must reference a scene timer in this scene")
                elif kind == "play_sfx":
                    _check_keys(action, {"kind", "cue_ref"}, action_path, issues)
                    cue_ref = action.get("cue_ref")
                    _stable_id(cue_ref, f"{action_path}.cue_ref", issues)
                    if cue_ref not in audio_cue_ids:
                        _issue(
                            issues,
                            "AUDIO_CUE_UNKNOWN",
                            f"{action_path}.cue_ref",
                            f"unknown audio cue '{cue_ref}'",
                        )
                elif kind == "exit_to_shell":
                    _check_keys(action, {"kind"}, action_path, issues)
                elif kind in {
                    "set_element_visibility",
                    "set_element_position",
                    "set_element_frame",
                    "set_element_waiting_animation",
                }:
                    element_ref = action.get("element_ref")
                    element = target_elements.get(element_ref)
                    if kind == "set_element_visibility":
                        _check_keys(
                            action,
                            {"kind", "element_ref", "visible"},
                            action_path,
                            issues,
                        )
                    elif kind == "set_element_position":
                        _check_keys(
                            action,
                            {"kind", "element_ref", "x", "y"},
                            action_path,
                            issues,
                        )
                    elif kind == "set_element_frame":
                        _check_keys(
                            action,
                            {"kind", "element_ref", "frame_ref"},
                            action_path,
                            issues,
                        )
                    else:
                        _check_keys(
                            action,
                            {
                                "kind",
                                "element_ref",
                                "waiting_visual_ref",
                                "waiting_element_ref",
                                "timeline_policy",
                            },
                            action_path,
                            issues,
                        )
                    _stable_id(element_ref, f"{action_path}.element_ref", issues)
                    if element is None:
                        _issue(
                            issues,
                            "ACTION_ELEMENT_UNKNOWN",
                            f"{action_path}.element_ref",
                            "target state render model has no matching element",
                        )
                        continue
                    if kind == "set_element_visibility":
                        visible = action.get("visible")
                        if not isinstance(visible, bool):
                            _issue(
                                issues,
                                "ACTION_TYPE_INVALID",
                                f"{action_path}.visible",
                                "must be true or false",
                            )
                        elif not visible and element.get("focus_role", "none") == "focus":
                            _issue(
                                issues,
                                "RENDER_FOCUS_INVALID",
                                f"{action_path}.visible",
                                "the focus element must remain visible",
                            )
                    elif kind == "set_element_position":
                        x = action.get("x")
                        y = action.get("y")
                        if (
                            isinstance(x, bool)
                            or not isinstance(x, int)
                            or isinstance(y, bool)
                            or not isinstance(y, int)
                        ):
                            _issue(
                                issues,
                                "ACTION_TYPE_INVALID",
                                action_path,
                                "position must use integer x and y",
                            )
                        elif (
                            x < 0
                            or y < 0
                            or x + int(element.get("width", 0)) > 168
                            or y + int(element.get("height", 0)) > 144
                        ):
                            _issue(
                                issues,
                                "RENDER_BOUNDS_INVALID",
                                action_path,
                                "element action exceeds the 168x144 canvas",
                            )
                    elif kind == "set_element_frame":
                        frame_ref = action.get("frame_ref")
                        _stable_id(frame_ref, f"{action_path}.frame_ref", issues)
                        if element.get("kind") != "sprite":
                            _issue(
                                issues,
                                "ACTION_ELEMENT_TYPE_INVALID",
                                f"{action_path}.element_ref",
                                "frame selection requires a sprite element",
                            )
                        if frame_ref not in frame_ids:
                            _issue(
                                issues,
                                "ASSET_FRAME_UNKNOWN",
                                f"{action_path}.frame_ref",
                                f"unknown frame '{frame_ref}'",
                            )
                    else:
                        waiting_visual_ref = action.get("waiting_visual_ref")
                        waiting_element_ref = action.get("waiting_element_ref")
                        waiting_visual = waiting_visuals.get(waiting_visual_ref)
                        waiting_element = None
                        _stable_id(
                            waiting_visual_ref,
                            f"{action_path}.waiting_visual_ref",
                            issues,
                        )
                        _stable_id(
                            waiting_element_ref,
                            f"{action_path}.waiting_element_ref",
                            issues,
                        )
                        if isinstance(waiting_visual, dict):
                            waiting_element = next(
                                (
                                    item
                                    for item in waiting_visual.get("elements", [])
                                    if isinstance(item, dict)
                                    and item.get("element_id")
                                    == waiting_element_ref
                                ),
                                None,
                            )
                        else:
                            _issue(
                                issues,
                                "WAIT_VISUAL_UNKNOWN",
                                f"{action_path}.waiting_visual_ref",
                                "waiting visual does not exist",
                            )
                        if waiting_element is None:
                            _issue(
                                issues,
                                "WAIT_ELEMENT_UNKNOWN",
                                f"{action_path}.waiting_element_ref",
                                "waiting visual has no matching element",
                            )
                        elif waiting_element.get("source_element_ref") != element_ref:
                            _issue(
                                issues,
                                "ACTION_WAIT_ELEMENT_MISMATCH",
                                f"{action_path}.waiting_element_ref",
                                "waiting animation must target the same retained element",
                            )
                        if element.get("kind") != "sprite":
                            _issue(
                                issues,
                                "ACTION_ELEMENT_TYPE_INVALID",
                                f"{action_path}.element_ref",
                                "waiting animation selection requires a sprite element",
                            )
                        if action.get("timeline_policy") not in {
                            "preserve",
                            "rebase",
                        }:
                            _issue(
                                issues,
                                "ACTION_TIMELINE_POLICY_INVALID",
                                f"{action_path}.timeline_policy",
                                "must be preserve or rebase",
                            )
                        target_state_record = states.get(route.get("target_state"))
                        target_waiting = (
                            waiting_visuals.get(
                                target_state_record.get("waiting_visual_ref")
                            )
                            if isinstance(target_state_record, dict)
                            else None
                        )
                        if (
                            isinstance(waiting_visual, dict)
                            and isinstance(target_waiting, dict)
                            and (
                                waiting_visual.get("phase_quantum_ms")
                                != target_waiting.get("phase_quantum_ms")
                                or waiting_visual.get("combined_step_count")
                                != target_waiting.get("combined_step_count")
                            )
                        ):
                            _issue(
                                issues,
                                "ACTION_WAIT_TIMELINE_INCOMPATIBLE",
                                action_path,
                                "waiting animation cadence and step count must match the target state",
                            )
                else:
                    _issue(issues, "ACTION_KIND_INVALID", f"{action_path}.kind", "unsupported V1 action")

    wait_policy = scene.get("reactive_wait_default")
    if not isinstance(wait_policy, dict):
        _issue(issues, "WAIT_POLICY_INVALID", f"{base}.reactive_wait_default", "must be an object")
    else:
        path = f"{base}.reactive_wait_default"
        _check_keys(wait_policy, {"policy_id", "waiting_visual_ref", "hold_fallback_allowed", "event_interests"}, path, issues)
        _stable_id(wait_policy.get("policy_id"), f"{path}.policy_id", issues)
        if wait_policy.get("waiting_visual_ref") not in waiting_visuals:
            _issue(issues, "WAIT_VISUAL_UNKNOWN", f"{path}.waiting_visual_ref", "waiting visual does not exist")
        if not isinstance(wait_policy.get("hold_fallback_allowed"), bool):
            _issue(issues, "WAIT_FALLBACK_INVALID", f"{path}.hold_fallback_allowed", "must be true or false")
        interests = wait_policy.get("event_interests")
        if not isinstance(interests, list):
            _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.event_interests", "must be an array")
        else:
            for index, action_ref in enumerate(interests):
                if action_ref not in all_event_bindings:
                    _issue(issues, "WAIT_EVENT_UNKNOWN", f"{path}.event_interests[{index}]", "event binding does not exist")

    interaction = scene.get("interaction_policy")
    if not isinstance(interaction, dict):
        _issue(issues, "POWER_IDLE_ROUTE_MISSING", f"{base}.interaction_policy", "must be an object")
    else:
        path = f"{base}.interaction_policy"
        required = {"policy_id", "mode", "meaningful_activity_actions"}
        allowed = required | {"inactive_route", "bounded_deferrals"}
        _check_keys(interaction, required, path, issues, allowed)
        _stable_id(interaction.get("policy_id"), f"{path}.policy_id", issues)
        mode = interaction.get("mode")
        if mode not in {"continuous", "timeout"}:
            _issue(issues, "POWER_INTERACTION_MODE_INVALID", f"{path}.mode", "must be continuous or timeout")
        if mode == "timeout":
            if interaction.get("inactive_route") not in {"preserve_scene", "exit_to_shell"}:
                _issue(issues, "POWER_IDLE_ROUTE_MISSING", f"{path}.inactive_route", "must preserve_scene or exit_to_shell")
            if interaction.get("bounded_deferrals", []) != []:
                _issue(issues, "POWER_DEFERRAL_UNSUPPORTED", f"{path}.bounded_deferrals", "the V1 subset does not support deferrals")
        elif mode == "continuous":
            if "inactive_route" in interaction:
                _issue(issues, "POWER_CONTINUOUS_ROUTE_INVALID", f"{path}.inactive_route", "continuous mode must not declare an inactive route")
            if "bounded_deferrals" in interaction:
                _issue(issues, "POWER_CONTINUOUS_DEFERRAL_INVALID", f"{path}.bounded_deferrals", "continuous mode must not declare inactivity deferrals")
        meaningful = interaction.get("meaningful_activity_actions")
        if not isinstance(meaningful, list):
            _issue(issues, "PROJECT_TYPE_INVALID", f"{path}.meaningful_activity_actions", "must be an array")
        else:
            for index, action_ref in enumerate(meaningful):
                if action_ref not in input_actions:
                    _issue(issues, "INPUT_ACTION_UNKNOWN", f"{path}.meaningful_activity_actions[{index}]", "input action does not exist")


def _scene_path(root: Path, source: Any, issues: list[ValidationIssue]) -> Path | None:
    if not isinstance(source, str) or not source:
        _issue(issues, "SCENE_SOURCE_INVALID", "project.scene_sources", "scene source must be a relative path")
        return None
    relative = Path(source)
    if relative.is_absolute() or ".." in relative.parts:
        _issue(issues, "SCENE_SOURCE_INVALID", source, "scene source must stay inside the project")
        return None
    path = (root / relative).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError:
        _issue(issues, "SCENE_SOURCE_INVALID", source, "scene source resolves outside the project")
        return None
    return path


def _compile_asset_catalogs(
    root: Path,
    catalogs: list[dict[str, Any]],
) -> tuple[
    list[dict[str, Any]],
    list[dict[str, Any]],
    list[Masked1bppFrame],
    list[CompiledAudioAsset],
    list[dict[str, Any]],
    list[ValidationIssue],
]:
    issues: list[ValidationIssue] = []
    assets: list[dict[str, Any]] = []
    animations: list[dict[str, Any]] = []
    frames: list[Masked1bppFrame] = []
    audio_assets: list[CompiledAudioAsset] = []
    audio_cues: list[dict[str, Any]] = []
    asset_ids: set[str] = set()
    frame_ids: set[str] = set()
    animation_ids: set[str] = set()
    audio_asset_ids: set[str] = set()
    audio_cue_ids: set[str] = set()
    from .tiled_assets import validate_record
    from .imported_properties import ImportedPropertyError
    map_ids: set[str] = set()
    for catalog_index, catalog in enumerate(catalogs):
        path = f"asset_catalogs[{catalog_index}].map_assets"
        for asset_id, record in _unique_ids(catalog.get("map_assets", []), "asset_id", path, issues, 128).items():
            if asset_id in map_ids:
                _issue(issues, "PROJECT_ID_DUPLICATE", path, f"duplicate ID '{asset_id}'")
            map_ids.add(asset_id)
            try:
                validate_record(record, root)
            except ImportedPropertyError as exc:
                _issue(issues, "MAP_IMPORT_INVALID", path, str(exc))
    for catalog in catalogs:
        for category in ("assets", "audio_assets"):
            records = catalog.get(category, [])
            for record in records if isinstance(records, list) else []:
                if isinstance(record, dict) and isinstance(record.get("asset_id"), str) and record["asset_id"] in map_ids:
                    _issue(issues, "PROJECT_ID_DUPLICATE", category, "Map asset ID collides with another asset")
    for catalog_index, catalog in enumerate(catalogs):
        base = f"asset_catalogs[{catalog_index}]"
        _check_keys(
            catalog,
            {"schema_id", "schema_version", "assets", "animations"},
            base,
            issues,
            {
                "schema_id",
                "schema_version",
                "assets",
                "animations",
                "audio_assets",
                "audio_cues",
                "map_assets",
            },
        )
        if catalog.get("schema_id") != "peepshow.authoring.assets" or catalog.get("schema_version") != 1:
            _issue(issues, "ASSET_SCHEMA_UNSUPPORTED", base, "expected peepshow.authoring.assets version 1")
        catalog_assets = _unique_ids(catalog.get("assets"), "asset_id", f"{base}.assets", issues, 128)
        for asset_id, asset in catalog_assets.items():
            asset_path = f"{base}.assets[{asset_id}]"
            if asset_id in asset_ids:
                _issue(issues, "PROJECT_ID_DUPLICATE", f"{asset_path}.asset_id", f"duplicate ID '{asset_id}'")
                continue
            asset_ids.add(asset_id)
            for frame in asset.get("frames", []) if isinstance(asset.get("frames"), list) else []:
                if not isinstance(frame, dict) or not isinstance(frame.get("frame_id"), str):
                    continue
                frame_id = frame["frame_id"]
                if frame_id in frame_ids:
                    _issue(issues, "PROJECT_ID_DUPLICATE", f"{asset_path}.frames", f"duplicate ID '{frame_id}'")
                else:
                    frame_ids.add(frame_id)
            frames.extend(_check_asset(asset, asset_path, root, issues))
            assets.append(asset)
        catalog_animations = _unique_ids(
            catalog.get("animations"),
            "animation_id",
            f"{base}.animations",
            issues,
            128,
        )
        for animation_id, animation in catalog_animations.items():
            animation_path = f"{base}.animations[{animation_id}]"
            if animation_id in animation_ids:
                _issue(
                    issues,
                    "PROJECT_ID_DUPLICATE",
                    f"{animation_path}.animation_id",
                    f"duplicate ID '{animation_id}'",
                )
                continue
            animation_ids.add(animation_id)
            _check_animation(animation, animation_path, issues)
            animations.append(animation)
        catalog_audio_assets = _unique_ids(
            catalog.get("audio_assets", []),
            "asset_id",
            f"{base}.audio_assets",
            issues,
            AUDIO_MAX_ASSETS,
        )
        for audio_asset_id, audio_asset in catalog_audio_assets.items():
            audio_path = f"{base}.audio_assets[{audio_asset_id}]"
            if audio_asset_id in audio_asset_ids:
                _issue(
                    issues,
                    "PROJECT_ID_DUPLICATE",
                    f"{audio_path}.asset_id",
                    f"duplicate ID '{audio_asset_id}'",
                )
                continue
            audio_asset_ids.add(audio_asset_id)
            before = len(issues)
            _check_keys(
                audio_asset,
                {"asset_id", "asset_type", "source_path", "source_format"},
                audio_path,
                issues,
                {"asset_id", "asset_type", "source_path", "source_format", "tags"},
            )
            if "tags" in audio_asset:
                _check_asset_tags(audio_asset["tags"], f"{audio_path}.tags", issues)
            _stable_id(audio_asset_id, f"{audio_path}.asset_id", issues)
            if audio_asset.get("asset_type") != "sampled_sfx":
                _issue(
                    issues,
                    "AUDIO_ASSET_TYPE_INVALID",
                    f"{audio_path}.asset_type",
                    "must be sampled_sfx",
                )
            if audio_asset.get("source_format") != "wav":
                _issue(
                    issues,
                    "AUDIO_SOURCE_FORMAT_INVALID",
                    f"{audio_path}.source_format",
                    "must be wav",
                )
            if len(issues) == before:
                try:
                    audio_assets.append(import_sampled_sfx(root, audio_asset))
                except (AudioAssetError, KeyError) as exc:
                    _issue(issues, "AUDIO_SOURCE_INVALID", audio_path, str(exc))
        catalog_audio_cues = _unique_ids(
            catalog.get("audio_cues", []),
            "cue_id",
            f"{base}.audio_cues",
            issues,
            AUDIO_MAX_CUES,
        )
        for cue_id, cue in catalog_audio_cues.items():
            cue_path = f"{base}.audio_cues[{cue_id}]"
            if cue_id in audio_cue_ids:
                _issue(
                    issues,
                    "PROJECT_ID_DUPLICATE",
                    f"{cue_path}.cue_id",
                    f"duplicate ID '{cue_id}'",
                )
                continue
            audio_cue_ids.add(cue_id)
            _check_keys(
                cue,
                {"cue_id", "asset_ref", "priority", "volume"},
                cue_path,
                issues,
                {"cue_id", "display_name", "asset_ref", "priority", "volume"},
            )
            _stable_id(cue_id, f"{cue_path}.cue_id", issues)
            if "display_name" in cue:
                _text(cue.get("display_name"), f"{cue_path}.display_name", issues, 64)
            _stable_id(cue.get("asset_ref"), f"{cue_path}.asset_ref", issues)
            for field in ("priority", "volume"):
                value = cue.get(field)
                if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 255:
                    _issue(
                        issues,
                        "AUDIO_CUE_VALUE_INVALID",
                        f"{cue_path}.{field}",
                        "must be an integer in 0..255",
                    )
            audio_cues.append(cue)
    for animation in animations:
        for index, frame_ref in enumerate(animation.get("frame_refs", [])):
            if frame_ref not in frame_ids:
                _issue(
                    issues,
                    "ASSET_FRAME_UNKNOWN",
                    f"animation[{animation.get('animation_id')}].frame_refs[{index}]",
                    f"unknown frame '{frame_ref}'",
                )
    for cue in audio_cues:
        if cue.get("asset_ref") not in audio_asset_ids:
            _issue(
                issues,
                "AUDIO_ASSET_UNKNOWN",
                f"audio_cues[{cue.get('cue_id')}].asset_ref",
                f"unknown audio asset '{cue.get('asset_ref')}'",
            )
    # Package audio capacity is checked against selected cues at compilation,
    # not against unused library recordings while opening/editing a project.
    return assets, animations, frames, audio_assets, audio_cues, issues


def _new_project_slug(project_name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", project_name.lower()).strip("_")
    if not slug:
        slug = "project"
    if not slug[0].isalpha():
        slug = f"project_{slug}"
    return slug[:48].rstrip("_")


def _scene_schema_version(value: Any) -> int:
    if type(value) is not int or value not in (1, 2):
        raise ProjectCommandError("SCENE_SCHEMA_VERSION_UNSUPPORTED", "scene_schema_version must be integer 1 or 2")
    return value


def _new_state_scene(
    scene_id: str,
    display_name: str,
    *,
    interaction_template: dict[str, Any] | None = None,
    scene_schema_version: int = 1,
) -> dict[str, Any]:
    input_actions: list[dict[str, Any]] = []
    routes: list[dict[str, Any]] = []
    event_interests: list[str] = []

    interaction_mode = (
        interaction_template.get("mode")
        if isinstance(interaction_template, dict)
        else "continuous"
    )
    interaction_policy: dict[str, Any] = {
        "policy_id": f"{scene_id}_interaction",
        "mode": interaction_mode,
        "meaningful_activity_actions": list(event_interests),
    }
    if interaction_mode == "timeout":
        inactive_route = interaction_template.get("inactive_route")
        interaction_policy["inactive_route"] = (
            inactive_route
            if inactive_route in {"preserve_scene", "exit_to_shell"}
            else "preserve_scene"
        )
        if "bounded_deferrals" in interaction_template:
            interaction_policy["bounded_deferrals"] = []

    scene = {
        "schema_id": "peepshow.authoring.state_scene",
        "schema_version": _scene_schema_version(scene_schema_version),
        "scene_id": scene_id,
        "display_name": display_name,
        "scene_type": "STATE_SCENE",
        "entry_state": "start",
        "variables": [],
        "input_actions": input_actions,
        "scene_exits": [],
        "routes": routes,
        "reactive_wait_default": {
            "policy_id": f"{scene_id}_wait_policy",
            "hold_fallback_allowed": True,
            "event_interests": event_interests,
        },
        "interaction_policy": interaction_policy,
    }
    if scene_schema_version == 2:
        scene["objects"] = []
        scene["states"] = [{"state_id": "start", "display_name": "Start", "object_overrides": []}]
        return scene

    scene.update({
        "states": [
            {
                "state_id": "start",
                "display_name": "Start",
                "waiting_visual_ref": "static_wait",
            }
        ],
        "render_models": [
            {
                "visual_id": "scene_placement",
                "focus_index": 0,
                "elements": [],
            }
        ],
        "waiting_visuals": [
            {
                "waiting_visual_id": "static_wait",
                "presentation_id": f"{scene_id}_static",
                "phase_quantum_ms": 250,
                "combined_step_count": 1,
                "settled_step": 0,
                "cycle_policy": "loop",
                "elements": [],
            }
        ],
    })
    scene["reactive_wait_default"]["waiting_visual_ref"] = "static_wait"
    return scene


def create_project(project_root: str | Path, *, scene_schema_version: int = 1,
                   initial_scene_id: str = 'main', authoring_mode=None, create_initial_scene=True, execution_semantics=None) -> ProjectBundle:
    from .authoring_foundation import MODE
    from .execution_semantics import LEGACY, STARTUP, TERMINAL
    if execution_semantics not in (None, LEGACY, STARTUP, TERMINAL):
        raise ProjectCommandError('EXECUTION_SEMANTICS_UNSUPPORTED', 'Unknown execution contract')
    if execution_semantics in (STARTUP, TERMINAL):
        if authoring_mode not in (None, MODE):
            raise ProjectCommandError('AUTHORING_MODE_INVALID', 'Machine startup requires incremental_v1')
        authoring_mode = MODE
    if authoring_mode not in (None, MODE) or type(create_initial_scene) is not bool:
        raise ProjectCommandError('AUTHORING_MODE_INVALID', 'Unknown mode or invalid create_initial_scene')
    if not create_initial_scene and authoring_mode != MODE:
        raise ProjectCommandError('AUTHORING_MODE_REQUIRED', 'An asset-only project requires incremental_v1')
    if authoring_mode == MODE:
        scene_schema_version = 2
    scene_schema_version = _scene_schema_version(scene_schema_version)
    issues = []
    _stable_id(initial_scene_id, 'initial_scene_id', issues)
    if issues:
        raise ProjectCommandError(issues[0].code, issues[0].message)
    root = Path(project_root)
    if not root.is_absolute():
        raise ProjectCommandError("PROJECT_PATH_INVALID", "new project path must be absolute")
    if root.suffix != ".peepproj":
        raise ProjectCommandError(
            "PROJECT_SUFFIX_INVALID",
            "editable project directories must end in .peepproj",
        )
    if root.exists():
        raise ProjectCommandError(
            "PROJECT_CREATE_TARGET_EXISTS",
            "choose a new project location; that path already exists",
        )
    if not root.parent.is_dir():
        raise ProjectCommandError(
            "PROJECT_CREATE_PARENT_MISSING",
            "the selected project parent directory does not exist",
        )

    project_name = root.stem.strip()
    if not 1 <= len(project_name) <= 96:
        raise ProjectCommandError(
            "PROJECT_TEXT_INVALID",
            "project name must contain 1..96 characters",
        )
    slug = _new_project_slug(project_name)
    scene_source = f"scenes/{initial_scene_id}.state.json"
    project = {
        "schema_id": "peepshow.authoring.project",
        "schema_version": 1,
        "project_id": f"project.{slug}",
        "project_name": project_name,
        "package": {
            "package_id": f"dev.peepshow.{slug}",
            "display_name": project_name,
            "version": "0.1.0",
        },
        "selected_target_profile": TARGET_PROFILE_ID,
        "entry_scene": initial_scene_id,
        "scene_sources": [scene_source],
        "validation": {
            "build_profile": "development",
            "ruleset_version": 1,
        },
    }
    scene = _new_state_scene(initial_scene_id, "Main", scene_schema_version=scene_schema_version)
    if authoring_mode == MODE:
        from .authoring_foundation import empty_scene
        project.update(authoring_mode=MODE, variable_model='scoped_v1', package_variables=[])
        empty_scene(scene)
    if execution_semantics is not None:
        project['execution_semantics'] = execution_semantics
    if execution_semantics in (STARTUP, TERMINAL) and create_initial_scene:
        from .machine_startup import starter
        starter(scene)
    if not create_initial_scene:
        project.update(entry_scene=None, scene_sources=[])

    staging_root = root.with_name(f".{root.stem}.creating.peepproj")
    if staging_root.exists():
        raise ProjectCommandError(
            "PROJECT_CREATE_STAGING_EXISTS",
            f"remove the incomplete creation directory '{staging_root.name}' and try again",
        )
    try:
        (staging_root / "scenes").mkdir(parents=True)
        (staging_root / "project.json").write_text(
            json.dumps(project, ensure_ascii=True, indent=2) + "\n",
            encoding="utf-8",
        )
        if create_initial_scene:
            (staging_root / scene_source).write_text(
                json.dumps(scene, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
        staged_bundle = load_project(staging_root)
        if not staged_bundle.valid:
            issue = staged_bundle.issues[0]
            raise ProjectCommandError(issue.code, f"{issue.path}: {issue.message}")
        staging_root.replace(root)
    except ProjectCommandError:
        shutil.rmtree(staging_root, ignore_errors=True)
        raise
    except OSError as exc:
        shutil.rmtree(staging_root, ignore_errors=True)
        raise ProjectCommandError(
            "PROJECT_CREATE_FAILED",
            f"could not create project: {exc}",
        ) from exc

    return load_project(root)


def load_project(project_root: str | Path) -> ProjectBundle:
    root = Path(project_root)
    issues: list[ValidationIssue] = []
    if root.suffix != ".peepproj":
        _issue(issues, "PROJECT_SUFFIX_INVALID", str(root), "editable project directories must end in .peepproj")
    if not root.is_dir():
        _issue(issues, "PROJECT_ROOT_MISSING", str(root), "project directory does not exist")
        return ProjectBundle(root, {}, (), (), (), (), (), (), (), (), (), tuple(issues))

    project = _read_json(root / "project.json", issues, "PROJECT_MANIFEST_INVALID")
    if project is None:
        return ProjectBundle(root, {}, (), (), (), (), (), (), (), (), (), tuple(issues))
    _check_project(project, issues)
    from .machine_startup import enabled as startup_enabled
    if startup_enabled(project) and project.get('authoring_mode') != 'incremental_v1':
        _issue(issues, 'MACHINE_STARTUP_SOURCE_MODE', 'project.authoring_mode',
               'New execution contracts require incremental_v1; existing projects are not implicitly migrated')

    asset_catalogs: list[dict[str, Any]] = []
    loaded_asset_sources: list[str] = []
    asset_sources = project.get("asset_sources", [])
    if isinstance(asset_sources, list):
        for source in asset_sources:
            try:
                path = resolve_project_path(root, source, "asset catalog path")
            except ImageAssetError as exc:
                _issue(issues, "ASSET_SOURCE_INVALID", f"project.asset_sources[{source}]", str(exc))
                continue
            catalog = _read_json(path, issues, "ASSET_SOURCE_INVALID")
            if catalog is None:
                continue
            asset_catalogs.append(catalog)
            loaded_asset_sources.append(str(source))
    (
        assets,
        animations,
        frames,
        audio_assets,
        audio_cues,
        catalog_issues,
    ) = _compile_asset_catalogs(root, asset_catalogs)
    issues.extend(catalog_issues)
    frame_ids = {frame.frame_id for frame in frames}
    animation_ids = {
        str(animation["animation_id"])
        for animation in animations
        if isinstance(animation.get("animation_id"), str)
    }
    audio_cue_ids = {
        str(cue["cue_id"])
        for cue in audio_cues
        if isinstance(cue.get("cue_id"), str)
    }

    scenes: list[dict[str, Any]] = []
    loaded_scene_sources: list[str] = []
    scene_ids: set[str] = set()
    sources = project.get("scene_sources")
    if isinstance(sources, list):
        for source in sources:
            path = _scene_path(root, source, issues)
            if path is None:
                continue
            scene = _read_json(path, issues, "SCENE_SOURCE_INVALID")
            if scene is None:
                continue
            _check_scene(
                scene,
                str(source),
                {frame.frame_id: frame for frame in frames},
                animation_ids,
                audio_cue_ids,
                issues,
                {animation["animation_id"]: animation for animation in animations},
                variable_project=project,
            )
            scene_id = scene.get("scene_id")
            if isinstance(scene_id, str):
                if scene_id in scene_ids:
                    _issue(issues, "SCENE_ID_DUPLICATE", str(source), f"duplicate scene ID '{scene_id}'")
                scene_ids.add(scene_id)
            scenes.append(scene)
            loaded_scene_sources.append(str(source))

    from .authoring_foundation import enabled, finish
    if enabled(project):
        return finish(ProjectBundle(root, project, tuple(scenes), tuple(loaded_scene_sources),
            tuple(asset_catalogs), tuple(loaded_asset_sources), tuple(assets), tuple(animations),
            tuple(frames), tuple(audio_assets), tuple(audio_cues), tuple(issues)))
    from .world_reference_project import check_project as check_world_references
    check_world_references(scenes, asset_catalogs, issues)
    from .actor_templates import validate as validate_actor_templates
    try:
        validate_actor_templates(project, scenes, asset_catalogs, frames=frame_ids, animations=animation_ids, audio=audio_cue_ids)
    except (ProjectCommandError, KeyError, TypeError, ValueError, StopIteration, AttributeError, IndexError) as exc:
        _issue(issues, 'ACTOR_TEMPLATE_INVALID', 'project.actor_templates', str(exc))
    entry_scene = project.get("entry_scene")
    if isinstance(entry_scene, str) and entry_scene not in scene_ids:
        _issue(issues, "SCENE_ENTRY_MISSING", "project.entry_scene", f"unknown entry scene '{entry_scene}'")
    editor_nodes = project.get("editor", {}).get("scene_flow", {}).get("nodes", {}) if isinstance(project.get("editor"), dict) else {}
    if isinstance(editor_nodes, dict):
        for scene_id in editor_nodes:
            if isinstance(scene_id, str) and scene_id not in scene_ids:
                _issue(
                    issues,
                    "SCENE_ID_UNKNOWN",
                    f"project.editor.scene_flow.nodes[{scene_id}]",
                    f"unknown scene '{scene_id}'",
                )
    scene_flow = project.get("editor", {}).get("scene_flow", {}) if isinstance(project.get("editor"), dict) else {}
    references = scene_flow.get("references", {}) if isinstance(scene_flow, dict) else {}
    if isinstance(references, dict):
        for reference_id, reference in references.items():
            target_scene = reference.get("target_scene") if isinstance(reference, dict) else None
            if isinstance(target_scene, str) and target_scene not in scene_ids:
                _issue(
                    issues,
                    "SCENE_ID_UNKNOWN",
                    f"project.editor.scene_flow.references[{reference_id}].target_scene",
                    f"unknown scene '{target_scene}'",
                )
    exit_references = scene_flow.get("exit_references", {}) if isinstance(scene_flow, dict) else {}
    scenes_by_id = {
        scene.get("scene_id"): scene
        for scene in scenes
        if isinstance(scene, dict) and isinstance(scene.get("scene_id"), str)
    }
    if isinstance(exit_references, dict):
        for source_scene, scene_group in exit_references.items():
            source = scenes_by_id.get(source_scene)
            if source is None:
                _issue(
                    issues,
                    "SCENE_ID_UNKNOWN",
                    f"project.editor.scene_flow.exit_references[{source_scene}]",
                    f"unknown scene '{source_scene}'",
                )
                continue
            if not isinstance(scene_group, dict):
                continue
            for endpoint_key, reference_id in scene_group.items():
                path = f"project.editor.scene_flow.exit_references[{source_scene}][{endpoint_key}]"
                reference = references.get(reference_id) if isinstance(references, dict) else None
                if not isinstance(reference, dict):
                    _issue(issues, "PROJECT_REFERENCE_MISSING", path, f"unknown scene-flow reference '{reference_id}'")
                    continue
                if not isinstance(endpoint_key, str) or ":" not in endpoint_key:
                    continue
                endpoint_kind, endpoint_id = endpoint_key.split(":", 1)
                collection_name = "scene_exits" if endpoint_kind == "scene_exit" else "routes"
                id_field = "scene_exit_id" if endpoint_kind == "scene_exit" else "route_id"
                endpoint = next(
                    (
                        record
                        for record in source.get(collection_name, [])
                        if isinstance(record, dict) and record.get(id_field) == endpoint_id
                    ),
                    None,
                )
                if endpoint is None:
                    _issue(issues, "PROJECT_REFERENCE_MISSING", path, f"unknown {endpoint_kind} '{endpoint_id}'")
                elif endpoint.get("target_scene") != reference.get("target_scene"):
                    _issue(
                        issues,
                        "COMMAND_TARGET_INVALID",
                        path,
                        "scene-flow reference target does not match the authored scene destination",
                    )
    scene_route_layouts = scene_flow.get("routes", {}) if isinstance(scene_flow, dict) else {}
    if isinstance(scene_route_layouts, dict):
        for source_scene, scene_group in scene_route_layouts.items():
            source = scenes_by_id.get(source_scene)
            if source is None:
                _issue(
                    issues,
                    "SCENE_ID_UNKNOWN",
                    f"project.editor.scene_flow.routes[{source_scene}]",
                    f"unknown scene '{source_scene}'",
                )
                continue
            if not isinstance(scene_group, dict):
                continue
            for endpoint_key in scene_group:
                path = f"project.editor.scene_flow.routes[{source_scene}][{endpoint_key}]"
                if not isinstance(endpoint_key, str) or ":" not in endpoint_key:
                    continue
                endpoint_kind, endpoint_id = endpoint_key.split(":", 1)
                collection_name = "scene_exits" if endpoint_kind == "scene_exit" else "routes"
                id_field = "scene_exit_id" if endpoint_kind == "scene_exit" else "route_id"
                endpoint = next(
                    (
                        record
                        for record in source.get(collection_name, [])
                        if isinstance(record, dict) and record.get(id_field) == endpoint_id
                    ),
                    None,
                )
                if endpoint is None:
                    _issue(issues, "PROJECT_REFERENCE_MISSING", path, f"unknown {endpoint_kind} '{endpoint_id}'")
    state_graph_scenes = project.get("editor", {}).get("state_graph", {}).get("scenes", {}) if isinstance(project.get("editor"), dict) else {}
    if isinstance(state_graph_scenes, dict):
        for scene_id, scene_layout in state_graph_scenes.items():
            if not isinstance(scene_id, str):
                continue
            target_scene = scenes_by_id.get(scene_id)
            if target_scene is None:
                _issue(
                    issues,
                    "SCENE_ID_UNKNOWN",
                    f"project.editor.state_graph.scenes[{scene_id}]",
                    f"unknown scene '{scene_id}'",
                )
                continue
            if not isinstance(scene_layout, dict):
                continue
            nodes = scene_layout.get("nodes")
            if isinstance(nodes, dict):
                valid_node_ids = _state_graph_node_ids(target_scene)
                for node_id in nodes:
                    if isinstance(node_id, str) and node_id not in valid_node_ids:
                        _issue(
                            issues,
                            "GRAPH_STATE_UNKNOWN",
                            f"project.editor.state_graph.scenes[{scene_id}].nodes[{node_id}]",
                            f"unknown state graph node '{node_id}'",
                        )
            handlers = scene_layout.get("handlers")
            if isinstance(handlers, dict):
                for handler_id, layout in handlers.items():
                    if not isinstance(layout, dict):
                        continue
                    try:
                        _check_handler_layout_target(target_scene, handler_id, layout)
                    except ProjectCommandError as exc:
                        _issue(issues, exc.code,
                               f"project.editor.state_graph.scenes[{scene_id}].handlers[{handler_id}]", exc.message)
            routes = scene_layout.get("routes")
            if isinstance(routes, dict):
                routes_by_id = {
                    route.get("route_id"): route
                    for route in target_scene.get("routes", [])
                    if isinstance(route, dict) and isinstance(route.get("route_id"), str)
                }
                for route_id, route_layout in routes.items():
                    if not isinstance(route_id, str):
                        continue
                    target_route = routes_by_id.get(route_id)
                    if target_route is None:
                        _issue(
                            issues,
                            "GRAPH_ROUTE_UNKNOWN",
                            f"project.editor.state_graph.scenes[{scene_id}].routes[{route_id}]",
                            f"unknown route '{route_id}'",
                        )
                        continue
                    sources = route_layout.get("sources") if isinstance(route_layout, dict) else None
                    if not isinstance(sources, dict):
                        continue
                    valid_sources = set(target_route.get("from_states", []))
                    for source_state in sources:
                        if isinstance(source_state, str) and source_state not in valid_sources:
                            _issue(
                                issues,
                                "GRAPH_ROUTE_SOURCE_UNKNOWN",
                                f"project.editor.state_graph.scenes[{scene_id}].routes[{route_id}].sources[{source_state}]",
                                f"state '{source_state}' is not a source of route '{route_id}'",
                            )
    for scene, source in zip(scenes, loaded_scene_sources):
        for scene_exit in scene.get("scene_exits", []):
            if not isinstance(scene_exit, dict):
                continue
            target_scene = scene_exit.get("target_scene")
            if isinstance(target_scene, str) and target_scene not in scene_ids:
                _issue(
                    issues,
                    "SCENE_TRANSITION_TARGET_UNKNOWN",
                    f"scene[{source}].scene_exits[{scene_exit.get('scene_exit_id')}].target_scene",
                    f"unknown scene '{target_scene}'",
                )
        for route in [*scene.get("routes", []), *scene.get("event_handlers", [])]:
            if not isinstance(route, dict) or "target_scene" not in route:
                continue
            target_scene = route.get("target_scene")
            if isinstance(target_scene, str) and target_scene not in scene_ids:
                _issue(
                    issues,
                    "SCENE_TRANSITION_TARGET_UNKNOWN",
                    f"scene[{source}].{'event_handlers' if 'handler_id' in route else 'routes'}[{route.get('handler_id', route.get('route_id'))}].target_scene",
                    f"unknown scene '{target_scene}'",
                )
    interaction_modes = {
        scene.get("interaction_policy", {}).get("mode")
        for scene in scenes
        if isinstance(scene.get("interaction_policy"), dict)
    }
    if len(interaction_modes) > 1:
        _issue(
            issues,
            "POWER_INTERACTION_MODE_CONFLICT",
            "project.scene_sources",
            "all scenes in one package must use the same interaction mode",
        )
    from .instance_project import validate_bundle as validate_instances
    return validate_instances(ProjectBundle(
        root,
        project,
        tuple(scenes),
        tuple(loaded_scene_sources),
        tuple(asset_catalogs),
        tuple(loaded_asset_sources),
        tuple(assets),
        tuple(animations),
        tuple(frames),
        tuple(audio_assets),
        tuple(audio_cues),
        tuple(issues),
    ))


def apply_project_commands(
    bundle: ProjectBundle,
    commands: Any,
) -> tuple[ProjectBundle, tuple[dict[str, Any], ...]]:
    from .scene_object_authoring import OBJECT_COMMANDS, apply_object_command, check_command_model
    if not bundle.valid:
        raise ProjectCommandError("PROJECT_INVALID", "project must validate before commands can be applied")
    if not isinstance(commands, list) or not commands:
        raise ProjectCommandError("COMMAND_LIST_INVALID", "commands must be a non-empty array")
    if len(commands) > 64:
        raise ProjectCommandError("COMMAND_LIST_INVALID", "commands must contain at most 64 entries")

    project = deepcopy(bundle.project)
    scenes = deepcopy(list(bundle.scenes))
    scene_sources = list(bundle.scene_sources)
    asset_catalogs = deepcopy(list(bundle.asset_catalogs))
    asset_catalog_sources = list(bundle.asset_catalog_sources)
    assets = deepcopy(list(bundle.assets))
    animations = deepcopy(list(bundle.animations))
    frames = list(bundle.frames)
    audio_assets = list(bundle.audio_assets)
    audio_cues = deepcopy(list(bundle.audio_cues))
    applied: list[dict[str, Any]] = []

    for command in commands:
        if not isinstance(command, dict):
            raise ProjectCommandError("COMMAND_SHAPE_INVALID", "each command must be an object")
        kind = command.get("kind")
        from .machine_startup import enabled as startup_enabled
        if startup_enabled(project) and kind == 'state.set_entry':
            raise ProjectCommandError('SCENE_ENTRY_NOT_USED', 'Use scene.machine.set_entry; this contract has no Scene-to-State connection')
        from .behavior_library import COMMANDS as BEHAVIOR_LIBRARY_COMMANDS, apply as apply_behavior_library
        if kind in BEHAVIOR_LIBRARY_COMMANDS:
            applied.append(apply_behavior_library(project, scenes, command))
            continue
        from .flow_library import COMMANDS as LIBRARY_COMMANDS, apply as apply_library
        if kind in LIBRARY_COMMANDS:
            applied.append(apply_library(project, scenes, command))
            continue
        from .execution_semantics import COMMAND as SEMANTICS_COMMAND, apply as pin_semantics
        if kind == SEMANTICS_COMMAND:
            applied.append(pin_semantics(project, command))
            continue
        from .authoring_foundation import COMMANDS as FOUNDATION_COMMANDS, MAP_COMMANDS as NATIVE_MAP_COMMANDS, enabled
        from .authoring_foundation import VISIBILITY_COMMANDS as FOUNDATION_VISIBILITY
        if command.get('kind') in FOUNDATION_COMMANDS + NATIVE_MAP_COMMANDS or enabled(project) and kind in FOUNDATION_VISIBILITY:
            from .authoring_foundation import check_command
            check_command(command)
        else:
            check_command_model(scenes, command)
        from .menu_component import COMMANDS as MENU_COMMANDS
        from .inventory_source import COMMANDS as INVENTORY_COMMANDS
        if kind in INVENTORY_COMMANDS:
            from .inventory_source import apply_command as apply_inventory
            applied.append(apply_inventory(project, scenes, command))
            continue
        from .behavior_response import COMMANDS as RESPONSE_COMMANDS
        from .actor_assembly import COMMANDS as ACTOR_COMMANDS
        from .actor_templates import COMMANDS as TEMPLATE_COMMANDS
        from .visibility_source import COMMANDS as VISIBILITY_COMMANDS
        from .behavior_destinations import COMMANDS as DESTINATION_COMMANDS
        if enabled(project) and kind in ACTOR_COMMANDS + TEMPLATE_COMMANDS:
            if kind in TEMPLATE_COMMANDS[:2] and len(commands) != 1:
                raise ProjectCommandError('ACTOR_TEMPLATE_INVALID', 'Capture/Apply requires a standalone command')
            from .entity_editing import apply as apply_entity_actor
            applied.append(apply_entity_actor(bundle, project, scenes, asset_catalogs, command))
            continue
        if kind in VISIBILITY_COMMANDS or kind in DESTINATION_COMMANDS:
            from . import visibility_source, behavior_destinations
            module = visibility_source if kind in VISIBILITY_COMMANDS else behavior_destinations
            applied.append(module.apply_command(scenes, command))
            continue
        if kind in TEMPLATE_COMMANDS:
            from .actor_templates import apply_command as apply_template
            if kind in TEMPLATE_COMMANDS[:2] and len(commands) != 1:
                raise ProjectCommandError('ACTOR_TEMPLATE_INVALID', 'Capture/Apply requires a standalone command from a validated actor')
            try:
                applied.append(apply_template(project, scenes, asset_catalogs, command))
            except (KeyError, TypeError, ValueError, StopIteration, AttributeError, IndexError) as exc:
                raise ProjectCommandError('ACTOR_TEMPLATE_INVALID', str(exc)) from exc
            continue
        if kind in ACTOR_COMMANDS:
            from .actor_assembly import apply_command
            applied.append(apply_command(scenes, asset_catalogs, command))
            from .actor_templates import sync_target_binding
            sync_target_binding(project, scenes, asset_catalogs, command)
            if kind == 'scene.actor.remove' and 'actor_templates' in project:
                project['actor_templates']['placements'][:] = [p for p in project['actor_templates']['placements']
                    if (p['scene_id'],p['instance_ref']) != (command['scene_id'],command['instance_ref'])]
        elif kind in MENU_COMMANDS:
            from .menu_component import apply_command
            applied.append(apply_command(scenes, command))
        elif kind in RESPONSE_COMMANDS:
            from .behavior_response import apply_command
            applied.append(apply_command(scenes, command))
        elif kind in FOUNDATION_COMMANDS:
            if not enabled(project):
                raise ProjectCommandError('AUTHORING_MODE_REQUIRED', 'Use an incremental_v1 project; existing source is not silently migrated')
            from .authoring_foundation import apply
            applied.append(apply(scenes, command, asset_catalogs))
        elif kind in NATIVE_MAP_COMMANDS:
            from .native_map_authoring import apply
            _primary_asset_catalog(project, asset_catalogs, asset_catalog_sources)
            applied.append(apply(bundle.root, asset_catalogs, command, scenes))
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                raise ProjectCommandError(catalog_issues[0].code, catalog_issues[0].message)
        elif kind in {"scene.machines.set", "scene.machines.clear"}:
            from .scene_machines import apply_command
            if kind == 'scene.machines.clear' and enabled(project):
                _require_command_fields(command, {'kind','scene_id'}, {'kind','scene_id','command_id'})
                from .authoring_foundation import apply
                target = _command_scene(scenes, command['scene_id'])
                for machine in list(target.get('machine_logic', {}).get('machines', [])):
                    apply(scenes, dict(kind='scene.machine.remove',scene_id=command['scene_id'],machine_id=machine['machine_id']))
                applied.append(deepcopy(command))
            else:
                applied.append(apply_command(scenes, command))
        elif kind in {"scene.flowcharts.set", "scene.flowcharts.clear"}:
            from .flowcharts import apply_command
            applied.append(apply_command(scenes, command))
        elif kind in {"scene.presentation_selectors.set", "scene.presentation_selectors.clear"}:
            from .presentation_selectors import apply_command
            applied.append(apply_command(scenes, command))
        elif kind in {"scene.entry_graph.set", "scene.entry_graph.clear"}:
            from .scene_entry import apply_command
            applied.append(apply_command(scenes, command))
        elif kind in {"project.variables.enable", "package_variable.add", "package_variable.update", "package_variable.delete"}:
            from .scoped_variables import apply_command
            applied.append(apply_command(project, scenes, command))
        elif kind in OBJECT_COMMANDS:
            applied.append(apply_object_command(scenes, command))
        elif kind == "scene.add":
            applied.append(
                _apply_scene_add(bundle.root, project, scenes, scene_sources, command)
            )
        elif kind == "scene.rename":
            applied.append(_apply_scene_rename(scenes, command))
        elif kind == "project.settings.set":
            _require_command_fields(command, {"kind", "settings"}, {"kind", "settings", "command_id"})
            settings_issues = []
            _check_project_settings(command["settings"], settings_issues)
            if settings_issues:
                raise ProjectCommandError(settings_issues[0].code, settings_issues[0].message)
            project["settings"] = deepcopy(command["settings"])
            applied.append({"kind": kind, "settings": deepcopy(command["settings"])})
        elif kind == "project.set_entry_scene":
            applied.append(_apply_project_set_entry_scene(project, scenes, command))
        elif kind == "state.create":
            applied.append(_apply_state_create(project, scenes, command))
        elif kind == "state.add":
            applied.append(_apply_state_add(scenes, command))
        elif kind == "state.delete":
            applied.append(_apply_state_delete(project, scenes, command))
        elif kind == "state.set_entry":
            applied.append(_apply_state_set_reference(scenes, command, incremental=enabled(project)))
        elif kind == "state.rename":
            applied.append(_apply_state_rename(scenes, command))
        elif kind == "render_model.add":
            applied.append(_apply_render_model_add(scenes, command))
        elif kind == "render_model.delete":
            applied.append(_apply_render_model_delete(scenes, command))
        elif kind == "render_model.set_focus_index":
            applied.append(_apply_render_model_set_focus(scenes, command))
        elif kind in {"variable.add", "variable.update"}:
            applied.append(_apply_variable_upsert(scenes, command))
        elif kind == "variable.delete":
            applied.append(_apply_variable_delete(scenes, command))
        elif kind in {"input_action.add", "input_action.update"}:
            applied.append(_apply_input_action_upsert(scenes, command))
        elif kind == "input_action.delete":
            applied.append(_apply_input_action_delete(scenes, command))
        elif kind == "route.create_trigger":
            applied.append(_apply_route_create_trigger(project, scenes, command))
        elif kind == "route.rebind_trigger":
            applied.append(_apply_route_rebind_trigger(scenes, command))
        elif kind in {"event_binding.add", "event_binding.update"}:
            applied.append(_apply_event_binding_upsert(scenes, command))
        elif kind == "event_binding.delete":
            applied.append(_apply_event_binding_delete(project, scenes, command))
        elif kind in {"event_handler.add", "event_handler.update", "event_handler.delete"}:
            applied.append(_apply_event_handler_command(project, scenes, command))
        elif kind == "route.add":
            applied.append(_apply_route_add(scenes, command))
        elif kind == "route.delete":
            applied.append(_apply_route_delete(project, scenes, command))
        elif kind in {"route.set_sources", "route.set_action_ref", "route.set_event_ref"}:
            applied.append(_apply_route_set_binding(project, scenes, command))
        elif kind == "route.set_target":
            applied.append(_apply_route_set_target(project, scenes, command))
        elif kind in ("scene_exit.add", "scene.restart.add"):
            applied.append(_apply_scene_exit_add(project, scenes, command))
        elif kind == "scene_exit.set_target":
            applied.append(_apply_scene_exit_set_target(project, scenes, command))
        elif kind == "scene_exit.delete":
            applied.append(_apply_scene_exit_delete(project, scenes, command))
        elif kind == "render_element.set_position":
            applied.append(_apply_render_element_set_position(scenes, command))
        elif kind == "state_placement.set_override":
            applied.append(_apply_state_placement_set_override(scenes, frames, command))
        elif kind == "state_placement.clear_override":
            applied.append(_apply_state_placement_clear_override(scenes, command))
        elif kind == "placement_object.add":
            applied.append(_apply_placement_object_add(scenes, frames, command))
        elif kind == "render_element.add":
            applied.append(_apply_render_element_add(scenes, frames, command))
        elif kind == "render_element.delete":
            applied.append(_apply_render_element_delete(scenes, command))
        elif kind == "render_element.set_bounds":
            applied.append(_apply_render_element_set_bounds(scenes, command))
        elif kind == "render_element.set_kind":
            applied.append(_apply_render_element_set_kind(scenes, command))
        elif kind == "render_element.bind_waiting_animation":
            applied.append(_apply_render_element_bind_waiting_animation(scenes, frames, command))
        elif kind == "render_element.clear_waiting_animation":
            applied.append(_apply_render_element_clear_waiting_animation(scenes, command))
        elif kind in {
            "render_element.set_layer",
            "render_element.set_visibility",
            "render_element.set_z_order",
            "render_element.set_visual_ref",
        }:
            applied.append(_apply_render_element_set_property(scenes, frames, command))
        elif kind == "waiting_visual.upsert":
            applied.append(_apply_waiting_visual_upsert(scenes, command))
        elif kind == "waiting_visual.delete":
            applied.append(_apply_waiting_visual_delete(scenes, command))
        elif kind == "state.set_waiting_visual":
            applied.append(_apply_state_set_waiting_visual(scenes, command))
        elif kind in ("asset.set_tags", "audio_asset.set_tags"):
            applied.append(_apply_asset_tags(asset_catalogs, command))
            if kind == "asset.set_tags":
                for asset in assets:
                    if asset["asset_id"] == command["asset_id"]:
                        asset["tags"] = deepcopy(command["tags"])
        elif kind in ("map.import", "map.reimport", "map.property.set", "map.property.clear", "map.delete"):
            from .tiled_assets import apply_command
            _primary_asset_catalog(project, asset_catalogs, asset_catalog_sources)
            applied.append(apply_command(bundle.root, asset_catalogs, command))
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                issue = catalog_issues[0]
                raise ProjectCommandError(issue.code, issue.message)
        elif kind == "asset.upsert":
            applied.append(_apply_asset_upsert(project, asset_catalogs, asset_catalog_sources, command))
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                issue = catalog_issues[0]
                raise ProjectCommandError(issue.code, issue.message)
        elif kind == "asset.delete":
            applied.append(_apply_asset_delete(asset_catalogs, scenes, command))
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                issue = catalog_issues[0]
                raise ProjectCommandError(issue.code, issue.message)
        elif kind == "animation.upsert":
            applied.append(_apply_animation_upsert(project, asset_catalogs, asset_catalog_sources, command))
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                issue = catalog_issues[0]
                raise ProjectCommandError(issue.code, issue.message)
        elif kind == "animation.delete":
            applied.append(_apply_animation_delete(asset_catalogs, scenes, command))
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                issue = catalog_issues[0]
                raise ProjectCommandError(issue.code, issue.message)
        elif kind == "audio_asset.upsert":
            applied.append(
                _apply_audio_asset_upsert(
                    project, asset_catalogs, asset_catalog_sources, command
                )
            )
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                issue = catalog_issues[0]
                raise ProjectCommandError(issue.code, issue.message)
        elif kind == "audio_asset.delete":
            applied.append(_apply_audio_asset_delete(asset_catalogs, command))
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                issue = catalog_issues[0]
                raise ProjectCommandError(issue.code, issue.message)
        elif kind == "audio_cue.upsert":
            applied.append(
                _apply_audio_cue_upsert(
                    project, asset_catalogs, asset_catalog_sources, command
                )
            )
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                issue = catalog_issues[0]
                raise ProjectCommandError(issue.code, issue.message)
        elif kind == "audio_cue.delete":
            applied.append(_apply_audio_cue_delete(asset_catalogs, scenes, command))
            assets, animations, frames, audio_assets, audio_cues, catalog_issues = _compile_asset_catalogs(bundle.root, asset_catalogs)
            if catalog_issues:
                issue = catalog_issues[0]
                raise ProjectCommandError(issue.code, issue.message)
        elif kind == "editor.scene_flow.set_node_position":
            applied.append(_apply_scene_flow_node_position(project, scenes, command))
        elif kind == "editor.scene_flow.set_package_entry_position":
            applied.append(_apply_scene_flow_package_entry_position(project, command))
        elif kind == "editor.scene_flow.add_reference":
            applied.append(_apply_scene_flow_reference_add(project, scenes, command))
        elif kind == "editor.scene_flow.set_reference_position":
            applied.append(_apply_scene_flow_reference_position(project, command))
        elif kind == "editor.scene_flow.set_reference_target":
            applied.append(_apply_scene_flow_reference_target(project, scenes, command))
        elif kind == "editor.scene_flow.delete_reference":
            applied.append(_apply_scene_flow_reference_delete(project, command))
        elif kind == "editor.scene_flow.set_exit_reference":
            applied.append(_apply_scene_flow_exit_reference(project, scenes, command))
        elif kind == "editor.scene_flow.set_route_layout":
            applied.append(_apply_scene_flow_route_layout(project, scenes, command))
        elif kind == "editor.state_graph.set_node_position":
            applied.append(_apply_state_graph_node_position(project, scenes, command))
        elif kind == "editor.state_graph.set_entry_layout":
            applied.append(_apply_state_graph_entry_layout(project, scenes, command))
        elif kind == "editor.state_graph.delete_system_exit":
            applied.append(_apply_state_graph_system_exit_delete(project, scenes, command))
        elif kind == "editor.state_graph.set_route_layout":
            applied.append(_apply_state_graph_route_layout(project, scenes, command))
        elif kind == "editor.state_graph.set_handler_layout":
            applied.append(_apply_state_graph_handler_layout(project, scenes, command))
        elif kind == "route.set_guard":
            applied.append(_apply_route_set_guard(scenes, command))
        elif kind in {"route.guard.add", "route.guard.delete", "route.guard.move"}:
            applied.append(_apply_route_guard_list(scenes, command))
        elif kind == "route.set_action":
            applied.append(_apply_route_set_action(scenes, command))
        elif kind in {"route.action.add", "route.action.delete", "route.action.move"}:
            applied.append(_apply_route_action_list(scenes, command))
        elif kind in {"scene.set_reactive_wait_default", "scene.set_interaction_policy", "scene.set_joystick_policy"}:
            applied.append(_apply_scene_policy(scenes, command))
        else:
            raise ProjectCommandError("COMMAND_KIND_UNKNOWN", f"unknown command kind '{kind}'")

    from .authoring_foundation import enabled, finish, check_project, check_scene
    if enabled(project):
        issues = []
        check_project(project, issues)
        for scene in scenes:
            check_scene(scene, f"scenes[{scene['scene_id']}]", issues)
        candidate = finish(ProjectBundle(bundle.root, project, tuple(scenes), tuple(scene_sources),
            tuple(asset_catalogs), tuple(asset_catalog_sources), tuple(assets), tuple(animations),
            tuple(frames), tuple(audio_assets), tuple(audio_cues), tuple(issues)))
        if not candidate.valid:
            problem = candidate.issues[0]
            raise ProjectCommandError(problem.code, f'{problem.path}: {problem.message}')
        return candidate, tuple(applied)
    frame_lookup = {frame.frame_id: frame for frame in frames}
    frame_ids = set(frame_lookup)
    animation_ids = {
        animation.get("animation_id")
        for animation in animations
        if isinstance(animation.get("animation_id"), str)
    }
    audio_cue_ids = {
        cue.get("cue_id")
        for cue in audio_cues
        if isinstance(cue.get("cue_id"), str)
    }
    validation_issues: list[ValidationIssue] = []
    for index, scene in enumerate(scenes):
        _check_scene(
            scene,
            f"scenes[{index}]",
            frame_lookup,
            animation_ids,
            audio_cue_ids,
            validation_issues,
            {animation["animation_id"]: animation for animation in animations},
            variable_project=project,
        )
    from .world_reference_project import check_project as check_world_references
    check_world_references(scenes, asset_catalogs, validation_issues)
    from .actor_templates import validate as validate_actor_templates
    try:
        validate_actor_templates(project, scenes, asset_catalogs, frames=frame_ids, animations=animation_ids, audio=audio_cue_ids)
    except (ProjectCommandError, KeyError, TypeError, ValueError, StopIteration, AttributeError, IndexError) as exc:
        raise ProjectCommandError('ACTOR_TEMPLATE_INVALID', str(exc)) from exc
    if validation_issues:
        issue = validation_issues[0]
        raise ProjectCommandError(issue.code, f"{issue.path}: {issue.message}")

    from .instance_project import validate_bundle as validate_instances
    candidate = validate_instances(ProjectBundle(
            bundle.root,
            project,
            tuple(scenes),
            tuple(scene_sources),
            tuple(asset_catalogs),
            tuple(asset_catalog_sources),
            tuple(assets),
            tuple(animations),
            tuple(frames),
            tuple(audio_assets),
            tuple(audio_cues),
            (),
        ))
    if not candidate.valid:
        issue = candidate.issues[0]
        raise ProjectCommandError(issue.code, f"{issue.path}: {issue.message}")
    return candidate, tuple(applied)


def save_project(bundle: ProjectBundle) -> tuple[str, ...]:
    if not bundle.valid:
        raise ProjectCommandError("PROJECT_INVALID", "project must validate before it can be saved")
    if len(bundle.scene_sources) != len(bundle.scenes):
        raise ProjectCommandError("PROJECT_SAVE_FAILED", "loaded scene sources do not match scene records")

    written: list[str] = []
    project_path = bundle.root / "project.json"
    encoded_project = (
        json.dumps(
            bundle.project,
            ensure_ascii=True,
            indent=2,
            sort_keys=False,
        )
        + "\n"
    )
    project_temp_path = project_path.with_name(".project.json.tmp")
    try:
        project_temp_path.write_text(encoded_project, encoding="utf-8")
        project_temp_path.replace(project_path)
    except OSError as exc:
        try:
            project_temp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise ProjectCommandError("PROJECT_SAVE_FAILED", f"could not save project manifest: {exc}") from exc
    written.append("project.json")

    for source, scene in zip(bundle.scene_sources, bundle.scenes, strict=True):
        issues: list[ValidationIssue] = []
        path = _scene_path(bundle.root, source, issues)
        if path is None or issues:
            issue = issues[0] if issues else ValidationIssue("SCENE_SOURCE_INVALID", source, "scene source is invalid")
            raise ProjectCommandError(issue.code, issue.message)
        encoded = (
            json.dumps(
                scene,
                ensure_ascii=True,
                indent=2,
                sort_keys=False,
            )
            + "\n"
        )
        temp_path = path.with_name(f".{path.name}.tmp")
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            temp_path.write_text(encoded, encoding="utf-8")
            temp_path.replace(path)
        except OSError as exc:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass
            raise ProjectCommandError("PROJECT_SAVE_FAILED", f"could not save scene source '{source}': {exc}") from exc
        written.append(source)

    if len(bundle.asset_catalog_sources) != len(bundle.asset_catalogs):
        raise ProjectCommandError("PROJECT_SAVE_FAILED", "loaded asset sources do not match asset catalogs")
    for source, catalog in zip(bundle.asset_catalog_sources, bundle.asset_catalogs, strict=True):
        try:
            path = resolve_project_path(bundle.root, source, "asset catalog path")
        except ImageAssetError as exc:
            raise ProjectCommandError("ASSET_SOURCE_INVALID", str(exc)) from exc
        encoded = (
            json.dumps(
                catalog,
                ensure_ascii=True,
                indent=2,
                sort_keys=False,
            )
            + "\n"
        )
        temp_path = path.with_name(f".{path.name}.tmp")
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            temp_path.write_text(encoded, encoding="utf-8")
            temp_path.replace(path)
        except OSError as exc:
            try:
                temp_path.unlink(missing_ok=True)
            except OSError:
                pass
            raise ProjectCommandError("PROJECT_SAVE_FAILED", f"could not save asset source '{source}': {exc}") from exc
        written.append(source)
    return tuple(written)


def format_issues(issues: Iterable[ValidationIssue]) -> str:
    return "\n".join(f"{issue.code} {issue.path}: {issue.message}" for issue in issues)
