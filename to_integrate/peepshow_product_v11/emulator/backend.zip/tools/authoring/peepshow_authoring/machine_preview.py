"""Bounded, addressed machine execution through the shared preview action engine."""
from copy import deepcopy
from dataclasses import replace

from .preview import StateScenePreview, PreviewError, PreviewInputResult
from .scene_objects import resolve_object
from .scene_machines import sample_percent, sample_delay


class MachinePreview(StateScenePreview):
    def __init__(self, *args, _world_context=None, _scope_sources=None, _menu_budget_ms=None, **kwargs):
        # Direct internal callers may supply a context; public map packages carry
        # fresh per-Scene templates. Both use the ordinary atomic publication point.
        self._world_context = deepcopy(_world_context)
        # Internal qualification may inject sources; negotiated public packages
        # carry their own source ownership metadata through the base constructor.
        if _scope_sources is not None:
            kwargs['_session_scope_sources'] = _scope_sources
        if _menu_budget_ms is not None:
            if type(_menu_budget_ms) is not int or not 1 <= _menu_budget_ms <= 600000:
                raise PreviewError('menu action wait policy must be in 1..600000 ms')
            kwargs['_session_menu_budget_ms'] = _menu_budget_ms
        super().__init__(*args, **kwargs)

    def _activate_scene(self, scene_id, *, run_entry=True):
        from .scope_timing import ScopeTiming
        source = getattr(self, '_scope_sources', {}).get(scene_id)
        if source is not None and '_inventory_catalog' in source:
            for item in source['_inventory_catalog']['items']:
                self._inventory_state['counts'].setdefault(item['item_id'], item['initial_count'])
        scoped = source is not None and ('menu_component' in source or 'execution_scopes' in source['machine_logic'])
        self._scope_timing = ScopeTiming(source) if scoped else None
        from .scope_menu import ScopeMenu
        menu = source['machine_logic'].get('execution_scopes', {}).get('menu', {}) if source is not None else {}
        self._scope_menu = ScopeMenu(menu.get('confirm_receiver'), menu.get('entry_receiver')) if scoped else None
        from .menu_component_preview import MenuSession
        self._menu_component = MenuSession(source['menu_component']) if source is not None and 'menu_component' in source else None
        self._scope_confirm_receiver = None
        self._menu_requested = None
        self._menu_input_receivers = {}
        if source is not None:
            from .scope_input import ScopeInput
            if self._scope_input is None:
                self._scope_input = ScopeInput()
            self._menu_input_receivers = deepcopy(menu.get('input_receivers', {}))
        template = self._scenes.get(scene_id, {}).get('_world_template')
        if template is not None:
            self._world_context = deepcopy(template)
        self._scene_inverted = False
        self._periodic_state_deadlines = {}
        self._object_effects = {}
        self._one_shot_clips = {}
        self._completion_sequence = 0
        self._completion_order = {}
        self._effect_activation = getattr(self, '_effect_activation', 0) + 1
        super()._activate_scene(scene_id, run_entry=run_entry)
        self._machines = self._scene["machine_logic"]
        if self._scope_timing is not None:
            if (set(self._scope_timing.owners['machines']) != {m['machine_id'] for m in self._machines['machines']}
                    or set(self._scope_timing.owners['objects']) != set(self._object_definitions)):
                raise PreviewError('scope timing ownership does not match compiled Scene')
            if self._calendars or self._machines.get('time_reconcile'):
                raise PreviewError('scoped calendar reconciliation is not connected')
        self._machine_states = {m["machine_id"]: self._retained_machine_states.get(
            (scene_id, m["machine_id"]), m["entry_state"]) if m.get("retain_state", False)
            else m["entry_state"] for m in self._machines["machines"]}
        self._machine_entered = {m: 0 for m in self._machine_states}
        self._machine_activations = {m: 1 for m in self._machine_states}
        self._machine_primary = (None if self._object_source["entry_state"] is None else
            next(m["machine_id"] for m in self._machines["machines"]
                 if self._object_source["entry_state"] in m["states"]))
        self._machine_seed = self._machines["seed"]
        for binding in self._graph['event_bindings']:
            if 'delay_max_ms' not in binding['configuration']:
                continue
            index = binding['binding_index']
            if binding['event_type'] == 'time.scene_elapsed':
                if index in self._scene_timer_deadlines:
                    self._scene_timer_deadlines[index] = self._timer_delay(index)
            else:
                self._arm_random_state_timer(binding)
        self._machine_trace = []
        self._machine_rejection = None
        self._machine_indexes = {s["state_id"]: i for i, s in enumerate(self._graph["states"])}
        self._machine_compiled = {r["route_id"]: r for r in self._graph["routes"]}
        self._selector_visuals = {}
        self._flow_pending = {}
        self._flow_trace = []
        self._flow_work = 0
        self._restore_primary()
        self._select_visuals()
        self._render_framebuffer()
        self._entry_pending = run_entry
        if run_entry and not self._defer_activation:
            from .preview_steps import drain
            drain(self.iterate_scene_entry())

    def iterate_scene_entry(self):
        """Scene Activated uses the same cooperative transaction as ordinary input."""
        from .preview_steps import checkpoint
        if not self._entry_pending:
            raise PreviewError('Scene entry has already completed')
        scene_id = self.scene_id
        yield checkpoint(self, 'lifecycle', operation='scene_entry', destination=scene_id)
        activation = self._machines.get("scene_activated")
        if activation is not None:
            result = yield from self._iterate_binding(None, "SCENE_ACTIVATED", "activation", activation["event_ref"])
            if self._machine_rejection is not None:
                raise PreviewError("scene activation rejected: " + self._machine_rejection)
            if result.system_action or self.scene_id != scene_id:
                raise PreviewError("scene activation cannot leave or suspend its destination")
            self.entry_audio_events.extend(result.audio_events)
        self._entry_pending = False
        self._defer_activation = False

    def _select_visuals(self):
        from .presentation_selectors import matches
        variables = {}
        for index, variable in enumerate(self._graph["variables"]):
            definition = self._scoped_variables.get(variable["variable_id"])
            key = (definition["scope"], definition["variable_id"]) if definition else ("scene", variable["variable_id"])
            variables[key] = self._variables[index]
        for ref, selection in self._flow_pending.items():
            if self._scope_held('objects', ref):
                continue
            definition = self._object_definitions[ref]
            default = ('animation_ref', definition['animation_ref']) if definition.get('animation_ref') else (
                'visual_ref', definition['defaults']['visual_ref'])
            old = self._selector_visuals.get(ref, (*default, 0))
            self._selector_visuals[ref] = old if old[:2] == selection else (*selection, self._object_now(ref))
        world = self._world_context
        selectors = world.selectors if world is not None and world.selectors is not None else self._machines.get("presentation_selectors", [])
        for selector in selectors:
            if self._scope_held('objects', selector['object_ref']) and selector['object_ref'] in self._selector_visuals:
                continue
            # Evaluate all predicates, including later rules, just like native
            # postfix evaluation. Read failure rejects instead of hiding behind
            # an earlier match or a short-circuit Boolean expression.
            matched = ["when" not in r or matches(r["when"], self._machine_states, variables,
                       world_guard=world.selector_predicate if world is not None else None)
                       for r in selector["rules"]]
            rule = next(r for r, match in zip(selector["rules"], matched) if match)
            kind = "animation_ref" if "animation_ref" in rule else "visual_ref"
            ref = selector["object_ref"]
            old = self._selector_visuals.get(ref)
            if old is None or old[:2] != (kind, rule[kind]):
                self._selector_visuals[ref] = (kind, rule[kind], self._object_now(ref))

    def select_state(self, state_id):
        if state_id not in self._machine_indexes or not any(state_id in m["states"] for m in self._machines["machines"]):
            raise PreviewError(f"unknown state '{state_id}'")
        owner = next(m["machine_id"] for m in self._machines["machines"] if state_id in m["states"])
        self._machine_states[owner] = state_id
        self._machine_entered[owner] = self._machine_now(owner)
        self._machine_activations[owner] += 1
        self._clear_machine_timers(owner)
        self._restore_primary()
        self._select_visuals()
        self._render_framebuffer()

    def _restore_primary(self):
        if self._machine_primary is None:
            self._state_index = int(self._graph["entry_state"])
            self._state_elapsed_ms = self._elapsed_ms
            return
        self._state_index = self._machine_indexes[self._machine_states[self._machine_primary]]
        self._state_elapsed_ms = self._machine_now(self._machine_primary) - self._machine_entered[self._machine_primary]

    def _machine_now(self, ref):
        return self._scope_timing.now('machines', ref) if self._scope_timing else self._elapsed_ms

    def _object_now(self, ref):
        return self._scope_timing.now('objects', ref) if self._scope_timing else self._elapsed_ms

    def _timer_now(self, binding_index):
        binding = next(b for b in self._graph['event_bindings'] if b['binding_index'] == binding_index)
        return self._machine_now(self._machines['timer_receivers'][binding['binding_id']])

    def _scope_held(self, kind, ref):
        return self._scope_timing is not None and self._scope_timing.held(kind, ref)

    def _receiver_now(self, receiver):
        if self._scope_timing is None:
            return self._elapsed_ms
        identity = (self._world_context.receiver_identity(receiver)
                    if hasattr(self._world_context, 'receiver_identity') else dict(machine_id=receiver))
        kind, ref = ('instances', identity['instance_id']) if 'instance_id' in identity else ('machines', receiver)
        if self._scope_held(kind, ref) and (kind, ref) != self._scope_confirm_receiver:
            raise PreviewError('scope_suspended_receiver')
        return self._scope_timing.now(kind, ref)

    def _set_scope_timing(self, *, gameplay_active, menu_active):
        """Private safe-boundary timing control, not Open/Close Menu or input focus."""
        if self._scope_menu is not None and self._scope_menu.pending is not None:
            raise PreviewError('menu transition owns clock activity')
        if self._scope_timing is None:
            raise PreviewError('scope timing requires explicit ownership')
        candidate = deepcopy(self)
        candidate._scope_timing.set_activity(gameplay_active, menu_active)
        candidate._sync_timeline_pause()
        candidate._select_visuals()
        candidate._render_framebuffer()
        self.__dict__.clear()
        self.__dict__.update(candidate.__dict__)

    def _sync_timeline_pause(self):
        for records in (self._object_effects, self._one_shot_clips):
            for ref, (timeline, _) in records.items():
                timeline.pause(int(self._suspended or self._scope_held('objects', ref)))

    def _set_scope_focus(self, scope, *, held_sources):
        """Private modal handoff; submitted SFX must have acknowledged stop first."""
        if self._scope_timing is None or self._scope_input is None:
            raise PreviewError('focus transfer requires scoped ownership')
        if self._suspended or getattr(self, '_scope_dispatching', False):
            raise PreviewError('focus transfer requires an active, settled transaction boundary')
        if self._scope_menu is not None and self._scope_menu.pending is not None:
            raise PreviewError('menu transition owns focus transfer')
        candidate = deepcopy(self)
        candidate._scope_input.transfer(scope, held_sources)
        candidate._scope_audio.change_focus(scope)
        candidate._scope_timing.set_activity(scope == 'gameplay', scope == 'menu')
        candidate._sync_timeline_pause()
        candidate._select_visuals()
        candidate._render_framebuffer()
        self.__dict__.clear()
        self.__dict__.update(candidate.__dict__)

    def _menu_open(self, *, held_sources, budget_ms, hide_world=True):
        from .scope_menu import begin
        return begin(self, True, held_sources=held_sources, budget_ms=budget_ms, hide_world=hide_world)

    def _menu_close(self, *, held_sources, budget_ms, confirm=False):
        from .scope_menu import begin
        return begin(self, False, held_sources=held_sources, budget_ms=budget_ms, confirm=confirm)

    def _menu_finish(self, token, *, held_sources):
        from .scope_menu import finish
        return finish(self, token, held_sources=held_sources)

    def _menu_cancel_transition(self, token):
        from .scope_menu import require_pending, abort
        require_pending(self, token)
        abort(self, 'cancelled')
        return deepcopy(self._scope_menu.last)

    def apply_input(self, logical_source, event_kind='press', *, _focus_generation=None):
        from .preview_steps import drain
        return drain(self.iterate_input(logical_source, event_kind, _focus_generation=_focus_generation))

    def iterate_input(self, logical_source, event_kind='press', *, _focus_generation=None):
        if self._scope_menu is not None and self._scope_menu.pending is not None:
            focus = self._scope_input
            generation = focus.generation if _focus_generation is None else _focus_generation
            status = focus.observe(logical_source, event_kind, generation, self._suspended)
            if status != 'stale_generation':
                focus.finish('menu_transition_pending')
            return PreviewInputResult(logical_source, event_kind, None, False, None)
        if self._menu_component is not None and self._scope_input.scope == 'menu' and event_kind == 'repeat':
            from .preview import LOGICAL_SOURCES
            focus = self._scope_input
            generation = focus.generation if _focus_generation is None else _focus_generation
            if focus.observe(logical_source, event_kind, generation, self._suspended):
                return PreviewInputResult(logical_source, event_kind, None, False, None)
            action = next((a for a in self._graph['inputs'] if a['logical_source'] == LOGICAL_SOURCES[logical_source]
                           and a.get('logical_event', 1) == 1), None)
            if action is not None:
                return (yield from self._iterate_dispatch_input(action['binding_index'], logical_source, event_kind, action['action_id']))
            focus.finish('unbound_consumed')
            return PreviewInputResult(logical_source, event_kind, None, False, None)
        return (yield from super().iterate_input(logical_source, event_kind, _focus_generation=_focus_generation))

    def advance(self, elapsed_ms):
        from .preview_steps import drain
        return drain(self.iterate_advance(elapsed_ms))

    def iterate_advance(self, elapsed_ms):
        if self._scope_menu is not None and self._scope_menu.pending is not None:
            from .scope_menu import advance
            from .preview_steps import checkpoint
            yield checkpoint(self, 'time', elapsed_ms=elapsed_ms, lifecycle='menu_wait')
            return advance(self, elapsed_ms)
        return (yield from super().iterate_advance(elapsed_ms))

    def _dispatch_input(self, action_index, logical_source, event_kind, action_id):
        from .preview_steps import drain
        return drain(self._iterate_dispatch_input(action_index, logical_source, event_kind, action_id))

    def _iterate_dispatch_input(self, action_index, logical_source, event_kind, action_id):
        focus = self._scope_input
        if self._menu_component is not None:
            from .menu_component_preview import dispatch
            from .preview_steps import checkpoint
            yield checkpoint(self, 'lifecycle', operation='menu_input', logical_source=logical_source)
            result = dispatch(self, logical_source, event_kind, action_id)
            if result is not None:
                return result
        if focus is None or focus.scope == 'gameplay':
            return (yield from super()._iterate_dispatch_input(action_index, logical_source, event_kind, action_id))
        address = self._menu_input_receivers.get(action_id)
        if address is None:
            focus.finish('unmapped_menu_consumed')
            return PreviewInputResult(logical_source, event_kind, action_id, False, None)
        focus.begin_action(logical_source, event_kind, action_id)
        result = yield from self._iterate_binding(action_index, logical_source, event_kind, address['event_ref'],
                                     _receiver=address['machine_ref'])
        if self._scope_input.generation == focus.generation:
            self._scope_input.finish('delivered' if result.accepted else 'unhandled_or_rejected')
        return replace(result, action_id=action_id)

    def _clear_machine_timers(self, owner):
        for binding in self._graph["event_bindings"]:
            if (binding["event_type"] == "time.state_entry_elapsed"
                    and self._machines["timer_receivers"][binding["binding_id"]] == owner):
                self._fired_timer_bindings.discard(binding["binding_index"])
                self._periodic_state_deadlines.pop(binding['binding_index'], None)
                self._arm_random_state_timer(binding)

    def _timer_delay(self, binding_index):
        binding = next(b for b in self._graph['event_bindings'] if b['binding_index'] == binding_index)
        config = binding['configuration']
        seed, delay = sample_delay(self._machine_seed, config['delay_ms'], config.get('delay_max_ms'))
        self._machine_seed = seed
        return delay

    def _arm_random_state_timer(self, binding):
        if 'delay_max_ms' not in binding['configuration']:
            return
        owner = self._machines['timer_receivers'][binding['binding_id']]
        if any(r['event_ref'] == binding['binding_id'] and self._machine_states[owner] in r['from_states']
               for r in self._machines['routes']):
            self._periodic_state_deadlines[binding['binding_index']] = self._machine_now(owner) + self._timer_delay(binding['binding_index'])

    def _apply_binding(self, binding_index, logical_source, event_kind, binding_id, *, _receiver=None):
        from .preview_steps import drain
        return drain(self._iterate_binding(binding_index, logical_source, event_kind, binding_id, _receiver=_receiver))

    def _iterate_binding(self, binding_index, logical_source, event_kind, binding_id, *, _receiver=None):
        if self._scope_menu is not None and self._scope_menu.pending is not None:
            raise PreviewError('menu transition is pending')
        receiver = _receiver
        if binding_index is not None and binding_index < 0:
            self._fired_timer_bindings.discard(binding_index)
            is_clip = isinstance(binding_id, tuple)
            effect, address = (self._one_shot_clips[binding_id[1]] if is_clip
                               else self._object_effects[binding_id])
            status, _ = effect.take(self._effect_activation, effect.generation)
            if status != 0:
                raise PreviewError('effect completion unavailable')
            receiver, binding_id = address
            logical_source, event_kind = ('object.clip_completed' if is_clip else 'object.effect_completed'), 'completed'
        candidate = deepcopy(self)
        if candidate._world_context is not None:
            candidate._world_context.begin()
        candidate._flow_pending = {}
        candidate._flow_local_seconds = None if self._local_ms is None else (self._local_ms // 1000) % 86400
        candidate._flow_trace = []
        candidate._flow_work = 0
        candidate._scope_dispatching = True
        try:
            result = yield from candidate._iterate_chain(binding_index, logical_source, event_kind, binding_id, receiver=receiver)
        finally:
            candidate._scope_dispatching = False
        if isinstance(candidate, MachinePreview) and candidate._machine_rejection is None:
            from .inventory_source import collect
            collect(candidate, self)
        menu_request = candidate._menu_requested if isinstance(candidate, MachinePreview) else None
        if menu_request is not None and candidate._machine_rejection is None:
            origin = dict(candidate._machine_trace[-1], action=deepcopy(menu_request))
            candidate._menu_requested = None
            try:
                from .scope_menu import begin
                from .preview_steps import checkpoint
                yield checkpoint(candidate, 'lifecycle', operation=menu_request['kind'])
                begin(candidate, menu_request['kind'] == 'menu.open',
                      held_sources=candidate._scope_input.held, budget_ms=candidate._menu_action_budget_ms,
                      hide_world=(candidate._menu_component.source['hide_world']
                          if 'menu_ref' in menu_request else menu_request.get('hide_world', True)),
                      confirm=menu_request.get('disposition') == 'confirm')
                candidate._scope_menu.last['request'] = origin
                if candidate._scope_menu.pending is not None:
                    candidate._scope_menu.pending['request'] = origin
            except (PreviewError, ValueError) as exc:
                candidate._machine_rejection = str(exc)
                candidate._machine_trace.append(dict(result='rejected', reason=str(exc), component='menu'))
        # Scene replacement can change the executor type. Plain destinations
        # have no machine/world transaction to resolve after the chain settles.
        if (isinstance(candidate, MachinePreview) and candidate._machine_rejection is None
                and candidate._world_context is not None and menu_request is None):
            try:
                from .camera_source import resolve as resolve_camera
                resolve_camera(candidate._world_context)
            except (ValueError, PreviewError) as exc:
                candidate._machine_rejection = str(exc)
                candidate._machine_trace.append(dict(result='rejected', reason=str(exc), component='camera'))
        if getattr(candidate, "_machine_rejection", None) is not None:
            self._machine_rejection = candidate._machine_rejection
            self._machine_trace = candidate._machine_trace
            self._flow_trace = candidate._flow_trace
            self._flow_work = candidate._flow_work
            for record in self._machine_trace:
                if record["result"] in ("applied", "no_change"):
                    record["result"] = "rolled_back"
            return PreviewInputResult(logical_source, event_kind, binding_id, False, None)
        if isinstance(candidate, MachinePreview) and menu_request is None:
            candidate._select_visuals()
            candidate._render_framebuffer()
        self.__class__ = type(candidate)
        self.__dict__.clear()
        self.__dict__.update(candidate.__dict__)
        return result

    def _apply_chain(self, binding_index, logical_source, event_kind, binding_id, *, receiver=None,
                     _deferred_sends=None):
        from .preview_steps import drain
        return drain(self._iterate_chain(binding_index, logical_source, event_kind, binding_id,
                                        receiver=receiver, _deferred_sends=_deferred_sends))

    def _iterate_chain(self, binding_index, logical_source, event_kind, binding_id, *, receiver=None,
                       _deferred_sends=None):
        from .preview_steps import checkpoint, queue_snapshot, annotate
        if receiver is None:
            receiver = (self._machines['time_reconcile']['machine_ref'] if logical_source == 'TIME_RECONCILE' else
                        self._machines["scene_activated"]["machine_ref"] if logical_source == "SCENE_ACTIVATED"
                        else {**self._machines["input_receivers"], **self._machines["timer_receivers"]}[binding_id])
        queue = [(receiver, binding_id)]
        self._machine_trace = []
        self._machine_rejection = None
        root = PreviewInputResult(logical_source, event_kind, binding_id, False, None)
        audio = []
        destination = None
        processed = 0
        queue_capacity = getattr(self._world_context, 'queue_limit', 32)
        chain_capacity = min(64, getattr(self._world_context, 'queue_limit', 64))
        while queue:
            if processed >= 64:
                self._machine_rejection = "event_chain_capacity"
                break
            machine, event = queue.pop(0)
            processed += 1
            # Private mixed preview adapter. The outer _apply_binding candidate
            # owns all mutations, so a later receiver failure rolls them back.
            delivery = getattr(self._world_context, 'iterate_instance', None)
            if delivery is not None:
                delivered_selection = None
                try:
                    resolver = getattr(self._world_context, 'resolve_receiver', None)
                    if resolver is not None:
                        machine, event = resolver(machine, event)
                    delivered = yield from annotate(delivery(machine, event, self._receiver_now(machine)), outer_queue=queue_snapshot(self, queue))
                    if delivered is not None:
                        trace, sends = delivered
                        delivered_selection = trace.get('selected_response')
                        if processed + len(queue) + len(sends) > chain_capacity:
                            raise PreviewError('event_queue_or_chain_capacity')
                        self._machine_trace.append(trace)
                        queue.extend(sends)
                        continue
                except (PreviewError, ValueError) as exc:
                    self._machine_rejection = str(exc)
                    record = dict(self._world_context.receiver_identity(machine),
                                  event_id=event, result='rejected', reason=str(exc))
                    selected = getattr(exc, 'selected_response', None) or delivered_selection
                    if selected is not None:
                        record['selected_response'] = deepcopy(selected)
                    terminal = getattr(exc, 'terminal_response', None)
                    if terminal is not None:
                        record['terminal_response'] = deepcopy(terminal)
                    self._machine_trace.append(record)
                    break
            try:
                self._receiver_now(machine)
                from .inventory_conditions import is_condition, compare as compare_inventory
                from .response_conditions import matches as response_conditions_match
                matching = next(((ri, route) for ri, route in enumerate(self._machines["routes"])
                             if route["machine_ref"] == machine and route["event_ref"] == event
                             and (machine is None or self._machine_states[machine] in route["from_states"])
                             and all(self._guard_passes(g) for g in self._machine_compiled[f"machine.{ri}.0"]["guards"])
                             and all(compare_inventory(g, self._inventory_state['counts'])
                                     for g in route['guards'] if is_condition(g))
                             and response_conditions_match(self, route['guards'])
                             and (self._world_context is None or self._world_context.matches(route['route_id']))), None)
            except (PreviewError, ValueError) as exc:
                self._machine_rejection = str(exc)
                self._machine_trace.append(dict(machine_id=machine, event_id=event, result='rejected', reason=str(exc)))
                break
            if matching is None:
                self._machine_trace.append({"machine_id": machine, "event_id": event, "result": "unhandled"})
                continue
            ri, route = matching
            from .response_preview import selected_fields
            selection = selected_fields(self, route)
            debug_program = self._scene.get('_terminal_programs', {}).get(route['route_id'], {})
            debug_route = debug_program.get('origin', {}).get('route_id', route['route_id'])
            yield checkpoint(self, 'handler', machine_id=machine, event_id=event, route_id=debug_route, queue=queue_snapshot(self, queue))
            menu_actions = [a for a in route.get('actions', []) if a['kind'] in ('menu.open', 'menu.close')]
            if menu_actions:
                # A lifecycle request is admitted at this transaction boundary,
                # not executed recursively inside a queued event chain.
                if (self._scope_menu is None or self._menu_action_budget_ms is None
                        or processed != 1 or queue or _deferred_sends is not None
                        or logical_source in ('SCENE_ACTIVATED', 'MENU_ENTRY', 'MENU_CONFIRM')):
                    self._machine_rejection = 'menu_action_requires_scoped_root_dispatch_and_host_wait_policy'
                    self._machine_trace.append(dict(machine_id=machine, event_id=event,
                        route_id=route['route_id'], result='rejected', reason=self._machine_rejection, **selection))
                    break
                self._menu_requested = deepcopy(menu_actions[0])
                self._machine_trace.append(dict(machine_id=machine, event_id=event,
                    route_id=route['route_id'], result='applied', **selection))
                root = replace(root, accepted=True, route_id=route['route_id'])
                break
            if route['route_id'] not in self._scene.get('_terminal_programs', {}):
                yield checkpoint(self, 'lifecycle', operation='root_handler', route_id=debug_route,
                                 machine_id=machine, event_id=event)
            candidate = deepcopy(self)
            if candidate._scope_timing is not None:
                candidate._audio_scope_context = candidate._scope_timing.scope('machines', machine)
            terminal_order = bool(candidate._scene.get('_terminal_order'))
            prepared_compiled, prepared_sends, prepared_audio = None, [], []
            program = candidate._scene.get('_terminal_programs', {}).get(route['route_id'])
            if program is not None:
                candidate._state_index = candidate._machine_indexes[candidate._machine_states[machine]]
                try:
                    from .terminal_order import iterate as iterate_response
                    terminal_outcome, prepared_compiled, prepared_sends, prepared_audio, response_trace = yield from iterate_response(
                        candidate, program, (logical_source, event_kind, binding_id))
                    selection = dict(terminal_response=response_trace)
                    route = {**route, **terminal_outcome}
                except (PreviewError, ValueError) as exc:
                    self._machine_rejection = str(exc)
                    self._machine_trace.append(dict(machine_id=machine, event_id=event,
                        route_id=route['route_id'], result='rejected', reason=str(exc),
                        terminal_response=deepcopy(getattr(candidate, '_terminal_response_trace', {}))))
                    break
            outcome_index = 0
            sample = None
            if "outcomes" in route:
                try:
                    candidate._machine_seed, sample = sample_percent(candidate._machine_seed)
                except PreviewError as exc:
                    self._machine_rejection = str(exc)
                    self._machine_trace.append({"machine_id": machine, "event_id": event, "result": "rejected",
                                                "reason": self._machine_rejection, **selection})
                    break
                boundary = 0
                outcome_index = None
                for oi, outcome in enumerate(route["outcomes"]):
                    boundary += outcome["weight"]
                    if sample < boundary:
                        outcome_index = oi
                        break
            if outcome_index is None:
                self._machine_seed = candidate._machine_seed
                self._machine_trace.append({"machine_id": machine, "event_id": event, "route_id": route["route_id"],
                                            "result": "no_change", "sample": sample, **selection})
                continue
            outcome = route.get("outcomes", [route])[outcome_index]
            sends = prepared_sends + [(a["machine_ref"], a["event_ref"]) for a in outcome["actions"] if a["kind"] == "send_event"]
            if any(a["kind"] == "exit_to_shell" for a in outcome["actions"]) and (queue or sends):
                self._machine_rejection = "shell_exit_with_pending_events"
                self._machine_trace.append({"machine_id": machine, "event_id": event, "result": "rejected",
                                            "reason": self._machine_rejection, **selection})
                break
            # Reserve all emitted work before committing this receiver transaction.
            if len(queue) + len(sends) > queue_capacity or processed + len(queue) + len(sends) > chain_capacity:
                self._machine_rejection = "event_queue_or_chain_capacity"
                self._machine_trace.append({"machine_id": machine, "event_id": event, "result": "rejected",
                                            "reason": self._machine_rejection, **selection})
                break
            compiled = prepared_compiled or candidate._machine_compiled[f"machine.{ri}.{outcome_index}"]
            requested = compiled['target_scene']
            if requested is not None:
                if destination is not None and destination != requested:
                    self._machine_rejection = 'scene_exit_conflict'
                    self._machine_trace.append({'machine_id': machine, 'event_id': event,
                        'result': 'rejected', 'reason': self._machine_rejection, **selection})
                    break
                destination = requested
            compiled = {**compiled, 'target_scene': None}
            if terminal_order:
                compiled = {**compiled, 'target_state_index': None}
            old_fired = set(candidate._fired_timer_bindings)
            if machine is not None:
                candidate._state_index = candidate._machine_indexes[candidate._machine_states[machine]]
                if "target_state" in outcome and not terminal_order:
                    candidate._machine_states[machine] = outcome["target_state"]
                    candidate._machine_entered[machine] = candidate._machine_now(machine)
                    candidate._machine_activations[machine] += 1
            try:
                # Native flow-enabled transactions enter their destination before
                # actions; plain routes arm state timers after their actions.
                if not terminal_order and 'target_state' in outcome and candidate._machines.get('flowcharts'):
                    candidate._clear_machine_timers(machine)
                    old_fired = set(candidate._fired_timer_bindings)
                if (terminal_order or candidate._world_context is not None or candidate._machines.get('flowcharts') or any(a['kind'] in ('object.play_effect', 'scene.set_inversion', 'object.play_clip', 'object.cancel_clip') for a in outcome['actions'])) and compiled['target_scene'] is None:
                    from .flowcharts import execute_actions
                    result = candidate._execute_route({**compiled, 'operations': ()}, logical_source, event_kind, binding_id)
                    sends, flow_audio = list(prepared_sends), list(prepared_audio)
                    if candidate._world_context is not None:
                        system_action = candidate._world_context.execute(candidate, route, outcome_index, compiled,
                                        (logical_source, event_kind, binding_id), sends, flow_audio)
                    else:
                        system_action = execute_actions(candidate, outcome['actions'], compiled,
                                        (logical_source, event_kind, binding_id), sends, flow_audio)
                    if system_action and (queue or sends):
                        raise PreviewError('shell_exit_with_pending_events')
                    if len(queue) + len(sends) > queue_capacity or processed + len(queue) + len(sends) > chain_capacity:
                        raise PreviewError('event_queue_or_chain_capacity')
                    result = replace(result, audio_events=tuple(flow_audio), system_action=system_action)
                else:
                    result = candidate._execute_route(compiled, logical_source, event_kind, binding_id)
                if compiled['target_scene'] is None:
                    candidate._fired_timer_bindings = old_fired
                    if terminal_order and 'target_state' in outcome:
                        candidate._machine_states[machine] = outcome['target_state']
                        candidate._machine_entered[machine] = candidate._machine_now(machine)
                        candidate._machine_activations[machine] += 1
                        candidate._clear_machine_timers(machine)
                    elif "target_state" in outcome and not candidate._machines.get('flowcharts'):
                        candidate._clear_machine_timers(machine)
                    candidate._restore_primary()
                    candidate._render_framebuffer()
            except (PreviewError, ValueError) as exc:
                self._flow_trace = candidate._flow_trace
                self._flow_work = candidate._flow_work
                self._machine_rejection = str(exc)
                self._machine_trace.append({"machine_id": machine, "event_id": event, "result": "rejected",
                                            "reason": self._machine_rejection, **selection})
                break
            if len(audio) + len(result.audio_events) > 8:
                self._machine_rejection = "event_chain_audio_capacity"
                self._machine_trace.append({"machine_id": machine, "event_id": event, "result": "rejected",
                                            "reason": self._machine_rejection, **selection})
                break
            trace = [*self._machine_trace, {"machine_id": machine, "event_id": event,
                     "route_id": route["route_id"], "result": "applied", "sample": sample, **selection}]
            self.__class__ = type(candidate)
            self.__dict__.clear()
            self.__dict__.update(candidate.__dict__)
            audio.extend(result.audio_events)
            if processed == 1:
                root = replace(result, route_id=route["route_id"])
            elif result.system_action:
                root = replace(root, system_action=result.system_action)
            self._machine_trace = trace
            if _deferred_sends is None:
                queue.extend(sends)
            else:
                _deferred_sends.extend(sends)
            yield checkpoint(self, 'handler_complete', machine_id=machine, event_id=event, route_id=debug_route, queue=queue_snapshot(self, queue))
            if self._suspended:
                break
        if destination is not None and self._machine_rejection is None:
            yield checkpoint(self, 'lifecycle', operation='restart_scene' if destination == self.scene_id else 'change_scene', destination=destination)
            departure_type, departure = type(self), self.__dict__.copy()
            try:
                if self._suspended:
                    raise PreviewError('scene_exit_with_shell_suspend')
                inventory = self._scope_sources.get(self.scene_id, {}).get('_inventory_catalog')
                if destination == self.scene_id and inventory and inventory['reset_on_restart']:
                    # Only the admitted private candidate changes; a failed Scene
                    # replacement restores the departure state below.
                    self._inventory_state = dict(counts={}, collected=[])
                    self._package_variables = {k:v for k,v in self._package_variables.items()
                                               if k not in inventory['reset_variables']}
                result = yield from self._iterate_execute_route({'target_scene': destination, 'operations': (),
                    'route_id': root.route_id}, logical_source, event_kind, binding_id)
                if len(audio) + len(result.audio_events) > 8:
                    raise PreviewError('event_chain_audio_capacity')
                audio.extend(result.audio_events)
                root = replace(root, accepted=True)
                self._machine_trace = departure['_machine_trace']
            except (PreviewError, ValueError) as exc:
                self.__class__ = departure_type
                self.__dict__.clear()
                self.__dict__.update(departure)
                self._machine_rejection = str(exc)
        return replace(root, audio_events=tuple(audio))

    def _suspend_from_action(self):
        self.suspend()

    def _start_object_effect(self, action):
        from .object_effects import EffectTimeline, EffectSpec, INVERT, SHAKE
        ref = action['object_ref']
        effect = self._object_effects.get(ref, (None, None))[0] or EffectTimeline(self._effect_activation)
        completion = action.get('completion')
        spec = EffectSpec(INVERT if action['effect'] == 'invert' else SHAKE,
                          action['duration_ms'], action['step_ms'], action.get('amplitude', 0),
                          int(completion is not None))
        if effect.start(spec) != 0:
            raise PreviewError('effect start rejected')
        effect.pause(int(self._suspended or self._scope_held('objects', ref)))
        self._object_effects[ref] = (effect, (completion['machine_ref'], completion['event_ref']) if completion else None)
        self._completion_sequence += 1
        self._completion_order[('effect', ref)] = self._completion_sequence

    def _change_object_clip(self, action):
        from .object_clips import ClipTimeline, ClipSpec, RUNNING
        ref = action['object_ref']
        clip = self._one_shot_clips.get(ref, (None, None))[0]
        if action['kind'] == 'object.cancel_clip':
            if clip is not None:
                clip.cancel()
            return
        occupied = {key for key, (value, _) in self._one_shot_clips.items()
                    if value.state == RUNNING or value.pending or value.sample() is not None}
        if ref not in occupied and len(occupied) >= 8:
            raise PreviewError('one-shot clip capacity exceeded')
        animation = self._object_clips[action['animation_ref']]
        spec = ClipSpec(tuple(zip(animation['frame_refs'], animation['frame_duration_ms'])),
                        int(action['end_policy'] == 'hold_last'), int('completion' in action))
        clip = clip or ClipTimeline(self._effect_activation)
        if clip.start(spec) != 0:
            raise PreviewError('one-shot clip start rejected')
        clip.pause(int(self._suspended or self._scope_held('objects', ref)))
        completion = action.get('completion')
        self._one_shot_clips[ref] = (clip, (completion['machine_ref'], completion['event_ref']) if completion else None)
        self._completion_sequence += 1
        self._completion_order[('clip', ref)] = self._completion_sequence

    def suspend(self):
        if self._scope_menu is not None and self._scope_menu.pending is not None:
            from .scope_menu import abort
            abort(self, 'system_preempted')
        super().suspend()
        self._sync_timeline_pause()

    def resume(self):
        from .preview_steps import drain
        return drain(self.iterate_resume())

    def iterate_resume(self):
        was_suspended = self._suspended
        super().resume()
        self._sync_timeline_pause()
        if was_suspended:
            yield from self._iterate_reconcile_time()

    def _reconcile_time(self):
        from .preview_steps import drain
        return drain(self._iterate_reconcile_time())

    def _iterate_reconcile_time(self):
        binding = self._machines.get('time_reconcile')
        if binding and not self._suspended:
            result = yield from self._iterate_binding(None, 'TIME_RECONCILE', 'changed', binding['event_ref'])
            if self._machine_rejection:
                raise PreviewError('time reconciliation rejected: ' + self._machine_rejection)
            self.entry_audio_events.extend(result.audio_events)

    def set_local_time(self, local_time):
        super().set_local_time(local_time)
        self._reconcile_time()

    def _advance_visual(self, elapsed_ms):
        if self._scope_timing is not None:
            self._scope_timing.advance(elapsed_ms)
        for effect, _ in self._object_effects.values(): effect.advance(elapsed_ms)
        for clip, _ in self._one_shot_clips.values(): clip.advance(elapsed_ms)
        super()._advance_visual(elapsed_ms)
        self._restore_primary()

    def _iterate_execute_route(self, route, logical_source, event_kind, binding_id):
        if route['target_scene'] is not None:
            for machine in self._machines['machines']:
                if machine.get('retain_state', False):
                    self._retained_machine_states[(self.scene_id, machine['machine_id'])] = self._machine_states[machine['machine_id']]
        return (yield from super()._iterate_execute_route(route, logical_source, event_kind, binding_id))

    def _consume_timer(self, binding_index):
        binding = next((b for b in self._graph['event_bindings'] if b['binding_index'] == binding_index), None)
        if binding is None or binding['event_type'] == 'time.local_schedule' or binding['configuration'].get('mode') != 'periodic':
            return super()._consume_timer(binding_index)
        delay = binding['configuration']['delay_ms']
        if binding['event_type'] == 'time.scene_elapsed':
            deadlines = self._scene_timer_deadlines
            deadline = deadlines[binding_index]
        else:
            deadlines = self._periodic_state_deadlines
            owner = self._machines['timer_receivers'][binding['binding_id']]
            deadline = deadlines.get(binding_index, self._machine_entered[owner] + delay)
        # Preview transactions are synchronous; late samples skip missed periods.
        # Arm before actions so Start preserves cadence and Restart/Cancel win.
        deadlines[binding_index] = deadline + ((self._timer_now(binding_index) - deadline) // delay + 1) * delay

    def _next_state_timer(self):
        candidates = []
        from .object_effects import RUNNING, COMPLETE
        # Completion roots precede timers, then sort by object and start order.
        completions = []
        for kind, records in (('effect', self._object_effects), ('clip', self._one_shot_clips)):
            for ref, (effect, address) in records.items():
                pending = effect.pending if kind == 'clip' else effect.state == COMPLETE
                if address and not effect.paused and (effect.state == RUNNING or pending):
                    completions.append((ref, self._completion_order[(kind, ref)], kind, effect))
        for index, (ref, _, kind, effect) in enumerate(sorted(completions)):
            candidates.append((effect.spec.duration_ms - effect.elapsed_ms, index - len(completions),
                               ('clip', ref) if kind == 'clip' else ref))
        for binding in self._graph["event_bindings"]:
            index, ref = binding["binding_index"], binding["binding_id"]
            if self._scope_held('machines', self._machines['timer_receivers'][ref]):
                continue
            kind = binding["event_type"]
            if kind == "time.local_schedule":
                deadline = self._calendars[index].deadline
                if deadline is not None and self._local_ms is not None:
                    candidates.append((max(0, deadline - self._local_ms), index, ref))
            elif kind == "time.scene_elapsed":
                if index in self._scene_timer_deadlines:
                    candidates.append((max(0, self._scene_timer_deadlines[index] - self._timer_now(index)), index, ref))
            elif index not in self._fired_timer_bindings:
                machine = self._machines["timer_receivers"][ref]
                if any(r["event_ref"] == ref and self._machine_states[machine] in r["from_states"] for r in self._machines["routes"]):
                    deadline = self._periodic_state_deadlines.get(index,
                        self._machine_entered[machine] + binding["configuration"]["delay_ms"])
                    candidates.append((max(0, deadline - self._machine_now(machine)), index, ref))
        return min(candidates, key=lambda c: (c[0], c[1] in self._calendars,
                   self._calendars[c[1]].deadline if c[1] in self._calendars else 0, c[1])) if candidates else None

    def _resolved_element(self, model_index, element_index, element):
        ref = str(element["element_id"])
        override = {}
        active = set(self._machine_states.values())
        for state in self._object_source["states"]:
            if state["state_id"] in active:
                override.update(next((o for o in state["object_overrides"] if o["object_ref"] == ref), {}))
        definition = self._object_definitions[ref]
        elapsed = self._object_now(ref)
        selection = getattr(self, "_selector_visuals", {}).get(ref)
        live = self._object_live[ref]
        if selection is not None:
            kind, visual, origin = selection
            definition = dict(definition)
            live = dict(live)
            definition.pop("animation_ref", None)
            if kind == "animation_ref":
                definition["animation_ref"] = visual
                live["static_frame_ref"] = None
            else:
                live["static_frame_ref"] = visual
            elapsed -= origin
        resolved = dict(element)
        if definition["kind"] == "text":
            resolved.update({key: definition[key] for key in ("text", "font_id", "scale", "alignment")})
            if isinstance(definition['text'], list):
                from .presentation_text_source import resolved_source
                declarations, values = {}, {}
                for index, variable in enumerate(self._graph['variables']):
                    declared = self._scoped_variables[variable['variable_id']]
                    key = (declared['scope'], declared['variable_id'])
                    declarations[key] = declared
                    values[key] = bool(self._variables[index]) if declared['value_type'] == 'bool' else self._variables[index]
                resolved['text'] = resolved_source(definition, declarations, values)
            resolved["kind"] = 9
        resolved.update(resolve_object(definition, live, override,
                                       self._object_clips if self._include_waiting_visuals else {}, elapsed))
        if (self._scope_timing is not None and self._scope_timing.scope('objects', ref) == 'menu'
                and self._scope_input.scope != 'menu'):
            resolved['visible'] = 0  # Parent scope mask, not an authored child edit.
        if self._world_context is not None:
            position = self._world_context.position(ref)
            if position is not None:
                resolved['x'], resolved['y'] = position
                from .visibility_source import actor_visible
                if not actor_visible(self._world_context, ref):
                    # Parent mask only: never overwrite the child's live or
                    # State visibility. Screen-space objects are not members.
                    resolved['visible'] = 0
        clip = self._one_shot_clips.get(ref)
        if clip is not None and clip[0].sample() is not None:
            resolved['visual_ref'] = clip[0].sample()
        effect = self._object_effects.get(ref)
        if effect is not None:
            dx, dy, invert = effect[0].sample()
            resolved['x'] += dx
            resolved['y'] += dy
            resolved['_effect_invert'] = invert
        component=getattr(self,'_menu_component',None)
        if component is not None:
            from .menu_navigation import resolve_object as resolve_menu_object
            resolved=resolve_menu_object(component,self,ref,resolved)
        from .inventory_source import masked
        if masked(self, ref):
            resolved['visible'] = 0
        return resolved

    def _render_framebuffer(self):
        # Event-chain candidates are private. Resolve and render only after the
        # complete root transaction succeeds, while it can still roll back.
        if getattr(self, '_scope_dispatching', False):
            return self._framebuffer
        frame = super()._render_framebuffer()
        if self._scene_inverted:
            self._framebuffer = bytes(value ^ 255 for value in frame)
        if getattr(self, '_menu_component', None) is not None and self._menu_component.visible:
            self._framebuffer = self._menu_component.render(self)
        return self._framebuffer

    def _background_framebuffer(self):
        spatial = getattr(self._world_context, 'spatial', None)
        if spatial is None:
            return super()._background_framebuffer()
        context = self._world_context
        visibility = context.visibility
        key = (id(spatial), context.values[1, 0], context.values[2, 0],
               None if visibility is None else (visibility['world'],
                   tuple(sorted(visibility['layers'].items()))))
        cached = getattr(self, '_map_background_cache', None)
        if cached is None or cached[0] != key:
            cached = (key, bytes(spatial.render(context)))
            self._map_background_cache = cached
        # The immutable cached background must never receive sprite writes.
        return bytearray(cached[1])

    def snapshot(self, input_result=None):
        result = super().snapshot(input_result)
        if self._machine_primary is None:
            result['scene'].update(state_id=None, state_index=None, display_name=self._object_source['display_name'])
            result['scene_elapsed_ms'] = self._elapsed_ms
        result['scene_inverted'] = self._scene_inverted
        for obj in result.get("objects", []):
            selection = self._selector_visuals.get(obj["object_id"])
            if selection is None:
                continue
            kind, visual, origin = selection
            obj["playback"] = None
            if kind == "animation_ref":
                clip = self._object_clips[visual]
                remaining = (self._object_now(obj['object_id']) - origin) % sum(clip["frame_duration_ms"])
                for phase, duration in enumerate(clip["frame_duration_ms"]):
                    if remaining < duration:
                        obj["playback"] = dict(animation_ref=visual, phase_index=phase, remaining_ms=duration - remaining)
                        break
                    remaining -= duration
        result["machines"] = [{"machine_id": m["machine_id"], "display_name": m["display_name"],
                               "state_id": self._machine_states[m["machine_id"]],
                               "activation": self._machine_activations[m["machine_id"]],
                               "elapsed_ms": self._machine_now(m["machine_id"]) - self._machine_entered[m["machine_id"]]}
                              for m in self._machines["machines"]]
        from .response_preview import authored_trace
        result["machine_execution"] = {"seed": self._machine_seed, "trace": authored_trace(self._machine_trace),
                                       "rejection": self._machine_rejection}
        if self._scope_timing is not None:
            result['scope_timing'] = self._scope_timing.snapshot()
            result['scope_menu'] = self._scope_menu.snapshot()
        if self._menu_component is not None:
            result['menu_component'] = self._menu_component.snapshot(self)
        if self._inventory_state['counts']:
            result['inventory'] = deepcopy(self._inventory_state)
        instances = getattr(self._world_context, 'instance_snapshot', None)
        if instances is not None:
            result['instances'] = instances()
        if getattr(self._world_context, 'spatial', None) is not None:
            result['world'] = dict(camera=dict(x=self._world_context.values[1,0],
                                               y=self._world_context.values[2,0]))
            if self._world_context.camera is not None:
                result['world']['camera_component'] = deepcopy(self._world_context.camera)
            if self._world_context.visibility is not None:
                from .visibility_source import snapshot as visibility_snapshot
                result['world']['visibility'] = visibility_snapshot(self._world_context)
        if self._object_effects:
            result['object_effects'] = [dict(object_ref=ref, generation=e.generation,
                elapsed_ms=e.elapsed_ms, state=e.state, paused=bool(e.paused),
                sample=e.sample(), next_ms=e.next_ms(), awake=bool(e.awake()))
                for ref, (e, _) in sorted(self._object_effects.items())]
        if self._one_shot_clips:
            result['object_clips'] = [dict(object_ref=ref, generation=c.generation,
                elapsed_ms=c.elapsed_ms, state=c.state, paused=bool(c.paused), pending=bool(c.pending),
                frame_ref=c.sample(), next_ms=c.next_ms(), awake=bool(c.awake()))
                for ref, (c, _) in sorted(self._one_shot_clips.items())]
        if self._machines.get('flowcharts'):
            result['flowchart_execution'] = dict(trace=deepcopy(self._flow_trace), work=self._flow_work,
                                                rejection=self._machine_rejection)
        result['next_update_ms'] = self._next_preview_update(result)
        return result
