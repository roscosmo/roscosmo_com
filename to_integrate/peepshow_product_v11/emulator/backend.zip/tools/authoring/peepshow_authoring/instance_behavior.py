"""Private shared graph compilation, not project syntax or installed export.

Reuse the ordinary single-role machine source and route compiler. Property
operands are behavior-local names in declaration order, never world slots.
The enclosing Scene compiler still owns instance assignment and writer admission.
"""
from dataclasses import dataclass

from .instance_bindings import BehaviorBindings
from .machine_wire import require, MachinePayload
from .world_operands_wire import compile_operands
from .world_references import CompiledWorldReferences
from .world_routes import compile_world_machine_logic


@dataclass(frozen=True)
class CompiledBehavior:
    bindings: BehaviorBindings
    logic: MachinePayload
    operands: bytes


def compile_behavior(bundle, scene_id, bindings, guards, actions, attachments, *, queries=()):
    """Compile once, independent of instance count and property defaults.

    guards/actions are (operand ID, local property name, EQ..GE/SET/ADD, literal).
    attachments use the existing world-route insertion contract, preserving SEND
    order. Only named self-events and local property operations are admitted.
    No graph cloning per instance and no fabricated map/entity are required.
    """
    require(isinstance(bindings, BehaviorBindings) and
            type(bindings.behavior_id) is str and bool(bindings.behavior_id),
            'shared behavior binding declaration required')
    require(isinstance(bindings.properties, (tuple, list)), 'behavior properties must be an array')
    from .instance_bindings import BehaviorProperty
    names, local = {}, []
    for prop in bindings.properties:
        require(isinstance(prop, BehaviorProperty) and type(prop.name) is str and prop.name and
                prop.name not in names and prop.value_type in ('bool', 'int32') and
                type(prop.writable) is bool, 'invalid or duplicate behavior property')
        names[prop.name] = len(local)
        local.append((5, len(local), int(prop.value_type == 'bool'), 0 if prop.writable else 255))
    scene = next((s for s in bundle.scenes if s['scene_id'] == scene_id), None)
    require(scene is not None and 'machine_logic' in scene, 'behavior machine source required')
    graph = scene['machine_logic']
    require(len(graph['machines']) == 1, 'behavior requires one local role')
    role = graph['machines'][0]['machine_id']
    require(not scene.get('variables') and not bundle.project.get('package_variables') and
            not scene.get('input_actions') and not scene.get('event_bindings') and
            not graph.get('flowcharts') and not graph.get('world_references') and
            not graph.get('world_positions') and not graph.get('presentation_selectors'),
            'behavior subset excludes variables, input/timer bindings, flows and visual adapters')
    require(not graph.get('input_receivers') and not graph.get('timer_receivers') and
            not graph.get('scene_activated') and not graph.get('time_reconcile'),
            'behavior accepts explicitly addressed named events only')
    machine = graph['machines'][0]
    require(not machine.get('variable_writes') and not machine.get('object_writes') and
            not machine.get('effect_writes') and not machine.get('scene_writes') and
            not any(s.get('object_overrides') for s in scene['states']),
            'behavior cannot claim ordinary variable/object writers or visual overrides')
    for route in graph['routes']:
        require(route['machine_ref'] == role and not route['guards'] and
                not any(k in route for k in ('outcomes', 'target_scene', 'scene_exit_ref')),
                'behavior subset requires deterministic local routes and local property guards')
        for action in route['actions']:
            require(action.get('kind') == 'send_event' and action.get('machine_ref') == role,
                    'behavior actions must be property operations or named self SEND')

    def lower(rows, write):
        require(isinstance(rows, (tuple, list)), 'behavior operands must be an array')
        sources, lowered = [], []
        operations = {'SET': 1, 'ADD': 2, 'MOVE': 7} if write else {
            'EQ': 1, 'NE': 2, 'LT': 3, 'LE': 4, 'GT': 5, 'GE': 6}
        for row in rows:
            require(isinstance(row, (tuple, list)) and len(row) == 4, 'invalid behavior operand')
            identity, name, op, value = row
            require(type(identity) is str and identity and identity not in sources and
                    type(name) is str and (name in names or not write and name in query_names) and type(op) is str and op in operations,
                    'unknown or duplicate behavior operand')
            index = names[name] if name in names else len(local) + query_names.index(name)
            prop = bindings.properties[index] if name in names else BehaviorProperty(name, 'bool', False)
            if write and op == 'MOVE':
                require(type(value) is str and value in query_names and prop.writable,
                        'checked move requires a writable property and destination query')
                sources.append(identity)
                lowered.append((index, 7, query_names.index(value)))
                continue
            require(type(value) is (bool if prop.value_type == 'bool' else int),
                    'behavior literal has wrong type')
            require(not write or prop.writable, 'behavior property is read-only')
            sources.append(identity)
            lowered.append((index, operations[op], int(value)))
        return tuple(sources), lowered

    query_names, query_rows, occupancy = [], [], []
    for identity, x, y, width, height, dx, dy, actors in queries:
        require(identity not in names and identity not in query_names and x in names and y in names,
                'invalid or duplicate local collision query')
        adjacency = type(actors) is int and actors == 2
        facing = type(actors) is int and actors in (3, 4)
        absolute = type(actors) is int and actors in (5, 6)
        require(bindings.properties[names[x]].field == 'entity_x' and
                bindings.properties[names[y]].field == 'entity_y' and (type(actors) is bool or adjacency or facing or absolute),
                'collision query requires local entity coordinates and actor policy')
        if facing or absolute:
            require(bindings.properties[names[x]].owner == bindings.properties[names[y]].owner == 'self',
                    'destination requires Self coordinates')
        if facing:
            require(dx in names and bindings.properties[names[dx]].field == 'property' and
                    bindings.properties[names[dx]].owner == 'self', 'destination requires Self facing')
            dx = names[dx]
        if adjacency:
            require(dx in names and dy in names and
                bindings.properties[names[x]].owner == bindings.properties[names[y]].owner == 'self' and
                bindings.properties[names[dx]].owner == bindings.properties[names[dy]].owner == 'target' and
                bindings.properties[names[dx]].field == 'entity_x' and
                bindings.properties[names[dy]].field == 'entity_y',
                'adjacency requires Self and explicit Target coordinates')
            dx, dy = names[dx], names[dy]
        query_names.append(identity)
        query_rows.append((names[x], names[y], width, height, dx, dy))
        occupancy.append(int(actors))
    guard_ids, guard_rows = lower(guards, False)
    action_ids, action_rows = lower(actions, True)
    if queries:
        from .world_operands_wire import compile_query_operands
        operands = compile_query_operands(local, guard_rows, action_rows, query_rows, 1, occupancy=occupancy)
    else:
        operands = compile_operands(local, guard_rows, action_rows, 1)
    # Route compilation only consumes operand/source tables. No map is needed
    # for local operands; this record must never be passed to map/query lowering.
    local_world = CompiledWorldReferences(None, operands, tuple(names), guard_ids,
                                          action_ids, (role,), ())
    payload = compile_world_machine_logic(bundle, scene_id, local_world, attachments)
    require(not payload.effects and not payload.variables, 'unsupported behavior output')
    return CompiledBehavior(BehaviorBindings(bindings.behavior_id, tuple(bindings.properties)),
                            payload, operands)
