"""Opt-in v3 behavior ports, lowered onto existing queued outgoing events."""
from copy import deepcopy
from .imported_properties import ImportedPropertyError

CAPABILITY = dict(source_version=3, field='behaviors[].interface',
    schema='schemas/authoring/behavior-interface-v1.schema.json',
    fields=['inputs', 'outputs'], event_names='behavior.machine_logic.events',
    output_action='emit_output', output_event_field='event_ref',
    binding_field='outgoing', unbound_output='no_op',
    legacy_without_interface='unchanged', host_editing=True, host_preview=True,
    runtime=False, export=False, hardware_validation='not_qualified',
    preview_requires='all_scenes_have_map_scene_bindings',
    commands=['scene.machines.set'], persisted=True, undo_redo=True)


def ports(behavior):
    if 'interface' not in behavior:
        return None
    path = f"behavior[{behavior.get('behavior_id', '?')}].interface"
    value = behavior['interface']
    def fail(message):
        raise ImportedPropertyError(f'{path}: {message}')
    if type(value) is not dict or set(value) != {'inputs', 'outputs'}:
        fail('requires inputs and outputs')
    events = behavior.get('machine_logic', {}).get('events', [])
    named = {e.get('event_id') for e in events if type(e) is dict and type(e.get('event_id')) is str}
    for kind in ('inputs', 'outputs'):
        names = value[kind]
        if type(names) is not list or any(type(n) is not str or n not in named for n in names):
            fail(f'{kind} must name declared behavior events')
        if len(set(names)) != len(names):
            fail(f'duplicate {kind}')
    if set(value['inputs']) & set(value['outputs']):
        fail('an event cannot be both input and output')
    return value


def lower_behavior(behavior, version):
    """Copy before removing author-only roles and translating output actions."""
    result = deepcopy(behavior)
    declared = ports(result)
    if declared is not None and version != 3:
        raise ImportedPropertyError('behavior interface requires source version 3')
    outputs = set(declared['outputs']) if declared else set()
    for route in result.get('machine_logic', {}).get('routes', []):
        path = f"behavior[{result.get('behavior_id', '?')}].routes[{route.get('route_id', '?')}]"
        if route.get('event_ref') in outputs:
            raise ImportedPropertyError(f'{path}: output events cannot have local handlers')
        for action in route.get('actions', []):
            if action.get('kind') == 'emit_output':
                if set(action) != {'kind', 'event_ref'} or type(action['event_ref']) is not str or action['event_ref'] not in outputs:
                    raise ImportedPropertyError(f'{path}: emit_output requires a declared output')
                action.update(kind='send_event', machine_ref='self')
            elif declared is not None and action.get('kind') == 'send_event' and action.get('event_ref') in outputs:
                raise ImportedPropertyError(f'{path}: use emit_output for declared outputs')
    result.pop('interface', None)
    return result


def validate_bindings(source):
    """Enforce ports for legacy bridges too, not only the new send syntax."""
    definitions = {b['behavior_id']: b for b in source['behaviors']}
    instances = {i['instance_id']: definitions.get(i['behavior_ref']) for i in source['instances']}
    def check(instance, event, kind):
        behavior = instances.get(instance)
        if behavior is None:
            raise ImportedPropertyError(f'unknown instance {instance!r}')
        declared = ports(behavior)
        if declared is not None and event not in declared[kind]:
            raise ImportedPropertyError(f'instance[{instance}]: {event!r} is not in declared {kind}')
    for bridge in source['bridges']:
        if 'interaction_targets' in bridge.get('query', {}):
            for target in bridge['query']['interaction_targets']:
                check(target['instance_ref'], target['input_event_ref'], 'inputs')
            continue
        targets = bridge['query']['eligible'] if 'query' in bridge else [bridge['instance_ref']]
        for target in targets:
            check(target, bridge['target_event_ref'], 'inputs')
    for output in source.get('outgoing', []):
        check(output['instance_ref'], output['event_ref'], 'outputs')
