"""Project-local actor templates; expanded ordinary Scene source stays inspectable."""
from copy import deepcopy

COMMANDS = ('project.actor_template.capture', 'project.actor_template.update_from_actor',
    'project.actor_template.remove', 'scene.actor_template.place',
    'scene.actor_template.set_bindings', 'scene.actor_template.override',
    'scene.actor_template.reset_override', 'scene.actor_template.make_independent',
    'scene.actor_template.link')
GROUPS = ('properties', 'objects', 'occupancy', 'interactions', 'selectors',
          'output_responses', 'outputs', 'state_overrides')
CAPABILITY = dict(version=1, commands=list(COMMANDS),
    inspection='project.actor_template.inspect', field='project.actor_templates',
    schema='schemas/authoring/actor-templates-v1.schema.json',
    command_schema='schemas/authoring/actor-template-command-v1.schema.json',
    host_editing=True, host_preview=True, persisted=True, undo_redo=True,
    runtime=False, export=False, maximum_templates=32, maximum_placements=128,
    override_groups=list(GROUPS), override_granularity='explicit_component_group',
    update='explicit_apply_from_valid_placed_actor', capture_update_standalone=True,
    placement='explicit_named_external_bindings', incoming_connections='authored_separately',
    behavior_sharing='existing_scene_definition_or_explicitly_copied_definition',
    nested_templates=False, runtime_spawning=False)
FIELDS = ('properties', 'geometry', 'instance', 'objects', 'references', 'positions',
          'selectors', 'occupancy', 'interactions', 'outputs', 'output_responses',
          'state_overrides', 'writers')
BINDING_KEYS = dict(writer_ref='machine', machine_ref='machine', flow_ref='flow',
    instance_ref='actor', owner_id='entity', entity_ref='entity', target_ref='entity',
    reference_ref='world_reference', source_ref='world_reference', x_ref='world_reference',
    y_ref='world_reference', variable_ref='variable', scene_state_ref='scene_state')


def require(ok, message):
    if not ok:
        from .project import ProjectCommandError
        raise ProjectCommandError('ACTOR_TEMPLATE_INVALID', message)


def library(project):
    return project.get('actor_templates', dict(version=1, definitions=[], placements=[]))


def definition(project, identity):
    value = next((t for t in library(project)['definitions'] if t['template_id'] == identity), None)
    require(value is not None, 'Unknown actor template: ' + str(identity))
    return value


def link(project, scene_id, identity):
    value = next((p for p in library(project)['placements']
                  if (p['scene_id'], p['instance_ref']) == (scene_id, identity)), None)
    require(value is not None, 'Actor is not linked to a template')
    return value


def mappings(entity, identity, objects, refs, selectors, asset):
    return dict(instance_id={'@self': identity}, instance_ref={'@self': identity},
        owner_id={'@entity': entity}, entity_ref={'@entity': entity},
        object_id=objects, object_ref=objects, reference_id=refs, reference_ref=refs,
        source_ref=refs, x_ref=refs, y_ref=refs, selector_id=selectors, asset_id={'@map': asset})


def capture(scene, catalogs, identity):
    """Copy owned source, never current preview state or incoming game policy."""
    from .actor_assembly import assembly, property_defaults, remap
    from .actor_removal import inspection
    a = assembly(scene, catalogs, identity)
    require(inspection(scene, a)['supported'], 'Unsupported actor assembly for template capture')
    g, s = a['graph'], a['graph']['instance_behaviors']
    objects = [o for o in scene['objects'] if o['object_id'] in a['visuals']]
    own = mappings(a['instance']['entity']['owner_id'], identity,
        {f'@visual{i}': o['object_id'] for i, o in enumerate(objects)},
        {f'@ref{i}': r['reference_id'] for i, r in enumerate(a['refs'])},
        {f'@selector{i}': r['selector_id'] for i, r in enumerate(a['selectors'])}, a['config']['asset_ref'])
    body = dict(properties=property_defaults(a),
        geometry={k: a['placement'].get(k, 0) for k in ('width', 'height')},
        instance=deepcopy(a['instance']), objects=objects, references=a['refs'],
        positions=a['positions'], selectors=a['selectors'],
        occupancy=[r for r in a['config']['occupancy'] if r['entity_ref'] == a['instance']['entity']['owner_id']],
        interactions=[r for r in g.get('interactables', []) if r['instance_ref'] == identity],
        outputs=[r for r in s.get('outgoing', []) if r['instance_ref'] == identity],
        output_responses=deepcopy(a['instance'].get('output_responses', [])),
        state_overrides=[dict(scene_state_ref=state['state_id'], objects=[
            r for r in state['object_overrides'] if r['object_ref'] in a['visuals']])
            for state in scene['states'] if any(r['object_ref'] in a['visuals'] for r in state['object_overrides'])],
        writers=[])
    body['instance'].pop('output_responses', None)
    for group, key in (('machines', 'machine_ref'), ('flowcharts', 'flow_ref')):
        for owner in g.get(group, []):
            writes = [r for r in owner['object_writes'] if r['object_ref'] in a['visuals']]
            effects = [dict(object_ref=r) for r in owner.get('effect_writes', []) if r in a['visuals']]
            if writes or effects:
                body['writers'].append({key: owner['machine_id'] if key == 'machine_ref' else owner['flowchart_id'],
                                        'writes': writes, 'effects': effects})
    body = remap(body, {key: {v:k for k,v in values.items()} for key, values in own.items()})
    behavior = next(b for b in s['behaviors'] if b['behavior_id'] == a['instance']['behavior_ref'])
    return body, own, deepcopy(behavior), dict(width=a['config']['cell_width'], height=a['config']['cell_height'])


def externalize(body, labels=None):
    """External references become named, typed slots with exact source paths."""
    body = deepcopy(body)
    slots, values, by_value = [], {}, {}
    pending = [((), body)]
    while pending:
        path, value = pending.pop()
        if type(value) is dict:
            for key, item in value.items():
                location = path + (key,)
                if key in BINDING_KEYS and type(item) is str and not item.startswith('@'):
                    kind = BINDING_KEYS[key]
                    pair = (kind, item)
                    if pair not in by_value:
                        name = f'{kind}_{len(slots) + 1}'
                        by_value[pair] = name
                        slots.append(dict(binding_id=name, kind=kind, label=(labels or {}).get(pair,item), paths=[]))
                        values[name] = item
                    name = by_value[pair]
                    next(s for s in slots if s['binding_id'] == name)['paths'].append(list(location))
                    value[key] = None
                elif type(item) in (dict, list):
                    pending.append((location, item))
        elif type(value) is list:
            pending.extend((path + (i,), item) for i, item in enumerate(value))
    return body, slots, values


def binding_labels(scene, catalogs):
    """Supply author names so a client need not display map IDs as labels."""
    from .scene_map_entities import materialize
    g = scene['machine_logic']
    config = g['map_scene']
    imported = next(r for c in catalogs for r in c.get('map_assets', []) if r['asset_id'] == config['asset_ref'])
    record = materialize(imported,config)
    entities = {'object:' + str(o['id']):o.get('name','') or 'Object ' + str(o['id'])
        for layer in record['snapshot']['layers'] if layer['type']=='objectgroup' for o in layer['objects']}
    labels = {('entity',ref):name for ref,name in entities.items()}
    for kind, rows, identity in (('machine',g['machines'],'machine_id'),
                                ('flow',g.get('flowcharts',[]),'flowchart_id'),
                                ('scene_state',scene['states'],'state_id')):
        labels.update({(kind,r[identity]):r.get('display_name',r[identity]) for r in rows})
    labels.update({('actor',i['instance_id']):entities.get(i['entity']['owner_id'],i['instance_id'])
                   for i in g['instance_behaviors']['instances']})
    for r in g['world_references']:
        target = r['target']
        labels[('world_reference',r['reference_id'])] = entities.get(target.get('owner_id'),'World') + '.' + target.get('property_id',target.get('field','value'))
    return labels


def at(root, path):
    for key in path:
        root = root[key]
    return root


def resolved(template, placement):
    body = deepcopy(template['components'])
    body.update(deepcopy(placement['overrides']))
    require(type(placement['bindings']) is dict and set(placement['bindings']) == {s['binding_id'] for s in template['bindings']},
            'Supply every named external binding; no receiver is inferred')
    for slot in template['bindings']:
        value = placement['bindings'][slot['binding_id']]
        require(type(value) is str and value and not value.startswith('@'), 'Invalid external binding ' + slot['binding_id'])
        for path in slot['paths']:
            # Overrides retain the same declared slots. Deleting/reordering a slot
            # is an interface change, not an implicit rebinding.
            parent = at(body, path[:-1])
            require(parent[path[-1]] is None, 'Override must retain declared binding slot ' + slot['binding_id'])
            parent[path[-1]] = value
    return body


def shape(body):
    """Stable owned identities keep incoming actions and references intact."""
    return ([o['object_id'] for o in body['objects']],
            [r['reference_id'] for r in body['references']],
            [s['selector_id'] for s in body['selectors']], body['instance']['behavior_ref'])


def replace_rows(rows, predicate, incoming):
    incoming = list(deepcopy(incoming))
    result = []
    for row in rows:
        if predicate(row):
            if incoming:
                result.append(incoming.pop(0))
        else:
            result.append(row)
    result.extend(incoming)
    rows[:] = result


def install(scene, catalogs, template, placement, *, position=None):
    from .actor_assembly import remap, point
    from .scene_map_entities import materialize
    g = scene['machine_logic']
    require('execution_scopes' not in g, 'Explicit execution-scope assemblies are unsupported')
    config, source = g['map_scene'], g['instance_behaviors']
    require(source['version'] == 3 and not source['bridges'], 'Templates require V3 direct behavior inputs')
    require(template['grid'] == dict(width=config['cell_width'], height=config['cell_height']),
            'Template grid differs from destination map grid')
    body = resolved(template, placement)
    identity = placement['instance_ref']
    existing = next((i for i in source['instances'] if i['instance_id'] == identity), None)
    if existing:
        old, own, _, _ = capture(scene, catalogs, identity)
        require(shape(old) == shape(body), 'Changing owned member identities requires an independent copy')
        local = next(o for o in config['local_entities'] if 'object:' + str(o['id']) == existing['entity']['owner_id'])
    else:
        imported = next(r for c in catalogs for r in c.get('map_assets', []) if r['asset_id'] == config['asset_ref'])
        record = materialize(imported, config)
        x, y = point(position, dict(record=record, config=config))
        oid = max((o['id'] for l in record['snapshot']['layers'] if l['type'] == 'objectgroup' for o in l['objects']), default=0) + 1
        local = dict(id=oid, name=identity, x=x, y=y, width=0, height=0, properties=[])
        own = mappings('object:' + str(oid), identity,
            {o['object_id']: identity if len(body['objects']) == 1 else identity + '.visual' + str(i)
             for i,o in enumerate(body['objects'])},
            {r['reference_id']: identity + '.ref' + str(i) for i,r in enumerate(body['references'])},
            {s['selector_id']: identity + '.selector' + str(i) for i,s in enumerate(body['selectors'])}, config['asset_ref'])
        from .project import STABLE_ID
        for key, used in (('object_id', {o['object_id'] for o in scene['objects']}),
                          ('reference_id', {r['reference_id'] for r in g['world_references']}),
                          ('selector_id', {r['selector_id'] for r in g.get('presentation_selectors', [])})):
            require(all(STABLE_ID.fullmatch(n) and n not in used for n in own[key].values()), 'Actor member identity conflict')
        config.setdefault('local_entities', []).append(local)
    data = remap(body, own)
    behavior = next((b for b in source['behaviors'] if b['behavior_id'] == template['behavior']['behavior_id']), None)
    if behavior is None:
        source['behaviors'].append(deepcopy(template['behavior']))
    else:
        require(behavior == template['behavior'], 'Destination shared behavior differs; update that definition explicitly first')
    local.update(data['geometry'], properties=data['properties'])
    instance = data['instance']
    if data['output_responses']:
        instance['output_responses'] = data['output_responses']
    visuals, refs = set(own['object_id'].values()), set(own['reference_id'].values())
    entity = own['owner_id']['@entity']
    replace_rows(scene['objects'], lambda r:r['object_id'] in visuals, data['objects'])
    for key, members, predicate in (
        ('world_references', 'references', lambda r:r['reference_id'] in refs),
        ('world_positions', 'positions', lambda r:r['object_ref'] in visuals),
        ('presentation_selectors', 'selectors', lambda r:r['object_ref'] in visuals),
        ('interactables', 'interactions', lambda r:r['instance_ref'] == identity)):
        replace_rows(g.setdefault(key, []), predicate, data[members])
    replace_rows(config['occupancy'], lambda r:r['entity_ref'] == entity, data['occupancy'])
    replace_rows(source['instances'], lambda r:r['instance_id'] == identity, [instance])
    replace_rows(source.setdefault('outgoing', []), lambda r:r['instance_ref'] == identity, data['outputs'])
    states = {s['state_id']:s for s in scene['states']}
    require(all(r['scene_state_ref'] in states for r in data['state_overrides']), 'Unknown bound Scene State')
    for state in scene['states']:
        row = next((r for r in data['state_overrides'] if r['scene_state_ref'] == state['state_id']), None)
        replace_rows(state['object_overrides'], lambda r:r['object_ref'] in visuals, row['objects'] if row else [])
    for group, key, id_key in (('machines','machine_ref','machine_id'), ('flowcharts','flow_ref','flowchart_id')):
        owners = {o[id_key]:o for o in g.get(group, [])}
        require(all(r[key] in owners for r in data['writers'] if key in r), 'Unknown presentation writer')
        for owner in owners.values():
            row = next((r for r in data['writers'] if r.get(key) == owner[id_key]), None)
            replace_rows(owner['object_writes'], lambda r:r['object_ref'] in visuals, row['writes'] if row else [])
            if row and row['effects'] or 'effect_writes' in owner:
                replace_rows(owner.setdefault('effect_writes', []), lambda r:r in visuals,
                             [r['object_ref'] for r in row['effects']] if row else [])


def inspect_source(project, template_ref=None):
    lib = deepcopy(library(project))
    if template_ref is not None:
        lib['definitions'] = [deepcopy(definition(project, template_ref))]
        lib['placements'] = [p for p in lib['placements'] if p['template_ref'] == template_ref]
    return lib


def sync_target_binding(project, scenes, catalogs, command):
    """The ordinary target picker is also an explicit linked binding edit."""
    if command['kind'] != 'scene.actor.set_bindings' or 'target_entity_ref' not in command['bindings']:
        return
    p = next((p for p in library(project)['placements']
              if (p['scene_id'],p['instance_ref']) == (command['scene_id'],command['instance_ref'])), None)
    if p is None:
        return
    require(set(command['bindings']) == {'target_entity_ref'},
            'Edit linked target separately; other template components use explicit overrides')
    template = definition(project,p['template_ref'])
    slots = [s for s in template['bindings'] if ['instance','target','owner_id'] in s['paths']]
    require(len(slots) == 1, 'No declared target binding exists in this template')
    p['bindings'][slots[0]['binding_id']] = command['bindings']['target_entity_ref']
    from .project import _command_scene
    install(_command_scene(scenes,p['scene_id']),catalogs,template,p)


def validate(project, scenes, catalogs, *, frames=None, animations=None, audio=None):
    """Stored links must exactly describe their ordinary, expanded source."""
    if 'actor_templates' not in project:
        return
    lib = project['actor_templates']
    require(type(lib) is dict and set(lib) == {'version','definitions','placements'} and lib['version'] == 1,
            'Expected actor template library version 1')
    require(type(lib['definitions']) is list and len(lib['definitions']) <= 32 and
            type(lib['placements']) is list and len(lib['placements']) <= 128, 'Template library capacity exceeded')
    from .project import STABLE_ID
    ids = set()
    for t in lib['definitions']:
        require(type(t) is dict and set(t) == {'template_id','display_name','grid','behavior','components','bindings'}, 'Malformed template definition')
        require(type(t['template_id']) is str and STABLE_ID.fullmatch(t['template_id']) and t['template_id'] not in ids, 'Duplicate/invalid template identity')
        ids.add(t['template_id'])
        require(type(t['display_name']) is str and 0 < len(t['display_name']) <= 96, 'Invalid template display name')
        require(type(t['components']) is dict and set(t['components']) == set(FIELDS), 'Malformed template components')
        body = t['components']
        require(type(t['grid']) is dict and set(t['grid']) == {'width','height'} and
                all(type(v) is int and v > 0 for v in t['grid'].values()), 'Invalid template grid')
        require(type(body['geometry']) is dict and set(body['geometry']) == {'width','height'} and
                all(type(v) is int and v >= 0 for v in body['geometry'].values()), 'Invalid actor geometry')
        require(all(type(body[k]) is list for k in FIELDS if k not in ('geometry','instance')),
                'Actor component groups must be arrays')
        require(body['objects'] and body['positions'] and type(body['instance']) is dict and
                body['instance']['instance_id'] == '@self', 'Missing actor members')
        require(type(t['behavior']) is dict and t['behavior']['behavior_id'] == body['instance']['behavior_ref'],
                'Template behavior identity mismatch')
        for rows, field, prefix in ((body['objects'],'object_id','@visual'),
                                   (body['references'],'reference_id','@ref'),
                                   (body['selectors'],'selector_id','@selector')):
            require([r[field] for r in rows] == [prefix + str(i) for i in range(len(rows))],
                    'Owned member roles must remain stable and ordered')
        pending = [body, t['behavior']]
        resources = {'visual_ref':frames, 'animation_ref':animations, 'cue_ref':audio}
        while pending:
            value = pending.pop()
            if type(value) is dict:
                for key, item in value.items():
                    if key in resources and resources[key] is not None and item is not None:
                        require(type(item) is str and item in resources[key],
                                f'{t["template_id"]}: missing shared asset {item}')
                    if type(item) in (dict,list):
                        pending.append(item)
            elif type(value) is list:
                pending.extend(value)
        require(type(t['bindings']) is list and len(t['bindings']) <= 64, 'Invalid binding interface')
        names, paths = set(), set()
        for slot in t['bindings']:
            require(type(slot) is dict and set(slot) == {'binding_id','kind','label','paths'}, 'Malformed binding slot')
            name = slot['binding_id']
            require(type(name) is str and STABLE_ID.fullmatch(name) and name not in names and
                    slot['kind'] in set(BINDING_KEYS.values()), 'Invalid named binding')
            names.add(name)
            require(type(slot['paths']) is list and slot['paths'], 'Empty binding slot')
            for path in slot['paths']:
                require(type(path) is list and path and all(type(k) is str or type(k) is int and k >= 0 for k in path), 'Invalid binding path')
                require(tuple(path) not in paths and BINDING_KEYS.get(path[-1]) == slot['kind'] and
                        at(t['components'], path) is None, 'Invalid binding location')
                paths.add(tuple(path))
    seen = set()
    by_scene = {s['scene_id']:s for s in scenes}
    for p in lib['placements']:
        require(type(p) is dict and set(p) == {'scene_id','instance_ref','template_ref','bindings','overrides'}, 'Malformed linked placement')
        key = (p['scene_id'],p['instance_ref'])
        require(key not in seen and p['scene_id'] in by_scene, 'Duplicate or missing template placement Scene')
        seen.add(key)
        require(type(p['overrides']) is dict and not set(p['overrides']) - set(GROUPS), 'Unknown override group')
        expected = resolved(definition(project, p['template_ref']), p)
        actual, _, _, actual_grid = capture(by_scene[p['scene_id']], catalogs, p['instance_ref'])
        require(actual_grid == definition(project,p['template_ref'])['grid'], 'Linked template grid differs from its Scene')
        require(actual == expected, f'{p["scene_id"]}/{p["instance_ref"]}: linked setup changed; use an explicit override or Make independent')


def apply_command(project, scenes, catalogs, command):
    from .project import _require_command_fields, _command_scene, STABLE_ID
    kind = command['kind']
    capture_kind = kind in COMMANDS[:2]
    required = {'kind'}
    optional = set()
    if capture_kind:
        required |= {'scene_id','instance_ref','template_id'}
        if kind.endswith('.capture'):
            required.add('display_name')
    elif kind == 'project.actor_template.remove':
        required.add('template_ref')
    elif kind == 'scene.actor_template.place':
        required |= {'scene_id','template_ref','instance_id','position','bindings'}
    elif kind == 'scene.actor_template.link':
        required |= {'scene_id','template_ref','instance_ref','bindings'}
    else:
        required |= {'scene_id','instance_ref'}
        if kind.endswith('.set_bindings'):
            required.add('bindings')
        if kind.endswith('.override'):
            required |= {'group','value'}
        if kind.endswith('.reset_override'):
            required.add('group')
    _require_command_fields(command, required, required | optional | {'command_id'})
    lib = project.setdefault('actor_templates', dict(version=1, definitions=[], placements=[]))
    result = deepcopy(command)
    if capture_kind:
        scene = _command_scene(scenes, command['scene_id'])
        body, _, behavior, grid = capture(scene, catalogs, command['instance_ref'])
        body, slots, bindings = externalize(body, binding_labels(scene,catalogs))
        identity = command['template_id']
        require(type(identity) is str and STABLE_ID.fullmatch(identity), 'Invalid template identity')
        if kind.endswith('.capture'):
            require(not any(t['template_id'] == identity for t in lib['definitions']), 'Template identity already exists')
            lib['definitions'].append(dict(template_id=identity, display_name=command['display_name'],
                components=body, bindings=slots, behavior=behavior, grid=grid))
        else:
            old = definition(project, identity)
            # Binding names are stable across Apply from a differently named actor.
            require([(r['kind'],r['paths']) for r in old['bindings']] == [(r['kind'],r['paths']) for r in slots]
                    and shape(old['components']) == shape(body), 'Template interface changed; keep bindings/member roles stable or create another template')
            for before, after in zip(old['bindings'], slots):
                after['binding_id'], after['label'] = before['binding_id'], before['label']
            old.update(components=body, bindings=slots, behavior=behavior, grid=grid)
            for p in lib['placements']:
                if p['template_ref'] == identity:
                    install(_command_scene(scenes,p['scene_id']), catalogs, old, p)
        result['suggested_bindings'] = bindings
    elif kind == 'project.actor_template.remove':
        identity = command['template_ref']
        definition(project, identity)
        require(not any(p['template_ref'] == identity for p in lib['placements']), 'Template still has linked placements; detach or remove them explicitly')
        lib['definitions'][:] = [t for t in lib['definitions'] if t['template_id'] != identity]
    elif kind in ('scene.actor_template.place', 'scene.actor_template.link'):
        placing = kind.endswith('.place')
        identity = command['instance_id' if placing else 'instance_ref']
        require(type(identity) is str and STABLE_ID.fullmatch(identity), 'Invalid actor identity')
        scene = _command_scene(scenes, command['scene_id'])
        exists = any(i['instance_id'] == identity for i in scene['machine_logic']['instance_behaviors']['instances'])
        require(not exists if placing else exists, 'Actor identity already exists or is missing')
        require(not any((p['scene_id'],p['instance_ref']) == (scene['scene_id'],identity) for p in lib['placements']), 'Actor is already linked')
        p = dict(scene_id=scene['scene_id'], instance_ref=identity, template_ref=command['template_ref'],
                 bindings=deepcopy(command['bindings']), overrides={})
        if placing:
            install(scene, catalogs, definition(project,p['template_ref']), p, position=command['position'])
        else:
            from .actor_assembly import inspect_source as inspect_actor
            require(inspect_actor(scene,catalogs,identity)['scene_local'], 'Link requires a Scene-local actor; imported map markers remain map-owned')
            template = definition(project,p['template_ref'])
            _, _, behavior, grid = capture(scene,catalogs,identity)
            require(behavior == template['behavior'] and grid == template['grid'],
                    'Link requires the same behavior definition and map grid')
        lib['placements'].append(p)
    else:
        p = link(project,command['scene_id'],command['instance_ref'])
        if kind.endswith('.make_independent'):
            lib['placements'].remove(p)
        else:
            if kind.endswith('.set_bindings'):
                require(type(command['bindings']) is dict, 'Expected named bindings')
                p['bindings'].update(deepcopy(command['bindings']))
            else:
                group = command['group']
                require(group in GROUPS, 'Unknown override group')
                if kind.endswith('.reset_override'):
                    require(group in p['overrides'], 'No override exists for ' + group)
                    del p['overrides'][group]
                else:
                    p['overrides'][group] = deepcopy(command['value'])
            install(_command_scene(scenes,p['scene_id']), catalogs, definition(project,p['template_ref']),p)
    return result
