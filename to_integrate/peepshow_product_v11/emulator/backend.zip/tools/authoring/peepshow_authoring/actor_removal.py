"""Remove a placed actor's authored components without deleting shared resources."""
from copy import deepcopy


def at(root, path):
    for key in path:
        root = root[key]
    return root


def parts(scene, actor):
    """Exact array members owned by the placement, in the current source revision."""
    g = ['machine_logic']
    entity = actor['instance']['entity']['owner_id']
    identity = actor['instance']['instance_id']
    visuals = actor['visuals']
    refs = {r['reference_id'] for r in actor['refs']}
    result = []

    def add(path, predicate):
        rows = at(scene, path)
        indices = [i for i, row in enumerate(rows) if predicate(row)]
        if indices:
            result.append((path, indices))

    add(['objects'], lambda r: r['object_id'] in visuals)
    for field, predicate in (
        ('world_positions', lambda r: r['object_ref'] in visuals),
        ('world_references', lambda r: r['reference_id'] in refs),
        ('presentation_selectors', lambda r: r['object_ref'] in visuals),
        ('interactables', lambda r: r['instance_ref'] == identity),
    ):
        if field in actor['graph']:
            add(g + [field], predicate)
    add(g + ['map_scene', 'occupancy'], lambda r: r['entity_ref'] == entity)
    if 'local_entities' in actor['config']:
        add(g + ['map_scene', 'local_entities'], lambda r: r['id'] == actor['placement']['id'])
    add(g + ['instance_behaviors', 'instances'], lambda r: r['instance_id'] == identity)
    if 'outgoing' in actor['graph']['instance_behaviors']:
        add(g + ['instance_behaviors', 'outgoing'], lambda r: r['instance_ref'] == identity)
    for i, state in enumerate(scene['states']):
        add(['states', i, 'object_overrides'], lambda r: r['object_ref'] in visuals)
    for group in ('machines', 'flowcharts'):
        for i, owner in enumerate(actor['graph'].get(group, [])):
            add(g + [group, i, 'object_writes'], lambda r: r['object_ref'] in visuals)
            if 'effect_writes' in owner:
                add(g + [group, i, 'effect_writes'], lambda r: r in visuals)
    from .actor_assembly import action_lists, owns_actions
    for path, _ in action_lists(actor['graph']):
        if owns_actions(actor['graph'], path, identity):
            continue
        add(path, lambda r: r.get('instance_ref') == identity or r.get('object_ref') in visuals)
    return result


def dependencies(scene, actor, owned):
    """Return references outside owned parts and explicitly removable connections."""
    refs = {r['reference_id'] for r in actor['refs']}
    entity = {actor['instance']['entity']['owner_id']}
    identities = {
        'instance_ref': ('instance', {actor['instance']['instance_id']}),
        'object_ref': ('object', actor['visuals']),
        'entity_ref': ('entity', entity), 'target_ref': ('entity', entity),
        'owner_id': ('entity', entity),
        **{key: ('world_reference', refs) for key in
           ('reference_ref', 'source_ref', 'x_ref', 'y_ref', 'facing_ref')},
    }
    skipped = {tuple(path + [index]) for path, indices in owned for index in indices}
    # Shared definitions have their own local object/property namespaces.
    skipped.add(('machine_logic', 'instance_behaviors', 'behaviors'))
    skipped.add(('machine_logic', 'layout'))
    result, pending = [], [((), scene)]
    while pending:
        path, value = pending.pop()
        if path in skipped:
            continue
        if type(value) is dict:
            for key, item in value.items():
                if key in identities and type(item) is str:
                    kind, names = identities[key]
                    if item in names:
                        result.append(dict(source_path=list(path) + [key], reference_kind=kind, reference=item))
                if type(item) in (dict, list):
                    pending.append((path + (key,), item))
        elif type(value) is list:
            if path and path[-1] == 'eligible':
                for i, item in enumerate(value):
                    if item == actor['instance']['instance_id']:
                        result.append(dict(source_path=list(path) + [i], reference_kind='instance', reference=item))
            pending.extend((path + (i,), item) for i, item in enumerate(value))
    return sorted(result, key=lambda r: repr(r['source_path']))


def inspection(scene, actor):
    source, graph = actor['graph']['instance_behaviors'], actor['graph']
    unsupported = []
    if source['bridges']:
        unsupported.append('legacy_event_bridges')
    if 'execution_scopes' in graph:
        unsupported.append('explicit_execution_scopes')
    if any(p['object_ref'] in actor['visuals'] for p in scene.get('pickups', [])):
        unsupported.append('pickup_components')
    if set(scene.get('menu_component', {}).get('scope', {}).get('objects', [])) & actor['visuals']:
        unsupported.append('menu_owned_objects')
    owned = parts(scene, actor)
    blockers = dependencies(scene, actor, owned)
    return dict(supported=not unsupported, unsupported=unsupported,
        blocked=bool(blockers or unsupported), blockers=blockers,
        requires_connection_removal=bool(actor['incoming']),
        connection_count=len(actor['incoming']),
        imported_marker_retained=not any(o['id'] == actor['placement']['id']
            for o in actor['config'].get('local_entities', [])))


def remove(scene, actor, command):
    from .actor_assembly import require
    from .project import ProjectCommandError
    require(type(command['remove_connections']) is bool, 'remove_connections must explicitly be true or false')
    report = inspection(scene, actor)
    require(report['supported'], 'Unsupported actor removal: ' + ', '.join(report['unsupported']))
    if report['blockers']:
        row = report['blockers'][0]
        raise ProjectCommandError('ACTOR_ASSEMBLY_REFERENCED',
            f"{row['source_path']}: still references {row['reference']}; retarget or remove this dependency first")
    if report['requires_connection_removal'] and not command['remove_connections']:
        row = actor['incoming'][0]
        raise ProjectCommandError('ACTOR_ASSEMBLY_REFERENCED',
            f"{row['source_path']}: actor has incoming actions; explicitly choose remove_connections")
    for path, indices in sorted(parts(scene, actor), key=lambda part: -len(part[0])):
        rows = at(scene, path)
        for index in reversed(indices):
            rows.pop(index)
    if actor['config'].get('local_entities') == []:
        actor['config'].pop('local_entities')
    return dict(kind=command['kind'], scene_id=scene['scene_id'], instance_ref=command['instance_ref'],
        entity_ref=actor['instance']['entity']['owner_id'],
        removed_objects=sorted(actor['visuals']),
        removed_connections=deepcopy(actor['incoming']), imported_marker_retained=report['imported_marker_retained'])
