"""Studio world source/host-preview discovery; no device export capability grant."""
from copy import deepcopy

CAPABILITY = {
    'status': 'host_preview', 'host_editing': True, 'host_preview': True,
    'preview_requires': 'all_scenes_have_map_scene_bindings',
    'runtime': False, 'export': False, 'hardware_validation': 'not_qualified',
    'requires_scene_machines': True,
    'commands': ['scene.machines.set', 'scene.flowcharts.set'],
    'declarations_field': 'machine_logic.world_references',
    'position_bindings': {
        'field': 'machine_logic.world_positions', 'host_editing': True,
        'host_preview': True, 'runtime': False, 'export': False,
        'preview_requires': 'all_scenes_have_map_scene_bindings',
        'commands': ['scene.machines.set'], 'object_kind': 'sprite',
        'owns': ['x','y'], 'offset_type': 'int32',
        'projection': 'entity_minus_camera_plus_offset',
        'unbound_objects': 'screen_relative', 'shared_entity': True,
        'schema': 'schemas/authoring/world-position-bindings-v1.schema.json',
    },
    'reference_schema': 'schemas/authoring/world-reference-v1.schema.json',
    'declarations_schema': 'schemas/authoring/world-reference-declarations-v1.schema.json',
    'operand_schema': 'schemas/authoring/world-operand-source-v1.schema.json',
    'fields': ['property', 'camera_x', 'camera_y', 'entity_x', 'entity_y'],
    'types': ['bool', 'int32'], 'writer_kinds': ['machine', 'flow'],
    'writer_policy': 'exclusive_declared_owner', 'omitted_writer': 'read_only',
    'caller_transfers_writer': False, 'duplicate_targets': 'rejected',
    'guard_kind': 'world.compare', 'comparisons': ['eq', 'ne', 'lt', 'le', 'gt', 'ge'],
    'boolean_comparisons': ['eq', 'ne'], 'action_kinds': ['world.set', 'world.add', 'world.copy', 'world.min', 'world.max', 'world.subtract'],
    'integer_actions': ['world.set', 'world.add', 'world.copy', 'world.min', 'world.max', 'world.subtract'],
    'subtract_source_field': 'source_ref', 'subtract_reads': 'current_transaction',
    'copy_source_field': 'source_ref', 'copy_reads': 'current_transaction',
    'min_max_operand': 'int32_literal',
    'boolean_actions': ['world.set'], 'integer_overflow': 'reject_transaction',
    'route_guards': 'and', 'flow_branch_field': 'world_guards',
    'flow_branch_combination': 'and_with_when', 'arbitrary_world_predicates': False,
    'visual_selectors': {
        'host_editing': True, 'host_preview': True, 'runtime': False, 'export': False,
        'preview_requires': 'all_scenes_have_map_scene_bindings',
        'predicate_kind': 'world.compare', 'composition': ['all', 'any', 'not'],
        'read_only': True, 'requires_writer': False, 'token_cost': 1,
        'evaluation': 'settled_event_chain',
        'schema': 'schemas/authoring/presentation-selector-predicate-v1.schema.json',
        'commands': ['scene.presentation_selectors.set', 'scene.presentation_selectors.clear'],
    },
    'budget_policy': 'counts_toward_existing_guard_action_and_predicate_limits',
    'flow_guard_token_cost': 2, 'reference_validation': 'final_project_transaction_and_load',
    'persisted': True, 'undo_redo': True,
    'diagnostics_field': 'world_authoring', 'validation_error': 'WORLD_REFERENCE_INVALID',
    'readiness_error': 'TILEMAP_RUNTIME_UNAVAILABLE',
}


def report(bundle):
    """Describe validated source at the enclosing response's project revision.

    Counts are source inventory, not RAM, LPBAM or execution-cost estimates.
    """
    if not bundle.valid:
        return None
    from .authoring_foundation import enabled, execution_issues
    if enabled(bundle):
        return dict(status='incremental_authoring', scenes=[dict(scene_id=s['scene_id'], world=deepcopy(s.get('world'))) for s in bundle.scenes], issues=execution_issues(bundle))
    from .world_logic_source import project
    scenes = []
    for scene in bundle.scenes:
        graph = scene.get('machine_logic', {})
        if not graph.get('world_references') and not graph.get('world_positions'):
            continue
        source = project(scene)
        scenes.append({
            'scene_id': scene['scene_id'],
            'path': f"scenes[{scene['scene_id']}].machine_logic.world_references",
            'references': deepcopy(graph.get('world_references', [])),
            'position_bindings': deepcopy(source.positions),
            'unique_guard_count': len(source.guards), 'action_occurrence_count': len(source.actions),
            'preview_ready': False, 'export_ready': False,
            'blocking_code': 'TILEMAP_RUNTIME_UNAVAILABLE',
            'message': 'World source is editable and validated; public map preview and installed export are not available.',
        })
    return {'status': 'authoring_only', 'resource_analysis': 'not_performed', 'scenes': scenes}
