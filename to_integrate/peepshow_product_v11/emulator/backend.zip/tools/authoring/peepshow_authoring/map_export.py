"""Public, source-driven HW6 map export. Installation owns exact RAM admission.

This profile reuses the qualified encoder; it does not substitute a fixture or
interpret a preview graph as a device graph. Unsupported source stays editable.
"""
import struct
from .processing_cache import cached_map_readiness
from .v2_export import issue

PROFILE_ID = 'hw6_authored_maps_v1'


def applies(bundle):
    return any('map_scene' in s.get('machine_logic', {}) for s in bundle.scenes)


def public_profile():
    from .target_profile import TARGET_PROFILE
    return dict(profile_id=PROFILE_ID, profile_revision=2, status='development_restricted',
        container_version=2, execution_model='scene_machines_v1', export=True,
        maximum_scenes=8, maximum_package_bytes=TARGET_PROFILE['package']['maximum_bytes'],
        requires='all_scenes_map_bound_and_project_build_issues_empty',
        menu_packages='all_scenes_v2_object_menu_or_all_scenes_without_menu',
        supported=['ordinary_and_shared_event_responses', 'direct_recipient_events',
            'behavior_outputs', 'actor_templates_and_overrides', 'named_facing',
            'cardinal_checked_destinations', 'terrain_and_actor_collision',
            'offscreen_patrols', 'approach_restricted_interaction',
            'initial_manual_or_follow_camera', 'scene_exit_and_restart',
            'sprite_animation_effects_audio', 'object_menu_hierarchy',
            'menu_scope_input_and_pause', 'confirmed_drafts', 'walk_on_pickups',
            'inventory_conditions_and_quantity_text', 'map_base_colour'],
        preview_only=['camera_follow_or_look_at_actions', 'facing_relative_destinations',
            'explicit_cell_destinations', 'interaction_no_target_event',
            'world_layer_group_visibility', 'legacy_list_menu', 'explicit_execution_scopes',
            'mixed_map_and_non_map_scenes', 'mixed_menu_and_non_menu_scenes'],
        readiness_operation='project.validate', readiness_field='build_issues',
        build_operation='project.build_package', shipping_build=False,
        hardware_evidence='authored_dungeon_operator_tested',
        edited_projects_require_hardware_test=True, latency_target_proven=False,
        device_exact_admission_required=True,
        scene_ram_admission='install_and_launch', display_admission='install_and_runtime',
        standalone_binary_inspection=False,
        export_metadata='compiled_container_and_selected_source_not_preview_execution')


def _walk(value, path):
    """Visit authored paths, including flows, responses and shared definitions."""
    pending = [(value, path)]
    while pending:
        row, location = pending.pop()
        if isinstance(row, dict):
            yield row, location
            pending.extend((v, location + '.' + k) for k, v in reversed(tuple(row.items())))
        elif isinstance(row, list):
            pending.extend((v, f'{location}[{i}]') for i, v in reversed(tuple(enumerate(row))))


def source_issues(bundle):
    problems = []
    def reject(code, path, message):
        problems.append(issue(code, path, message))
    if not 1 <= len(bundle.scenes) <= 8:
        reject('MAP_SCENE_PROFILE', 'scenes', 'Map export requires one to eight map-bound machine Scenes.')
    if bundle.project.get('validation', {}).get('build_profile') == 'shipping':
        reject('MAP_SHIPPING_UNAVAILABLE', 'validation.build_profile', 'Map export is development-only.')
    menus = any('menu_component' in s for s in bundle.scenes)
    for scene in bundle.scenes:
        path = f"scenes[{scene['scene_id']}]"
        graph = scene.get('machine_logic', {})
        if 'map_scene' not in graph:
            reject('MAP_SCENE_PROFILE', path, 'Every Scene in a map package requires map_scene bindings; mixed Scene models remain unavailable.')
        if scene['interaction_policy']['mode'] != 'continuous':
            reject('MAP_INTERACTION_POLICY_UNAVAILABLE', path + '.interaction_policy', 'Map export requires continuous interaction.')
        if 'execution_scopes' in graph:
            reject('EXECUTION_SCOPE_DEVICE_UNAVAILABLE', path + '.machine_logic.execution_scopes',
                   'Use the V2 object Menu component for installed pause; explicit legacy execution scopes remain preview-only.')
        menu = scene.get('menu_component')
        if menus and menu is None:
            reject('MAP_MENU_PACKAGE_UNAVAILABLE', path, 'A package with a Menu component currently requires one in every Scene.')
        if menu is not None and (menu['version'] != 2 or menu['presentation']['kind'] != 'objects'):
            reject('MENU_PRESENTATION_DEVICE_UNAVAILABLE', path + '.menu_component', 'Installed menus require V2 Scene-object presentation; list presentation remains preview-only.')
        if not menus and (bundle.project.get('inventory') or scene.get('pickups')):
            reject('INVENTORY_DEVICE_UNAVAILABLE', path + '.pickups', 'Installed inventory currently requires the object Menu component in each Scene.')
        spec = graph.get('map_scene', {})
        if 'visibility' in spec and spec['visibility'] != dict(world=True, layers=[]):
            reject('VISIBILITY_DEVICE_UNAVAILABLE', path + '.machine_logic.map_scene.visibility',
                   'World/layer/group visibility configuration remains preview-only; Menu world hiding is supported.')
        for row, location in _walk(scene, path):
            kind = row.get('kind', '')
            if kind in ('camera.follow', 'camera.look_at'):
                reject('CAMERA_ACTION_DEVICE_UNAVAILABLE', location, 'Configure initial Manual/Follow camera; runtime camera commands remain preview-only.')
            if kind in ('visibility.world', 'visibility.layer', 'visibility.group'):
                reject('VISIBILITY_DEVICE_UNAVAILABLE', location, 'World/layer/group visibility actions remain preview-only.')
            cell = row.get('cell')
            if 'destination_id' in row and isinstance(cell, dict):
                if cell.get('kind') == 'cell':
                    reject('EXPLICIT_DESTINATION_DEVICE_UNAVAILABLE', location + '.cell', 'Explicit-cell destinations remain preview-only; use adjacent cardinal destinations.')
                elif 'facing_ref' in cell:
                    reject('FACING_DESTINATION_DEVICE_UNAVAILABLE', location + '.cell', 'Facing-relative destinations remain preview-only; use a named cardinal direction.')
            if row.get('no_target') is not None:
                reject('INTERACTION_DEVICE_UNAVAILABLE', location + '.no_target', 'No-target event delivery remains preview-only; no target may be a no-op on device.')
    return problems


def _encode(bundle):
    from .map_qualification import _build
    return _build(bundle, scoped=any('menu_component' in s for s in bundle.scenes))


@cached_map_readiness
def analyze_readiness(bundle):
    from .asset_library import package_assets
    if not bundle.valid:
        return dict(issues=[], admission=None, reason='invalid_source')
    problems = source_issues(bundle)
    if problems:
        return dict(issues=problems, admission=None, reason='unsupported_source')
    try:
        _encode(package_assets(bundle))
    except (ValueError, KeyError, TypeError, IndexError, OverflowError, struct.error) as exc:
        # Source validation and each encoder retain their own author-facing
        # location. Do not invent an exact node when the encoder lacks one.
        text = str(exc)
        code = text.split(':', 1)[0]
        if not code.isupper() or ' ' in code:
            code = 'MAP_ENCODING_UNSUPPORTED'
        return dict(issues=[issue(code, 'scenes', text)], admission=None, reason='encoding_failed')
    return dict(issues=[], admission=None, reason='device_map_admission_required')


def build_checked(bundle):
    from .asset_library import package_assets
    from .compiler import EggCompileError
    if not bundle.valid:
        raise EggCompileError('project must validate before map export')
    problems = source_issues(bundle)
    if problems:
        raise EggCompileError('; '.join(f"{p['code']} {p['path']}: {p['message']}" for p in problems))
    try:
        return _encode(package_assets(bundle))
    except (ValueError, KeyError, TypeError, IndexError, OverflowError, struct.error) as exc:
        raise EggCompileError(f'MAP_ENCODING_UNSUPPORTED: {exc}') from exc


def compiled_metadata(bundle, blob):
    """Summarise this compiler's output, not an arbitrary binary's execution.

    Container integrity is checked independently. Exact Scene/display resource
    validation belongs to the installed native loader, not the host preview.
    """
    import hashlib
    from .asset_library import package_assets
    from .egg_format import parse_egg
    selected = package_assets(bundle)
    container = parse_egg(blob, _development_v2=True, _container_only=True)
    manifest = container['manifest']
    return dict(container_version=2, export_profile_id=PROFILE_ID,
        package_id=manifest['package_id'], target_profile=manifest['target_profile'],
        entry_scene=manifest['entry_scene'], scene_count=manifest['scene_count'],
        asset_frame_count=len(selected.frames), animation_count=len(selected.animations),
        audio_asset_count=len(container['audio_assets']), audio_cue_count=len(container['audio_cues']),
        chunk_count=len(container['chunks']), size_bytes=len(blob),
        sha256=hashlib.sha256(blob).hexdigest())
