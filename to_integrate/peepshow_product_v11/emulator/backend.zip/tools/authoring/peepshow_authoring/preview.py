from __future__ import annotations

import base64
import hashlib
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from .egg_format import EggPackage
from .scene_objects import initialize_objects, apply_object_actions, resolve_object


DISPLAY_WIDTH = 168
DISPLAY_HEIGHT = 144
DISPLAY_STRIDE = DISPLAY_WIDTH // 8
DISPLAY_BUFFER_SIZE = DISPLAY_STRIDE * DISPLAY_HEIGHT
LOGICAL_SOURCES = {
    "BUTTON_A": 1,
    "BUTTON_B": 2,
    "BUTTON_L": 3,
    "BUTTON_R": 4,
    "BUTTON_START": 5,
    "JOY_LEFT": 6,
    "JOY_RIGHT": 7,
    "JOY_UP": 8,
    "JOY_DOWN": 9,
    "JOY_UP_LEFT": 10,
    "JOY_UP_RIGHT": 11,
    "JOY_DOWN_LEFT": 12,
    "JOY_DOWN_RIGHT": 13,
}
LOGICAL_EVENTS = {"press": 1, "release": 2, "hold": 3, "repeat": 4}


class PreviewError(ValueError):
    """Raised when a validated package cannot execute in the current preview subset."""


@dataclass(frozen=True)
class PreviewInputResult:
    logical_source: str
    event_kind: str
    action_id: str | None
    accepted: bool
    route_id: str | None
    audio_events: tuple[dict[str, object], ...] = ()
    system_action: str | None = None


class StateScenePreview:
    """Deterministic selected-scene executor over an independently parsed package."""

    def __new__(cls, package=None, scene_id=None, *args, **kwargs):
        if cls is StateScenePreview and package is not None and any(s["scene_id"] == scene_id and "machine_logic" in s for s in package.scenes):
            from .machine_preview import MachinePreview
            return object.__new__(MachinePreview)
        return object.__new__(cls)

    def __init__(
        self,
        package: EggPackage,
        scene_id: str,
        state_id: str | None = None,
        *,
        include_waiting_visuals: bool = True,
        _session_variables: dict[str, int] | None = None,
        _session_machine_states: dict | None = None,
        _session_local_ms: int | None = None,
        _session_scope_sources: dict | None = None,
        _session_scope_input=None,
        _session_scope_audio=None,
        _session_menu_budget_ms=None,
        _session_inventory=None,
        _defer_activation=False,
    ) -> None:
        self._defer_activation = _defer_activation
        self._package = package
        self._scenes = {str(scene["scene_id"]): scene for scene in package.scenes}
        self._frames = {str(frame["frame_id"]): frame for frame in package.assets}
        self._animations = {str(animation["animation_id"]): animation for animation in package.animations}
        self._audio_cues = package.audio_cues
        self._include_waiting_visuals = include_waiting_visuals
        self._elapsed_ms = 0
        self._local_ms: int | None = _session_local_ms
        self._package_variables = dict(_session_variables or {})
        self._inventory_state = deepcopy(_session_inventory or dict(counts={}, collected=[]))
        self._retained_machine_states = dict(_session_machine_states or {})
        public_sources = {s['scene_id']: s['_scope_source'] for s in package.scenes if '_scope_source' in s}
        self._scope_sources = deepcopy(_session_scope_sources if _session_scope_sources is not None else public_sources)
        self._scope_input = deepcopy(_session_scope_input)
        self._scope_audio = deepcopy(_session_scope_audio)
        self._menu_action_budget_ms = _session_menu_budget_ms
        if public_sources and self._menu_action_budget_ms is None:
            from .execution_scope_source import CAPABILITY
            self._menu_action_budget_ms = CAPABILITY['preview_adapter']['menu_wait_budget_ms']
        if self._scope_input is None and public_sources:
            from .scope_input import ScopeInput
            self._scope_input = ScopeInput()
            self._scope_input.needs_snapshot = True
        if self._scope_audio is None and self._scope_sources:
            # Track package SFX even when a scoped session begins in a plain
            # Scene, before its first menu-capable Scene is entered.
            from .scope_audio import ScopeAudio
            self._scope_audio = ScopeAudio()
        self._audio_scope_context = 'gameplay'
        self._activate_scene(scene_id, run_entry=state_id is None and include_waiting_visuals)
        if state_id is not None:
            self.select_state(state_id)
        else:
            self._render_framebuffer()

    def select_state(self, state_id: str) -> None:
        state_index = next(
            (
                index
                for index, state in enumerate(self._graph["states"])
                if str(state["state_id"]) == state_id
            ),
            None,
        )
        if state_index is None:
            raise PreviewError(f"state '{state_id}' is not present in scene '{self.scene_id}'")
        self._state_index = state_index
        self._state_elapsed_ms = 0
        self._fired_timer_bindings: set[int] = set()
        self._step_elapsed_ms = 0
        self._step_index = int(self._waiting()["settled_step"])
        self._render_framebuffer()

    @property
    def scene_id(self) -> str:
        return str(self._scene["scene_id"])

    def _state(self) -> dict[str, object]:
        return self._graph["states"][self._state_index]

    def _waiting(self) -> dict[str, object]:
        return self._waiting_visuals[int(self._state()["waiting_visual_index"])]

    def _guard_passes(self, guard: dict[str, int], evidence=None) -> bool:
        left = self._variables[guard["variable_index"]]
        right = guard["value"]
        operator = guard["operator"]
        if not 1 <= operator <= 6:
            raise PreviewError("compiled guard operator is unsupported")
        result = (left == right, left != right, left < right,
                  left <= right, left > right, left >= right)[operator - 1]
        if evidence is not None:
            variable = self._graph['variables'][guard['variable_index']]['variable_id']
            evidence.append(dict(kind='variable', variable_id=variable,
                binding=deepcopy(getattr(self, '_scoped_variables', {}).get(variable)),
                left=left, right=right, operator=('eq','ne','lt','le','gt','ge')[operator-1],
                result=result))
        return result

    def _activate_scene(self, scene_id: str, *, run_entry: bool = True) -> None:
        scene = self._scenes.get(scene_id)
        if scene is None:
            raise PreviewError(f"scene '{scene_id}' is not present in the package")
        self._scene = scene
        if self._scope_audio is not None:
            self._scope_audio.change_focus('gameplay')
        if self._scope_input is not None:
            self._scope_input.enter_scene()
        self._object_source = scene.get("object_source")
        self._object_definitions = {obj["object_id"]: obj for obj in self._object_source["objects"]} if self._object_source else {}
        self._object_live = initialize_objects(list(self._object_definitions.values()))
        self._object_clips = scene.get("object_animations", {})
        self._graph = scene["graph"]
        self._render_models = scene["render_models"]
        self._waiting_visuals = scene["waiting_visuals"]
        self._state_index = int(self._graph["entry_state"])
        self._variables = [int(variable["initial"]) for variable in self._graph["variables"]]
        self._scoped_variables = scene.get("scoped_variables", {})
        for index, variable in enumerate(self._graph["variables"]):
            definition = self._scoped_variables.get(variable["variable_id"])
            if definition and definition["scope"] == "package":
                self._variables[index] = self._package_variables.setdefault(
                    definition["variable_id"], int(definition["initial"]))
        self.entry_audio_events: list[dict[str, object]] = []
        self._entry_trace: list[str] = []
        if run_entry and self._object_source and self._object_source.get("entry_graph"):
            if self._defer_activation:
                raise PreviewError('Startup debugging requires machine Scene Activated responses; legacy entry graphs are not stepable')
            self._run_scene_entry()
        self._element_overrides: dict[tuple[int, int], dict[str, object]] = {}
        self._waiting_element_overrides: dict[
            tuple[int, int], dict[str, object]
        ] = {}
        self._elapsed_ms = 0
        self._state_elapsed_ms = 0
        self._fired_timer_bindings: set[int] = set()
        self._scene_timer_delays = {
            int(binding["binding_index"]): int(binding["configuration"]["delay_ms"])
            for binding in self._graph.get("event_bindings", ())
            if binding["event_type"] == "time.scene_elapsed"
        }
        self._scene_timer_deadlines = {
            int(binding["binding_index"]): int(binding["configuration"]["delay_ms"])
            for binding in self._graph.get("event_bindings", ())
            if binding["event_type"] == "time.scene_elapsed"
            and binding["configuration"]["start_policy"] == "scene_entry"
        }
        from .calendar_schedule import CalendarSchedule
        self._calendars = {binding['binding_index']: CalendarSchedule(binding['configuration'])
                           for binding in self._graph.get('event_bindings', ())
                           if binding['event_type'] == 'time.local_schedule'}
        self._rebase_calendar()
        self._suspended = False
        self._step_elapsed_ms = 0
        self._step_index = int(self._waiting()["settled_step"])
        self._validate_scene_subset()

    def _run_scene_entry(self) -> None:
        from .scene_entry import NODE_LIMIT
        graph = self._object_source["entry_graph"]
        nodes = {node["node_id"]: node for node in graph["nodes"]}
        variables = {
            (definition["scope"], definition["variable_id"]): (index, definition)
            for index, variable in enumerate(self._graph["variables"])
            if (definition := self._scoped_variables.get(variable["variable_id"]))
        }
        operators = {"eq": 1, "ne": 2, "lt": 3, "le": 4, "gt": 5, "ge": 6}

        def passes(guard):
            index, _ = variables[(guard.get("variable_scope", "scene"), guard["variable_ref"])]
            return self._guard_passes({"variable_index": index,
                                      "operator": operators[guard["operator"]], "value": int(guard["value"])})

        ident = graph["root"]
        for _ in range(NODE_LIMIT):
            node = nodes[ident]
            self._entry_trace.append(ident)
            if node["kind"] == "state":
                self._state_index = next(index for index, state in enumerate(self._graph["states"])
                                         if state["state_id"] == node["state_ref"])
                return
            if node["kind"] == "decision":
                ident = next((branch["next"] for branch in node["branches"]
                              if all(passes(guard) for guard in branch["guards"])), node["default"])
                continue
            for action in node["actions"]:
                if action["kind"] == "play_sfx":
                    cue = next(cue for cue in self._audio_cues if cue["cue_id"] == action["cue_ref"])
                    self.entry_audio_events.append(self._audio_event(cue))
                    continue
                index, definition = variables[(action.get("variable_scope", "scene"), action["variable_ref"])]
                operation = action["operation"]
                if operation == "reset":
                    value = int(definition["initial"])
                elif operation == "assign":
                    value = int(action["value"])
                else:
                    value = max(definition["minimum"], min(definition["maximum"],
                                self._variables[index] + int(action["value"])))
                self._variables[index] = value
                if definition["scope"] == "package":
                    self._package_variables[definition["variable_id"]] = value
            ident = node["next"]
        raise PreviewError("entry graph exceeded its bounded path length")

    def apply_input(self, logical_source: str, event_kind: str = "press", *, _focus_generation=None) -> PreviewInputResult:
        from .preview_steps import drain
        return drain(self.iterate_input(logical_source, event_kind, _focus_generation=_focus_generation))

    def iterate_input(self, logical_source, event_kind='press', *, _focus_generation=None):
        focus = self._scope_input
        if focus is not None:
            generation = focus.generation if _focus_generation is None else _focus_generation
            if focus.observe(logical_source, event_kind, generation, self._suspended):
                return PreviewInputResult(logical_source, event_kind, None, False, None)
        elif self._suspended:
            return PreviewInputResult(logical_source, event_kind, None, False, None)
        source = LOGICAL_SOURCES.get(logical_source)
        if source is None:
            raise PreviewError(f"logical source '{logical_source}' is unsupported")
        event = LOGICAL_EVENTS.get(event_kind)
        if event is None:
            raise PreviewError(f"logical event '{event_kind}' is unsupported")
        action = next(
            (
                action
                for action in self._graph["inputs"]
                if int(action["logical_source"]) == source
                and int(action.get("logical_event", 1)) == event
            ),
            None,
        )
        if action is None:
            if focus is not None:
                focus.finish('unbound_consumed')
            return PreviewInputResult(logical_source, event_kind, None, False, None)
        action_index = int(
            action.get("binding_index", self._graph["inputs"].index(action))
        )
        action_id = str(action["action_id"])
        return (yield from self._iterate_dispatch_input(action_index, logical_source, event_kind, action_id))

    def _dispatch_input(self, action_index, logical_source, event_kind, action_id):
        from .preview_steps import drain
        return drain(self._iterate_dispatch_input(action_index, logical_source, event_kind, action_id))

    def _iterate_dispatch_input(self, action_index, logical_source, event_kind, action_id):
        focus = self._scope_input
        if focus is not None:
            focus.begin_action(logical_source, event_kind, action_id)
        result = yield from self._iterate_binding(action_index, logical_source, event_kind, action_id)
        if focus is not None and self._scope_input.generation == focus.generation:
            self._scope_input.finish('delivered' if result.accepted else 'unhandled_or_rejected')
        return result

    def _scope_input_snapshot(self, active_sources, *, generation):
        if self._scope_input is None:
            raise PreviewError('input snapshot requires scoped focus')
        if self._suspended:
            raise PreviewError('system retains input ownership until resume')
        self._scope_input.observe_snapshot(active_sources, generation)

    def _audio_event(self, cue):
        event = {"kind": "play_sfx", **{
            key: cue[key] for key in ("cue_id", "asset_id", "priority", "volume")}}
        if self._scope_audio is not None:
            return self._scope_audio.stage(self._audio_scope_context, event)
        return event

    def _scope_audio_take(self):
        if self._scope_audio is None or getattr(self, '_scope_dispatching', False):
            raise PreviewError('audio qualification requires scoped ownership at a settled boundary')
        return self._scope_audio.take()

    def _scope_audio_stop(self):
        if getattr(getattr(self, '_scope_menu', None), 'pending', None) is not None:
            raise PreviewError('menu transition owns its audio stop')
        if self._scope_audio is None or self._suspended or getattr(self, '_scope_dispatching', False):
            raise PreviewError('scope audio stop requires an active, settled boundary')
        return self._scope_audio.stop([self._scope_audio.focus])

    def _scope_audio_complete_stop(self, token, *, success):
        if self._scope_audio is None:
            raise PreviewError('audio qualification requires scoped ownership')
        self._scope_audio.complete_stop(token, success)

    def _apply_binding(
        self,
        binding_index: int,
        logical_source: str,
        event_kind: str,
        binding_id: str,
    ) -> PreviewInputResult:
        route = next(
            (
                candidate
                for candidate in self._graph["routes"]
                if int(candidate["action_index"]) == binding_index
                and (not candidate["source_state_indexes"]
                     or self._state_index in candidate["source_state_indexes"])
                and all(self._guard_passes(guard) for guard in candidate["guards"])
            ),
            None,
        )
        if route is None:
            return PreviewInputResult(logical_source, event_kind, binding_id, False, None)

        if self._scope_audio is not None:
            # A scoped session can enter a plain Scene. Its inherited audio
            # outbox still publishes only after the complete route succeeds.
            candidate = deepcopy(self)
            result = candidate._execute_route(route, logical_source, event_kind, binding_id)
            self.__class__ = type(candidate)
            self.__dict__.clear()
            self.__dict__.update(candidate.__dict__)
            return result
        return self._execute_route(route, logical_source, event_kind, binding_id)

    def _execute_route(self, route, logical_source, event_kind, binding_id):
        from .preview_steps import drain
        return drain(self._iterate_execute_route(route, logical_source, event_kind, binding_id))

    def _iterate_execute_route(self, route, logical_source, event_kind, binding_id):
        target_scene = route["target_scene"]
        if target_scene in self._scene.get('_authoring_stale_scenes', ()):
            from .preview_dependencies import StalePreviewScene
            raise StalePreviewScene(str(target_scene))
        if target_scene is not None:
            audio_events: list[dict[str, object]] = []
            for operation in route["operations"]:
                if int(operation["kind"]) != 7:
                    raise PreviewError(
                        "direct scene replacement can execute only play_sfx actions"
                    )
                cue_index = int(operation["cue_index"])
                if not 0 <= cue_index < len(self._audio_cues):
                    raise PreviewError("compiled SFX action cue is invalid")
                cue = self._audio_cues[cue_index]
                audio_events.append(self._audio_event(cue))
            if self._object_source:
                # Admit the fresh destination before publishing any exit cues.
                candidate = StateScenePreview(
                    self._package, str(target_scene),
                    include_waiting_visuals=self._include_waiting_visuals,
                    _session_variables=self._package_variables,
                    _session_machine_states=self._retained_machine_states,
                    _session_local_ms=self._local_ms,
                    _session_scope_sources=self._scope_sources,
                    _session_scope_input=self._scope_input,
                    _session_scope_audio=self._scope_audio,
                    _session_menu_budget_ms=self._menu_action_budget_ms,
                    _session_inventory=self._inventory_state,
                    _defer_activation=bool(self._scenes[str(target_scene)].get("_terminal_order")),
                )
                if getattr(candidate, "_entry_pending", False):
                    yield from candidate.iterate_scene_entry()
                candidate._local_ms = self._local_ms
                candidate._rebase_calendar()
                audio_events.extend(candidate.entry_audio_events)
                self.__class__ = type(candidate)
                self.__dict__.clear()
                self.__dict__.update(candidate.__dict__)
                return PreviewInputResult(
                    logical_source, event_kind, binding_id, True, str(route["route_id"]),
                    tuple(audio_events),
                )
            self._activate_scene(str(target_scene))
            self._render_framebuffer()
            return PreviewInputResult(
                logical_source,
                event_kind,
                binding_id,
                True,
                str(route["route_id"]),
                tuple(audio_events),
            )

        prior_waiting = self._waiting()
        object_live = self._object_live
        variables = list(self._variables)
        element_overrides = {
            key: dict(value) for key, value in self._element_overrides.items()
        }
        waiting_element_overrides = {
            key: dict(value)
            for key, value in self._waiting_element_overrides.items()
        }
        force_timeline_rebase = False
        audio_events: list[dict[str, object]] = []
        system_action: str | None = None
        definitions = self._graph["variables"]
        target_state = route["target_state_index"]
        changes_state = target_state is not None
        if not changes_state:
            target_state = self._state_index
        timer_commands: list[tuple[int, int]] = []
        target_model_index = int(
            self._graph["states"][int(target_state)]["render_model_index"]
        )
        target_model = self._render_models[target_model_index]
        for operation in route["operations"]:
            if "object_action" in operation:
                object_live = apply_object_actions(
                    list(self._object_definitions.values()), object_live, [operation["object_action"]],
                    {ref: (int(frame["width"]), int(frame["height"])) for ref, frame in self._frames.items()},
                )
                continue
            kind = int(operation["kind"])
            if kind == 2:
                continue
            if kind == 7:
                cue_index = int(operation["cue_index"])
                if not 0 <= cue_index < len(self._audio_cues):
                    raise PreviewError("compiled SFX action cue is invalid")
                cue = self._audio_cues[cue_index]
                audio_events.append(self._audio_event(cue))
                continue
            if kind == 8:
                system_action = "exit_to_shell"
                continue
            if kind in {9, 10, 11}:
                timer_commands.append((kind, int(operation["binding_index"])))
                continue
            if kind in {3, 4, 5, 6}:
                element_index = int(operation["element_index"])
                if not 0 <= element_index < len(target_model["elements"]):
                    raise PreviewError("compiled element action target is invalid")
                element = target_model["elements"][element_index]
                key = (target_model_index, element_index)
                override = dict(element_overrides.get(key, {}))
                if kind == 3:
                    visible = int(operation["visible"])
                    if not visible and int(element.get("focus_role", 0)):
                        raise PreviewError("compiled action cannot hide the focus element")
                    override["visible"] = visible
                elif kind == 4:
                    x = int(operation["x"])
                    y = int(operation["y"])
                    if (
                        x < 0
                        or y < 0
                        or x + int(element["width"]) > DISPLAY_WIDTH
                        or y + int(element["height"]) > DISPLAY_HEIGHT
                    ):
                        raise PreviewError("compiled element position is outside the display")
                    override["x"] = x
                    override["y"] = y
                elif kind == 5:
                    frame_ref = str(operation["frame_ref"])
                    self._require_native_frame(element, frame_ref)
                    override["visual_ref"] = frame_ref
                else:
                    waiting = self._waiting_visuals[
                        int(operation["waiting_visual_index"])
                    ]
                    waiting_element_ref = str(operation["waiting_element_ref"])
                    waiting_element = next(
                        (
                            item
                            for item in waiting["elements"]
                            if str(item["element_id"]) == waiting_element_ref
                        ),
                        None,
                    )
                    if (
                        waiting_element is None
                        or str(waiting_element["source_element_ref"])
                        != str(element["element_id"])
                    ):
                        raise PreviewError(
                            "compiled waiting-animation action target is invalid"
                        )
                    if (
                        int(waiting["phase_quantum_ms"])
                        != int(self._waiting_visuals[int(
                            self._graph["states"][int(target_state)][
                                "waiting_visual_index"
                            ]
                        )]["phase_quantum_ms"])
                        or int(waiting["combined_step_count"])
                        != int(self._waiting_visuals[int(
                            self._graph["states"][int(target_state)][
                                "waiting_visual_index"
                            ]
                        )]["combined_step_count"])
                    ):
                        raise PreviewError(
                            "compiled waiting-animation timeline is incompatible"
                        )
                    for visual_ref in waiting_element["phase_visual_refs"]:
                        self._require_native_frame(element, str(visual_ref))
                    waiting_element_overrides[key] = dict(waiting_element)
                    force_timeline_rebase = (
                        force_timeline_rebase
                        or int(operation["timeline_policy"]) == 2
                    )
                element_overrides[key] = override
                continue
            variable_index = int(operation["variable_index"])
            if int(operation["operation"]) == 1:
                value = int(operation["value"])
            elif int(operation["operation"]) == 2:
                value = variables[variable_index] + int(operation["value"])
            else:
                raise PreviewError("compiled variable operation is unsupported")
            definition = definitions[variable_index]
            if self._scoped_variables:
                value = max(int(definition["minimum"]), min(value, int(definition["maximum"])))
            if not int(definition["minimum"]) <= value <= int(definition["maximum"]):
                raise PreviewError(f"route '{route['route_id']}' writes a variable outside its compiled bounds")
            variables[variable_index] = value

        self._variables = variables
        for index, variable in enumerate(definitions):
            definition = self._scoped_variables.get(variable["variable_id"])
            if definition and definition["scope"] == "package":
                self._package_variables[definition["variable_id"]] = variables[index]
        self._object_live = object_live
        self._element_overrides = element_overrides
        self._waiting_element_overrides = waiting_element_overrides
        self._state_index = int(target_state)
        if changes_state:
            self._state_elapsed_ms = 0
            self._fired_timer_bindings.clear()
        for kind, timer_index in timer_commands:
            if kind == 11:
                self._scene_timer_deadlines.pop(timer_index, None)
            elif kind == 10 or timer_index not in self._scene_timer_deadlines:
                self._scene_timer_deadlines[timer_index] = (
                    self._timer_now(timer_index) + self._timer_delay(timer_index)
                )
        if system_action == "exit_to_shell":
            self._suspend_from_action()
        next_waiting = self._waiting()
        if force_timeline_rebase or not self._compatible_timeline(
            prior_waiting, next_waiting
        ):
            self._step_index = int(next_waiting["settled_step"])
            self._step_elapsed_ms = 0
        self._render_framebuffer()
        return PreviewInputResult(
            logical_source,
            event_kind,
            binding_id,
            True,
            str(route["route_id"]),
            tuple(audio_events),
            system_action,
        )

    @staticmethod
    def _compatible_timeline(first: dict[str, object], second: dict[str, object]) -> bool:
        return (
            first["presentation_id"] == second["presentation_id"]
            and first["phase_quantum_ms"] == second["phase_quantum_ms"]
            and first["combined_step_count"] == second["combined_step_count"]
        )

    def advance(self, elapsed_ms: int) -> tuple[PreviewInputResult, ...]:
        from .preview_steps import drain
        return drain(self.iterate_advance(elapsed_ms))

    def _iterate_binding(self, *args, **kwargs):
        # Legacy preview drains through the same adapter; debugger admission still
        # requires terminal response graphs.
        if False:
            yield
        return self._apply_binding(*args, **kwargs)

    def iterate_advance(self, elapsed_ms):
        from .preview_steps import checkpoint
        if isinstance(elapsed_ms, bool) or not isinstance(elapsed_ms, int) or not 0 <= elapsed_ms <= 600000:
            raise PreviewError("elapsed_ms must be an integer in 0..600000")
        yield checkpoint(self, 'time', elapsed_ms=elapsed_ms)
        if self._suspended:
            self._advance_clock(elapsed_ms)
            return ()
        results: list[PreviewInputResult] = []
        remaining_ms = elapsed_ms
        dispatch_count = 0
        while True:
            timer = self._next_state_timer()
            if timer is None:
                self._advance_visual(remaining_ms)
                break
            due_in_ms, binding_index, binding_id = timer
            if due_in_ms > remaining_ms:
                self._advance_visual(remaining_ms)
                break
            self._advance_visual(due_in_ms)
            remaining_ms -= due_in_ms
            yield checkpoint(self, 'timer', binding_id=binding_id, binding_index=binding_index)
            is_calendar = binding_index in self._calendars
            timer_state = (set(self._fired_timer_bindings), dict(self._scene_timer_deadlines)) if self._object_source else None
            if is_calendar:
                self._calendars[binding_index].consume(self._local_ms)
            self._consume_timer(binding_index)
            try:
                result = yield from self._iterate_binding(
                    binding_index,
                    "time.local_schedule" if is_calendar else
                    ("time.scene_elapsed" if binding_index in self._scene_timer_delays else "time.state_entry_elapsed"),
                    "scheduled" if is_calendar else "elapsed",
                    binding_id,
                )
            except PreviewError:
                if timer_state is not None:
                    self._fired_timer_bindings, self._scene_timer_deadlines = timer_state
                raise
            results.append(result)
            yield checkpoint(self, 'timer_complete', binding_id=binding_id,
                             rejection=getattr(self, '_machine_rejection', None))
            dispatch_count += 1
            if self._suspended:
                break
            if dispatch_count > 128:
                raise PreviewError("timer cascade exceeds the bounded preview budget")
            if remaining_ms == 0:
                next_timer = self._next_state_timer()
                if next_timer is None or next_timer[0] > 0:
                    break
        return tuple(results)

    def _timer_delay(self, binding_index):
        return self._scene_timer_delays[binding_index]

    def _timer_now(self, binding_index):
        return self._elapsed_ms

    def _object_now(self, object_ref):
        return self._elapsed_ms

    def _consume_timer(self, binding_index):
        self._fired_timer_bindings.add(binding_index)
        self._scene_timer_deadlines.pop(binding_index, None)

    def _next_state_timer(self) -> tuple[int, int, str] | None:
        candidates: list[tuple[int, int, str]] = []
        for binding in self._graph.get("event_bindings", ()):
            binding_index = int(binding["binding_index"])
            if binding["event_type"] == "time.local_schedule":
                deadline = self._calendars[binding_index].deadline
                if deadline is not None and self._local_ms is not None:
                    candidates.append((max(0, deadline - self._local_ms),
                                       binding_index, str(binding["binding_id"])))
                continue
            if binding["event_type"] == "time.scene_elapsed":
                if binding_index in self._scene_timer_deadlines:
                    candidates.append((max(0, self._scene_timer_deadlines[binding_index] - self._elapsed_ms),
                                       binding_index, str(binding["binding_id"])))
                continue
            if binding_index in self._fired_timer_bindings:
                continue
            if not any(
                int(route["action_index"]) == binding_index
                and self._state_index in route["source_state_indexes"]
                for route in self._graph["routes"]
            ):
                continue
            delay_ms = int(binding["configuration"]["delay_ms"])
            candidates.append(
                (
                    max(0, delay_ms - self._state_elapsed_ms),
                    binding_index,
                    str(binding["binding_id"]),
                )
            )
        return min(candidates) if candidates else None

    def suspend(self) -> None:
        if self._scope_audio is not None and not self._suspended:
            self._scope_audio.stop(('gameplay', 'menu'))
        if self._scope_input is not None and not self._suspended:
            self._scope_input.preempt()
        self._suspended = True

    def _suspend_from_action(self) -> None:
        self._scene_timer_deadlines.clear()
        self.suspend()

    def resume(self) -> None:
        if self._scope_audio is not None:
            self._scope_audio.resume()
        self._suspended = False

    def set_local_time(self, local_time: str | None) -> None:
        """Explicit simulation clock edit; no host-clock polling or catch-up actions."""
        if local_time is None:
            self._local_ms = None
        else:
            try:
                value = datetime.fromisoformat(local_time)
                if value.tzinfo is not None or not 2000 <= value.year <= 2099:
                    raise ValueError()
                self._local_ms = int((value - datetime(2000, 1, 1)).total_seconds() * 1000)
            except (ValueError, TypeError):
                raise PreviewError("local_time must be a local ISO date/time in 2000..2099 or null") from None
        self._rebase_calendar()

    def _advance_clock(self, elapsed_ms: int) -> None:
        if self._local_ms is not None:
            self._local_ms += elapsed_ms
            if self._local_ms >= 3155760000000:
                self._local_ms = None
                self._rebase_calendar()

    def _rebase_calendar(self) -> None:
        for schedule in self._calendars.values():
            schedule.rebase(self._local_ms)

    @property
    def _calendar_deadline(self):
        """Compatibility summary: earliest armed calendar deadline."""
        return min((s.deadline for s in self._calendars.values() if s.deadline is not None), default=None)

    def _advance_visual(self, elapsed_ms: int) -> None:
        self._advance_clock(elapsed_ms)
        waiting = self._waiting()
        quantum = int(waiting["phase_quantum_ms"])
        step_count = int(waiting["combined_step_count"])
        total = self._step_elapsed_ms + elapsed_ms
        self._step_index = (self._step_index + total // quantum) % step_count
        self._step_elapsed_ms = total % quantum
        self._elapsed_ms += elapsed_ms
        self._state_elapsed_ms += elapsed_ms
        self._render_framebuffer()

    def _visual_overrides(self) -> dict[str, str]:
        if not self._include_waiting_visuals:
            return {}
        result: dict[str, str] = {}
        state = self._state()
        model_index = int(state["render_model_index"])
        model = self._render_models[model_index]
        waiting_by_source = {
            str(element["source_element_ref"]): element
            for element in self._waiting()["elements"]
        }
        for element_index, render_element in enumerate(model["elements"]):
            element = self._waiting_element_overrides.get(
                (model_index, element_index),
                waiting_by_source.get(str(render_element["element_id"])),
            )
            if element is None:
                continue
            phase_index = int(element["step_phase_indices"][self._step_index])
            result[str(element["source_element_ref"])] = str(element["phase_visual_refs"][phase_index])
        return result

    def _resolved_element(
        self,
        model_index: int,
        element_index: int,
        element: dict[str, object],
    ) -> dict[str, object]:
        if self._object_source is not None:
            ref = str(element["element_id"])
            state = next(state for state in self._object_source["states"] if state["state_id"] == self._state()["state_id"])
            override = next((item for item in state["object_overrides"] if item["object_ref"] == ref), {})
            resolved = dict(element)
            definition = self._object_definitions[ref]
            if definition["kind"] == "text":
                resolved.update({key: definition[key] for key in ("text", "font_id", "scale", "alignment")})
                resolved["kind"] = 9
            resolved.update(resolve_object(
                self._object_definitions[ref], self._object_live[ref], override,
                self._object_clips if self._include_waiting_visuals else {}, self._elapsed_ms,
            ))
            return resolved
        override = self._element_overrides.get((model_index, element_index))
        if not override:
            return element
        resolved = dict(element)
        resolved.update(override)
        return resolved

    def _resolve_frame(self, visual_ref: str) -> dict[str, object]:
        frame = self._frames.get(visual_ref)
        if frame is not None:
            return frame
        animation = self._animations.get(visual_ref)
        if animation is None:
            raise PreviewError(f"visual '{visual_ref}' is not a package sprite frame or animation")
        durations = tuple(int(value) for value in animation["frame_duration_ms"])
        indexes = tuple(int(value) for value in animation["frame_indexes"])
        cycle = sum(durations)
        loop_policy = int(animation["loop_policy"])
        if loop_policy == 1:
            position = self._elapsed_ms % cycle
            sequence = indexes
            sequence_durations = durations
        elif loop_policy in {2, 3}:
            position = min(self._elapsed_ms, cycle - 1)
            sequence = indexes
            sequence_durations = durations
        elif loop_policy == 4:
            sequence = indexes + indexes[-2:0:-1]
            sequence_durations = durations + durations[-2:0:-1]
            ping_pong_cycle = sum(sequence_durations)
            position = self._elapsed_ms % ping_pong_cycle
        else:
            raise PreviewError("compiled animation loop policy is unsupported")
        for frame_index, duration in zip(sequence, sequence_durations):
            if position < duration:
                return self._package.assets[frame_index]
            position -= duration
        return self._package.assets[sequence[-1]]

    def _validate_scene_subset(self) -> None:
        for state in self._graph["states"]:
            model = self._render_models[int(state["render_model_index"])]
            waiting = self._waiting_visuals[int(state["waiting_visual_index"])]
            elements = {str(element["element_id"]): element for element in model["elements"]}
            for element in model["elements"]:
                version = int(element.get("format_version", 1))
                kind = int(element["kind"])
                if version == 1 and kind != 1:
                    raise PreviewError(
                        f"element '{element['element_id']}' uses a procedural visual; "
                        "the package-backed preview requires sprites"
                    )
                retained_kinds = {1, 2, 3, 4, 5, 6, 7, 8} if self._object_source is not None else {1, 2, 3, 4, 5, 6}
                if version == 2 and kind not in retained_kinds:
                    raise PreviewError(f"element '{element['element_id']}' has an unsupported retained type")
                if kind == 1:
                    self._require_native_frame(element, str(element["visual_ref"]))
            for animated in waiting["elements"]:
                source_id = str(animated["source_element_ref"])
                source = elements.get(source_id)
                if source is None:
                    raise PreviewError(
                        f"waiting visual '{waiting['waiting_visual_id']}' references missing element '{source_id}'"
                    )
                if int(source["kind"]) != 1:
                    raise PreviewError(
                        f"waiting visual '{waiting['waiting_visual_id']}' requires a sprite source element"
                    )
                for visual_ref in animated["phase_visual_refs"]:
                    self._require_native_frame(source, str(visual_ref))
        for route in self._graph["routes"]:
            target_state = route["target_state_index"]
            if target_state is None:
                continue
            model_index = int(
                self._graph["states"][int(target_state)]["render_model_index"]
            )
            model = self._render_models[model_index]
            for operation in route["operations"]:
                if "object_action" in operation:
                    continue
                kind = int(operation["kind"])
                if kind not in {3, 4, 5, 6}:
                    continue
                element_index = int(operation["element_index"])
                if not 0 <= element_index < len(model["elements"]):
                    raise PreviewError("compiled element action target is invalid")
                if kind == 5:
                    self._require_native_frame(
                        model["elements"][element_index],
                        str(operation["frame_ref"]),
                    )
                elif kind == 6:
                    waiting = self._waiting_visuals[
                        int(operation["waiting_visual_index"])
                    ]
                    waiting_element = next(
                        (
                            item
                            for item in waiting["elements"]
                            if str(item["element_id"])
                            == str(operation["waiting_element_ref"])
                        ),
                        None,
                    )
                    if waiting_element is None:
                        raise PreviewError(
                            "compiled waiting-animation action source is invalid"
                        )
                    if str(waiting_element["source_element_ref"]) != str(
                        model["elements"][element_index]["element_id"]
                    ):
                        raise PreviewError(
                            "compiled waiting-animation action target is invalid"
                        )
                    target_waiting = self._waiting_visuals[
                        int(self._graph["states"][int(target_state)][
                            "waiting_visual_index"
                        ])
                    ]
                    if (
                        int(waiting["phase_quantum_ms"])
                        != int(target_waiting["phase_quantum_ms"])
                        or int(waiting["combined_step_count"])
                        != int(target_waiting["combined_step_count"])
                    ):
                        raise PreviewError(
                            "compiled waiting-animation timeline is incompatible"
                        )
                    for visual_ref in waiting_element["phase_visual_refs"]:
                        self._require_native_frame(
                            model["elements"][element_index], str(visual_ref)
                        )

    def _require_native_frame(self, element: dict[str, object], visual_ref: str) -> None:
        frame = self._resolve_frame(visual_ref)
        if int(frame["width"]) != int(element["width"]) or int(frame["height"]) != int(element["height"]):
            raise PreviewError(f"element '{element['element_id']}' requires unsupported runtime scaling")

    @staticmethod
    def _plane_bit(plane: bytes, stride: int, x: int, y: int) -> int:
        return (plane[y * stride + x // 8] >> (7 - (x % 8))) & 1

    @staticmethod
    def _write_bit(framebuffer: bytearray, x: int, y: int, value: int) -> None:
        if not (0 <= x < DISPLAY_WIDTH and 0 <= y < DISPLAY_HEIGHT):
            return
        offset = y * DISPLAY_STRIDE + x // 8
        mask = 1 << (7 - (x % 8))
        if value:
            framebuffer[offset] |= mask
        else:
            framebuffer[offset] &= ~mask

    @classmethod
    def _draw_line(cls, framebuffer: bytearray, x0: int, y0: int, x1: int, y1: int) -> None:
        dx = abs(x1 - x0)
        sx = 1 if x0 < x1 else -1
        dy = -abs(y1 - y0)
        sy = 1 if y0 < y1 else -1
        error = dx + dy
        while True:
            cls._write_bit(framebuffer, x0, y0, 1)
            if x0 == x1 and y0 == y1:
                return
            doubled = error * 2
            if doubled >= dy:
                error += dy
                x0 += sx
            if doubled <= dx:
                error += dx
                y0 += sy

    @classmethod
    def _draw_ellipse_row(cls, framebuffer: bytearray, center_x: int, center_y: int, x: int, y: int, filled: bool) -> None:
        if filled:
            cls._draw_line(framebuffer, center_x - x, center_y + y, center_x + x, center_y + y)
            cls._draw_line(framebuffer, center_x - x, center_y - y, center_x + x, center_y - y)
        else:
            for point_x, point_y in (
                (center_x + x, center_y + y),
                (center_x - x, center_y + y),
                (center_x + x, center_y - y),
                (center_x - x, center_y - y),
            ):
                cls._write_bit(framebuffer, point_x, point_y, 1)

    @classmethod
    def _draw_ellipse(cls, framebuffer: bytearray, center_x: int, center_y: int, radius_x: int, radius_y: int, filled: bool = False) -> None:
        x = 0
        y = radius_y
        radius_x_squared = radius_x * radius_x
        radius_y_squared = radius_y * radius_y
        dx = 0
        dy = 2 * radius_x_squared * y
        decision = radius_y_squared - radius_x_squared * radius_y + radius_x_squared // 4
        while dx < dy:
            cls._draw_ellipse_row(framebuffer, center_x, center_y, x, y, filled)
            x += 1
            dx += 2 * radius_y_squared
            if decision < 0:
                decision += radius_y_squared + dx
            else:
                y -= 1
                dy -= 2 * radius_x_squared
                decision += radius_y_squared + dx - dy

        decision = (
            radius_y_squared * (x * x + x)
            + radius_y_squared // 4
            + radius_x_squared * ((y - 1) * (y - 1))
            - radius_x_squared * radius_y_squared
        )
        while y >= 0:
            cls._draw_ellipse_row(framebuffer, center_x, center_y, x, y, filled)
            y -= 1
            dy -= 2 * radius_x_squared
            if decision > 0:
                decision += radius_x_squared - dy
            else:
                x += 1
                dx += 2 * radius_y_squared
                decision += radius_x_squared - dy + dx

    @classmethod
    def _draw_primitive(cls, framebuffer: bytearray, element: dict[str, object]) -> None:
        kind = int(element["kind"])
        x = int(element["x"])
        y = int(element["y"])
        width = int(element["width"])
        height = int(element["height"])
        right = x + width - 1
        bottom = y + height - 1
        if kind == 2:
            if element.get("line_direction", "down_right") == "up_right":
                cls._draw_line(framebuffer, x, bottom, right, y)
            else:
                cls._draw_line(framebuffer, x, y, right, bottom)
        elif kind == 3:
            cls._draw_line(framebuffer, x, y, right, y)
            cls._draw_line(framebuffer, x, bottom, right, bottom)
            cls._draw_line(framebuffer, x, y, x, bottom)
            cls._draw_line(framebuffer, right, y, right, bottom)
        elif kind == 4:
            for row in range(y, bottom + 1):
                cls._draw_line(framebuffer, x, row, right, row)
        elif kind in {5, 6, 7, 8}:
            cls._draw_ellipse(framebuffer, x + width // 2, y + height // 2, width // 2, height // 2, kind in {7, 8})
        else:
            raise PreviewError(f"element '{element['element_id']}' has an unsupported retained type")

    def _background_framebuffer(self):
        return bytearray(DISPLAY_BUFFER_SIZE)

    def _render_framebuffer(self) -> bytes:
        state = self._state()
        model_index = int(state["render_model_index"])
        model = self._render_models[model_index]
        overrides = self._visual_overrides()
        framebuffer = self._background_framebuffer()
        ordered = sorted(
            (
                (index, self._resolved_element(model_index, index, element))
                for index, element in enumerate(model["elements"])
            ),
            key=lambda item: (int(item[1].get("layer", 1)), int(item[1]["z_order"]), item[0]),
        )
        for _, element in ordered:
            if not int(element.get("visible", 1)):
                continue
            if int(element["kind"]) == 9:
                from .system_fonts import runtime_text_pixels
                for px, py in runtime_text_pixels(element["text"], element["font_id"], element["scale"],
                                                  element["alignment"], element["width"], element["height"]):
                    self._write_bit(framebuffer, int(element["x"]) + px, int(element["y"]) + py, int(not element.get('inverted', False)))
                continue
            if int(element["kind"]) != 1:
                if element.get('inverted', False):
                    coverage = bytearray(DISPLAY_BUFFER_SIZE)
                    self._draw_primitive(coverage, element)
                    for offset, mask in enumerate(coverage):
                        framebuffer[offset] &= mask ^ 255
                else:
                    self._draw_primitive(framebuffer, element)
                continue
            visual_ref = overrides.get(str(element["element_id"]), str(element["visual_ref"]))
            frame = self._resolve_frame(visual_ref)
            width = int(frame["width"])
            height = int(frame["height"])
            stride = int(frame["row_stride_bytes"])
            origin_x = int(element["x"]) - int(frame["pivot_x"])
            origin_y = int(element["y"]) - int(frame["pivot_y"])
            pixels = frame["pixels"]
            mask = frame["mask"]
            opaque = bool(frame["opaque"])
            for source_y in range(height):
                target_y = origin_y + source_y
                if not 0 <= target_y < DISPLAY_HEIGHT:
                    continue
                for source_x in range(width):
                    target_x = origin_x + source_x
                    if not 0 <= target_x < DISPLAY_WIDTH:
                        continue
                    if opaque or self._plane_bit(mask, stride, source_x, source_y):
                        self._write_bit(
                            framebuffer,
                            target_x,
                            target_y,
                            self._plane_bit(pixels, stride, source_x, source_y) ^ int(element.get('_effect_invert', 0)) ^ int(element.get('inverted', False)),
                        )
        self._framebuffer = bytes(framebuffer)
        return self._framebuffer

    def _next_preview_update(self, snapshot):
        """Host scheduling hint; elapsed time remains supplied by the host."""
        if self._suspended:
            return 1000
        delays = [1000]
        timer = self._next_state_timer()
        if timer is not None:
            delays.append(timer[0])
        timeline = snapshot['timeline']
        if timeline.get('step_count', 1) > 1:
            delays.append(timeline['phase_quantum_ms'] - timeline['step_elapsed_ms'])
        for obj in snapshot.get('objects', []):
            if obj.get('playback'):
                delays.append(obj['playback']['remaining_ms'])
        for records in (getattr(self, '_object_effects', {}), getattr(self, '_one_shot_clips', {})):
            for effect, _ in records.values():
                delay = effect.next_ms()
                if delay is not None and delay > 0 and not effect.paused:
                    delays.append(delay)
        if getattr(self, '_scope_menu', None) is not None and self._scope_menu.pending is not None:
            delays.append(10)
        return max(1, min(delays))

    def snapshot(self, input_result: PreviewInputResult | None = None) -> dict[str, Any]:
        state = self._state()
        waiting = self._waiting()
        variable_values = {
            str(definition["variable_id"]): value
            for definition, value in zip(self._graph["variables"], self._variables)
        }
        if self._scoped_variables:
            variable_values = {
                definition["variable_id"]: bool(value) if definition["value_type"] == "bool" else value
                for variable, value in zip(self._graph["variables"], self._variables)
                if (definition := self._scoped_variables[variable["variable_id"]])["scope"] == "scene"
            }
        event = None
        if input_result is not None:
            event = {
                "logical_source": input_result.logical_source,
                "event_kind": input_result.event_kind,
                "action_id": input_result.action_id,
                "accepted": input_result.accepted,
                "route_id": input_result.route_id,
                "audio_events": list(input_result.audio_events),
            }
        result = {
            "local_time": {"valid": self._local_ms is not None,
                           "milliseconds_since_2000": self._local_ms,
                           "calendar_deadline_ms": self._calendar_deadline,
                           "calendar_schedules": [{"binding_id": b['binding_id'],
                               "deadline_ms": self._calendars[b['binding_index']].deadline,
                               "consumed": self._calendars[b['binding_index']].consumed}
                               for b in self._graph.get('event_bindings', ()) if b['binding_index'] in self._calendars],
                           "suspended": self._suspended},
            "scene": {
                "scene_id": self.scene_id,
                "state_index": self._state_index,
                "state_id": state["state_id"],
                "display_name": state["display_name"],
            },
            "timeline": {
                "elapsed_ms": self._elapsed_ms,
                "presentation_id": waiting["presentation_id"],
                "step_index": self._step_index,
                "step_elapsed_ms": self._step_elapsed_ms,
                "phase_quantum_ms": waiting["phase_quantum_ms"],
                "step_count": waiting["combined_step_count"],
            },
            "variables": variable_values,
            "entry_trace": list(self._entry_trace),
            "package_variables": {
                definition["variable_id"]: bool(self._package_variables[definition["variable_id"]])
                if definition["value_type"] == "bool" else self._package_variables[definition["variable_id"]]
                for definition in self._scoped_variables.values() if definition["scope"] == "package"
            },
            "scoped_variables": [
                {"scope": definition["scope"], "variable_id": definition["variable_id"],
                 "value": bool(self._variables[index]) if definition["value_type"] == "bool" else self._variables[index]}
                for index, variable in enumerate(self._graph["variables"])
                if (definition := self._scoped_variables.get(variable["variable_id"]))
            ],
            "input": event,
            "framebuffer": {
                "width": DISPLAY_WIDTH,
                "height": DISPLAY_HEIGHT,
                "row_stride_bytes": DISPLAY_STRIDE,
                "encoding": "row_major_msb_1bpp_black_is_1",
                "size_bytes": len(self._framebuffer),
                "black_pixel_count": sum(byte.bit_count() for byte in self._framebuffer),
                "sha256": hashlib.sha256(self._framebuffer).hexdigest(),
                "data_base64": base64.b64encode(self._framebuffer).decode("ascii"),
            },
        }
        if self._object_source is not None:
            model_index = int(state["render_model_index"])
            model = self._render_models[model_index]
            objects = []
            for index, element in enumerate(model["elements"]):
                ref = str(element["element_id"])
                obj = self._object_definitions[ref]
                clip = self._object_clips.get(obj.get("animation_ref"))
                playback = None
                if clip is not None:
                    remaining = self._object_now(ref) % sum(clip["frame_duration_ms"])
                    for phase, duration in enumerate(clip["frame_duration_ms"]):
                        if remaining < duration:
                            playback = {"animation_ref": obj["animation_ref"], "phase_index": phase,
                                        "remaining_ms": duration - remaining}
                            break
                        remaining -= duration
                objects.append({"object_id": ref, "underlying": dict(self._object_live[ref]),
                                "effective": self._resolved_element(model_index, index, element), "playback": playback})
            result["scene"]["execution_model"] = "scene_objects"
            result["timeline"] = {"elapsed_ms": self._elapsed_ms, "ownership": "scene_objects"}
            result["objects"] = objects
            result["preview_backend"] = "host_scene_objects_not_firmware"
        if self._scope_input is not None:
            result['scope_input'] = self._scope_input.snapshot()
            result['scope_input']['system_preempted'] = self._suspended
        if self._scope_audio is not None:
            result['scope_audio'] = self._scope_audio.snapshot()
        result['next_update_ms'] = self._next_preview_update(result)
        return result
