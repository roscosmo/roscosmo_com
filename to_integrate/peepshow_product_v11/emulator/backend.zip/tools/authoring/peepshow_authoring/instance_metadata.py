"""Private ISM1 immutable metadata layout, not an installed egg chunk.

Compilation starts from source admission. Inspection validates the canonical
envelope and numeric references, NOT graph semantics, map ownership, integrity,
source lifetime or device resources. A firmware loader must perform those checks
before exposing any receiver. No package role or public export is granted here.
"""
from dataclasses import dataclass
import struct

from .instance_source import compile_instance_source
from .machine_wire import HEADER as GRAPH_HEADER, require
from .machine_limits import MACHINES, STATES, EVENTS, ROUTES
from .scene_machines import CAPABILITY
from .world_operands_wire import decode_operands, decode_query_operands

NONE = 0xffffffff
HEADER = struct.Struct('<4s14I')
BEHAVIOR = struct.Struct('<4I')
INSTANCE = struct.Struct('<5I')
BRIDGE = struct.Struct('<5I')
QUERY = struct.Struct('<7I12i')
CELL = struct.Struct('<4I')
POLICY_CELL = struct.Struct('<8I')
U32 = struct.Struct('<I')
OUTPUT = struct.Struct('<4I')


@dataclass(frozen=True)
class Metadata:
    behaviors: tuple       # (SMW1 bytes, local WOP1 bytes), shared once
    instances: tuple       # behavior, entity-X binding, writer, slot first/count
    bridges: tuple         # machine, event, instance/NONE, target event, query/NONE
    queries: tuple         # actor X/Y/Facing, grid W/H, cell first/count, 4 facings
    slots: tuple           # local operand order -> enclosing world binding
    cells: tuple           # X/Y binding, instance, behavior
    maximum_root_events: int
    initial_root_capacity: int
    required_queue_entries: int
    world_binding_count: int
    scene_machine_count: int
    scene_event_count: int
    outgoing: tuple = ()
    interaction_policies: tuple = ()  # input, direction mask, Boolean binding/NONE, expected


def _align(value):
    return (value + 3) & ~3


def behavior_shape(graph):
    """Envelope only; the existing native graph decoder remains authoritative."""
    require(len(graph) >= GRAPH_HEADER.size + 1, 'truncated instance graph')
    magic, version, header, size, seed, nm, ns, nv, ne, nt, nr, nf, nflow = GRAPH_HEADER.unpack_from(graph)
    require(magic == b'SMW1' and version == 1 and header == GRAPH_HEADER.size and
            size == len(graph) and nm == 1 and 1 <= ns <= STATES and 1 <= ne <= EVENTS and
            not (nv or nt or nf or nflow), 'unsupported instance graph envelope')
    entry = graph[header]
    require(entry < ns, 'invalid instance entry State')
    return ns, entry, ne


def _inspect_metadata(data, terrain=False):
    """Return immutable numeric records, or refuse without partial publication.

    Counts are checked against the exact buffer before allocating host lists.
    This is a layout inspector, deliberately not a trusted runtime decoder.
    """
    require(type(data) is bytes and len(data) >= HEADER.size, 'truncated instance metadata')
    magic, version, total, nb, ni, nr, nq, ns, nc, maximum, initial, queue, nw, nm, ne = HEADER.unpack_from(data)
    require(magic == b'ISM1' and version in ((1, 2, 3, 4, 5) if terrain else (1,)) and total == len(data),
            'invalid instance metadata header')
    require(version < 4 or len(data) >= HEADER.size + 4, 'truncated outgoing metadata header')
    no = U32.unpack_from(data, HEADER.size)[0] if version >= 4 else 0
    require(no <= ROUTES, 'too many outgoing endpoints')
    require(1 <= initial <= CAPABILITY['maximum_queue'] and
            1 <= maximum <= CAPABILITY['maximum_event_chain'] and queue == initial * maximum and
            queue <= CAPABILITY['maximum_event_chain'] and 1 <= nm <= MACHINES and 1 <= ne <= EVENTS,
            'invalid instance metadata context/work bound')
    header_size = HEADER.size + (4 if version >= 4 else 0)
    cell_codec = POLICY_CELL if version == 5 else CELL
    end = header_size + nb*BEHAVIOR.size + ni*INSTANCE.size + nr*BRIDGE.size + nq*QUERY.size + ns*4 + nc*cell_codec.size + no*OUTPUT.size
    require(end <= total, 'instance metadata tables exceed buffer')
    offset = header_size

    def table(codec, count):
        nonlocal offset
        result = tuple(codec.unpack_from(data, offset+i*codec.size) for i in range(count))
        offset += count*codec.size
        return result

    spans = table(BEHAVIOR, nb)
    instances = table(INSTANCE, ni)
    bridges = table(BRIDGE, nr)
    queries = table(QUERY, nq)
    slots = tuple(r[0] for r in table(U32, ns))
    wire_cells = table(cell_codec, nc)
    cells = tuple(r[:4] for r in wire_cells)
    policies = tuple(r[4:] for r in wire_cells) if version == 5 else ()
    outgoing = table(OUTPUT, no)
    cursor = end

    def payload(start, length):
        nonlocal cursor
        require(start == _align(cursor) and not any(data[cursor:start]) and
                length > 0 and length <= total-start, 'noncanonical instance payload span')
        cursor = start+length
        return data[start:cursor]

    behaviors, shapes, locals_ = [], [], []
    for go, gl, oo, ol in spans:
        graph, operands = payload(go, gl), payload(oo, ol)
        shapes.append(behavior_shape(graph))
        local = (decode_query_operands(operands, 1) if version >= 2 else
                 decode_operands(operands, 1))[0]
        require(all(r[0:2] == (5, i) for i, r in enumerate(local)),
                'instance local property slots must be consecutive')
        behaviors.append((graph, operands))
        locals_.append(local)
    require(cursor == total, 'trailing instance metadata bytes')
    require(all(slot < nw for slot in slots), 'instance world slot out of range')
    next_slot, entities = 0, set()
    for behavior, entity, writer, first, count in instances:
        require(behavior < nb and entity < nw and entity not in entities and
                writer < nm and first == next_slot and count == len(locals_[behavior]) and
                count <= ns-first, 'invalid instance assignment')
        require(len(set(slots[first:first+count])) == count, 'aliased local property bindings')
        entities.add(entity)
        next_slot += count
    require(next_slot == ns, 'unused instance slots')
    next_cell = 0
    for q in queries:
        ax, ay, facing, width, height, first, count = q[:7]
        require(max(ax, ay, facing) < nw and len({ax, ay, facing}) == 3 and
                1 <= width <= 0x7fffffff and 1 <= height <= 0x7fffffff and
                first == next_cell and count <= nc-first, 'invalid instance query')
        facings = tuple(q[7+i*3:10+i*3] for i in range(4))
        require(len({r[0] for r in facings}) == 4 and
                {r[1:] for r in facings} == {(-1, 0), (1, 0), (0, -1), (0, 1)},
                'invalid instance cardinal mapping')
        eligible = set()
        for x, y, instance, behavior in cells[first:first+count]:
            require(max(x, y) < nw and x != y and instance < ni and
                    instance not in eligible and behavior == instances[instance][0] and
                    x == instances[instance][1], 'invalid instance query target')
            eligible.add(instance)
        next_cell += count
    require(next_cell == nc, 'unused instance query cells')
    for cell, policy in zip(cells, policies):
        event, mask, enabled, expected = policy
        require(event < shapes[cell[3]][2] and 0 < mask < 16 and
                (enabled == NONE and expected == 0 or enabled < nw and expected <= 1),
                'invalid interaction policy')
    addresses, next_query = set(), 0
    for machine, event, instance, target_event, query in bridges:
        require(machine < nm and event < ne and (machine, event) not in addresses,
                'invalid instance bridge endpoint')
        addresses.add((machine, event))
        if query == NONE:
            require(instance < ni, 'invalid static instance target')
            targets = (instances[instance][0],)
        else:
            require(instance == NONE and query == next_query and query < nq,
                    'invalid instance query bridge')
            first, count = queries[query][5:7]
            targets = tuple(c[3] for c in cells[first:first+count])
            if policies:
                next_query += 1
                continue
            next_query += 1
        require(all(target_event < shapes[b][2] for b in targets) and
                (bool(targets) or target_event == 0), 'invalid target event')
    require(next_query == nq, 'unused instance queries')
    endpoints = set()
    for instance, event, machine, target in outgoing:
        require(instance < ni and event < shapes[instances[instance][0]][2] and
                machine < nm and target < ne and (instance, event) not in endpoints,
                'invalid outgoing endpoint')
        endpoints.add((instance, event))
    return Metadata(tuple(behaviors), instances, bridges, queries, slots, cells,
                    maximum, initial, queue, nw, nm, ne, outgoing, policies)


def inspect_metadata(data):
    """Ordinary revision-1 metadata; query-bearing revisions are refused."""
    return _inspect_metadata(data)


def inspect_terrain_metadata(data):
    """Explicit terrain envelope, not proof of actor coverage or movement reach."""
    return _inspect_metadata(data, terrain=True)


def encode_terrain_metadata(metadata, *, maximum_bytes, target_bindings=False):
    """Private numeric terrain transport for already compiled behavior graphs.

    Every behavior supplies query-aware WOP1, including zero-query behaviors.
    Revision 3 explicitly opts individual terrain queries into actor occupancy.
    ISM1 revision 4 carries explicit outgoing endpoints and Target authority.
    Runtime still admits same-entity mappings, writers, actors and full reach.
    This does not enable ordinary export or installed package admission.
    """
    require(type(target_bindings) is bool, 'invalid Target binding revision selector')
    require(isinstance(metadata, Metadata) and type(maximum_bytes) is int and
            HEADER.size <= maximum_bytes <= NONE, 'invalid terrain metadata budget')
    m = metadata
    version = 5 if m.interaction_policies else 4 if m.outgoing else 3 if target_bindings else 2
    require(not m.interaction_policies or len(m.interaction_policies) == len(m.cells),
            "interaction policy count mismatch")
    cell_codec = POLICY_CELL if version == 5 else CELL
    cell_records = tuple((*c, *p) for c, p in zip(m.cells, m.interaction_policies)) if version == 5 else m.cells
    cursor = (HEADER.size + (4 if version >= 4 else 0) + len(m.behaviors)*BEHAVIOR.size + len(m.instances)*INSTANCE.size +
              len(m.bridges)*BRIDGE.size + len(m.queries)*QUERY.size + len(m.slots)*4 + len(m.cells)*cell_codec.size + len(m.outgoing)*OUTPUT.size)
    spans = []
    for graph, operands in m.behaviors:
        start = _align(cursor)
        operand = _align(start+len(graph))
        spans.append((start, len(graph), operand, len(operands)))
        cursor = operand+len(operands)
    require(cursor <= maximum_bytes, 'terrain metadata exceeds supplied output budget')
    data = bytearray(HEADER.pack(b'ISM1', version, cursor, len(m.behaviors), len(m.instances),
        len(m.bridges), len(m.queries), len(m.slots), len(m.cells), m.maximum_root_events,
        m.initial_root_capacity, m.required_queue_entries, m.world_binding_count,
        m.scene_machine_count, m.scene_event_count))
    if version >= 4:
        data.extend(U32.pack(len(m.outgoing)))
    for codec, records in ((BEHAVIOR, spans), (INSTANCE, m.instances), (BRIDGE, m.bridges),
                          (QUERY, m.queries), (U32, [(s,) for s in m.slots]), (cell_codec, cell_records),
                          (OUTPUT, m.outgoing)):
        data.extend(b''.join(codec.pack(*row) for row in records))
    for behavior in m.behaviors:
        for value in behavior:
            data.extend(bytes(_align(len(data))-len(data)))
            data.extend(value)
    encoded = bytes(data)
    inspect_terrain_metadata(encoded)
    return encoded


def compile_metadata(bundle, scene_id, world, attachments, source, *,
                     queue_capacity, maximum_bytes, initial_event_capacity=1,
                     flow_attachments=None):
    """Compile source once, then serialize canonical tables and shared payloads.

    maximum_bytes is an explicit caller buffer/output budget, not a new target
    limit. Mutable State/generation, journals and preview objects are NOT stored.
    """
    require(type(maximum_bytes) is int and HEADER.size <= maximum_bytes <= NONE,
            'invalid instance metadata output budget')
    require(source.get('version') == 1,
            'spatial/Target source requires explicit terrain metadata transport')
    result = compile_instance_source(bundle, scene_id, world, attachments, source,
        queue_capacity=queue_capacity, initial_event_capacity=initial_event_capacity,
        flow_attachments=flow_attachments)
    instances, slots, bridges, queries, cells = [], [], [], [], []
    for row in result.instances.instances:
        instances.append((row.behavior, world.binding_sources.index(row.entity),
                          row.writer, len(slots), len(row.bindings)))
        slots.extend(row.bindings)
    for bridge, query in zip(result.routing.bridges, result.routing.queries, strict=True):
        index = NONE
        if query is not None:
            index = len(queries)
            queries.append((query.actor_x, query.actor_y, query.facing, query.width,
                query.height, len(cells), len(query.targets),
                *(v for r in query.facings for v in r)))
            cells.extend(query.targets)
        bridges.append((*bridge, index))
    nb = len(result.behaviors)
    cursor = HEADER.size + nb*BEHAVIOR.size + len(instances)*INSTANCE.size + len(bridges)*BRIDGE.size + len(queries)*QUERY.size + len(slots)*4 + len(cells)*CELL.size
    spans = []
    for behavior in result.behaviors:
        start = _align(cursor)
        operand = _align(start+len(behavior.logic.data))
        spans.append((start, len(behavior.logic.data), operand, len(behavior.operands)))
        cursor = operand+len(behavior.operands)
    require(cursor <= maximum_bytes, 'instance metadata exceeds supplied output budget')
    r = result.routing
    data = bytearray(HEADER.pack(b'ISM1', 1, cursor, nb, len(instances), len(bridges),
        len(queries), len(slots), len(cells), r.maximum_single_root_events,
        r.initial_event_capacity, r.required_queue_entries, len(world.binding_sources),
        len(result.scene.machines), len(result.scene.events)))
    for codec, records in ((BEHAVIOR, spans), (INSTANCE, instances), (BRIDGE, bridges),
                           (QUERY, queries), (U32, [(s,) for s in slots]), (CELL, cells)):
        data.extend(b''.join(codec.pack(*row) for row in records))
    for behavior in result.behaviors:
        for value in (behavior.logic.data, behavior.operands):
            data.extend(bytes(_align(len(data))-len(data)))
            data.extend(value)
    encoded = bytes(data)
    inspect_metadata(encoded)
    return encoded
