"""Shared typed world-reference shape. Not yet a project/service capability."""
import re

from .imported_properties import ImportedPropertyError, PropertyKey
from .tiled_assets import definitions


def validate_identity(asset, field, owner, prop, value_type):
    if (any(type(v) is not str for v in (asset, field, owner, prop, value_type))
            or not asset or value_type not in ('bool', 'int32')):
        raise ImportedPropertyError('invalid typed world reference')
    entity = re.fullmatch(r'object:[1-9][0-9]*', owner)
    if field == 'property':
        if not prop or not (owner == 'map' or re.fullmatch(r'(layer|object):[1-9][0-9]*', owner)):
            raise ImportedPropertyError('property reference requires a stable owner and property ID')
    elif field in ('camera_x', 'camera_y'):
        if owner != 'map' or prop or value_type != 'int32':
            raise ImportedPropertyError('camera reference requires map ownership and int32')
    elif field in ('entity_x', 'entity_y'):
        if not entity or prop or value_type != 'int32':
            raise ImportedPropertyError('entity coordinate requires an object ID and int32')
    else:
        raise ImportedPropertyError('unknown world reference field')


def parse_reference(source):
    """Return (WorldReference, expected primitive type), without resolving an asset."""
    from .world_references import WorldReference
    required = {'asset_id', 'field', 'owner_id', 'value_type'}
    if type(source) is not dict:
        raise ImportedPropertyError('world reference must be an object')
    if source.get('field') == 'property':
        required.add('property_id')
    if set(source) != required:
        raise ImportedPropertyError('invalid world reference fields')
    prop = source.get('property_id', '')
    validate_identity(source['asset_id'], source['field'], source['owner_id'], prop, source['value_type'])
    return WorldReference(source['asset_id'], source['field'], source['owner_id'], prop), source['value_type']


def validate_target(record, reference, expected, property_definitions=None):
    """Resolve against the accepted snapshot, never reread Tiled or compile pixels.

    Optional definitions must come from this same snapshot. Callers may reuse them
    when validating several references. Returns no mutable state or numeric slot.
    """
    validate_identity(reference.asset_id, reference.field, reference.owner_id, reference.property_id, expected)
    if reference.asset_id != record['asset_id']:
        raise ImportedPropertyError('foreign world reference')
    defs = definitions(record['asset_id'], record['snapshot']) if property_definitions is None else property_definitions
    if reference.field == 'property':
        key = PropertyKey(reference.asset_id, reference.owner_id, reference.property_id)
        if key not in defs or defs[key].value_type != expected:
            raise ImportedPropertyError('missing, static or mistyped world property')
    elif reference.field in ('entity_x', 'entity_y'):
        if not any(reference.owner_id == f"object:{obj['id']}"
                   for layer in record['snapshot']['layers'] if layer['type'] == 'objectgroup'
                   for obj in layer['objects']):
            raise ImportedPropertyError('missing world entity')


def resolve_reference(record, source):
    reference, expected = parse_reference(source)
    validate_target(record, reference, expected)
    return reference, expected
