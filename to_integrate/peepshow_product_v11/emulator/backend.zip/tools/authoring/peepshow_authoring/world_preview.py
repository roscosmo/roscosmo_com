"""World logic in the existing MachinePreview transaction boundary.

Public map preview supplies spatial rendering/query data through map_preview.
This evaluator is not device resource admission or an installed host.
Compiled map bytes are trusted compiler output, not an untrusted package parser.
"""
from .compiler import build_preview_package
from .machine_preview import MachinePreview
from .preview import PreviewError
from .tilemap_wire import HEADER, ENTITY, PROPERTY
from .world_operands_wire import decode_typed_operands as decode_operands, decode_query_operands
from .world_routes import _Routes, compile_world_machine_logic


class WorldPreviewContext:
    def __init__(self, graph, lowered, attachments, write_capacity, camera=(0, 0), flow_attachments=None):
        if type(write_capacity) is not int or write_capacity < 0:
            raise PreviewError('world write capacity must be explicitly admitted')
        if len(camera) != 2 or any(type(v) is not int or not -2**31 <= v < 2**31 for v in camera):
            raise PreviewError('invalid world camera')
        self.routes = _Routes(graph, lowered, attachments, flow_attachments)
        self.bindings, self.guards, self.actions = decode_operands(
            lowered.operands, len(lowered.machine_sources), len(lowered.flow_sources))
        self.queries, self.query_occupancy = (), ()
        if int.from_bytes(lowered.operands[4:8], 'little') in (2, 3, 4, 5, 6):
            decoded = decode_query_operands(lowered.operands, len(lowered.machine_sources), len(lowered.flow_sources))
            self.queries = decoded[3]
            self.query_occupancy = decoded[4] if len(decoded) == 5 else [0] * len(self.queries)
        self.spatial = None
        self.camera = None
        self.camera_actions = {}
        self.visibility = None
        self.visibility_actions = {}
        self.sources = lowered.binding_sources
        self.machines = lowered.machine_sources
        self.flows = lowered.flow_sources
        self.capacity = write_capacity
        data = lowered.map.data
        header = HEADER.unpack_from(data)
        self.values = {(1, 0): camera[0], (2, 0): camera[1]}
        self.types = {(1, 0): 0, (2, 0): 0}
        for i in range(header[11]):
            entity = ENTITY.unpack_from(data, header[14] + ENTITY.size * i)
            for field, value in ((3, entity[2]), (4, entity[3])):
                self.values[field, i] = value
                self.types[field, i] = 0
        slot = 0
        for i in range(header[12]):
            prop = PROPERTY.unpack_from(data, header[15] + PROPERTY.size * i)
            if prop[4] == 3:
                continue
            value = prop[5] if prop[5] < 2**31 else prop[5] - 2**32
            self.values[5, slot] = value
            self.types[5, slot] = int(prop[4] == 1)
            slot += 1
        for field, index, kind, _ in self.bindings:
            if self.types.get((field, index)) != kind:
                raise PreviewError('world binding does not match map storage')
        self.begin()

    def begin(self):
        self.written = set()

    def resolved_query(self, query):
        if self.spatial is None or not 0 <= query < len(self.queries):
            raise PreviewError('collision query has no admitted map context')
        record, kind = self.queries[query], self.query_occupancy[query]
        if kind in (3, 4):
            from .world_operands_wire import FACING_STEPS
            x, y, width, height, facing, _ = record
            direction = self.read(facing)
            if type(direction) is not int or not 0 <= direction < len(FACING_STEPS):
                raise PreviewError('invalid destination facing')
            record = (x, y, width, height, *FACING_STEPS[direction])
            kind -= 3
        return record, kind

    def read(self, binding, evidence=None):
        if binding >= len(self.bindings):
            query = binding - len(self.bindings)
            record, kind = self.resolved_query(query)
            return int(self.spatial.blocked(self, record, kind, evidence=evidence))
        field, index, kind, _ = self.bindings[binding]
        key = field, index
        if key not in self.values or self.types.get(key) != kind:
            raise PreviewError('world read failed')
        return self.values[key]

    def value(self, reference):
        """Inspect a declared reference; returned value is a copy, not a write API."""
        slot = self.sources.index(reference)
        value = self.read(slot)
        return bool(value) if self.bindings[slot][2] else value

    def matches(self, route, evidence=None):
        for operand in self.routes.guards(route):
            row = {} if evidence is not None else None
            if evidence is not None:evidence.append(row)
            if not self.predicate(operand, row):
                return False
        return True

    def predicate(self, operand, evidence=None):
        binding, compare, other = self.guards[operand]
        query = {} if evidence is not None and binding >= len(self.bindings) else None
        if evidence is not None:
            evidence.update(operator=('eq','ne','lt','le','gt','ge')[compare-1], right=other, evaluated=False)
            if query is not None:evidence['query']=query
            else:
                from dataclasses import asdict
                evidence['reference']=asdict(self.sources[binding])
        value = self.read(binding, evidence=query)
        result = (value == other, value != other, value < other, value <= other,
                  value > other, value >= other)[compare - 1]
        if evidence is not None:evidence.update(left=value,result=result,evaluated=True)
        return result

    def selector_predicate(self, value):
        key = value['reference_ref'], value['operator'], value['value']
        if key not in self.selector_guards:
            raise PreviewError('world selector reference is unavailable')
        return self.predicate(self.selector_guards[key])

    def position(self, object_ref):
        binding = self.positions.get(object_ref)
        if binding is None:
            return None
        entity, dx, dy = binding
        try:
            x = self.values[3,entity] - self.values[1,0] + dx
            y = self.values[4,entity] - self.values[2,0] + dy
        except KeyError as exc:
            raise PreviewError('world position read failed') from exc
        # Match native render scratch only. Full world coordinates stay intact.
        return max(-32768,min(32767,x)), max(-32768,min(32767,y))

    def flow_matches(self, player, flow, node, branch, ordinary):
        from .flowcharts import charge
        operands = self.routes.flows.guards(flow, node, branch)
        charge(player, 2 * len(operands))
        result = ordinary
        # Native postfix evaluates every token, including reads after false.
        for operand in operands:
            value = self.predicate(operand)
            result = result and value
        return result

    def write(self, operand, writer, evidence=None):
        if evidence is None:
            return self._write(operand, writer)
        from dataclasses import asdict
        binding, operation, value = self.actions[operand]
        slots = list(self.queries[value][:2]) if operation == 7 else [binding]
        if operation in (3, 6):slots.append(value)
        def snapshot():
            return [dict(reference=asdict(self.sources[slot]),
                         value=self.values[tuple(self.bindings[slot][:2])]) for slot in dict.fromkeys(slots)]
        if evidence is not None:evidence.update(before=snapshot(), completed=False)
        self._write(operand, writer, evidence)
        if evidence is not None:evidence.update(after=snapshot(), completed=True)

    def _write(self, operand, writer, evidence=None):
        binding, operation, value = self.actions[operand]
        if operation == 7:
            record, occupancy = self.resolved_query(value)
            query = {} if evidence is not None else None
            if evidence is not None:evidence['query']=query
            if self.spatial.blocked(self, record, occupancy, evidence=query):
                raise PreviewError('checked destination became blocked')
            x, y, width, height, dx, dy = record
            if any(self.bindings[slot][3] != writer or writer == 255 for slot in (x, y)):
                raise PreviewError('destination coordinate writer mismatch')
            if occupancy in (5, 6):
                # Reserve both writes before changing either coordinate. The
                # enclosing event candidate still owns commit/rollback.
                writes = [(self.bindings[x][:2], dx * width), (self.bindings[y][:2], dy * height)]
                if any(not -2**31 <= coordinate < 2**31 for _, coordinate in writes):
                    raise PreviewError('world value overflow')
                keys = {key for key, _ in writes}
                if len(self.written | keys) > self.capacity:
                    raise PreviewError('world journal capacity')
                self.written.update(keys)
                self.values.update(writes)
                return
            binding, value = (x, dx * width) if dx else (y, dy * height)
            operation = 2
        field, index, kind, owner = self.bindings[binding]
        if writer != owner or owner == 255:
            raise PreviewError('world writer mismatch')
        old = self.read(binding)
        if operation == 2:
            value += old
        elif operation == 3:
            value = self.read(value)
        elif operation == 4:
            value = min(old, value)
        elif operation == 5:
            value = max(old, value)
        elif operation == 6:
            value = old - self.read(value)
        if not -2**31 <= value < 2**31 or kind and value not in (0, 1):
            raise PreviewError('world value overflow')
        key = field, index
        if key not in self.written and len(self.written) >= self.capacity:
            raise PreviewError('world journal capacity')
        self.written.add(key)
        self.values[key] = value

    def execute(self, player, route, outcome_index, compiled, context, sends, audio):
        from .preview_steps import drain
        return drain(self.iterate_execute(player, route, outcome_index, compiled, context, sends, audio))

    def iterate_execute(self, player, route, outcome_index, compiled, context, sends, audio, observe=None):
        actions = route.get('outcomes', [route])[outcome_index]['actions']
        inserts = self.routes.insertions(route['route_id'], outcome_index)
        writer = self.machines.index(route['machine_ref']) if route['machine_ref'] in self.machines else 255
        return (yield from self._iterate_execute(player, actions, inserts, writer, compiled, context, sends, audio,
                             self.camera_actions.get(('route', route['route_id'], outcome_index), {}),
                             self.visibility_actions.get(('route', route['route_id'], outcome_index), {}), observe))

    def execute_flow(self, player, flow, node, compiled, context, sends, audio):
        return self._execute(player, node['actions'], self.routes.flows.insertions(flow, node['node_id']),
                             128 + self.flows.index(flow), compiled, context, sends, audio,
                             self.camera_actions.get(('flow', flow, node['node_id']), {}),
                             self.visibility_actions.get(('flow', flow, node['node_id']), {}))

    def _execute(self, player, actions, inserts, writer, compiled, context, sends, audio, camera_commands, visibility_commands):
        from .preview_steps import drain
        return drain(self._iterate_execute(player, actions, inserts, writer, compiled, context, sends, audio, camera_commands, visibility_commands))

    def _iterate_execute(self, player, actions, inserts, writer, compiled, context, sends, audio, camera_commands, visibility_commands, observe=None):
        from .flowcharts import charge, execute_actions
        if len(actions) != len(compiled['operations']):
            raise PreviewError('world action projection lost ordering')
        cursor, system_action = 0, None
        for position in range(len(actions) + 1):
            while cursor < len(inserts) and inserts[cursor][0] == position:
                mark = observe() if observe is not None else None
                if mark is not None:yield mark
                if player._machines.get('flowcharts'):
                    charge(player)
                detail = {} if mark is not None else None
                if mark is not None:mark['spatial_write']=detail
                self.write(inserts[cursor][1], writer, evidence=detail)
                if mark is not None:
                    from .preview_steps import complete_action
                    complete_action(mark)
                cursor += 1
            if position < len(actions):
                mark = observe() if observe is not None else None
                if mark is not None:yield mark
                if position in camera_commands:
                    from .camera_source import execute as camera_execute
                    camera_execute(self, camera_commands[position])
                if position in visibility_commands:
                    from .visibility_source import execute as visibility_execute
                    visibility_execute(self, visibility_commands[position])
                work = player._flow_work
                try:
                    result = execute_actions(player, [actions[position]],
                        {**compiled, 'operations': (compiled['operations'][position],)}, context, sends, audio)
                finally:
                    if not player._machines.get('flowcharts'):
                        player._flow_work = work
                if mark is not None:
                    from .preview_steps import complete_action
                    complete_action(mark)
                if result:
                    system_action = result
        return system_action


def create_world_context(bundle, scene_id, lowered, attachments, *, write_capacity, camera=(0, 0),
                         flow_attachments=None, selector_data=None, position_source=()):
    """Validate/configure before constructing a player or running Scene entry."""
    from .response_conditions import structural_bundle
    compile_world_machine_logic(structural_bundle(bundle), scene_id, lowered, attachments,
                                flow_attachments=flow_attachments,
                                _flowcharts=True, _object_effects=True, _calendars=True, _periodic=True)
    scene = next(s for s in bundle.scenes if s['scene_id'] == scene_id)
    context = WorldPreviewContext(scene['machine_logic'], lowered, attachments, write_capacity, camera, flow_attachments)
    context.selectors, context.selector_guards = selector_data if selector_data is not None else (None, {})
    from .world_position_source import lower
    numeric = lower(scene, lowered.map, position_source)
    context.positions = {scene['objects'][obj]['object_id']: (entity,x,y) for obj,entity,x,y in numeric}
    return context


def create_world_preview(bundle, scene_id, lowered, attachments, *, write_capacity, camera=(0, 0), flow_attachments=None,
                         selector_data=None, position_source=()):
    """Private one-Scene logic preview; normal Scene exit discards this context.

    Returning to a map Scene through public preview does not reattach it yet.
    A caller must create a new private preview to start another map activation.
    """
    context = create_world_context(bundle, scene_id, lowered, attachments, write_capacity=write_capacity,
        camera=camera, flow_attachments=flow_attachments, selector_data=selector_data, position_source=position_source)
    return MachinePreview(build_preview_package(bundle), scene_id, _world_context=context)
