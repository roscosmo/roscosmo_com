"""Private modal coordination over existing clocks, input, audio and rendering."""
from copy import deepcopy
from .preview import PreviewError


class ScopeMenu:
    def __init__(self, confirm_receiver=None, entry_receiver=None):
        self.open = False
        self.saved_world = None
        self.pending = None
        self.last = None
        self.confirm_receiver = deepcopy(confirm_receiver)
        self.entry_receiver = deepcopy(entry_receiver)

    def snapshot(self):
        return dict(open=self.open, saved_world=self.saved_world,
                    pending=deepcopy(self.pending), last=deepcopy(self.last),
                    confirm_receiver=deepcopy(self.confirm_receiver), entry_receiver=deepcopy(self.entry_receiver))


def visibility(player):
    context = player._world_context
    return getattr(context, 'visibility', None)


def present(player, opening, hide_world, saved_world, held_sources):
    """Prepare on a candidate; the caller publishes only after all checks pass."""
    masks = visibility(player)
    if masks is not None:
        masks['world'] = (False if hide_world else saved_world) if opening else saved_world
    player._scope_input.transfer('menu' if opening else 'gameplay', held_sources)
    player._scope_timing.set_activity(not opening, opening)
    player._sync_timeline_pause()
    player._select_visuals()
    component = getattr(player, '_menu_component', None)
    if component is not None:
        component.visible = opening
    player._render_framebuffer()


def publish(player, candidate):
    player.__dict__.clear()
    player.__dict__.update(candidate.__dict__)


def apply_confirmation(player, *, entry=False):
    """Run the declared owner through the existing executor on a private candidate.

    No clocks/input resume. Only this variable-only receiver gets a temporary
    delivery grant. The enclosing close publishes or discards the entire result.
    """
    component = getattr(player, '_menu_component', None)
    if component is not None:
        return component.initialize(player) if entry else component.apply(player)
    from .execution_scope_source import confirm_routes, ExecutionScopeError
    address = player._scope_menu.entry_receiver if entry else player._scope_menu.confirm_receiver
    if entry and address is None:
        return None
    try:
        confirm_routes(player._machines, address, player._scope_timing.owners['machines'], entry=entry)
    except ExecutionScopeError as exc:
        raise PreviewError(str(exc)) from None
    pending = player._scope_menu.pending
    player._scope_menu.pending = None
    player._scope_confirm_receiver = ('machines', address['machine_ref'])
    try:
        result = player._apply_binding(None, 'MENU_ENTRY' if entry else 'MENU_CONFIRM',
                                       'entry' if entry else 'confirm', address['event_ref'],
                                       _receiver=address['machine_ref'])
    finally:
        player._scope_confirm_receiver = None
        player._scope_menu.pending = pending
    if not result.accepted or player._machine_rejection is not None:
        raise PreviewError(('menu entry' if entry else 'menu confirmation') + ' not accepted: '
                           + (player._machine_rejection or 'no matching owner handler'))
    return dict(address, route_id=result.route_id)


def begin(player, opening, *, held_sources, budget_ms, hide_world=True, confirm=False):
    menu = player._scope_menu
    if menu is None or player._suspended or getattr(player, '_scope_dispatching', False):
        raise PreviewError('menu transition requires scoped ownership at an active, settled boundary')
    if menu.pending is not None:
        raise PreviewError('menu transition already pending')
    if (type(opening) is not bool or type(hide_world) is not bool
            or type(budget_ms) is not int or not 1 <= budget_ms <= 600000):
        raise PreviewError('menu transition requires Boolean mode and budget_ms in 1..600000')
    if opening == menu.open:
        raise PreviewError('menu is already in the requested state')
    component = getattr(player, '_menu_component', None)
    has_apply = menu.confirm_receiver is not None or component is not None and bool(component.source['drafts'])
    if type(confirm) is not bool or (confirm and (opening or not has_apply)):
        raise PreviewError('Confirm requires a declared gameplay apply receiver on close')
    owner = 'menu' if menu.open else 'gameplay'
    if (player._scope_input.scope != owner or player._scope_audio.focus != owner
            or player._scope_timing.active != dict(gameplay=not menu.open, menu=menu.open)):
        raise PreviewError('menu lifecycle does not match current focus and clock ownership')
    held = player._scope_input._snapshot_sources(held_sources)
    if player._scope_input.needs_snapshot:
        raise PreviewError('menu transition requires a fresh input snapshot')
    masks = visibility(player)
    if getattr(player._world_context, 'spatial', None) is not None and masks is None:
        raise PreviewError('map menu requires explicit map visibility configuration')
    saved = masks['world'] if opening and masks is not None else menu.saved_world
    # Reject invalid/restoration work before issuing an irreversible audio stop.
    candidate = deepcopy(player)
    if opening:
        apply_confirmation(candidate, entry=True)
    if confirm:
        apply_confirmation(candidate)
    present(candidate, opening, hide_world, saved, held)
    candidate = deepcopy(player)
    candidate._scope_input.pause_for_menu(held)
    stop = candidate._scope_audio.stop([owner])
    candidate._scope_timing.set_activity(False, False)
    candidate._sync_timeline_pause()
    token = candidate._scope_input.generation
    candidate._scope_menu.pending = dict(token=token, opening=opening, hide_world=hide_world,
        saved_world=saved, budget_ms=budget_ms, elapsed_ms=0, audio_token=stop['token'], confirm=confirm)
    candidate._scope_menu.last = dict(token=token, status='waiting_audio', opening=opening)
    publish(player, candidate)
    if stop['status'] == 'no_submitted_requests':
        return finish(player, token, held_sources=held)
    return dict(player._scope_menu.last, audio_stop=stop)


def require_pending(player, token):
    menu = player._scope_menu
    if (menu is None or menu.pending is None or type(token) is not int
            or token != menu.pending['token']):
        raise PreviewError('stale menu transition token')
    return menu.pending


def abort(player, reason):
    """Keep the last published state. Audio stop is never undone or replayed."""
    menu = player._scope_menu
    if menu is None or menu.pending is None:
        return
    pending = menu.pending
    menu.pending = None
    menu.last = dict(token=pending['token'], opening=pending['opening'], status=reason)
    if 'request' in pending:
        menu.last['request'] = deepcopy(pending['request'])
    player._scope_timing.set_activity(not menu.open, menu.open)
    player._sync_timeline_pause()
    player._scope_input._handoff(player._scope_input.scope, 'menu_transition_cancelled')
    player._scope_input.needs_snapshot = True
    if not player._scope_audio.pending_stop and not any(player._scope_audio.may_be_playing.values()):
        player._scope_audio.resume()


def finish(player, token, *, held_sources):
    pending = require_pending(player, token)
    if player._suspended or getattr(player, '_scope_dispatching', False):
        raise PreviewError('menu completion requires an active, settled boundary')
    held = player._scope_input._snapshot_sources(held_sources)
    if player._scope_audio.pending_stop is not None:
        raise PreviewError('menu audio stop is still pending')
    receipt = player._scope_audio.last_stop
    if receipt is None or receipt['token'] != pending['audio_token']:
        abort(player, 'audio_receipt_mismatch')
        return deepcopy(player._scope_menu.last)
    if receipt['status'] not in ('stopped', 'no_submitted_requests'):
        abort(player, 'audio_stop_failed')
        return deepcopy(player._scope_menu.last)
    candidate = deepcopy(player)
    confirmation = None
    entry_result = None
    if pending['confirm'] or pending['opening']:
        try:
            if pending['opening']:
                entry_result = apply_confirmation(candidate, entry=True)
            else:
                confirmation = apply_confirmation(candidate)
        except (PreviewError, ValueError) as exc:
            abort(player, 'entry_failed' if pending['opening'] else 'confirmation_failed')
            player._scope_menu.last['reason'] = str(exc)
            return deepcopy(player._scope_menu.last)
    try:
        candidate._scope_input.observe_snapshot(held, candidate._scope_input.generation)
        candidate._scope_audio.change_focus('menu' if pending['opening'] else 'gameplay')
        present(candidate, pending['opening'], pending['hide_world'], pending['saved_world'], held)
    except (PreviewError, ValueError) as exc:
        abort(player, 'presentation_failed')
        player._scope_menu.last['reason'] = str(exc)
        return deepcopy(player._scope_menu.last)
    menu = candidate._scope_menu
    menu.open = pending['opening']
    menu.saved_world = pending['saved_world'] if menu.open else None
    menu.pending = None
    menu.last = dict(token=token, opening=menu.open, status='committed')
    if 'request' in pending:
        menu.last['request'] = deepcopy(pending['request'])
    if menu.open:
        menu.last['entry'] = entry_result
    if not menu.open:
        menu.last.update(disposition='confirmed' if pending['confirm'] else 'cancelled',
                         confirmation=confirmation)
        component = getattr(candidate, '_menu_component', None)
        if component is not None:
            component.clear()
    publish(player, candidate)
    return deepcopy(menu.last)


def advance(player, elapsed_ms):
    if type(elapsed_ms) is not int or not 0 <= elapsed_ms <= 600000:
        raise PreviewError('elapsed_ms must be an integer in 0..600000')
    # Only wall time advances while an owner receipt is outstanding. Deadline is
    # observed at this host step; do not synthesize gameplay catch-up on expiry.
    player._advance_clock(elapsed_ms)
    pending = player._scope_menu.pending
    pending['elapsed_ms'] += elapsed_ms
    if pending['elapsed_ms'] >= pending['budget_ms']:
        abort(player, 'timeout')
    return ()
