"""Private Scene-local TAC1 operands; no installed package export opt-in."""
import struct

from .imported_properties import ImportedPropertyError
from .tilemap_binding import number

HEADER = struct.Struct('<4s5I')
RECORD = struct.Struct('<4I')
CONDITIONAL_RECORD = struct.Struct('<6I')
FIELDS = {'entity', 'x', 'y', 'cell_width', 'cell_height'}


def compile_terrain_actors(records, *, maximum_bytes=16 * 1024 * 1024):
    """Entity ordinals order records; X/Y are existing world-binding indices.

    Entity is compiler-only, not serialized: the firmware independently obtains
    membership from the admitted bindings. The caller must resolve these from
    the same Scene. Native admission validates membership and terrain spacing.
    This list alone does not prove every graph collision query is covered.
    """
    number(maximum_bytes, HEADER.size, 0xffffffff, 'host output budget')
    if not isinstance(records, (list, tuple)) or not records:
        raise ImportedPropertyError('terrain actor list must be nonempty')
    conditional = any(isinstance(row, dict) and 'solid_when' in row for row in records)
    record = CONDITIONAL_RECORD if conditional else RECORD
    total = HEADER.size + record.size * len(records)
    if total > maximum_bytes:
        raise ImportedPropertyError('terrain actors exceed host output budget')
    checked = []
    for row in records:
        if not isinstance(row, dict) or set(row) not in (FIELDS, FIELDS | {'solid_when'}):
            raise ImportedPropertyError('terrain actor fields are invalid')
        entry = {key: number(row[key], 1 if key.startswith('cell_') else 0,
                             0xffffffff, key) for key in FIELDS}
        entry['condition'] = (0, 0)
        if 'solid_when' in row:
            condition = row['solid_when']
            if (not isinstance(condition, dict) or set(condition) != {'binding', 'equals'}
                    or type(condition['equals']) is not bool):
                raise ImportedPropertyError('solid_when requires a binding and Boolean equals')
            entry['condition'] = (number(condition['binding'], 0, 0xfffffffe, 'solid binding') + 1,
                                  int(condition['equals']))
        checked.append(entry)
    checked.sort(key=lambda row: row['entity'])
    entities, bindings = set(), set()
    for row in checked:
        if row['entity'] in entities or row['x'] == row['y'] or bindings.intersection((row['x'], row['y'])):
            raise ImportedPropertyError('duplicate actor or aliased coordinate binding')
        entities.add(row['entity'])
        bindings.update((row['x'], row['y']))
    return HEADER.pack(b'TAC1', 2 if conditional else 1, total, len(checked), record.size, 0) + b''.join(
        record.pack(row['x'], row['y'], row['cell_width'], row['cell_height'],
                    *(row['condition'] if conditional else ())) for row in checked)
