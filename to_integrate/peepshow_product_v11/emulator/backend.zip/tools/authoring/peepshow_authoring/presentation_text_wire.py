"""Private BPT1 token records, not an admitted source field or egg section.

Callers resolve scoped references beforehand. These helpers are shared private
building blocks for package admission and preview, not a public source field.
Variable declarations use decoded SMG1 (initial, minimum, maximum, owner, boolean)
tuples. Formatting never reads live state or invents missing values.
"""
import struct


def encode_tokens(tokens):
    """Encode ('literal', str) / ('variable', resolved_index) pairs deterministically."""
    if not isinstance(tokens, (list, tuple)) or not 1 <= len(tokens) <= 16:
        raise ValueError('expected 1..16 tokens')
    result = bytearray(b'BPT1' + bytes((1, len(tokens), 0, 0)))
    literal_bytes = 0
    for token in tokens:
        if not isinstance(token, (list, tuple)) or len(token) != 2:
            raise ValueError('expected a typed token pair')
        kind, argument = token
        if kind == 'literal':
            if not isinstance(argument, str) or not argument:
                raise ValueError('literal must be nonempty text')
            if any(c != '\n' and not 32 <= ord(c) <= 126 for c in argument):
                raise ValueError('literal requires printable ASCII or LF')
            data = argument.encode('ascii')
            literal_bytes += len(data)
            if literal_bytes > 256:
                raise ValueError('literal bytes exceed resolved-text ceiling')
            result.extend(struct.pack('<BBH', 1, 0, len(data)))
            result.extend(data)
        elif kind == 'variable':
            if type(argument) is not int or not 0 <= argument < 32:
                raise ValueError('variable index must be 0..31')
            result.extend(struct.pack('<BBH', 2, 0, argument))
        else:
            raise ValueError('unknown token kind')
    return bytes(result)


def decode_tokens(record):
    """Strict structural inverse of encode_tokens; no padding or ignored bytes."""
    if not isinstance(record, (bytes, bytearray)) or not 8 <= len(record) <= 328:
        raise ValueError('invalid bounded-text record size')
    if record[:4] != b'BPT1' or record[4] != 1 or not 1 <= record[5] <= 16 or any(record[6:8]):
        raise ValueError('invalid bounded-text header')
    tokens, offset = [], 8
    for _ in range(record[5]):
        if len(record) - offset < 4:
            raise ValueError('truncated bounded-text token')
        kind, reserved, argument = struct.unpack_from('<BBH', record, offset)
        offset += 4
        if reserved:
            raise ValueError('reserved token byte must be zero')
        if kind == 1:
            if not argument or argument > len(record) - offset:
                raise ValueError('invalid literal span')
            try:
                text = record[offset:offset + argument].decode('ascii')
            except UnicodeDecodeError as error:
                raise ValueError('literal requires ASCII') from error
            tokens.append(('literal', text))
            offset += argument
        elif kind == 2:
            tokens.append(('variable', argument))
        else:
            raise ValueError('unknown token kind')
    if offset != len(record):
        raise ValueError('trailing bounded-text bytes')
    # Also enforce ASCII/LF, token argument and aggregate literal bounds.
    if encode_tokens(tokens) != record:
        raise ValueError('noncanonical bounded-text record')
    return tuple(tokens)


def analyze_tokens(tokens, variables, *, style, width, height):
    """Worst-case capacity from declared ranges, matching native Analyze.

    The owner byte is checked by machine admission, not this read-only binding.
    Unreferenced variable declarations are likewise left to machine admission.
    """
    encode_tokens(tokens)
    if not isinstance(variables, (list, tuple)) or len(variables) > 32:
        raise ValueError('invalid variable table')
    if (type(style) is not int or not 0 <= style <= 23 or
            any(type(v) is not int or not 1 <= v <= 0xffffffff for v in (width, height))):
        raise ValueError('invalid text style or local bounds')
    maximum_bytes = maximum_columns = columns = dependencies = 0
    lines = 1
    for kind, argument in tokens:
        if kind == 'literal':
            maximum_bytes += len(argument)
            for char in argument:
                if char == '\n':
                    columns = 0
                    lines += 1
                else:
                    columns += 1
                maximum_columns = max(maximum_columns, columns)
        else:
            if argument >= len(variables):
                raise ValueError('missing text variable')
            variable = variables[argument]
            if not isinstance(variable, (list, tuple)) or len(variable) != 5:
                raise ValueError('invalid variable declaration')
            initial, low, high, _, boolean = variable
            if (any(type(v) is not int or not -(1 << 31) <= v < (1 << 31)
                    for v in (initial, low, high)) or
                    type(boolean) is not int or boolean not in (0, 1) or
                    not low <= initial <= high or boolean and (low, high) != (0, 1)):
                raise ValueError('invalid text variable range')
            length = max(len(str(low)), len(str(high)))
            maximum_bytes += length
            columns += length
            maximum_columns = max(maximum_columns, columns)
            dependencies |= 1 << argument
        if maximum_bytes > 256:
            raise ValueError('resolved text exceeds 256 bytes')
    cell = 8 * ((style & 7) + 1)
    if maximum_columns * cell > width or lines * cell > height:
        raise ValueError('declared text range does not fit local bounds')
    return dict(maximum_bytes=maximum_bytes, maximum_columns=maximum_columns,
                lines=lines, dependencies=dependencies)


def resolve_tokens(tokens, variables, values, *, style, width, height):
    """Resolve one settled value snapshot, with no truncation or substitution."""
    analysis = analyze_tokens(tokens, variables, style=style, width=width, height=height)
    if (not isinstance(values, (list, tuple)) or len(values) > 32 or
            analysis['dependencies'] and len(values) < len(variables)):
        raise ValueError('missing settled value snapshot')
    for index, variable in enumerate(variables):
        if analysis['dependencies'] & (1 << index):
            value = values[index]
            if type(value) is not int or not variable[1] <= value <= variable[2]:
                raise ValueError('text value outside declared range')
    return ''.join(argument if kind == 'literal' else str(values[argument])
                   for kind, argument in tokens)
