"""Lower validated authoring projects into deterministic PKG1 .egg blobs."""

from __future__ import annotations

import hashlib
import struct
from copy import deepcopy
import zlib
from pathlib import Path
from typing import Any, Iterable

from .audio_assets import AUDIO_BLOCK_SAMPLES, AUDIO_CHANNELS, AUDIO_SAMPLE_RATE_HZ, AUDIO_MAX_BANK_BYTES
from .egg_format import (
    ANIMATION_HEADER,
    ANIMATION_RECORD,
    AUDIO_ASSET_HEADER,
    AUDIO_ASSET_RECORD,
    AUDIO_BANK_HEADER,
    AUDIO_CUE_HEADER,
    AUDIO_CUE_RECORD,
    ASSET_FLAG_OPAQUE,
    ASSET_HEADER,
    ASSET_RECORD,
    CHUNK_ANIMATION_TABLE,
    CHUNK_ASSET_TABLE,
    CHUNK_AUDIO_ADPCM_BANK,
    CHUNK_AUDIO_ASSET_TABLE,
    CHUNK_AUDIO_CUE_TABLE,
    CHUNK_MANIFEST,
    CHUNK_MASKED_1BPP_SPRITE_BANK,
    CHUNK_RENDER_MODELS,
    CHUNK_SCENE_OBJECTS,
    CHUNK_OBJECT_CONTROLS,
    CHUNK_SCENE_TABLE,
    CHUNK_STATE_GRAPH,
    CHUNK_STRING_TABLE,
    CHUNK_WAITING_VISUALS,
    EVENT_RECORD,
    GRAPH_HEADER,
    GUARD_RECORD,
    INPUT_RECORD,
    MANIFEST,
    OPERATION_RECORD,
    RENDER_ELEMENT_RECORD,
    RENDER_HEADER,
    RENDER_MODEL_RECORD,
    ROUTE_RECORD,
    SCENE_HEADER,
    SCENE_RECORD,
    SPRITE_BANK_HEADER,
    STATE_RECORD,
    STRING_HEADER,
    VARIABLE_RECORD,
    WAIT_ELEMENT_RECORD,
    WAIT_HEADER,
    WAIT_RECORD,
    EggChunkSpec,
    EggFormatError,
    EggPackage,
    build_container,
    parse_egg,
)
from .project import ProjectBundle
from .target_profile import TargetProfileError, target_profile_for_id


LOGICAL_SOURCES = {
    "BUTTON_A": 1,
    "BUTTON_B": 2,
    "BUTTON_L": 3,
    "BUTTON_R": 4,
    "BUTTON_START": 5,
    "JOY_LEFT": 6,
    "JOY_RIGHT": 7,
    "JOY_UP": 8,
    "JOY_DOWN": 9,
    "JOY_UP_LEFT": 10,
    "JOY_UP_RIGHT": 11,
    "JOY_DOWN_LEFT": 12,
    "JOY_DOWN_RIGHT": 13,
}
LOGICAL_EVENTS = {"press": 1, "release": 2, "hold": 3, "repeat": 4}
EVENT_CLASS_INPUT = 1
EVENT_CLASS_TIMER = 2
TIMER_EVENT_STATE_ENTRY_ELAPSED = 1
JOYSTICK_POLICIES = {"four_way": 1, "eight_way": 2}
GUARD_OPERATORS = {"eq": 1, "ne": 2, "lt": 3, "le": 4, "gt": 5, "ge": 6}
VARIABLE_OPERATIONS = {"assign": 1, "add": 2}
RENDER_KINDS = {
    "sprite": 1,
    "line": 2,
    "outline_rect": 3,
    "filled_rect": 4,
    "circle": 5,
    "ellipse": 6,
    "filled_circle": 7,
    "filled_ellipse": 8,
}
RENDER_LAYERS = {"BACKGROUND": 0, "SCENE": 1, "UI": 2}
INACTIVE_ROUTES = {"preserve_scene": 1, "exit_to_shell": 2}
INTERACTION_MODES = {"continuous": 1, "timeout": 2}
ANIMATION_LOOPS = {"loop": 1, "once": 2, "hold_last": 3, "ping_pong": 4}


def _generated_render_model_id(base_id: str, state_id: str, used: set[str]) -> str:
    base = f"{base_id}.{state_id}"
    if len(base) > 64:
        digest = hashlib.sha1(base.encode("utf-8")).hexdigest()[:8]
        base = f"{base[:55]}.{digest}"
    candidate = base[:64]
    index = 2
    while candidate in used:
        suffix = f".{index}"
        candidate = f"{base[:64 - len(suffix)]}{suffix}"
        index += 1
    used.add(candidate)
    return candidate


def _state_override_map(state: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        str(override["element_ref"]): override
        for override in state.get("placement_overrides", [])
        if isinstance(override, dict) and isinstance(override.get("element_ref"), str)
    }


def _apply_state_override(element: dict[str, Any], override: dict[str, Any] | None) -> dict[str, Any]:
    result = deepcopy(element)
    if override is None:
        return result
    if "x" in override and "y" in override:
        result["x"] = override["x"]
        result["y"] = override["y"]
    if "visible" in override:
        result["visible"] = override["visible"]
    if "visual_ref" in override:
        result["visual_ref"] = override["visual_ref"]
    return result


def _package_scene(scene: dict[str, Any]) -> dict[str, Any]:
    packaged = deepcopy(scene)
    base_model = scene["render_models"][0]
    used_model_ids: set[str] = set()
    render_models: list[dict[str, Any]] = []
    for state in packaged["states"]:
        state_id = str(state["state_id"])
        overrides = _state_override_map(state)
        model = deepcopy(base_model)
        model["visual_id"] = _generated_render_model_id(str(base_model["visual_id"]), state_id, used_model_ids)
        model["elements"] = [
            _apply_state_override(element, overrides.get(str(element["element_id"])))
            for element in base_model["elements"]
        ]
        state["render_model_ref"] = model["visual_id"]
        render_models.append(model)
    packaged["render_models"] = render_models
    return packaged


class EggCompileError(ValueError):
    """Raised when validated source cannot fit the frozen binary schema."""


def build_readiness_issues(bundle: ProjectBundle) -> list[dict[str, str]]:
    from .execution_semantics import issues as semantics_issues
    problems = semantics_issues(bundle.project)
    if problems:
        return problems
    from .machine_startup import enabled as startup_enabled
    if startup_enabled(bundle):
        return [dict(code='MACHINE_STARTUP_DEVICE_UNAVAILABLE', path='project.execution_semantics',
                     message='This execution contract is host-only; device export is not connected')]
    from .authoring_foundation import enabled, execution_issues, project_for_execution
    if enabled(bundle):
        if not bundle.valid:
            return []
        problems = execution_issues(bundle)
        if problems:
            return problems
        return build_readiness_issues(project_for_execution(bundle))
    if not bundle.valid:
        return []
    from .map_export import applies, analyze_readiness
    if applies(bundle):
        return analyze_readiness(bundle)['issues']
    from .asset_library import package_assets
    bundle = package_assets(bundle)
    from .tiled_assets import build_issues
    from .instance_project import readiness_issues as instance_issues
    from .execution_scope_source import readiness_issues as scope_issues
    authored_only = scope_issues(bundle) + instance_issues(bundle) + build_issues(bundle)
    if authored_only:
        return authored_only
    if any("machine_logic" in scene for scene in bundle.scenes):
        from .machine_export import readiness_issues
        return readiness_issues(bundle)
    if any(scene.get("schema_version") == 2 for scene in bundle.scenes):
        from .v2_export import source_issues, package_issues, issue
        issues = source_issues(bundle)
        if issues:
            return issues
        try:
            blob = build_development_egg_v2(bundle)
            package = parse_egg(blob, _development_v2=True)
            return package_issues(package, len(blob))
        except (EggCompileError, EggFormatError) as exc:
            return [issue("V2_ENCODING_UNSUPPORTED", "package", str(exc))]
    issues = []
    for source in sorted(bundle.scenes, key=lambda scene: scene["scene_id"]):
        scene = _package_scene(source)
        models = {model["visual_id"]: model for model in scene["render_models"]}
        for state in sorted(scene["states"], key=lambda state: state["state_id"]):
            model = models[state["render_model_ref"]]
            if not model["elements"]:
                issues.append({
                    "code": "RENDER_MODEL_EMPTY",
                    "scene_id": scene["scene_id"],
                    "state_id": state["state_id"],
                    "render_model_ref": model["visual_id"],
                    "path": f"scenes[{scene['scene_id']}].states[{state['state_id']}].render_model_ref",
                    "message": f"Scene \"{scene['scene_id']}\", state \"{state['state_id']}\": place at least one visual object before building.",
                })
    return issues


def _u16(value: int, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 0xFFFF:
        raise EggCompileError(f"{field} does not fit u16")
    return value


def _u32(value: int, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= 0xFFFFFFFF:
        raise EggCompileError(f"{field} does not fit u32")
    return value


def _i16(value: int, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not -0x8000 <= value <= 0x7FFF:
        raise EggCompileError(f"{field} does not fit i16")
    return value


def _i32(value: int, field: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not -0x80000000 <= value <= 0x7FFFFFFF:
        raise EggCompileError(f"{field} does not fit int32")
    return value


def _graph_routes(scene: dict[str, Any]) -> list[dict[str, Any]]:
    return [*scene["routes"], *(
        {**handler, "route_id": handler["handler_id"], "from_states": []}
        for handler in scene.get("event_handlers", [])
    )]


def _string_table(bundle: ProjectBundle, scenes: tuple[dict[str, Any], ...] | None = None,
                  *, _extra_strings=()) -> tuple[tuple[str, ...], dict[str, int], bytes]:
    project = bundle.project
    package = project["package"]
    source_scenes = bundle.scenes if scenes is None else scenes
    values: set[str] = {
        package["package_id"],
        package["display_name"],
        project["selected_target_profile"],
        project["entry_scene"],
    }
    for scene in source_scenes:
        values.update((scene["scene_id"], scene["display_name"]))
        values.update(record["variable_id"] for record in scene["variables"])
        values.update(record["action_id"] for record in scene["input_actions"])
        values.update(
            record["binding_id"] for record in scene.get("event_bindings", [])
        )
        for state in scene["states"]:
            values.update((state["state_id"], state["display_name"]))
        values.update(record["route_id"] for record in _graph_routes(scene))
        values.update(
            record["target_scene"]
            for record in _graph_routes(scene)
            if "target_scene" in record
        )
        values.update(obj["object_id"] for obj in scene.get("objects", []))
        from .presentation_text_source import resolved_source
        from .presentation_selectors import variable_definitions
        original = next((s for s in bundle.scenes if s['scene_id'] == scene['scene_id']), scene)
        text_definitions = variable_definitions(project, original)
        values.update(resolved_source(obj, text_definitions) for obj in scene.get("objects", []) if obj["kind"] == "text")
        for model in scene.get("render_models", []):
            values.add(model["visual_id"])
            for element in model["elements"]:
                values.add(element["element_id"])
                if element["kind"] == "sprite":
                    values.add(element["visual_ref"])
        for waiting in scene.get("waiting_visuals", []):
            values.update((waiting["waiting_visual_id"], waiting["presentation_id"]))
            for element in waiting["elements"]:
                values.update((element["element_id"], element["source_element_ref"]))
                values.update(element["phase_visual_refs"])
        values.add(scene["reactive_wait_default"]["policy_id"])
        values.add(scene["interaction_policy"]["policy_id"])
    for asset in bundle.assets:
        values.add(asset["asset_id"])
        values.update(frame["frame_id"] for frame in asset["frames"])
    values.update(animation["animation_id"] for animation in bundle.animations)
    values.update(asset.asset_id for asset in bundle.audio_assets)
    values.update(cue["cue_id"] for cue in bundle.audio_cues)
    values.update(_extra_strings)
    strings = tuple(sorted(values))
    if len(strings) > 0xFFFF:
        raise EggCompileError("string table contains more than 65535 strings")
    encoded = [value.encode("utf-8") for value in strings]
    if any(len(value) > 0xFFFF for value in encoded):
        raise EggCompileError("a string is longer than 65535 bytes")
    offsets = [0]
    payload = bytearray()
    for value in encoded:
        payload.extend(value)
        offsets.append(len(payload))
    header = STRING_HEADER.pack(b"STR1", 1, len(strings), len(payload))
    offset_table = struct.pack(f"<{len(offsets)}I", *offsets)
    return strings, {value: index for index, value in enumerate(strings)}, header + offset_table + payload


def _compile_manifest(project: dict[str, Any], strings: dict[str, int], scene_count: int) -> bytes:
    package = project["package"]
    version = tuple(int(part) for part in package["version"].split("."))
    for index, value in enumerate(version):
        _u16(value, f"package version field {index}")
    return MANIFEST.pack(
        b"MAN1",
        1,
        MANIFEST.size,
        strings[package["package_id"]],
        strings[package["display_name"]],
        strings[project["selected_target_profile"]],
        version[0],
        version[1],
        version[2],
        strings[project["entry_scene"]],
        _u16(scene_count, "scene count"),
        0,
    )


def _compile_render(scene: dict[str, Any], strings: dict[str, int]) -> bytes:
    model_records = bytearray()
    element_records = bytearray()
    element_count = 0
    for model in scene["render_models"]:
        first_element = element_count
        for element in model["elements"]:
            element_records.extend(
                RENDER_ELEMENT_RECORD.pack(
                    strings[element["element_id"]],
                    strings[element["visual_ref"]] if element["kind"] == "sprite" else 0xFFFF,
                    RENDER_KINDS[element["kind"]],
                    RENDER_LAYERS[element.get(
                        "layer",
                        "UI" if element.get("focus_role", "none") == "focus" else "SCENE",
                    )],
                    (1 if element.get("focus_role", "none") == "focus" else 0)
                    | (2 if element.get("visible", True) else 0)
                    | (
                        4
                        if element["kind"] == "line"
                        and element.get("line_direction", "down_right") == "up_right"
                        else 0
                    ),
                    0,
                    _i16(element["x"], "render x"),
                    _i16(element["y"], "render y"),
                    _u16(element["width"], "render width"),
                    _u16(element["height"], "render height"),
                    _u16(element["z_order"], "render z_order"),
                    0,
                )
            )
            element_count += 1
        model_records.extend(
            RENDER_MODEL_RECORD.pack(
                strings[model["visual_id"]],
                _u16(model["focus_index"], "focus index"),
                _u16(first_element, "first render element"),
                _u16(len(model["elements"]), "render element count"),
            )
        )
    header = RENDER_HEADER.pack(
        b"RND1",
        2,
        RENDER_HEADER.size,
        _u16(len(scene["render_models"]), "render model count"),
        _u16(element_count, "render element count"),
        0,
        0,
    )
    return header + model_records + element_records


def _compile_waiting(scene: dict[str, Any], strings: dict[str, int]) -> bytes:
    wait_records = bytearray()
    element_records = bytearray()
    phase_refs: list[int] = []
    sequence_values = bytearray()
    element_count = 0
    for waiting in scene["waiting_visuals"]:
        first_element = element_count
        for element in waiting["elements"]:
            first_phase = len(phase_refs)
            phase_refs.extend(strings[value] for value in element["phase_visual_refs"])
            first_step = len(sequence_values)
            sequence_values.extend(element["step_phase_indices"])
            element_records.extend(
                WAIT_ELEMENT_RECORD.pack(
                    strings[element["element_id"]],
                    strings[element["source_element_ref"]],
                    _u16(first_phase, "first phase reference"),
                    _u16(len(element["phase_visual_refs"]), "phase reference count"),
                    _u16(first_step, "first sequence step"),
                    _u16(len(element["step_phase_indices"]), "sequence step count"),
                )
            )
            element_count += 1
        wait_records.extend(
            WAIT_RECORD.pack(
                strings[waiting["waiting_visual_id"]],
                strings[waiting["presentation_id"]],
                _u16(waiting["phase_quantum_ms"], "waiting phase quantum"),
                _u16(waiting["combined_step_count"], "combined step count"),
                _u16(waiting["settled_step"], "settled step"),
                1,
                _u16(first_element, "first waiting element"),
                _u16(len(waiting["elements"]), "waiting element count"),
            )
        )
    header = WAIT_HEADER.pack(
        b"WAI1",
        1,
        WAIT_HEADER.size,
        _u16(len(scene["waiting_visuals"]), "waiting visual count"),
        _u16(element_count, "waiting element count"),
        _u16(len(phase_refs), "phase reference count"),
        _u16(len(sequence_values), "sequence value count"),
        0,
        0,
        0,
        0,
    )
    phases = struct.pack(f"<{len(phase_refs)}H", *phase_refs) if phase_refs else b""
    return header + wait_records + element_records + phases + sequence_values


def _compile_graph(
    scene: dict[str, Any],
    strings: dict[str, int],
    audio_cue_indexes: dict[str, int],
    *,
    _objects: bool = False,
) -> bytes:
    variables = scene["variables"]
    inputs = scene["input_actions"]
    events = scene.get("event_bindings", [])
    bindings = [*inputs, *events]
    states = scene["states"]
    routes = _graph_routes(scene)
    variable_index = {record["variable_id"]: index for index, record in enumerate(variables)}
    binding_index = {
        (record["action_id"] if "action_id" in record else record["binding_id"]): index
        for index, record in enumerate(bindings)
    }
    state_index = {record["state_id"]: index for index, record in enumerate(states)}
    render_index = {record["visual_id"]: index for index, record in enumerate(scene.get("render_models", []))}
    waiting_index = {record["waiting_visual_id"]: index for index, record in enumerate(scene.get("waiting_visuals", []))}

    variable_records = bytearray()
    for variable in variables:
        variable_records.extend(
            VARIABLE_RECORD.pack(
                strings[variable["variable_id"]],
                1,
                0,
                _i32(variable["initial"], "variable initial"),
                _i32(variable["minimum"], "variable minimum"),
                _i32(variable["maximum"], "variable maximum"),
            )
        )
    graph_version = 5 if events else 4
    if any(record["event_type"] == "time.scene_elapsed" for record in events):
        graph_version = 6
    if _objects:
        graph_version = 7
    if graph_version == 4:
        binding_records = b"".join(
            INPUT_RECORD.pack(
                strings[record["action_id"]],
                LOGICAL_SOURCES[record["logical_source"]]
                | (LOGICAL_EVENTS[record.get("event_kind", "press")] << 8),
            )
            for record in inputs
        )
    else:
        encoded_bindings = bytearray()
        for record in inputs:
            encoded_bindings.extend(
                EVENT_RECORD.pack(
                    strings[record["action_id"]],
                    EVENT_CLASS_INPUT,
                    LOGICAL_EVENTS[record.get("event_kind", "press")],
                    LOGICAL_SOURCES[record["logical_source"]],
                    0,
                )
            )
        for record in events:
            if record["event_type"] == "time.local_schedule":
                if not _objects:
                    raise EggCompileError("calendar schedules require V2 objects")
                config = record["configuration"]
                encoded_bindings.extend(EVENT_RECORD.pack(
                    strings[record["binding_id"]], EVENT_CLASS_TIMER, 3,
                    {"daily": 1, "today_offset": 2, "next_occurrence": 3}[config["mode"]],
                    config["time_of_day_seconds"] | (config.get("day_offset", 0) << 17),
                ))
                continue
            if record["event_type"] not in {"time.state_entry_elapsed", "time.scene_elapsed"}:
                raise EggCompileError("unsupported STATE event binding")
            encoded_bindings.extend(
                EVENT_RECORD.pack(
                    strings[record["binding_id"]],
                    EVENT_CLASS_TIMER,
                    2 if record["event_type"] == "time.scene_elapsed" else TIMER_EVENT_STATE_ENTRY_ELAPSED,
                    1 if record["configuration"].get("start_policy") == "action" else 0,
                    _u32(
                        record["configuration"]["delay_ms"],
                        "state-entry timer delay",
                    ),
                )
            )
        binding_records = bytes(encoded_bindings)
    state_records = b"".join(
        STATE_RECORD.pack(
            strings[record["state_id"]],
            strings[record["display_name"]],
            0xFFFF if _objects else render_index[record["render_model_ref"]],
            0xFFFF if _objects else waiting_index[record["waiting_visual_ref"]],
        )
        for record in states
    )

    route_records = bytearray()
    source_states: list[int] = []
    guard_records = bytearray()
    operation_records = bytearray()
    guard_count = 0
    operation_count = 0
    object_operation_count = 0
    for route in routes:
        target_elements: dict[str, int] = {}
        if "target_state" in route and not _objects:
            target_state_record = states[state_index[route["target_state"]]]
            target_render_model = scene["render_models"][
                render_index[target_state_record["render_model_ref"]]
            ]
            target_elements = {
                element["element_id"]: index
                for index, element in enumerate(target_render_model["elements"])
            }
        first_source = len(source_states)
        source_states.extend(state_index[value] for value in route["from_states"])
        first_guard = guard_count
        for guard in route["guards"]:
            guard_records.extend(
                GUARD_RECORD.pack(
                    variable_index[guard["variable_ref"]],
                    GUARD_OPERATORS[guard["operator"]],
                    0,
                    _i32(guard["value"], "guard value"),
                )
            )
            guard_count += 1
        first_operation = operation_count
        for operation in route["actions"]:
            if _objects and operation["kind"].startswith("object."):
                operation_records.extend(OPERATION_RECORD.pack(12, 0, object_operation_count, 0, 0, 0))
                object_operation_count += 1
            elif operation["kind"] == "set_variable":
                operation_records.extend(
                    OPERATION_RECORD.pack(
                        1,
                        VARIABLE_OPERATIONS[operation["operation"]],
                        variable_index[operation["variable_ref"]],
                        0,
                        0,
                        _i32(operation["value"], "operation value"),
                    )
                )
            elif operation["kind"] == "request_render":
                operation_records.extend(OPERATION_RECORD.pack(2, 0, 0xFFFF, 0, 0, 0))
            elif operation["kind"] == "set_element_visibility":
                operation_records.extend(
                    OPERATION_RECORD.pack(
                        3,
                        0,
                        target_elements[operation["element_ref"]],
                        0,
                        0,
                        1 if operation["visible"] else 0,
                    )
                )
            elif operation["kind"] == "set_element_position":
                operation_records.extend(
                    OPERATION_RECORD.pack(
                        4,
                        0,
                        target_elements[operation["element_ref"]],
                        _u16(operation["x"], "element action x"),
                        0,
                        _i32(operation["y"], "element action y"),
                    )
                )
            elif operation["kind"] == "set_element_frame":
                operation_records.extend(
                    OPERATION_RECORD.pack(
                        5,
                        0,
                        target_elements[operation["element_ref"]],
                        strings[operation["frame_ref"]],
                        0,
                        0,
                    )
                )
            elif operation["kind"] == "set_element_waiting_animation":
                source_waiting = scene["waiting_visuals"][
                    waiting_index[operation["waiting_visual_ref"]]
                ]
                source_element_index = next(
                    index
                    for index, element in enumerate(source_waiting["elements"])
                    if element["element_id"] == operation["waiting_element_ref"]
                )
                operation_records.extend(
                    OPERATION_RECORD.pack(
                        6,
                        1 if operation["timeline_policy"] == "preserve" else 2,
                        target_elements[operation["element_ref"]],
                        waiting_index[operation["waiting_visual_ref"]],
                        strings[source_waiting["elements"][source_element_index]["element_id"]],
                        0,
                    )
                )
            elif operation["kind"] == "play_sfx":
                operation_records.extend(
                    OPERATION_RECORD.pack(
                        7,
                        0,
                        audio_cue_indexes[operation["cue_ref"]],
                        0,
                        0,
                        0,
                    )
                )
            elif operation["kind"] == "exit_to_shell":
                operation_records.extend(
                    OPERATION_RECORD.pack(8, 0, 0, 0, 0, 0)
                )
            elif operation["kind"] in {"start_timer", "restart_timer", "cancel_timer"}:
                kind = {"start_timer": 9, "restart_timer": 10, "cancel_timer": 11}[operation["kind"]]
                operation_records.extend(
                    OPERATION_RECORD.pack(kind, 0, binding_index[operation["timer_ref"]], 0, 0, 0)
                )
            else:
                raise EggCompileError("unsupported STATE route action")
            operation_count += 1
        route_records.extend(
            ROUTE_RECORD.pack(
                strings[route["route_id"]],
                binding_index[route.get("event_ref", route.get("action_ref"))],
                state_index[route["target_state"]] if "target_state" in route else 0xFFFF,
                strings[route["target_scene"]] if "target_scene" in route else 0xFFFF,
                _u16(first_source, "first route source"),
                _u16(len(route["from_states"]), "route source count"),
                _u16(first_guard, "first route guard"),
                _u16(len(route["guards"]), "route guard count"),
                _u16(first_operation, "first route operation"),
                _u16(len(route["actions"]), "route operation count"),
            )
        )

    wait_policy = scene["reactive_wait_default"]
    interaction = scene["interaction_policy"]
    event_interests = [binding_index[value] for value in wait_policy["event_interests"]]
    meaningful = [binding_index[value] for value in interaction["meaningful_activity_actions"]]
    interaction_mode = INTERACTION_MODES[interaction["mode"]]
    inactive_route = INACTIVE_ROUTES.get(interaction.get("inactive_route"), 0)
    header = GRAPH_HEADER.pack(
        b"STG1",
        graph_version,
        GRAPH_HEADER.size,
        state_index[scene["entry_state"]],
        _u16(len(variables), "variable count"),
        _u16(len(bindings), "event binding count"),
        _u16(len(states), "state count"),
        _u16(len(routes), "route count"),
        _u16(len(source_states), "route source count"),
        _u16(guard_count, "guard count"),
        _u16(operation_count, "operation count"),
        strings[wait_policy["policy_id"]],
        0xFFFF if _objects else waiting_index[wait_policy["waiting_visual_ref"]],
        1 if wait_policy["hold_fallback_allowed"] else 0,
        _u16(len(event_interests), "event-interest count"),
        strings[interaction["policy_id"]],
        inactive_route,
        _u16(len(meaningful), "meaningful-action count"),
        interaction_mode | (JOYSTICK_POLICIES[scene.get("joystick_policy", "four_way")] << 8),
    )
    sources = struct.pack(f"<{len(source_states)}H", *source_states) if source_states else b""
    events = struct.pack(f"<{len(event_interests)}H", *event_interests) if event_interests else b""
    meaningful_bytes = struct.pack(f"<{len(meaningful)}H", *meaningful) if meaningful else b""
    return (
        header
        + variable_records
        + binding_records
        + state_records
        + route_records
        + sources
        + guard_records
        + operation_records
        + events
        + meaningful_bytes
    )


def _compile_scene_table(
    scenes: tuple[dict[str, Any], ...],
    strings: dict[str, int],
    chunk_indexes: dict[str, tuple[int, int, int]],
    *,
    _development_v2: bool = False,
) -> bytes:
    records = bytearray()
    for scene in scenes:
        state_index = {record["state_id"]: index for index, record in enumerate(scene["states"])}
        graph_index, render_index, waiting_index = chunk_indexes[scene["scene_id"]]
        records.extend(
            SCENE_RECORD.pack(
                strings[scene["scene_id"]],
                strings[scene["display_name"]],
                1,
                state_index[scene["entry_state"]],
                graph_index,
                render_index,
                waiting_index,
                (2 if scene.get("schema_version") == 2 else 1) if _development_v2 else 0,
                0,
            )
        )
    return SCENE_HEADER.pack(b"SCN2" if _development_v2 else b"SCN1", 2 if _development_v2 else 1, SCENE_HEADER.size, len(scenes), 0) + records


def _append_plane(payload: bytearray, plane: bytes, offsets: dict[bytes, int]) -> int:
    existing = offsets.get(plane)
    if existing is not None:
        return existing
    while len(payload) % 4:
        payload.append(0)
    offset = len(payload)
    payload.extend(plane)
    offsets[plane] = offset
    return offset


def _compile_asset_chunks(
    bundle: ProjectBundle,
    strings: dict[str, int],
    sprite_chunk_index: int,
    animation_chunk_index: int,
) -> tuple[bytes, bytes, bytes]:
    frames = tuple(sorted(bundle.frames, key=lambda frame: (frame.asset_id, frame.frame_id)))
    frame_indexes = {frame.frame_id: index for index, frame in enumerate(frames)}

    sprite_payload = bytearray(SPRITE_BANK_HEADER.size)
    plane_offsets: dict[bytes, int] = {}
    asset_records = bytearray()
    for frame in frames:
        pixel_offset = _append_plane(sprite_payload, frame.pixels, plane_offsets)
        if frame.opaque:
            mask_offset = 0
            mask_size = 0
            flags = ASSET_FLAG_OPAQUE
        else:
            mask_offset = _append_plane(sprite_payload, frame.mask, plane_offsets)
            mask_size = len(frame.mask)
            flags = 0
        asset_records.extend(
            ASSET_RECORD.pack(
                strings[frame.asset_id],
                strings[frame.frame_id],
                _u16(frame.width, "asset width"),
                _u16(frame.height, "asset height"),
                _u16(frame.row_stride_bytes, "asset row stride"),
                0,
                _i16(frame.pivot_x, "asset pivot x"),
                _i16(frame.pivot_y, "asset pivot y"),
                pixel_offset,
                len(frame.pixels),
                mask_offset,
                mask_size,
                flags,
            )
        )
    SPRITE_BANK_HEADER.pack_into(
        sprite_payload,
        0,
        b"SPB1",
        1,
        SPRITE_BANK_HEADER.size,
        len(sprite_payload) - SPRITE_BANK_HEADER.size,
        0,
    )
    asset_payload = ASSET_HEADER.pack(
        b"AST1",
        1,
        ASSET_HEADER.size,
        _u16(len(frames), "asset frame count"),
        _u16(sprite_chunk_index, "sprite chunk index"),
        _u16(animation_chunk_index, "animation chunk index"),
        0,
        0,
        0,
    ) + asset_records

    animation_records = bytearray()
    animation_frame_refs: list[int] = []
    animation_durations: list[int] = []
    for animation in sorted(bundle.animations, key=lambda item: item["animation_id"]):
        first_frame = len(animation_frame_refs)
        first_duration = len(animation_durations)
        selected_frames = [frame_indexes[frame_id] for frame_id in animation["frame_refs"]]
        animation_frame_refs.extend(selected_frames)
        animation_durations.extend(animation["frame_duration_ms"])
        width = max(frames[index].width for index in selected_frames)
        height = max(frames[index].height for index in selected_frames)
        animation_records.extend(
            ANIMATION_RECORD.pack(
                strings[animation["animation_id"]],
                _u16(first_frame, "animation first frame"),
                _u16(len(selected_frames), "animation frame count"),
                _u16(first_duration, "animation first duration"),
                ANIMATION_LOOPS[animation["loop_policy"]],
                _u16(width, "animation width"),
                _u16(height, "animation height"),
                0,
            )
        )
    frame_ref_bytes = (
        struct.pack(f"<{len(animation_frame_refs)}H", *animation_frame_refs)
        if animation_frame_refs
        else b""
    )
    duration_bytes = (
        struct.pack(f"<{len(animation_durations)}I", *animation_durations)
        if animation_durations
        else b""
    )
    animation_payload = (
        ANIMATION_HEADER.pack(
            b"ANI1",
            1,
            ANIMATION_HEADER.size,
            _u16(len(bundle.animations), "animation count"),
            _u16(len(animation_frame_refs), "animation frame-reference count"),
            _u16(len(animation_durations), "animation duration count"),
            0,
        )
        + animation_records
        + frame_ref_bytes
        + duration_bytes
    )
    return asset_payload, bytes(sprite_payload), animation_payload


def _compile_audio_chunks(
    bundle: ProjectBundle,
    strings: dict[str, int],
    bank_chunk_index: int,
) -> tuple[bytes, bytes, bytes]:
    assets = tuple(sorted(bundle.audio_assets, key=lambda asset: asset.asset_id))
    if sum(len(asset.adpcm) for asset in assets) > AUDIO_MAX_BANK_BYTES:
        raise EggCompileError(f"used audio exceeds the {AUDIO_MAX_BANK_BYTES}-byte package audio limit")
    asset_indexes = {asset.asset_id: index for index, asset in enumerate(assets)}
    bank_payload = bytearray(AUDIO_BANK_HEADER.size)
    asset_records = bytearray()
    for asset in assets:
        while len(bank_payload) % 4:
            bank_payload.append(0)
        data_offset = len(bank_payload)
        bank_payload.extend(asset.adpcm)
        asset_records.extend(
            AUDIO_ASSET_RECORD.pack(
                strings[asset.asset_id],
                0,
                asset.sample_count,
                asset.duration_ms,
                asset.decoded_pcm_bytes,
                data_offset,
                len(asset.adpcm),
                asset.block_count,
                zlib.crc32(asset.adpcm) & 0xFFFFFFFF,
                0,
            )
        )
    while len(bank_payload) % 4:
        bank_payload.append(0)
    AUDIO_BANK_HEADER.pack_into(
        bank_payload,
        0,
        b"ADB1",
        1,
        AUDIO_BANK_HEADER.size,
        len(bank_payload) - AUDIO_BANK_HEADER.size,
        0,
    )
    asset_payload = AUDIO_ASSET_HEADER.pack(
        b"AUD1",
        1,
        AUDIO_ASSET_HEADER.size,
        _u16(len(assets), "audio asset count"),
        _u16(bank_chunk_index, "audio bank chunk index"),
        AUDIO_SAMPLE_RATE_HZ,
        AUDIO_CHANNELS,
        AUDIO_BLOCK_SAMPLES,
        0,
    ) + asset_records

    cue_records = bytearray()
    cues = tuple(sorted(bundle.audio_cues, key=lambda cue: cue["cue_id"]))
    for cue in cues:
        cue_records.extend(
            AUDIO_CUE_RECORD.pack(
                strings[cue["cue_id"]],
                asset_indexes[cue["asset_ref"]],
                _u16(cue["priority"], "audio cue priority"),
                _u16(cue["volume"], "audio cue volume"),
                0,
                0,
            )
        )
    cue_payload = AUDIO_CUE_HEADER.pack(
        b"ACU1",
        1,
        AUDIO_CUE_HEADER.size,
        _u16(len(cues), "audio cue count"),
        _u16(len(assets), "audio cue asset count"),
        0,
        0,
    ) + cue_records
    return asset_payload, bytes(bank_payload), cue_payload


def build_egg(bundle: ProjectBundle) -> bytes:
    from .machine_startup import enabled as startup_enabled
    if startup_enabled(bundle):
        raise EggCompileError('MACHINE_STARTUP_DEVICE_UNAVAILABLE: This execution contract is host-only')
    from .execution_semantics import issues as semantics_issues
    problems = semantics_issues(bundle.project)
    if problems:
        raise EggCompileError(problems[0]['path'] + ': ' + problems[0]['message'])
    from .authoring_foundation import executable
    bundle = executable(bundle)
    from .map_export import applies, build_checked
    if applies(bundle):
        return build_checked(bundle)
    from .asset_library import package_assets
    bundle = package_assets(bundle)
    from .execution_scope_source import require_execution_ready
    require_execution_ready(bundle)
    if any("machine_logic" in scene for scene in bundle.scenes):
        from .machine_export import build_checked
        return build_checked(bundle)
    issues = build_readiness_issues(bundle)
    if issues:
        raise EggCompileError("\n".join(issue["message"] for issue in issues))
    return _build_egg(bundle, _development_v2=any(scene.get("schema_version") == 2 for scene in bundle.scenes))


def export_metadata(bundle: ProjectBundle, blob: bytes) -> dict:
    """Metadata for compiled output; never execute a preview to describe an egg."""
    from .authoring_foundation import executable
    bundle = executable(bundle)
    from .map_export import applies, compiled_metadata
    if applies(bundle):
        return compiled_metadata(bundle, blob)
    from .machine_export import PROFILE_ID as machine_profile
    from .v2_export import PROFILE_ID as object_profile
    package = parse_egg(blob)
    return dict(container_version=2 if any(s.get('execution_model') in (2, 3) for s in package.scenes) else 1,
        export_profile_id=machine_profile if any(s.get('execution_model') == 3 for s in package.scenes)
            else object_profile if any(s.get('execution_model') == 2 for s in package.scenes) else None,
        package_id=package.manifest['package_id'], target_profile=package.manifest['target_profile'],
        entry_scene=package.manifest['entry_scene'], scene_count=len(package.scenes),
        asset_frame_count=len(package.assets), animation_count=len(package.animations),
        audio_asset_count=len(package.audio_assets), audio_cue_count=len(package.audio_cues),
        chunk_count=len(package.chunks), size_bytes=len(blob), sha256=package.sha256)


def build_preview_package(bundle: ProjectBundle, *, scope_host: bool = False, _assets_selected: bool = False) -> EggPackage:
    """Compile an in-memory draft for host preview, never for export."""
    from .execution_semantics import issues as semantics_issues
    problems = semantics_issues(bundle.project)
    if problems:
        raise EggCompileError(problems[0]['path'] + ': ' + problems[0]['message'])
    original_bundle = bundle
    from .authoring_foundation import executable
    bundle = executable(bundle)
    from .response_preview import attach_sources
    if not _assets_selected:
        from .asset_library import package_assets
        bundle = package_assets(bundle)
    package = _build_preview_package(bundle, scope_host=scope_host)
    from .terminal_order import enabled as terminal_enabled, attach
    if terminal_enabled(original_bundle):
        attach(package, original_bundle)
    else:
        attach_sources(package, bundle)
    return package


def _build_preview_package(bundle: ProjectBundle, *, scope_host: bool = False) -> EggPackage:
    from dataclasses import replace
    from .behavior_response import lower_scene
    bundle = replace(bundle, scenes=tuple(lower_scene(s) for s in bundle.scenes))
    from .execution_scope_source import require_execution_ready
    require_execution_ready(bundle, preview=True, scope_host=scope_host)
    if any('map_scene' in scene.get('machine_logic', {}) for scene in bundle.scenes):
        from .map_preview import build_map_preview_package
        return build_map_preview_package(bundle, scope_host=scope_host)
    from .instance_project import readiness_issues
    if readiness_issues(bundle):
        raise EggCompileError(readiness_issues(bundle)[0]["message"])
    from .tiled_assets import build_issues
    if build_issues(bundle):
        raise EggCompileError(build_issues(bundle)[0]["message"])
    if any(scene.get("schema_version") == 2 for scene in bundle.scenes):
        from dataclasses import replace
        from .scene_object_authoring import graph_validation_view
        if not bundle.valid:
            raise EggCompileError("project must validate before preview")
        from .scoped_variables import project_scene
        from .scene_machines import project_scene as machine_scene
        projected = {scene["scene_id"]: project_scene(bundle.project, machine_scene(scene)) for scene in bundle.scenes}
        views = tuple(graph_validation_view(projected[scene["scene_id"]][0]) if scene.get("schema_version") == 2 else scene for scene in bundle.scenes)
        # The preview graph projection uses legacy visual records, not exported
        # V2 objects. Preserve binding indexes and restore calendar semantics below.
        for view in views:
            # Host component metadata is attached only after validated draft
            # compilation. Device builders still refuse the original source.
            view.pop('menu_component', None)
            if 'machine_logic' in next(s for s in bundle.scenes if s['scene_id'] == view['scene_id']):
                # Machine exits settle at the end of the addressed chain, not
                # in the legacy direct/SFX-only executor used by this draft IR.
                # Restore their destinations from source after parsing below.
                for route in (*view.get('routes', []), *view.get('event_handlers', [])):
                    route.pop('target_scene', None)
                    route.pop('scene_exit_ref', None)
            for binding in view.get("event_bindings", []):
                if binding['event_type'] in ('time.scene_elapsed', 'time.state_entry_elapsed'):
                    binding['configuration'].pop('mode', None)
                    binding['configuration'].pop('delay_max_ms', None)
                if binding["event_type"] == "time.local_schedule":
                    binding["event_type"] = "time.scene_elapsed"
                    binding["configuration"] = {"delay_ms": 1000, "start_policy": "action"}
        package = parse_egg(_build_egg(replace(bundle, scenes=views), _draft=True), _draft=True)
        sources = {scene["scene_id"]: scene for scene in bundle.scenes}
        for scene in package.scenes:
            source = sources[scene["scene_id"]]
            if source.get("schema_version") != 2:
                continue
            scene["object_source"] = deepcopy(source)
            scene["scoped_variables"] = projected[scene["scene_id"]][1]
            calendar = {binding["binding_id"]: binding for binding in source.get("event_bindings", [])
                        if binding["event_type"] == "time.local_schedule"}
            for binding in scene["graph"]["event_bindings"]:
                if binding["binding_id"] in calendar:
                    binding.update(deepcopy(calendar[binding["binding_id"]]))
                elif 'machine_logic' in source:
                    original = next((b for b in source.get('event_bindings', [])
                                     if b['binding_id'] == binding['binding_id']), None)
                    if original and 'mode' in original['configuration']:
                        binding['configuration']['mode'] = original['configuration']['mode']
                    if original and 'delay_max_ms' in original['configuration']:
                        binding['configuration']['delay_max_ms'] = original['configuration']['delay_max_ms']
            scene["object_animations"] = {clip["animation_id"]: deepcopy(clip) for clip in bundle.animations}
            routes = {route.get("route_id", route.get("handler_id")): route for route in [*source["routes"], *source.get("event_handlers", [])]}
            for route in scene["graph"]["routes"]:
                if "machine_logic" in source:
                    continue
                # Keep the shared executor's graph/timer IR, restoring only host object operations.
                actions = routes[route["route_id"]]["actions"]
                if len(actions) != len(route["operations"]):
                    raise EggCompileError("preview action projection lost operation ordering")
                route["operations"] = tuple(
                    {"object_action": deepcopy(action)} if action["kind"].startswith("object.") else operation
                    for action, operation in zip(actions, route["operations"])
                )
            if "machine_logic" in source:
                from .presentation_selectors import compile_selectors
                compile_selectors(bundle, source)
                scene["machine_logic"] = deepcopy(source["machine_logic"])
                original_bindings = {b["binding_id"] for b in source.get("event_bindings", [])}
                scene["graph"]["event_bindings"] = tuple(b for b in scene["graph"]["event_bindings"]
                                                        if b["binding_id"] in original_bindings)
                compiled = {r["route_id"]: r for r in scene["graph"]["routes"]}
                from .flowcharts import records_for_projection
                for key, _, actions in records_for_projection(source):
                    record = compiled[key]
                    record['operations'] = tuple(
                        {'object_action': deepcopy(action)} if action['kind'].startswith('object.')
                        else operation for action, operation in zip(actions, record['operations']))
                for ri, route in enumerate(source["machine_logic"]["routes"]):
                    for oi, outcome in enumerate(route.get("outcomes", [route])):
                        record = compiled[f"machine.{ri}.{oi}"]
                        record['target_scene'] = outcome.get('target_scene')
                        record["operations"] = tuple(
                            {"object_action": deepcopy(action)} if action["kind"].startswith("object.")
                            else operation for action, operation in zip(outcome["actions"], record["operations"]))
        if scope_host:
            from .execution_scope_source import attach_preview_sources
            attach_preview_sources(package, bundle)
        return package
    return parse_egg(_build_egg(bundle, _draft=True), _draft=True)


def build_development_egg_v2(bundle: ProjectBundle) -> bytes:
    """Encode structurally valid V2; normal export additionally checks HW6 limits."""
    if not any(scene.get("schema_version") == 2 for scene in bundle.scenes):
        raise EggCompileError("development V2 requires a scene-object scene")
    return _build_egg(bundle, _development_v2=True)


def build_scoped_test_egg(bundle: ProjectBundle) -> bytes:
    """Internal STG8 firmware test encoder; not a service/export operation."""
    return _build_egg(bundle, _development_v2=True, _scoped_test=True)


def _build_egg(bundle: ProjectBundle, *, _draft: bool = False, _development_v2: bool = False, _scoped_test: bool = False) -> bytes:
    if not _draft:
        from .asset_library import package_assets
        bundle = package_assets(bundle)
    from .menu_component import require_execution_ready as require_menu_ready
    require_menu_ready(bundle, preview=_draft)
    from .tiled_assets import build_issues
    if build_issues(bundle):
        raise EggCompileError(build_issues(bundle)[0]["message"])
    if any("machine_logic" in scene for scene in bundle.scenes):
        raise EggCompileError("SCENE_MACHINES_EXPORT_UNSUPPORTED: host-only machine source must never be encoded")
    from .scoped_variables import enabled
    entry_payloads = {}
    if _scoped_test or (enabled(bundle.project) and not _draft):
        from dataclasses import replace
        from .scoped_variables import project_scene
        from .entry_wire import compile_entry
        if not enabled(bundle.project):
            raise EggCompileError("STG8 test encoder requires scoped_v1")
        cues = {cue["cue_id"]: index for index, cue in enumerate(sorted(bundle.audio_cues, key=lambda c: c["cue_id"]))}
        entry_payloads = {scene["scene_id"]: compile_entry(bundle.project, scene, cues) for scene in bundle.scenes}
        bundle = replace(bundle, scenes=tuple(project_scene(bundle.project, scene)[0] for scene in bundle.scenes))
    if not bundle.valid:
        raise EggCompileError("project must validate before package compilation")
    if any(scene.get("schema_version") == 2 for scene in bundle.scenes) and not _development_v2:
        raise EggCompileError("SCENE_OBJECT_EXECUTABLE_UNAVAILABLE: version-2 scenes cannot be encoded as legacy eggs")
    try:
        target_profile = target_profile_for_id(
            bundle.project["selected_target_profile"]
        )
    except (KeyError, TargetProfileError) as exc:
        raise EggCompileError(f"target profile is unavailable: {exc}") from exc
    scenes = tuple(scene if scene.get("schema_version") == 2 else _package_scene(scene)
                   for scene in sorted(bundle.scenes, key=lambda scene: scene["scene_id"]))
    _, string_indexes, string_payload = _string_table(bundle, scenes)
    audio_cue_indexes = {
        cue["cue_id"]: index
        for index, cue in enumerate(sorted(bundle.audio_cues, key=lambda cue: cue["cue_id"]))
    }
    chunk_indexes = {
        scene["scene_id"]: (3 + index * 3, 4 + index * 3, 5 + index * 3)
        for index, scene in enumerate(scenes)
    }
    chunks: list[EggChunkSpec] = [
        EggChunkSpec("strings", CHUNK_STRING_TABLE, string_payload),
        EggChunkSpec("manifest", CHUNK_MANIFEST, _compile_manifest(bundle.project, string_indexes, len(scenes))),
        EggChunkSpec("scenes", CHUNK_SCENE_TABLE, _compile_scene_table(scenes, string_indexes, chunk_indexes, _development_v2=_development_v2)),
    ]
    for scene in scenes:
        scene_id = scene["scene_id"]
        if scene.get("schema_version") == 2:
            from .object_egg import compile_object_chunks
            object_payload, control_payload = compile_object_chunks(scene, string_indexes, bundle.frames, bundle.animations)
            graph_payload = _compile_graph(scene, string_indexes, audio_cue_indexes, _objects=True)
            if scene_id in entry_payloads:
                graph_payload = graph_payload[:4] + struct.pack("<H", 8) + graph_payload[6:] + entry_payloads[scene_id]
            chunks.extend((
                EggChunkSpec(f"state_graph.{scene_id}", CHUNK_STATE_GRAPH, graph_payload),
                EggChunkSpec(f"objects.{scene_id}", CHUNK_SCENE_OBJECTS, object_payload),
                EggChunkSpec(f"object_controls.{scene_id}", CHUNK_OBJECT_CONTROLS, control_payload),
            ))
            continue
        chunks.extend(
            (
                EggChunkSpec(
                    f"state_graph.{scene_id}",
                    CHUNK_STATE_GRAPH,
                    _compile_graph(scene, string_indexes, audio_cue_indexes),
                ),
                EggChunkSpec(f"render_models.{scene_id}", CHUNK_RENDER_MODELS, _compile_render(scene, string_indexes)),
                EggChunkSpec(f"waiting_visuals.{scene_id}", CHUNK_WAITING_VISUALS, _compile_waiting(scene, string_indexes)),
            )
        )
    if bundle.frames:
        asset_chunk_index = len(chunks)
        sprite_chunk_index = asset_chunk_index + 1
        animation_chunk_index = asset_chunk_index + 2
        asset_payload, sprite_payload, animation_payload = _compile_asset_chunks(
            bundle,
            string_indexes,
            sprite_chunk_index,
            animation_chunk_index,
        )
        chunks.extend(
            (
                EggChunkSpec("assets", CHUNK_ASSET_TABLE, asset_payload),
                EggChunkSpec("sprites.masked_1bpp", CHUNK_MASKED_1BPP_SPRITE_BANK, sprite_payload),
                EggChunkSpec("animations", CHUNK_ANIMATION_TABLE, animation_payload),
            )
        )
    if bundle.audio_assets:
        audio_asset_chunk_index = len(chunks)
        audio_bank_chunk_index = audio_asset_chunk_index + 2
        audio_asset_payload, audio_bank_payload, audio_cue_payload = _compile_audio_chunks(
            bundle,
            string_indexes,
            audio_bank_chunk_index,
        )
        chunks.extend(
            (
                EggChunkSpec("audio.assets", CHUNK_AUDIO_ASSET_TABLE, audio_asset_payload),
                EggChunkSpec("audio.cues", CHUNK_AUDIO_CUE_TABLE, audio_cue_payload),
                EggChunkSpec("audio.adpcm", CHUNK_AUDIO_ADPCM_BANK, audio_bank_payload),
            )
        )
    try:
        blob = build_container(bundle.project["package"]["package_id"], chunks, manifest_chunk_index=1, _development_v2=_development_v2)
        package_limit = int(target_profile["package"]["maximum_bytes"])
        if len(blob) > package_limit:
            raise EggCompileError(
                "compiled package exceeds the "
                f"{package_limit}-byte {target_profile['profile_id']} limit"
            )
        parse_egg(blob, _draft=_draft, _development_v2=_development_v2)
        return blob
    except (KeyError, struct.error, EggFormatError) as exc:
        raise EggCompileError(f"could not emit a valid .egg: {exc}") from exc


def write_egg(bundle: ProjectBundle, output_path: str | Path) -> Path:
    output = Path(output_path)
    if output.suffix.lower() != ".egg":
        raise EggCompileError("installable package output must end in .egg")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(build_egg(bundle))
    return output


def write_embedded_egg_c(
    bundle: ProjectBundle,
    output_path: str | Path,
    symbol: str = "g_ps_embedded_egg",
) -> Path:
    if not symbol or not symbol.replace("_", "a").isalnum() or symbol[0].isdigit():
        raise EggCompileError("embedded package symbol is not a C identifier")

    blob = build_egg(bundle)
    package_id = bundle.project["package"]["package_id"]
    digest = hashlib.sha256(blob).hexdigest()
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    for offset in range(0, len(blob), 12):
        values = ", ".join(f"0x{value:02X}U" for value in blob[offset : offset + 12])
        rows.append(f"  {values},")
    source = (
        "/* Generated by egg-tool embed. Do not edit manually. */\n"
        f"/* package={package_id} sha256={digest} */\n"
        "#include <stdint.h>\n\n"
        "#include \"ps_embedded_egg.h\"\n\n"
        f"const uint8_t {symbol}[] =\n"
        "{\n"
        + "\n".join(rows)
        + "\n};\n\n"
        f"const uint32_t {symbol}_size = (uint32_t)sizeof({symbol});\n"
    )
    output.write_text(source, encoding="ascii", newline="\n")
    return output
