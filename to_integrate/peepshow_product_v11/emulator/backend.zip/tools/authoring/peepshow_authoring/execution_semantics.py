"""Version boundary for authored execution; no implicit semantics migration."""
from copy import deepcopy
from .shared_triggers import CAPABILITY as SHARED_TRIGGER_CAPABILITY
from .callable_flows import CAPABILITY as CALLABLE_CAPABILITY
from .flow_library import CAPABILITY as FLOW_LIBRARY_CAPABILITY
from .behavior_library import CAPABILITY as BEHAVIOR_LIBRARY_CAPABILITY
from .preview_debug import CAPABILITY as PREVIEW_DEBUG_CAPABILITY

LEGACY = 'api120_v1'
PLANNED = 'authoring_v2'
STARTUP = 'machine_startup_v1'
TERMINAL = 'terminal_order_v1'
FIELD = 'execution_semantics'
COMMAND = 'project.execution_semantics.pin'
SCHEMA = 'schemas/authoring/execution-semantics-v1.schema.json'
COMMAND_SCHEMA = 'schemas/authoring/execution-semantics-command-v1.schema.json'

CAPABILITY = {
    'version': 1, 'project_field': FIELD, 'schema': SCHEMA,
    'command_schema': COMMAND_SCHEMA, 'commands': [COMMAND],
    'missing_field': LEGACY, 'implicit_source_rewrite': False,
    'supported_values': [LEGACY, STARTUP, TERMINAL], 'unknown_version_policy': 'reject_without_fallback',
    'pin_is_migration': False, 'migration_supported': False,
    'persistence': 'session_until_project.save', 'undo_redo': True,
    'contracts': {
        LEGACY: {
            'status': 'implemented_compatibility', 'authoring_save': True,
            'preview': True, 'device_export': 'existing_profile_subset_and_readiness',
            'scene_entry': 'existing_schema_rules_primary_machine_for_machine_scenes',
            'destination_before_actions': True,
            'response_decisions_before_actions': True,
            'event_delivery': 'queued_after_sender_response',
            'rollback_scope': 'root_event_transaction',
            'trigger_precedence': 'legacy_guarded_first_match_or_response_overlap_rejection',
            'flow_parameters': False, 'flow_named_outputs': False,
            'nested_flow_calls': False, 'project_logic_library': False,
            'inactive_disconnected_machines': False, 'reachable_only_preview': False,
            'draft_run': False, 'logic_step': False, 'state_step': False,
            'visual_breakpoints': False, 'trace_action_completion': False,
        },
        PLANNED: {
            'status': 'planned_not_accepted', 'authoring_save': False,
            'preview': False, 'device_export': False,
            'design_document': 'docs/03 Engine API/Authoring_Foundations_Contract.md',
            'planned_semantics': {
                'state_change': 'at_response_terminal',
                'operation_order': 'authored_diagram_order',
                'shared_trigger': 'state_specific_full_override_shared_overlap_error',
                'startup': 'scene_and_per_machine_initial_states',
                'preview': 'strict_participating_paths',
                'flow_parameters': True, 'flow_named_outputs': True,
                'nested_calls': 'bounded_no_recursion_no_waits',
                'definition_reuse': 'linked_scene_and_project_definitions',
                'debug_modes': ['run', 'logic_step', 'state_step'],
            },
            'draft_run': {'status': 'deferred', 'supported': False},
        },
    },
}


CAPABILITY['contracts'][STARTUP] = {
    **deepcopy(CAPABILITY['contracts'][LEGACY]),
    'status': 'host_startup_increment', 'device_export': False,
    'scene_entry': 'per_machine_initial_states_no_primary_machine',
    'inactive_disconnected_machines': True,
    'reachable_only_preview': False,
    'participation_scope': 'machines_and_called_flows_all_scenes_still_checked',
    'create_parameter': 'execution_semantics', 'create_value': STARTUP,
    'requires_authoring_mode': 'incremental_v1',
    'starter': {'scene_id': 'main', 'machine_id': 'main', 'state_id': 'start'},
    'entry_command': 'scene.machine.set_entry',
    'entry_command_schema': 'schemas/authoring/incremental-commands-v1.schema.json',
    'null_machine_entry': 'inactive', 'scene_entry_state': 'null',
    'snapshot_scene_state': 'null', 'scene_time': 'scene_elapsed_ms',
    'migration_supported': False,
}


CAPABILITY['contracts'][TERMINAL] = {
    **deepcopy(CAPABILITY['contracts'][STARTUP]),
    'status':'host_terminal_order_map_increment', 'create_value':TERMINAL,
    'destination_before_actions':False, 'response_decisions_before_actions':False,
    'operation_order':'authored_diagram_order', 'state_change':'at_response_terminal',
    'decisions_after_actions':True, 'contexts':['ordinary_machine', 'shared_behavior', 'actor_output'],
    'map_and_shared_behavior_preview':True, 'map_preview_requires':'all_scenes_map_bound',
    'checked_destination_proof':'same_executed_response_path',
    'destination_invalidators':['world_write','property_write','facing_write','flow_call','move'],
    'trigger_precedence':'explicit_state_full_override_shared_overlap_error',
    'shared_trigger_scope':'explicit_route_field_only_unannotated_unchanged',
    'shared_triggers':deepcopy(SHARED_TRIGGER_CAPABILITY),
    'flow_parameters':True, 'flow_named_outputs':True, 'nested_flow_calls':True,
    'callable_flows':deepcopy(CALLABLE_CAPABILITY),
    'project_logic_library':True, 'project_definition_kinds':['typed_flowcharts','shared_behavior_v3'],
    'flow_library':deepcopy(FLOW_LIBRARY_CAPABILITY),
    'behavior_library':deepcopy(BEHAVIOR_LIBRARY_CAPABILITY),
    'response_lifecycle_actions':False, 'root_lifecycle_handlers':True,
    'logic_step':True, 'state_step':True, 'visual_breakpoints':True,
    'trace_action_completion':True, 'debugger':deepcopy(PREVIEW_DEBUG_CAPABILITY),
    'terminal_trace':{'field':'machine_execution.trace[].terminal_response',
        'evidence':'visited_candidate_nodes', 'transaction_result_field':'result',
        'schema':'schemas/authoring/terminal-response-trace-v1.schema.json'},
}


def issues(project):
    value = project.get(FIELD, LEGACY)
    if value in (LEGACY, STARTUP, TERMINAL):
        return []
    return [dict(code='EXECUTION_SEMANTICS_UNSUPPORTED', path='project.' + FIELD,
        message=f'Unsupported execution semantics {value!r}; accepted contracts are {LEGACY}, {STARTUP}, {TERMINAL}. '
                'No fallback or implicit migration is performed.')]


def report(project):
    problems = issues(project)
    return dict(effective=project.get(FIELD, LEGACY),
                source='explicit' if FIELD in project else 'implicit_api120_compatibility',
                supported=not problems, issues=problems)


def capability():
    return deepcopy(CAPABILITY)


def apply(project, command):
    from .project import ProjectCommandError, _require_command_fields
    _require_command_fields(command, {'kind', FIELD}, {'kind', FIELD, 'command_id'})
    problems = issues(command)
    if not problems and (command[FIELD] != LEGACY or project.get(FIELD, LEGACY) != LEGACY):
        raise ProjectCommandError('EXECUTION_SEMANTICS_MIGRATION_REQUIRED', 'Pin only records existing api120_v1 semantics; use explicit migration when available')
    if problems:
        raise ProjectCommandError(problems[0]['code'], problems[0]['message'])
    project[FIELD] = LEGACY
    return {'kind': COMMAND, FIELD: LEGACY, 'migration': False}


def execution_project(project):
    """Canonical effective semantics for runtime identity only; never saved source."""
    return dict(project, execution_semantics=project.get(FIELD, LEGACY))
