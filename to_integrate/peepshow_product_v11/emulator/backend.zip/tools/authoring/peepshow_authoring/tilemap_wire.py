"""Private TMW1 layout/primitive-property codec, not an installable egg chunk.

Image compilation, shared entity definitions, logic binding and target admission
are deliberately separate. Tile IDs map back to source tiles in the host manifest.
"""
from dataclasses import dataclass
import struct

from .tiled_assets import validate_record, definitions
from .imported_properties import ImportedPropertyError
from .tile_selection import used_tiles, source_ranges

HEADER = struct.Struct('<4s19I')
LAYER = struct.Struct('<8I')
ENTITY = struct.Struct('<IIiiIIII')
PROPERTY = struct.Struct('<8I')
U32 = struct.Struct('<I')


@dataclass(frozen=True)
class CompiledMap:
    data: bytes
    tile_sources: tuple
    property_sources: tuple
    metadata_bytes: int
    cell_bytes: int
    mutable_value_bytes: int


def compile_map(record, root, *, block_width=8, block_height=8, maximum_bytes=16 * 1024 * 1024):
    """Compile accepted snapshot/default edits, without reading image files."""
    values = validate_record(record, root)
    if type(maximum_bytes) is not int or not 80 <= maximum_bytes <= 0xffffffff:
        raise ImportedPropertyError('Explicit host output budget must fit uint32')
    if any(type(n) is not int or not 1 <= n <= 256 for n in (block_width, block_height)):
        raise ImportedPropertyError('Block dimensions must be 1..256')
    data = record['snapshot']
    nx = (data['width'] + block_width - 1) // block_width
    ny = (data['height'] + block_height - 1) // block_height
    cell_cost = sum(layer['type'] == 'tilelayer' for layer in data['layers']) * nx * ny * block_width * block_height * 4
    if cell_cost + HEADER.size > maximum_bytes:
        raise ImportedPropertyError('Padded cell blocks exceed host output budget')
    defs = definitions(record['asset_id'], data)
    selected = used_tiles(data)
    tiles = source_ranges(selected)
    tile_count = len(selected)
    remap = {gid: index for index, gid in enumerate(selected, 1)}
    def tile(gid):
        if gid == 0:
            return 0
        return remap[gid]
    layers = sorted(enumerate(data['layers']), key=lambda pair: pair[1]['id'])
    owners = {'map': (0, 0)}
    entities = []
    for index, (_, layer) in enumerate(layers):
        owners[f"layer:{layer['id']}"] = (1, index)
        entities.extend((obj, index) for obj in layer.get('objects', []))
    entities.sort(key=lambda item: item[0]['id'])
    for index, (obj, _) in enumerate(entities):
        owners[f"object:{obj['id']}"] = (2, index)
    keys = sorted(defs, key=lambda key: (*owners[key.owner_id], key.property_id.encode('utf-8')))
    texts, props, mutable = bytearray(), [], 0
    for key in keys:
        name = key.property_id.encode('utf-8')
        name_offset = len(texts)
        texts.extend(name)
        value = values[key]
        kind = {'bool': 1, 'int32': 2, 'string': 3}[defs[key].value_type]
        aux = 0
        if kind == 3:
            encoded = value.encode('utf-8')
            value, aux = len(texts), len(encoded)
            texts.extend(encoded)
        else:
            value = int(value) & 0xffffffff
            mutable += 4
        props.append(PROPERTY.pack(*owners[key.owner_id], name_offset, len(name), kind, value, aux, 0))
    layer_off = HEADER.size
    entity_off = layer_off + len(layers) * LAYER.size
    prop_off = entity_off + len(entities) * ENTITY.size
    text_off = prop_off + len(props) * PROPERTY.size
    cells_off = (text_off + len(texts) + 3) & ~3
    if cells_off + cell_cost > maximum_bytes:
        raise ImportedPropertyError('Map metadata and cells exceed host output budget')
    bw, bh = block_width, block_height
    nx, ny = (data['width'] + bw - 1) // bw, (data['height'] + bh - 1) // bh
    block_bytes = bw * bh * 4
    cells, layer_records = bytearray(), []
    for order, layer in layers:
        visible = layer.get('visible', True)
        if type(visible) is not bool:
            raise ImportedPropertyError('Layer visible must be boolean')
        tiled = layer['type'] == 'tilelayer'
        layer_records.append(LAYER.pack(layer['id'], 1 if tiled else 2, int(visible),
                                        cells_off + len(cells) if tiled else 0,
                                        nx if tiled else 0, ny if tiled else 0, order, 0))
        if tiled:
            for by in range(ny):
                for bx in range(nx):
                    for y in range(bh):
                        for x in range(bw):
                            xx, yy = bx * bw + x, by * bh + y
                            gid = layer['data'][yy * data['width'] + xx] if xx < data['width'] and yy < data['height'] else 0
                            cells.extend(U32.pack(tile(gid)))
    entity_records = []
    for obj, layer_index in entities:
        if any(type(obj.get(field, default)) is not bool for field, default in (('point', False), ('visible', True))):
            raise ImportedPropertyError('Object point/visible must be boolean')
        entity_records.append(ENTITY.pack(obj['id'], layer_index, int(obj.get('x', 0)), int(obj.get('y', 0)),
                                           int(obj.get('width', 0)), int(obj.get('height', 0)),
                                           int(obj.get('point', False)), int(obj.get('visible', True))))
    total = cells_off + len(cells)
    if total > 0xffffffff:
        raise ImportedPropertyError('Map byte span exceeds uint32')
    header = HEADER.pack(b'TMW1', 1, total, data['width'], data['height'], data['tilewidth'], data['tileheight'],
                         bw, bh, tile_count, len(layers), len(entities), len(props), layer_off, entity_off,
                         prop_off, text_off, len(texts), cells_off, block_bytes)
    blob = header + b''.join(layer_records) + b''.join(entity_records) + b''.join(props) + texts
    blob += bytes(cells_off - len(blob)) + cells
    return CompiledMap(bytes(blob), tuple(tiles), tuple(keys), cells_off, len(cells), mutable)
