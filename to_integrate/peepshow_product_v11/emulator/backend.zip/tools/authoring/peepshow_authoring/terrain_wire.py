"""Private TCB1 terrain bitmap; not an installed chunk or public export API.

An explicitly selected Tiled tile layer supplies occupancy (nonzero = blocked).
Neither tile artwork nor layer names/visibility imply collision. The caller
must keep this designated data layer out of rendering when integration lands.
"""
import struct

from .imported_properties import ImportedPropertyError
from .tiled_assets import validate_record

HEADER = struct.Struct('<4s4I2i9I')


def compile_terrain(record, root, layer_id, *, block_width=8, block_height=8,
                    maximum_bytes=16 * 1024 * 1024):
    """Compile one explicit mask layer using the accepted import snapshot.

    This adapter uses the map tile grid at origin (0,0). The wire carries its
    own origin/spacing so terrain need not permanently share the visual grid.
    Output is block-row-major, bits are cell-row-major/LSB-first within a block.
    All edge and trailing-bit padding is zero.
    """
    validate_record(record, root)
    if type(layer_id) is not int or layer_id <= 0:
        raise ImportedPropertyError('Terrain requires an explicit positive layer ID')
    if any(type(n) is not int or not 1 <= n <= 256 for n in (block_width, block_height)):
        raise ImportedPropertyError('Terrain block dimensions must be 1..256')
    if type(maximum_bytes) is not int or not HEADER.size <= maximum_bytes <= 0xffffffff:
        raise ImportedPropertyError('Terrain output budget must fit uint32')
    source = record['snapshot']
    layer = next((item for item in source['layers'] if item['id'] == layer_id), None)
    if layer is None or layer['type'] != 'tilelayer':
        raise ImportedPropertyError('Terrain layer must identify a tile layer')
    return compile_collision_grid(source['width'], source['height'],
        source['tilewidth'], source['tileheight'], [bool(cell) for cell in layer['data']],
        block_width=block_width, block_height=block_height, maximum_bytes=maximum_bytes)


def compile_collision_grid(width, height, cell_width, cell_height, cells, *,
                           block_width=8, block_height=8,
                           maximum_bytes=16 * 1024 * 1024):
    """Pack explicit row-major Boolean world cells into existing TCB1 blocks.

    Independent of visual tile spacing, assets, Tiled GIDs and layer visibility.
    Origin is zero for the installed aligned-map path. Limits match the existing
    native codec, not a whole-map RAM reservation. This is a compiler primitive,
    not a new public service capability or complete Scene admission.
    """
    if any(type(n) is not int or not 1 <= n <= 65535 for n in (width, height)):
        raise ImportedPropertyError('Collision grid dimensions must be 1..65535')
    if any(type(n) is not int or not 1 <= n <= 0xffffffff for n in (cell_width, cell_height)):
        raise ImportedPropertyError('Collision cell dimensions must be positive uint32')
    if width * cell_width > 0x7fffffff or height * cell_height > 0x7fffffff:
        raise ImportedPropertyError('Collision world extent must fit int32')
    if any(type(n) is not int or not 1 <= n <= 256 for n in (block_width, block_height)):
        raise ImportedPropertyError('Terrain block dimensions must be 1..256')
    if type(maximum_bytes) is not int or not HEADER.size <= maximum_bytes <= 0xffffffff:
        raise ImportedPropertyError('Terrain output budget must fit uint32')
    if not isinstance(cells, (list, tuple)) or len(cells) != width * height:
        raise ImportedPropertyError('Collision cells must match the world grid dimensions')
    if any(type(cell) is not bool for cell in cells):
        raise ImportedPropertyError('Collision cells must be Boolean, not tile IDs')
    bw, bh = block_width, block_height
    nx, ny = (width + bw - 1) // bw, (height + bh - 1) // bh
    block_bytes = (bw * bh + 7) // 8
    total = HEADER.size + nx * ny * block_bytes
    if total > maximum_bytes:
        raise ImportedPropertyError('Terrain blocks exceed host output budget')
    result = bytearray(HEADER.pack(b'TCB1', 1, total, width, height, 0, 0,
                                  cell_width, cell_height, bw, bh,
                                  nx, ny, block_bytes, HEADER.size, 0))
    for by in range(ny):
        for bx in range(nx):
            block = bytearray(block_bytes)
            for y in range(min(bh, height - by * bh)):
                for x in range(min(bw, width - bx * bw)):
                    if cells[(by * bh + y) * width + bx * bw + x]:
                        bit = y * bw + x
                        block[bit // 8] |= 1 << (bit % 8)
            result.extend(block)
    return bytes(result)
