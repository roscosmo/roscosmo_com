"""Resumable input, time and lifecycle debugger over the existing candidate transaction engine."""
from copy import deepcopy
from dataclasses import asdict
from .protocol import ProtocolError
from .preview_steps import inspect_player

CAPABILITY = dict(version=6, operation='project.preview_debug',
    command_schema='schemas/authoring/preview-debug-command-v1.schema.json',
    execution_semantics=['terminal_order_v1'], modes=['logic','state','run'],
    breakpoints=['handler','decision','action','call','flow_return','terminal','time','timer','lifecycle'],
    instance_filter=True, time_policy='explicit_only', input_policy='one_explicit_input_per_transaction',
    state_step='next_handler_boundary_including_stay', continue_policy='settle_current_command_or_breakpoint',
    pending_values=True, atomic_commit=True, abort=True, instruction_replay=False,
    framebuffer='last_committed_until_settlement', audio='buffered_until_commit',
    evidence='executed_candidate_operations_plus_transaction_outcome',
    timer_stepping=True, lifecycle_stepping=True, scoped_menu_sessions=True,
    lifecycle_granularity='atomic_owner_operation', startup_entry_stepping=True,
    startup_reset_option={'debug_mode':['logic','state','run']},
    startup_profile='terminal_order_machine_scene_activated', initial_machine_setup='atomic',
    legacy_entry_graph_stepping=False,
    time_batch_commit='atomic', max_elapsed_ms=600000, host_receipts='explicit_no_auto_ack',
    commands=['start','startup','input','advance','suspend','resume','host','step','continue','inspect','mode','breakpoints','abort','stop'],
    bound_parameter_inspection=True, raw_operands=False,
    flow_inspection='typed_bindings_and_caller_outputs', parameter_values='variable_literal_object_property',
    spatial_operands='evaluated_world_predicates_and_destination_moves',
    object_operands='stored_defaults_and_live_before_after',
    query_inspection='never_reexecute',
    decision_operands=['variable','inventory','machine_state','time_available','time_of_day_range'],
    operand_sampling='during_evaluation_reached_operands_only',
    legacy_handler_stepping=False, draft_run=False, runtime=False, export=False,
    max_breakpoints=64, max_checkpoints=8192)


def fail(message, code='PREVIEW_DEBUG_UNAVAILABLE'):
    raise ProtocolError(code, message)


def public(mark):
    result = deepcopy({k:v for k,v in mark.items() if not k.startswith('_')})
    parts = mark.get('node_id','').split('/')[:-1]
    result['call_stack'] = [dict(call_node_id='/'.join(parts[:i+1]), flowchart_ref=parts[i+1]) for i in range(0,len(parts)-1,2)]
    if mark['kind']=='call':result['call_stack'].append(dict(call_node_id=mark['node_id'],flowchart_ref=mark['flowchart_ref']))
    records = mark.get('_flow_calls', [])
    for frame in result['call_stack']:
        record = next((c for c in records if c['call_node_id']==frame['call_node_id']), None)
        if record is not None:
            frame.update(parameters=deepcopy(record['parameters']),
                         continuations=deepcopy(record['continuations']), authored_path=record['authored_path'])
    if mark['kind']=='flow_return':
        record = next((c for c in records if mark['node_id'] in c['returns']), None)
        if record is not None:
            output = record['returns'][mark['node_id']]
            result.update(output_id=output, continuation_node_id=record['continuations'][output])
    return result


def admitted(player, scene_id=None, instance_id=None, behavior_id=None):
    """Conservative whole-active-Scene profile; unsupported work never runs through."""
    if not player._scene.get('_terminal_order'):
        fail('Debugging requires terminal_order_v1')
    programs = player._scene.get('_terminal_programs', {})
    private = set()
    for program in programs.values():
        private.update(program['compiled_nodes'].values())
    lifecycle_routes=[]
    menu=getattr(player,'_scope_menu',None)
    owner_addresses=[a for a in (getattr(menu,'entry_receiver',None),getattr(menu,'confirm_receiver',None)) if a]
    for route in player._machines['routes']:
        if route['route_id'] not in programs and route['route_id'] not in private:
            lifecycle = route.get('actions') and all(a['kind'] in ('menu.open','menu.close','exit_to_shell') for a in route['actions'])
            owner = any(route['machine_ref']==a['machine_ref'] and route['event_ref']==a['event_ref'] for a in owner_addresses)
            if not lifecycle and not owner:
                fail('Use response graphs for active gameplay handlers before entering debugger')
            lifecycle_routes.append(route['route_id'])
    locations=[]
    identity=dict(scene_id=scene_id or player.scene_id)
    if instance_id is not None: identity.update(instance_id=instance_id,behavior_id=behavior_id)
    locations.extend(dict(identity,route_id=r,kind='handler') for r in lifecycle_routes)
    for program in programs.values():
        address=dict(identity,route_id=program.get('origin',{}).get('route_id',program['route_id']))
        locations.append(dict(address,kind='handler'))
        for node in program['response']['nodes']:
            kind=node['kind'];at=dict(address,node_id=node['node_id'])
            if kind=='return':
                locations.append(dict(at,kind='terminal'))
            elif kind=='decision':locations.append(dict(at,kind='decision'))
            else:
                if not node['actions']:
                    locations.append(dict(at,kind='flow_return' if '/' in node['node_id'] and not node['next'].startswith(node['node_id'].rsplit('/',1)[0]+'/') else 'actions'))
                for ai, action in enumerate(node['actions']):
                    if action['kind'] in ('run_flowchart',):
                        fail('Legacy flow/lifecycle stepping is not supported by this increment')
                    locations.append(dict(at,kind='action',action_index=ai))
            parts=node['node_id'].split('/')[:-1]
            for depth in range(0,len(parts)-1,2):
                location=dict(address,kind='call',node_id='/'.join(parts[:depth+1]))
                if location not in locations:locations.append(location)
    locations.extend(dict(identity,kind=kind) for kind in ('time','timer','lifecycle'))
    locations.extend(dict(identity,kind='lifecycle',operation=op) for op in
        ('scene_entry','root_handler','menu_input','menu.open','menu.close','restart_scene','change_scene','suspend','resume',
         'input_snapshot','audio_take','audio_stop_complete','menu_finish','menu_cancel'))
    world=player._world_context
    for i, child in enumerate(getattr(world,'players',[])):
        behavior=world.combined.behaviors[world.combined.instances.instances[i].behavior].bindings.behavior_id
        locations.extend(admitted(child,scene_id or player.scene_id,world.ids[i],behavior))
    return locations


class Session:
    def __init__(self, player, source_revision, mode):
        self.locations=admitted(player)
        self.committed=player
        self.source_revision=source_revision
        self.mode=mode
        self.revision=0
        self.iterator=None
        self.next=None
        self.history=[]
        self.breakpoints=[]
        self.outcome='idle'
        self.reason='paused'
        self.input_result=None
        self.working=None
        self.steps=0
        self.queue=[]
        self.transaction=None
        self.host_result={}

    def set_breakpoints(self, rows):
        for row in rows:
            if not any(all(location.get(k)==v for k,v in row.items()) for location in self.locations):
                fail('Breakpoint does not identify a supported authored location', 'PREVIEW_DEBUG_BREAKPOINT_INVALID')
        self.breakpoints=deepcopy(rows)

    def submit(self, source, event_kind='press', focus_generation=None):
        from .preview import LOGICAL_SOURCES, LOGICAL_EVENTS
        if source not in LOGICAL_SOURCES or event_kind not in LOGICAL_EVENTS:
            fail('Unsupported input source/event', 'PREVIEW_DEBUG_INPUT_INVALID')
        if self.committed._scope_input is not None:
            from .scope_preview_host import generation
            generation(self.committed, focus_generation)
        self.begin('input', lambda p: p.iterate_input(source, event_kind, _focus_generation=focus_generation))

    def startup(self):
        if not getattr(self.committed, '_entry_pending', False):
            fail('Startup has already completed; reset with debug_mode to begin afresh', 'PREVIEW_DEBUG_STARTUP_COMPLETE')
        self.begin('startup', lambda p: p.iterate_scene_entry())

    def begin(self, kind, factory):
        if kind != 'startup' and getattr(self.committed, '_entry_pending', False):
            fail('Complete startup or discard this preview before submitting work', 'PREVIEW_DEBUG_STARTUP_REQUIRED')
        if self.iterator is not None:fail('Finish or abort the pending command', 'PREVIEW_DEBUG_BUSY')
        self.locations=admitted(self.committed)
        self.working=deepcopy(self.committed)
        self.iterator=factory(self.working)
        self.history=[];self.input_result=None;self.steps=0;self.outcome='pending';self.reason='command_ready'
        self.transaction=kind;self.host_result={};self.queue=[];self.rejection=None
        self._entering_scene=False
        self._receiver_scene=self.working.scene_id
        self.working._machine_rejection=None
        self._advance()
        if self.mode=='run' and self.iterator is not None and not self.hit():self.run()

    def advance_time(self, elapsed_ms):
        self.begin('advance', lambda p: p.iterate_advance(elapsed_ms))

    def lifecycle(self, operation, params):
        from .preview_steps import checkpoint
        from .scope_preview_host import operate, held
        def execute(player):
            yield checkpoint(player, 'lifecycle', operation=operation)
            if operation == 'suspend':
                player.suspend()
            elif operation == 'resume':
                if player._scope_input is not None and set(params) != {'focus_generation','held_sources'}:
                    fail('Scoped resume requires focus_generation and held_sources', 'PREVIEW_DEBUG_COMMAND_INVALID')
                if player._scope_input is None and params:
                    fail('Unscoped resume does not accept focus fields', 'PREVIEW_DEBUG_COMMAND_INVALID')
                sources=held(player,params) if player._scope_input is not None else None
                yield from player.iterate_resume()
                if sources is not None:
                    player._scope_input_snapshot(sources, generation=params['focus_generation'])
                return (yield from player.iterate_advance(0))
            else:
                result=operate(player,operation,params)
                # Host effects are returned once, only after this candidate commits.
                self.host_result={k:v for k,v in result.items() if k=='audio_commands'}
            return None
        self.begin(operation, execute)

    def effects(self):
        if self.transaction == 'startup':return dict(entry_events=deepcopy(self.committed.entry_audio_events))
        if isinstance(self.input_result, tuple):
            return dict(timer_events=[asdict(e) for e in self.input_result], **self.host_result)
        return deepcopy(self.host_result)

    def hit(self):
        return self.next is not None and any(all(self.next.get(k)==v for k,v in bp.items()) for bp in self.breakpoints)

    def _advance(self):
        old=self.next
        try:
            mark=next(self.iterator)
            if 'instance_id' in mark:mark['scene_id']=getattr(self, '_receiver_scene', self.working.scene_id)
            if mark['kind']=='lifecycle' and mark.get('operation')=='scene_entry':
                self._entering_scene=True
                self._receiver_scene=mark['scene_id']
                # Admit destination handlers before any entry action can run.
                self.locations=admitted(mark['_player'])
            # Capture operands once at the checkpoint, before execution resumes.
            # No condition is evaluated and no authored data is modified here.
            scene=self.working._scenes.get(mark['scene_id'], {})
            mark['_flow_calls']=deepcopy([c for c in scene.get('_debug_flow_calls', [])
                if c['route_id']==mark.get('route_id') and c['behavior_id']==mark.get('behavior_id')])
            from .preview_steps import inspect_parameter
            for call in mark['_flow_calls']:
                for parameter in call['parameters']:
                    parameter.update(inspect_parameter(mark['_player'], parameter))
            self.next=mark
            if mark.get('rejection'):self.rejection=mark['rejection']
            if 'queue' in mark:self.queue=deepcopy(mark.get('outer_queue',[])+mark['queue'])
            elif 'outer_queue' in mark:self.queue=deepcopy(mark['outer_queue'])
        except StopIteration as done:
            self.input_result=done.value
            self.iterator=None;self.next=None
            rejected=self.rejection or getattr(self.working,'_machine_rejection',None)
            if rejected is None:
                try:
                    self.locations=admitted(self.working)
                except Exception:
                    self.abort();self.outcome='failed';self.reason='destination_debug_unavailable'
                    raise
                self.committed=self.working
                self.outcome='committed'
            else:
                self.outcome='rolled_back'
            self.reason=rejected or 'steady_state'
        except Exception:
            self.abort();self.outcome='failed';self.reason='execution_failed'
            raise
        if old is not None:
            item=public(old)
            item['completion'] = ('failed' if item['kind'] in ('action','decision') and 'result' not in item else 'completed_pending')
            if item['kind']!='handler_complete':self.history.append(item)
        if self.hit():self.reason='breakpoint'

    def run(self, mode='run'):
        if self.iterator is None:fail('No input transaction is pending', 'PREVIEW_DEBUG_IDLE')
        self.reason='step'
        # Skip the currently paused breakpoint once, then honor subsequent ones.
        while self.iterator is not None:
            self.steps+=1
            if self.steps>CAPABILITY['max_checkpoints']:
                self.abort();fail('Debugger checkpoint limit exceeded', 'PREVIEW_DEBUG_BUDGET')
            prior=self.next
            self._advance()
            if self.iterator is None or self.hit():break
            if mode=='logic' and prior['kind'] not in ('handler','handler_complete','timer_complete'):break
            if mode=='state' and self.next['kind']=='handler_complete':
                if not self.next.get('queue') and 'instance_id' not in self.next and self.transaction not in ('advance','resume','startup') and not getattr(self, '_entering_scene', False):
                    continue
                self.reason='handler_boundary';break

    def abort(self):
        if self.iterator is not None:self.iterator.close()
        self.iterator=None;self.next=None;self.working=None;self.input_result=None
        self.outcome='aborted';self.reason='aborted';self.host_result={};self.queue=[]

    def snapshot(self):
        pending=inspect_player(self.next['_player']) if self.next is not None else None
        return dict(version=6, startup_complete=not getattr(self.committed, "_entry_pending", False), transaction=self.transaction, debug_revision=self.revision, source_revision=self.source_revision,
            mode=self.mode, outcome=self.outcome, reason=self.reason, pending=pending,
            committed=inspect_player(self.committed), next=None if self.next is None else public(self.next),
            executed=deepcopy(self.history), queued_deliveries=deepcopy(self.queue), breakpoints=deepcopy(self.breakpoints),
            locations=deepcopy(self.locations), input=None if self.input_result is None or isinstance(self.input_result,tuple) else {k:v for k,v in asdict(self.input_result).items() if k!='audio_events'},
            time_frozen=True, release_inputs_before_normal_run=True)
