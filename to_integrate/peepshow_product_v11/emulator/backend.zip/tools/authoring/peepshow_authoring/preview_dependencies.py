"""Conservative Scene dependency identities for a running preview snapshot."""
from copy import deepcopy
from dataclasses import replace
from .asset_library import package_assets
from .processing_cache import fingerprint, _map_dependencies


class StalePreviewScene(Exception):
    """Host control outcome, deliberately not a game PreviewError/rejection."""
    def __init__(self, scene_id):
        self.scene_id = scene_id
        super().__init__(f"Scene '{scene_id}' changed; restart preview before entering it")


def identities(bundle):
    from .target_profile import TARGET_PROFILE
    from .execution_semantics import execution_project
    project = {k: v for k, v in execution_project(bundle.project).items()
               if k not in ('editor', 'scene_sources')}
    maps = {r['asset_id']: r for c in bundle.asset_catalogs for r in c.get('map_assets', [])}
    result = {}
    for scene in bundle.scenes:
        selected = package_assets(replace(bundle, scenes=(scene,)))
        # Asset IDs can occur in bindings, selectors, world queries and flows.
        # Conservatively count every exact map-ID string in this Scene source.
        refs = set()
        pending = [scene]
        while pending:
            item = pending.pop()
            if isinstance(item, str) and item in maps:
                refs.add(item)
            elif isinstance(item, dict):
                pending.extend(v for k, v in item.items() if k not in ('editor', 'layout'))
            elif isinstance(item, (list, tuple)):
                pending.extend(item)
        records = [maps[r] for r in sorted(refs)]
        try:
            external = _map_dependencies(records, bundle.root)
        except (OSError, ValueError, KeyError, TypeError):
            external = None
        # An unverified dependency must never authorize preservation.
        if not bundle.valid or external is None:
            result[scene['scene_id']] = None
            continue
        result[scene['scene_id']] = fingerprint((
            bundle.root, project, TARGET_PROFILE,
            {k: v for k, v in scene.items() if k != 'display_name'},
            selected.assets, selected.frames, selected.animations,
            selected.audio_assets, selected.audio_cues, records, external,
        ))
    return result


def stale_scenes(baseline, current):
    return sorted(ref for ref in baseline.keys() | current.keys()
                  if baseline.get(ref) is None or current.get(ref) is None or baseline[ref] != current[ref])


def marked_copy(player, stale):
    if tuple(player._scene.get('_authoring_stale_scenes', ())) == tuple(stale):
        return player
    candidate = deepcopy(player)
    for scene in candidate._package.scenes:
        scene['_authoring_stale_scenes'] = tuple(stale)
    return candidate


def report(player):
    return {'active_scene': player._scene['scene_id'] if player else None,
            'stale_scenes': list(player._scene.get('_authoring_stale_scenes', ())) if player else [],
            'transition_policy': 'restart_before_entering_stale_scene'}
