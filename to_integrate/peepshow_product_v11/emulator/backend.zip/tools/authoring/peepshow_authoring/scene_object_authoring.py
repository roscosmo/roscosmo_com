"""Version-aware scene-object authoring integration; never an executable exporter."""

from copy import deepcopy
from .menu_component import COMMANDS as MENU_COMMANDS
from .inventory_source import COMMANDS as INVENTORY_COMMANDS
from .behavior_response import COMMANDS as RESPONSE_COMMANDS
from .actor_assembly import COMMANDS as ACTOR_COMMANDS
from .actor_templates import COMMANDS as TEMPLATE_COMMANDS
from .visibility_source import COMMANDS as VISIBILITY_COMMANDS
from .behavior_destinations import COMMANDS as DESTINATION_COMMANDS

from .project import (
    SCENE_KEYS, SCENE_OPTIONAL_KEYS, ProjectCommandError, ValidationIssue,
    _check_keys, _check_scene, _require_command_fields,
)
from .scene_objects import (
    PROPERTY_KEYS, SceneObjectError, apply_object_actions, clear_object_override,
    initialize_objects, validate_object_model,
)


OBJECT_COMMANDS = (
    "object.add", "object.delete", "object.rename", "object.set_defaults", "object.set_kind",
    "object.bind_animation", "object.clear_animation", "object.set_text",
    "object_override.set", "object_override.clear",
    "object_actions.set",
)
# Other legacy commands are not implicitly safe for a different scene representation.
STATE_MANAGEMENT_COMMANDS = (
    "state.add", "state.create", "state.delete", "state.rename", "state.set_entry",
    "editor.state_graph.set_node_position", "editor.state_graph.set_entry_layout",
)
LOCAL_GRAPH_COMMANDS = (
    "variable.add", "variable.update", "variable.delete",
    "input_action.add", "input_action.update", "input_action.delete",
    "event_binding.add", "event_binding.update", "event_binding.delete",
    "event_handler.add", "event_handler.update", "event_handler.delete",
    "route.create_trigger", "route.rebind_trigger", "route.add", "route.delete",
    "route.set_action_ref", "route.set_event_ref", "route.set_sources", "route.set_target",
    "route.guard.add", "route.guard.delete", "route.guard.move", "route.set_guard",
    "scene.set_reactive_wait_default", "scene.set_interaction_policy", "scene.set_joystick_policy",
    "editor.state_graph.set_route_layout", "editor.state_graph.delete_system_exit",
    "editor.state_graph.set_handler_layout",
)
SCENE_FLOW_COMMANDS = (
    "editor.scene_flow.set_node_position", "editor.scene_flow.set_package_entry_position",
    "editor.scene_flow.add_reference", "editor.scene_flow.set_reference_position",
    "editor.scene_flow.set_reference_target", "editor.scene_flow.delete_reference",
    "editor.scene_flow.set_exit_reference", "editor.scene_flow.set_route_layout",
)
SCENE_CONNECTION_COMMANDS = (
    "scene_exit.add", "scene.restart.add", "scene_exit.set_target", "scene_exit.delete", *SCENE_FLOW_COMMANDS,
)
COMMON_SCENE_COMMANDS = (
    *VISIBILITY_COMMANDS,
    *DESTINATION_COMMANDS,
    *TEMPLATE_COMMANDS,
    *ACTOR_COMMANDS,
    *RESPONSE_COMMANDS,
    *MENU_COMMANDS,
    *(c for c in INVENTORY_COMMANDS if c.startswith('scene.')),
    "scene.machines.set", "scene.machines.clear",
    "scene.flowcharts.set", "scene.flowcharts.clear",
    "scene.presentation_selectors.set", "scene.presentation_selectors.clear",
    "scene.entry_graph.set", "scene.entry_graph.clear",
    "scene.rename", "project.set_entry_scene", *STATE_MANAGEMENT_COMMANDS,
    *LOCAL_GRAPH_COMMANDS, *SCENE_CONNECTION_COMMANDS,
)


def execution_model(scene):
    if "machine_logic" in scene:
        return "scene_machines_v1"
    return "scene_objects" if scene.get("schema_version") == 2 else "legacy_state_bindings"


def graph_validation_view(scene, *, validation_only=False):
    """Adapt only shared graph/render primitives for existing validation/host compilation.

    Object operations have placeholders at the same positions. Host preview
    restores their symbolic operations and owns live objects; this is not a
    lowering of object semantics to legacy executable semantics.
    """
    view = deepcopy(scene)
    view["schema_version"] = 1
    elements = []
    for obj in view.pop("objects"):
        element = {key: value for key, value in obj.items() if key not in {"object_id", "defaults", "animation_ref", "display_name"}}
        element.update(obj["defaults"])
        # Object preview resolves polarity from its source/live bank, not RND2.
        element.pop("inverted", None)
        if validation_only:
            # Signed object placement was already checked by validate_object_model.
            # The reused legacy validator checks graph/asset/shape constraints,
            # not the scene-owned object's viewport eligibility.
            element.update(x=0, y=0)
        element["element_id"] = obj["object_id"]
        element["focus_role"] = "none"
        if obj["kind"] == "text":
            # Shared legacy graph validation has no authored runtime text type.
            element["kind"] = "filled_rect"
            for key in ("text", "font_id", "scale", "alignment"):
                element.pop(key, None)
        elements.append(element)
    view["render_models"] = [{"visual_id": "object_preview", "focus_index": 0, "elements": elements}]
    view["waiting_visuals"] = [{
        "waiting_visual_id": "object_preview_wait", "presentation_id": "object_preview_wait",
        "phase_quantum_ms": 250, "combined_step_count": 1, "settled_step": 0,
        "cycle_policy": "loop", "elements": [],
    }]
    for state in view["states"]:
        state.pop("object_overrides")
        state["waiting_visual_ref"] = "object_preview_wait"
    if isinstance(view.get("reactive_wait_default"), dict):
        view["reactive_wait_default"]["waiting_visual_ref"] = "object_preview_wait"
    for route in [*view.get("routes", []), *view.get("event_handlers", [])]:
        if isinstance(route, dict) and isinstance(route.get("actions"), list):
            route["actions"] = [
                {"kind": "request_render"} if isinstance(action, dict)
                and isinstance(action.get("kind"), str) and action["kind"].startswith("object.")
                else action for action in route["actions"]
            ]
    return view


def check_object_scene(scene, source, frame_lookup, animations, audio_cue_ids, issues, *, _machine_projection=False):
    base = f"scene[{source}]"
    start = len(issues)
    required = (SCENE_KEYS - {"render_models", "waiting_visuals"}) | {"objects"}
    _check_keys(scene, required, base, issues, required | SCENE_OPTIONAL_KEYS)
    sizes = {key: (frame.width, frame.height) for key, frame in frame_lookup.items()}
    issues.extend(ValidationIssue(item.code, f"{base}.{item.path}", item.message) for item in
                  validate_object_model({"objects": scene.get("objects"), "states": scene.get("states")}, sizes, animations))
    for collection in ("routes", "event_handlers"):
        if not isinstance(scene.get(collection, []), list):
            issues.append(ValidationIssue("PROJECT_TYPE_INVALID", f"{base}.{collection}", "must be an array"))
    wait = scene.get("reactive_wait_default")
    if isinstance(wait, dict) and "waiting_visual_ref" in wait:
        issues.append(ValidationIssue("OBJECT_LEGACY_FIELD", f"{base}.reactive_wait_default.waiting_visual_ref", "version 2 does not select state waiting records"))
    if len(issues) != start:
        return
    live = initialize_objects(scene["objects"])
    for collection in ("routes", "event_handlers"):
        for index, route in enumerate(scene.get(collection, [])):
            if not isinstance(route, dict) or not isinstance(route.get("actions"), list):
                continue
            if "target_scene" in route:
                path = f"{base}.{collection}[{index}]"
                if route["target_scene"] == scene["scene_id"] and not _machine_projection:
                    issues.append(ValidationIssue("SCENE_EXIT_TARGET_INVALID", path, "scene replacement must target another scene"))
                if not _machine_projection and any(not isinstance(action, dict) or action.get("kind") != "play_sfx"
                       for action in route["actions"]):
                    issues.append(ValidationIssue("SCENE_TRANSITION_ACTION_UNSUPPORTED", f"{path}.actions", "version-2 fresh scene replacement supports only play_sfx actions"))
            elif "scene_exit_ref" in route:
                issues.append(ValidationIssue("SCENE_EXIT_TARGET_MISMATCH", f"{base}.{collection}[{index}]", "a scene exit reference requires target_scene"))
            for action_index, action in enumerate(route["actions"]):
                if not isinstance(action, dict) or not isinstance(action.get("kind"), str):
                    continue
                path = f"{base}.{collection}[{index}].actions[{action_index}]"
                if action["kind"].startswith("set_element_"):
                    issues.append(ValidationIssue("OBJECT_LEGACY_ACTION", path, "legacy destination-binding mutations cannot target scene objects"))
                elif action["kind"].startswith("object."):
                    try:
                        apply_object_actions(scene["objects"], live, [action], sizes)
                    except SceneObjectError as exc:
                        issues.append(ValidationIssue(exc.issue.code, path, exc.issue.message))
    if len(issues) != start:
        return
    _check_scene(graph_validation_view(scene, validation_only=True), source, frame_lookup, set(animations), audio_cue_ids, issues,
                 allow_handler_scene_exits=True, allow_calendar=True, _machine_projection=_machine_projection)


def check_command_model(scenes, command):
    from .tiled_assets import COMMANDS as MAP_COMMANDS
    if command.get("kind") in MAP_COMMANDS:
        return  # Catalog-only commands; no Scene graph is traversed or changed.
    ref = command.get("scene_id")
    scene = next((item for item in scenes if item["scene_id"] == ref), None)
    kind = command.get("kind")
    if not isinstance(kind, str):
        raise ProjectCommandError("COMMAND_SHAPE_INVALID", "command kind must be text")
    if kind in OBJECT_COMMANDS:
        if scene is None or scene.get("schema_version") != 2:
            raise ProjectCommandError("COMMAND_EXECUTION_MODEL_MISMATCH", "object commands require a version-2 scene")
    elif scene is not None and scene.get("schema_version") == 2 and kind not in COMMON_SCENE_COMMANDS:
        raise ProjectCommandError("COMMAND_EXECUTION_MODEL_MISMATCH", f"'{kind}' is not supported for scene-owned objects")
    # Global commands that traverse/change scenes need explicit v2 integration too.
    elif scene is None and any(item.get("schema_version") == 2 for item in scenes):
        if kind not in {"asset.upsert", "asset.delete", "animation.upsert", "animation.delete",
                        "audio_asset.upsert", "audio_asset.delete", "audio_cue.upsert", "audio_cue.delete",
                        "scene.add", "project.set_entry_scene", "project.settings.set", "project.variables.enable", *INVENTORY_COMMANDS, *TEMPLATE_COMMANDS,
                        "package_variable.add", "package_variable.update", "package_variable.delete", *SCENE_FLOW_COMMANDS}:
            raise ProjectCommandError("COMMAND_EXECUTION_MODEL_MISMATCH", f"'{kind}' has not been integrated with mixed scene models")


def apply_object_command(scenes, command):
    kind = command["kind"]
    fields = {
        "object.add": {"object", "visible_in_states"},
        "object.delete": {"object_id"},
        "object.rename": {"object_id", "display_name"},
        "object.set_text": {"object_id", "text", "font_id", "scale", "alignment", "width", "height"},
        "object.set_defaults": {"object_id", "properties"},
        "object.set_kind": {"object_id", "object_kind"},
        "object.bind_animation": {"object_id", "animation_ref"},
        "object.clear_animation": {"object_id"},
        "object_override.set": {"object_id", "state_id", "properties"},
        "object_override.clear": {"object_id", "state_id", "properties"},
        "object_actions.set": {"owner_kind", "owner_id", "actions"},
    }[kind]
    required = {"kind", "scene_id"} | fields
    if kind == "object.add":
        required -= {"visible_in_states"}
    _require_command_fields(command, required, {"kind", "scene_id", "command_id"} | fields)
    scene = next(item for item in scenes if item["scene_id"] == command["scene_id"])
    if kind == "object.add":
        obj = deepcopy(command["object"])
        if not isinstance(obj, dict):
            raise ProjectCommandError("OBJECT_TYPE_INVALID", "object must be a definition")
        selected = command.get("visible_in_states")
        if "visible_in_states" in command:
            ids = {state["state_id"] for state in scene["states"]}
            if not isinstance(selected, list) or any(not isinstance(ref, str) or ref not in ids for ref in selected) or len(set(selected)) != len(selected):
                raise ProjectCommandError("GRAPH_STATE_UNKNOWN", "visible_in_states must contain distinct existing states")
            if not isinstance(obj.get("defaults"), dict) or not isinstance(obj.get("object_id"), str):
                raise ProjectCommandError("OBJECT_TYPE_INVALID", "object requires defaults and a stable object_id")
            obj["defaults"]["visible"] = False
            for state in scene["states"]:
                if state["state_id"] in selected:
                    state["object_overrides"].append({"object_ref": obj["object_id"], "visible": True})
        scene["objects"].append(obj)
    elif kind == "object_actions.set":
        if command["owner_kind"] not in ("route", "handler"):
            raise ProjectCommandError("COMMAND_TARGET_INVALID", "owner_kind must be route or handler")
        collection, key = ("routes", "route_id") if command["owner_kind"] == "route" else ("event_handlers", "handler_id")
        owner = next((item for item in scene.get(collection, []) if item[key] == command["owner_id"]), None)
        if owner is None:
            raise ProjectCommandError("COMMAND_TARGET_UNKNOWN", "route/handler does not exist")
        owner["actions"] = deepcopy(command["actions"])
    else:
        obj = next((item for item in scene["objects"] if item["object_id"] == command["object_id"]), None)
        if obj is None:
            raise ProjectCommandError("OBJECT_REFERENCE_UNKNOWN", "object does not exist")
        if kind == "object.delete":
            if any(action.get("object_ref") == obj["object_id"] for route in [*scene["routes"], *scene.get("event_handlers", [])] for action in route["actions"]):
                raise ProjectCommandError("OBJECT_IN_USE", "remove object actions before deleting the object")
            scene["objects"].remove(obj)
            for state in scene["states"]:
                state["object_overrides"] = [item for item in state["object_overrides"] if item["object_ref"] != obj["object_id"]]
        elif kind == "object.set_text":
            if obj["kind"] != "text":
                raise ProjectCommandError("OBJECT_TEXT_INVALID", "object.set_text requires a text object")
            for key in ("text", "font_id", "scale", "alignment", "width", "height"):
                obj[key] = deepcopy(command[key])
        elif kind == "object.rename":
            obj["display_name"] = command["display_name"]
        elif kind == "object.set_defaults":
            values = command["properties"]
            if not isinstance(values, dict) or not values or values.keys() - PROPERTY_KEYS:
                raise ProjectCommandError("OBJECT_PROPERTY_INVALID", "properties must select x, y, visible or visual_ref")
            obj["defaults"].update(deepcopy(values))
        elif kind == "object.set_kind":
            object_kind = command["object_kind"]
            families = (
                {"outline_rect", "filled_rect"},
                {"circle", "filled_circle"},
                {"ellipse", "filled_ellipse"},
            )
            if not isinstance(object_kind, str) or not any(obj.get("kind") in family and object_kind in family for family in families):
                raise ProjectCommandError(
                    "OBJECT_KIND_INVALID",
                    "object_kind must select the outline or filled variant of the same shape",
                )
            obj["kind"] = object_kind
        elif kind == "object.bind_animation":
            obj["animation_ref"] = command["animation_ref"]
        elif kind == "object.clear_animation":
            obj.pop("animation_ref", None)
        else:
            state = next((item for item in scene["states"] if item["state_id"] == command["state_id"]), None)
            if state is None:
                raise ProjectCommandError("GRAPH_STATE_UNKNOWN", "state does not exist")
            if kind == "object_override.clear":
                values = command["properties"]
                if not isinstance(values, list):
                    raise ProjectCommandError("OBJECT_PROPERTY_INVALID", "properties must be a list of individual property names")
                try:
                    updated = clear_object_override(state, obj["object_id"], values)
                except SceneObjectError as exc:
                    raise ProjectCommandError(exc.issue.code, exc.issue.message) from exc
                state.update(updated)
            else:
                values = command["properties"]
                if not isinstance(values, dict) or not values or values.keys() - PROPERTY_KEYS:
                    raise ProjectCommandError("OBJECT_PROPERTY_INVALID", "properties must select individual object properties")
                override = next((item for item in state["object_overrides"] if item["object_ref"] == obj["object_id"]), None)
                if override is None:
                    override = {"object_ref": obj["object_id"]}
                    state["object_overrides"].append(override)
                override.update(deepcopy(values))
    return deepcopy(command)
