"""Checked grid destinations lowered to bounded transaction primitives.

No cached query result or extra runtime state. Static path validation proves that
the actor origin and occupancy cannot change between a clear check and its move.
"""
from .imported_properties import ImportedPropertyError
from .scene_collision_source import DIRECTIONS

CAPABILITY = dict(host_editing=True, host_preview=True, persisted=True, undo_redo=True,
    runtime=False, export=False, hardware_validation='not_qualified',
    preview_requires='all_scenes_have_map_scene_bindings',
    field='machine_logic.destinations', schema='schemas/authoring/destination-v1.schema.json',
    commands=['scene.machines.set', 'scene.flowcharts.set'],
    guard_kinds=['destination.clear', 'destination.blocked'], action_kind='destination.move',
    locations=['scene_transition', 'scene_flowchart'], directions=list(DIRECTIONS),
    cell_kinds=['adjacent', 'cell'], facing_relative=True, facing_reference_field='cell.facing_ref', explicit_cell=True,
    explicit_cell_fields=['x', 'y'], explicit_cell_units='zero_based_map_grid',
    explicit_cell_values='signed_integer_literals', pathfinding=False, swept_collision=False,
    behavior_local=True, behavior_schema='schemas/authoring/behavior-destination-v1.schema.json',
    behavior_capability='instance_behaviors.destinations', maximum_destinations=128, grid='map_scene',
    requires='registered_occupancy_entity', out_of_bounds='blocked',
    failed_query='reject_transaction', check_lifetime='same_route_or_flow_path',
    move_requires='clear_check_on_every_path_without_intervening_occupancy_or_used_facing_write',
    check_across_event_or_flow_call=False, implicit_facing=False, implicit_turn=False,
    validation_error='DESTINATION_INVALID', readiness_error='DESTINATION_DEVICE_UNAVAILABLE')


class DestinationError(ImportedPropertyError):
    code = 'DESTINATION_INVALID'


def lower(graph):
    """Mutate only the private compilation copy, leaving saved source readable."""
    from .project import STABLE_ID
    from .world_reference_project import declarations
    from .scene_collision_source import declarations as collision_declarations

    def fail(path, message):
        raise DestinationError(f'{path}: {message}')

    rows = graph.pop('destinations', [])
    if type(rows) is not list or len(rows) > 128:
        fail('destinations', 'requires at most 128 declarations')
    # Reserve all authored strings, including broken references, so generated
    # queries cannot accidentally repair an invalid legacy reference.
    used, pending = set(), [graph, rows]
    while pending:
        value = pending.pop()
        if type(value) is str:
            used.add(value)
        elif type(value) is dict:
            pending.extend(value.values())
        elif type(value) is list:
            pending.extend(value)
    if not rows and not any(k in used for k in ('destination.clear', 'destination.blocked', 'destination.move')):
        return {}
    source = graph.get('map_scene', {})
    refs = {name: (ref, kind) for name, ref, kind in declarations(graph)}
    queries = graph.setdefault('collision_queries', [])
    if type(queries) is not list:
        fail('collision_queries', 'requires an array')
    destinations, facing_refs, paired_refs, dynamic_moves = {}, {}, {}, {}
    for row in rows:
        if type(row) is not dict or set(row) != {'destination_id', 'entity_ref', 'cell', 'include_actors'}:
            fail('destinations', 'requires destination_id, entity_ref, cell and include_actors')
        name, cell = row['destination_id'], row['cell']
        if type(name) is not str or not STABLE_ID.fullmatch(name) or name in destinations:
            fail('destinations', 'invalid or duplicate destination_id')
        facing = type(cell) is dict and cell.get('direction') == 'facing'
        absolute = type(cell) is dict and cell.get('kind') == 'cell'
        if absolute:
            if set(cell) != {'kind', 'x', 'y'} or any(type(cell[a]) is not int or not -2**31 <= cell[a] < 2**31 for a in ('x', 'y')):
                fail(name, 'explicit cell requires signed integer grid x/y literals')
        elif (type(cell) is not dict or set(cell) != ({'kind', 'direction', 'facing_ref'} if facing else {'kind', 'direction'}) or
                cell['kind'] != 'adjacent' or type(cell['direction']) is not str or
                (not facing and cell['direction'] not in DIRECTIONS)):
            fail(name, 'requires an adjacent cardinal/facing cell or explicit cell; other expressions are unavailable')
        query_id = 'ps_destination_0'
        ordinal = 0
        while query_id in used:
            ordinal += 1
            query_id = f'ps_destination_{ordinal}'
        used.add(query_id)
        query = dict(query_id=query_id, entity_ref=row['entity_ref'],
                     include_actors=row['include_actors'])
        if absolute:
            query['cell'] = dict(x=cell['x'], y=cell['y'])
        else:
            query['direction'] = cell['direction']
        if facing:
            query['facing_ref'] = cell['facing_ref']
        try:
            collision_declarations(dict(machine_logic={**graph, 'collision_queries': [query]}), refs)
        except ImportedPropertyError as exc:
            fail(name, str(exc))
        occupant = next(o for o in source['occupancy'] if o['entity_ref'] == row['entity_ref'])
        dx, dy = (0, 0) if facing or absolute else DIRECTIONS[cell['direction']]
        axis, amount = ('x', dx * source['cell_width']) if dx else ('y', dy * source['cell_height'])
        if not -(2**31) <= amount < 2**31:
            fail(name, 'grid step exceeds integer movement range')
        destinations[name] = (query_id, occupant['x_ref'] if facing or absolute else occupant[axis+'_ref'], amount)
        if facing:
            facing_refs[name] = (cell['facing_ref'], occupant['x_ref'], occupant['y_ref'])
        if facing or absolute:
            paired_refs[name] = (occupant['x_ref'], occupant['y_ref'])
        queries.append(query)

    # Position/solidity writes invalidate clear results; a facing write also
    # invalidates destinations that depend on it. Single-writer validation still
    # verifies each generated move belongs to its enclosing machine/flow.
    dependencies = set()
    for occupant in source.get('occupancy', []):
        dependencies.update((occupant.get('x_ref'), occupant.get('y_ref')))
        dependencies.add(occupant.get('solid_when', {}).get('reference_ref'))

    def destination(item, path):
        ref = item.get('destination_ref')
        if set(item) != {'kind', 'destination_ref'} or type(ref) is not str or ref not in destinations:
            fail(path, 'requires a declared destination_ref and no extra fields')
        return ref

    def guards(items, path):
        proven = set()
        for index, item in enumerate(items):
            if type(item) is not dict or item.get('kind') not in ('destination.clear', 'destination.blocked'):
                continue
            ref = destination(item, path)
            blocked = item['kind'] == 'destination.blocked'
            if not blocked:
                proven.add(ref)
            items[index] = dict(kind='collision.compare', query_ref=destinations[ref][0], operator='eq', value=blocked)
        return proven

    def actions(items, proven, path):
        proven = set(proven)
        for index, item in enumerate(items):
            if type(item) is not dict:
                continue  # Ordinary validation reports the malformed action.
            kind = item.get('kind', '')
            if kind == 'destination.move':
                ref = destination(item, f'{path}.actions[{index}]')
                if ref not in proven:
                    fail(f'{path}.actions[{index}]', f'{ref}: move requires a clear check on every path, after the last position/solidity/used-facing write or flow call')
                query_id, coordinate, amount = destinations[ref]
                replacement = dict(kind='world.add', reference_ref=coordinate, value=amount)
                items[index] = replacement
                if ref in paired_refs:
                    x, y = paired_refs[ref]
                    writers = {r['reference_id']: r.get('writer') for r in graph['world_references']}
                    if writers[x] is None or writers[x] != writers[y]:
                        fail(path, f'{ref}: resolved destination movement requires one declared writer for both coordinates')
                    # Identity of a compiler-created action, not an authored
                    # marker that could bypass the checked-path validation.
                    dynamic_moves[id(replacement)] = query_id
                proven.clear()
            elif kind == 'run_flowchart' or (type(kind) is str and kind.startswith('world.') and item.get('reference_ref') in dependencies):
                proven.clear()
            elif kind == 'facing.set' or (type(kind) is str and kind.startswith('world.')):
                proven.difference_update(name for name, (facing, _, _) in facing_refs.items()
                                         if facing == item.get('reference_ref'))
        return proven

    for route in graph.get('routes', []):
        path = f"routes[{route['route_id']}]"
        proven = guards(route['guards'], path)
        for outcome in route.get('outcomes', [route]):
            actions(outcome['actions'], proven, path)

    for chart in graph.get('flowcharts', []):
        path = f"flowcharts[{chart['flowchart_id']}]"
        nodes = {n['node_id']: n for n in chart['nodes']}
        if len(nodes) != len(chart['nodes']) or not 1 <= len(nodes) <= 128 or chart['root'] not in nodes:
            fail(path, 'requires unique nodes and a root, within the existing 128-node limit')
        edges, incoming, degrees = {}, {n: [] for n in nodes}, dict.fromkeys(nodes, 0)
        for name, node in nodes.items():
            if node['kind'] == 'decision':
                edges[name] = [(b['next'], guards(b.get('world_guards', []), path)) for b in node['branches']]
                edges[name].append((node['default'], set()))
            elif node['kind'] == 'actions':
                edges[name] = [(node['next'], set())]
            else:
                edges[name] = []
            for target, _ in edges[name]:
                if target not in nodes:
                    fail(path, 'missing flow edge target')
                degrees[target] += 1
        incoming[chart['root']].append(set())  # Calls never inherit a caller's check.
        ready = [n for n, count in degrees.items() if count == 0]
        visited = 0
        while ready:
            name = ready.pop()
            visited += 1
            node = nodes[name]
            proofs = incoming[name]
            proven = set.intersection(*proofs) if proofs else set()
            if node['kind'] == 'actions':
                proven = actions(node['actions'], proven, f'{path}.nodes[{name}]')
            for target, added in edges[name]:
                incoming[target].append(proven | added)
                degrees[target] -= 1
                if degrees[target] == 0:
                    ready.append(target)
        if visited != len(nodes):
            fail(path, 'flow cycles are unsupported')
    return dynamic_moves
