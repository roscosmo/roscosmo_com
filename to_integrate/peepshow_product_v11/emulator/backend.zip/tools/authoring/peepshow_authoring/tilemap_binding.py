"""Private TMB1 scene bindings. Reserved chunk roles, NOT enabled egg export."""
import struct

from .imported_properties import ImportedPropertyError

# Reserved for coordinated package integration. Do not add these to the public
# container allowlist until all-scene semantic admission supports them.
CHUNK_TILEMAP = 15
CHUNK_TILESET = 16
CHUNK_MAP_BINDINGS = 17
CHUNK_TERRAIN = 18  # Private reservation; all current installed/export paths reject.
HEADER = struct.Struct('<4s7I')
RECORD = struct.Struct('<IIQQiiIIII')
FIELDS = {'scene_id', 'map_id', 'bank_id', 'camera_x', 'camera_y', 'width', 'height', 'gutter'}


def number(value, minimum, maximum, name):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ImportedPropertyError(f'{name} is outside its integer range')
    return value


def compile_bindings(records, scene_count, *, maximum_bytes=16 * 1024 * 1024):
    """Scene IDs are existing one-based catalog ordinals, not authoring strings.

    Chunk IDs are exact nonzero uint64 container identities supplied by the
    future package compiler, not locally generated hashes or filename matches.
    One initial viewport per bound Scene in this first wire version.
    """
    number(scene_count, 1, 0xffffffff, 'scene count')
    number(maximum_bytes, HEADER.size, 0xffffffff, 'host output budget')
    if not isinstance(records, (list, tuple)) or not records or len(records) > scene_count:
        raise ImportedPropertyError('binding count must be nonzero and fit the scene catalog')
    total = HEADER.size + len(records) * RECORD.size
    if total > maximum_bytes:
        raise ImportedPropertyError('bindings exceed host output budget')
    checked = []
    for r in records:
        if not isinstance(r, dict) or set(r) != FIELDS:
            raise ImportedPropertyError('binding fields are invalid')
        checked.append(dict(
            scene_id=number(r['scene_id'], 1, scene_count, 'scene'),
            map_id=number(r['map_id'], 1, 0xffffffffffffffff, 'map chunk'),
            bank_id=number(r['bank_id'], 1, 0xffffffffffffffff, 'bank chunk'),
            camera_x=number(r['camera_x'], -0x80000000, 0x7fffffff, 'camera x'),
            camera_y=number(r['camera_y'], -0x80000000, 0x7fffffff, 'camera y'),
            width=number(r['width'], 1, 0xffffffff, 'viewport width'),
            height=number(r['height'], 1, 0xffffffff, 'viewport height'),
            gutter=number(r['gutter'], 0, 0xffffffff, 'gutter')))
    checked.sort(key=lambda r: r['scene_id'])
    seen, maps, banks = set(), {}, set()
    for r in checked:
        if r['scene_id'] in seen:
            raise ImportedPropertyError('duplicate scene binding')
        seen.add(r['scene_id'])
        if r['map_id'] in maps and maps[r['map_id']] != r['bank_id']:
            raise ImportedPropertyError('one map cannot use conflicting tile banks')
        maps[r['map_id']] = r['bank_id']
        banks.add(r['bank_id'])
    if maps.keys() & banks:
        raise ImportedPropertyError('map and bank chunk roles overlap')
    return HEADER.pack(b'TMB1', 1, total, len(checked), RECORD.size, 0, 0, 0) + b''.join(
        RECORD.pack(r['scene_id'], 0, r['map_id'], r['bank_id'], r['camera_x'], r['camera_y'],
                    r['width'], r['height'], r['gutter'], 0) for r in checked)


def compile_terrain_bindings(records, scene_count, *, maximum_bytes=16 * 1024 * 1024):
    """TMB1 v2 terrain IDs; v3 camera component; v4 white/black base colour.

    Reuses v1 map/bank/camera validation. At least one Scene requires terrain;
    callers with no collision use v1. No package exporter opts in implicitly.
    """
    number(scene_count, 1, 0xffffffff, 'scene count')
    number(maximum_bytes, HEADER.size, 0xffffffff, 'host output budget')
    if not isinstance(records, (list, tuple)) or not records or len(records) > scene_count:
        raise ImportedPropertyError('binding count must be nonzero and fit the scene catalog')
    components = any(isinstance(row, dict) and "camera_policy" in row for row in records)
    black = any(isinstance(row, dict) and row.get('base_colour') == 'black' for row in records)
    components = components or black
    stride = 84 if components else 56
    total = HEADER.size + len(records) * stride
    if total > maximum_bytes:
        raise ImportedPropertyError('terrain bindings exceed host output budget')
    ordinary, terrain = [], {}
    for row in records:
        if not isinstance(row, dict) or not (FIELDS | {'terrain_id'}) <= set(row) or \
                set(row) - FIELDS - {'terrain_id', 'camera_policy', 'base_colour'}:
            raise ImportedPropertyError('terrain binding fields are invalid')
        if row.get('base_colour', 'white') not in ('white', 'black'):
            raise ImportedPropertyError('base_colour must be white or black')
        scene = number(row['scene_id'], 1, scene_count, 'scene')
        if scene in terrain:
            raise ImportedPropertyError('duplicate scene binding')
        terrain[scene] = number(row['terrain_id'], 0, 0xffffffffffffffff, 'terrain chunk')
        ordinary.append({key: row[key] for key in FIELDS})
    legacy = compile_bindings(ordinary, scene_count, maximum_bytes=maximum_bytes)
    visual_ids = {row[key] for row in ordinary for key in ('map_id', 'bank_id')}
    if not any(terrain.values()) or visual_ids.intersection(terrain.values()):
        raise ImportedPropertyError('terrain requires nonzero, disjoint chunk identities')
    result = bytearray(HEADER.pack(b'TMB1', 4 if black else 3 if components else 2,
                                  total, len(records), stride, 0, 0, 0))
    for offset in range(HEADER.size, len(legacy), RECORD.size):
        row = legacy[offset:offset + RECORD.size]
        result.extend(row)
        scene_id = struct.unpack_from('<I', row)[0]
        source = next(r for r in records if r['scene_id'] == scene_id)
        if black:
            struct.pack_into('<I', result, len(result) - RECORD.size + 4,
                             int(source.get('base_colour', 'white') == 'black'))
        result.extend(struct.pack('<Q', terrain[scene_id]))
        if components:
            policy = source.get('camera_policy')
            if policy is None:
                result.extend(bytes(28))
            else:
                if type(policy) is not tuple or len(policy) != 7:
                    raise ImportedPropertyError('invalid camera policy')
                mode, entity, x, y, clamp, width, height = policy
                number(mode, 1, 2, 'camera mode'); number(entity, 0, 0xffffffff, 'camera entity')
                number(x, -2**31, 2**31-1, 'camera offset x'); number(y, -2**31, 2**31-1, 'camera offset y')
                number(clamp, 0, 1, 'camera clamp'); number(width, 1, 2**31-1, 'map width'); number(height, 1, 2**31-1, 'map height')
                if mode == 1 and (entity != 0xffffffff or x or y) or mode == 2 and entity == 0xffffffff:
                    raise ImportedPropertyError('invalid camera target')
                result.extend(struct.pack('<IIiiIII', *policy))
    return bytes(result)
