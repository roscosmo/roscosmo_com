"""Local calendar arithmetic; explicit samples only, never host-clock polling."""
from dataclasses import dataclass
from .machine_limits import TIMERS

DAY = 86400000
LIMIT = 3155760000000  # 2100-01-01, exclusive.
MODES = ('daily', 'today_offset', 'next_occurrence', 'next_weekday', 'weekly')
CAPABILITY = {
    'host_editing': True, 'host_preview': True, 'runtime': True, 'export': True,
    'status': 'development_restricted', 'modes': list(MODES),
    'hardware_evidence': 'weekly_bench_delivery_shell_resume_scene_cancel_confirmed',
    'public_artifact_hardware_validation': 'pending',
    'maximum_per_scene': TIMERS, 'maximum_combined_timers': TIMERS, 'ownership': 'scene',
    'time_of_day_seconds': {'minimum': 0, 'maximum': 86399},
    'day_offset': {'minimum': 0, 'maximum': 32767, 'mode': 'today_offset'},
    'weekday': {'minimum': 1, 'maximum': 7, 'monday': 1, 'mode': 'next_weekday'},
    'weekdays': {'minimum_items': 1, 'maximum_items': 7, 'unique': True,
                 'minimum': 1, 'maximum': 7, 'mode': 'weekly'},
    'clock_edit': 'skip_crossed_occurrences', 'suspension': 'coalesce_one_on_resume',
    'scene_replacement': 'cancel_and_fresh_arm', 'timer_actions': [],
}


def valid_configuration(config, expanded=False):
    mode = config.get('mode')
    if not isinstance(mode, str) or mode not in (MODES if expanded else MODES[:3]):
        return False
    seconds, offset = config.get('time_of_day_seconds'), config.get('day_offset', 0)
    if (type(seconds) is not int or not 0 <= seconds < 86400 or
            type(offset) is not int or not 0 <= offset <= 32767 or mode != 'today_offset' and offset):
        return False
    if mode == 'next_weekday':
        return type(config.get('weekday')) is int and 1 <= config['weekday'] <= 7 and 'weekdays' not in config
    if mode == 'weekly':
        days = config.get('weekdays')
        return (isinstance(days, list) and 1 <= len(days) <= 7 and
                all(type(d) is int and 1 <= d <= 7 for d in days) and
                len(set(days)) == len(days) and 'weekday' not in config)
    return 'weekday' not in config and 'weekdays' not in config


@dataclass
class CalendarSchedule:
    config: dict
    deadline: int | None = None
    once: int | None = None
    last: int | None = None
    consumed: bool = False

    def rebase(self, now):
        self.deadline = None
        if now is None or self.consumed:
            return
        mode = self.config['mode']
        recurring = mode in ('daily', 'weekly')
        floor = max(now, self.last or 0) if recurring else now
        target = floor // DAY * DAY + self.config['time_of_day_seconds'] * 1000
        if mode in ('weekly', 'next_weekday'):
            days = self.config['weekdays'] if mode == 'weekly' else [self.config['weekday']]
            # Epoch day zero is Saturday. At most one calendar week plus today.
            target = next((target + offset * DAY for offset in range(8)
                           if target + offset * DAY > floor and
                           ((floor // DAY + offset + 5) % 7 + 1) in days), LIMIT)
        elif mode == 'today_offset':
            target += self.config.get('day_offset', 0) * DAY
        elif target <= floor:
            target += DAY
        if not recurring:
            if self.once is None:
                self.once = target
            target = self.once
            if target <= now:
                self.consumed = True
                return
        if target < LIMIT:
            self.deadline = target

    def consume(self, now):
        self.last = self.deadline
        self.consumed = self.config['mode'] not in ('daily', 'weekly')
        self.rebase(now)
