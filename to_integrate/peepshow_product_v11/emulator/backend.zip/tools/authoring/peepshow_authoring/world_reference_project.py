"""Authoring-only Scene reference declarations and project target validation."""
from .imported_properties import ImportedPropertyError
from .world_reference_source import parse_reference, validate_target
from .tiled_assets import definitions


def declarations(graph):
    from .project import STABLE_ID
    rows = graph.get('world_references', [])
    if type(rows) is not list:
        raise ImportedPropertyError('world_references must be an array')
    found = set()
    result = []
    for row in rows:
        if type(row) is not dict or not {'reference_id', 'target'} <= set(row) or set(row) - {'reference_id', 'target', 'writer', 'semantic'}:
            raise ImportedPropertyError('world declaration requires reference_id and target')
        identity = row['reference_id']
        if type(identity) is not str or not STABLE_ID.fullmatch(identity) or identity in found:
            raise ImportedPropertyError('invalid or duplicate world reference_id')
        found.add(identity)
        reference, expected = parse_reference(row['target'])
        from .facing_source import declaration
        declaration(row)
        result.append((identity, reference, expected))
    return result


def check_project(scenes, catalogs, issues):
    """Validate final candidate/load state, not intermediate command ordering."""
    from .project import _issue
    maps = {}
    for catalog in catalogs:
        records = catalog.get('map_assets', []) if isinstance(catalog, dict) else []
        if not isinstance(records, list):
            continue  # Catalog validation reports malformed collections separately.
        for record in records:
            if isinstance(record, dict) and isinstance(record.get('asset_id'), str):
                maps.setdefault(record['asset_id'], []).append(record)
    cached = {}
    for index, scene in enumerate(scenes):
        graph = scene.get('machine_logic') if isinstance(scene, dict) else None
        if not isinstance(graph, dict):
            continue
        path = f'scenes[{index}].machine_logic.world_references'
        try:
            rows = declarations(graph)
            from .facing_source import validate_links
            validate_links(graph)
            from .world_position_source import declarations as positions
            from .world_references import WorldReference
            rows += [(f"position:{r['object_ref']}", WorldReference(r['asset_id'], 'entity_x', r['entity_ref']), 'int32')
                     for r in positions(scene)]
        except ImportedPropertyError as exc:
            _issue(issues, 'WORLD_REFERENCE_INVALID', path, str(exc))
            continue
        for identity, reference, expected in rows:
            try:
                candidates = maps.get(reference.asset_id, [])
                if len(candidates) != 1:
                    raise ImportedPropertyError(f'missing or ambiguous map asset {reference.asset_id}')
                from .scene_map_entities import materialize
                cache_key = (index, reference.asset_id)
                if cache_key not in cached:
                    record = materialize(candidates[0], graph.get('map_scene'))
                    cached[cache_key] = (record, definitions(reference.asset_id, record['snapshot']))
                record, defs = cached[cache_key]
                validate_target(record, reference, expected, defs)
                if any(r['reference_id'] == identity and r.get('semantic') == 'facing'
                       for r in graph.get('world_references', [])):
                    from .facing_source import validate_default
                    validate_default(record, reference, defs)
            except (ImportedPropertyError, KeyError, TypeError) as exc:
                _issue(issues, 'WORLD_REFERENCE_INVALID', f'{path}[{identity}]', str(exc))
