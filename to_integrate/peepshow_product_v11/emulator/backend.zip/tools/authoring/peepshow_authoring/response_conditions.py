"""Ordinary response State/time predicates on the existing host transaction.

The private guard preserves a labelled branch's truth value through structural
projection. It is not a saved source operand or a device execution grant.
"""
from .flowcharts import predicate_leaves, evaluate

GUARD_KIND = 'response.predicate'
FIELDS = {'machine_ref', 'state_ref', 'time_available', 'time_of_day_range'}
CAPABILITY = dict(
    machine_state=dict(fields=['machine_ref', 'state_ref'], ordinary_machines_only=True,
        sampling='current_queued_receiver_before_destination_and_actions', requires_writer=False),
    local_time=dict(fields=['time_available', 'time_of_day_range'],
        sampling='one_snapshot_per_external_transaction', start_inclusive=True,
        end_exclusive=True, midnight_wrap=True, unavailable_range_result=False,
        reconciliation_field='time_reconcile', automatic_polling=False),
    composition='connected_decision_nodes', inverse='when_false',
    host_preview=True, runtime=False, export=False)


def is_condition(value):
    return type(value) is dict and bool(FIELDS.intersection(value))


def validate(value, machines):
    from .project import ProjectCommandError
    if not is_condition(value) or set(value) not in (
            {'machine_ref', 'state_ref'}, {'time_available'}, {'time_of_day_range'}):
        raise ValueError('requires a machine-State, time availability or local-time range condition')
    try:
        predicate_leaves(value)  # Share endpoint/type semantics with callable flows.
    except ProjectCommandError as exc:
        raise ValueError(exc.message) from exc
    if 'machine_ref' in value:
        ref, state = value['machine_ref'], value['state_ref']
        machine = next((m for m in machines if m.get('machine_id') == ref), None)
        if (type(ref) is not str or type(state) is not str or machine is None
                or state not in machine['states']):
            raise ValueError(f'unknown machine-State pair {ref!r} / {state!r}')


def is_guard(value):
    return type(value) is dict and value.get('kind') == GUARD_KIND


def validate_guard(value, machines):
    if set(value) != {'kind', 'condition', 'expected'} or type(value['expected']) is not bool:
        raise ValueError('invalid private response predicate')
    validate(value['condition'], machines)


def matches(player, guards, evidence=None):
    # Each checked leaf charges the existing bounded transaction work budget.
    # Invalid references have already failed admission; evaluation errors propagate
    # and reject the transaction, never becoming the False branch.
    return all(evaluate(player, g['condition'], [], '', evidence=evidence) == g['expected']
               for g in guards if is_guard(g))


def uses_local_time(graph):
    for route in graph.get('routes', []):
        conditions = [n.get('condition', {}) for n in route.get('response', {}).get('nodes', [])]
        conditions += [g['condition'] for g in route.get('guards', []) if is_guard(g)]
        if any('time_available' in c or 'time_of_day_range' in c for c in conditions):
            return True
    return False


def structural_bundle(bundle):
    """Native shape/ownership proof for host map adapters, never device export.

    The ordinary host evaluator retains these guards. Native admission checks
    all branch effects even though it cannot encode these response predicates.
    Its temporary time-reconciliation hook is omitted when its only conditions
    were removed; the real host hook and source are retained without changes.
    """
    from copy import deepcopy
    from dataclasses import replace
    from .flowcharts import uses_local_time as scene_uses_time
    scenes=[]
    for scene in bundle.scenes:
        routes=scene.get('machine_logic', {}).get('routes', [])
        if not any(is_guard(g) for r in routes for g in r.get('guards', [])):
            scenes.append(scene)
            continue
        scene=deepcopy(scene)
        for route in scene['machine_logic']['routes']:
            route['guards']=[g for g in route['guards'] if not is_guard(g)]
        if not scene_uses_time(scene):
            scene['machine_logic'].pop('time_reconcile', None)
        scenes.append(scene)
    return replace(bundle, scenes=tuple(scenes))
