"""Cooperative host execution checkpoints; no threads, replay or wall clock."""
from copy import deepcopy


def drain(iterator):
    while True:
        try:
            next(iterator)
        except StopIteration as done:
            return done.value


def checkpoint(player, kind, **location):
    return dict(kind=kind, scene_id=player.scene_id, _player=player, **location)


def inspect_player(player):
    world = getattr(player, '_world_context', None)
    return dict(scene_id=player.scene_id, elapsed_ms=player._elapsed_ms, local_ms=player._local_ms, suspended=player._suspended,
        machine_states=deepcopy(getattr(player, '_machine_states', {})),
        package_variables=deepcopy(player._package_variables),
        variables=[dict(variable_id=v['variable_id'], value=player._variables[i], scope=deepcopy(player._scoped_variables.get(v['variable_id']))) for i,v in enumerate(player._graph['variables'])],
        objects=deepcopy(getattr(player, '_object_live', {})),
        inventory=deepcopy(getattr(player, '_inventory_state', {})),
        world_values=[dict(slot=list(k) if isinstance(k,tuple) else k, value=v)
                      for k,v in getattr(world, 'values', {}).items()])


def queue_snapshot(player, queue):
    world = getattr(player, '_world_context', None)
    result = []
    for receiver, event in queue:
        if world is not None and hasattr(world, 'resolve_receiver'):
            receiver, event = world.resolve_receiver(receiver, event)
            identity = world.receiver_identity(receiver)
        else:
            identity = dict(machine_id=receiver)
        result.append(dict(identity, event_id=event))
    return result


def annotate(iterator, **fields):
    try:
        while True:
            try:
                mark = next(iterator)
            except StopIteration as done:
                return done.value
            mark.update(fields)
            yield mark
    finally:
        iterator.close()


def inspect_parameter(player, parameter):
    """Read a bound operand without executing predicates or granting write access."""
    declaration, binding = parameter['declaration'], parameter['binding']
    kind = declaration['type']
    if kind in ('int32', 'boolean', 'direction'):
        return dict(value_available=True, value=deepcopy(binding))
    if kind == 'object':return object_operand(player, binding)
    if kind == 'property':
        world = getattr(player, '_world_context', None)
        slot = getattr(world, 'debug_properties', {}).get(binding)
        if slot is not None:
            field, index, value_type, _ = world.bindings[slot]
            value = world.values[field,index]
            return dict(value_available=True, value=bool(value) if value_type else value)
    if kind == 'variable':
        if binding['variable_scope'] == 'package':
            values = player._package_variables
            if binding['variable_ref'] in values:
                return dict(value_available=True, value=values[binding['variable_ref']])
        else:
            for i, variable in enumerate(player._graph['variables']):
                scope = player._scoped_variables.get(variable['variable_id'], {})
                if scope.get('scope') == 'scene' and scope.get('variable_id') == binding['variable_ref']:
                    return dict(value_available=True, value=player._variables[i])
    return dict(value_available=False)


def object_operand(player, ref):
    definition = getattr(player, '_object_definitions', {}).get(ref)
    if definition is None:return dict(value_available=False)
    return dict(value_available=True, value=dict(defaults=deepcopy(definition['defaults']),
        live=deepcopy(player._object_live.get(ref, {}))), representation='stored_not_rendered')


def action_operands(player, action):
    result = {}
    if 'object_ref' in action:
        result['object'] = dict(object_ref=action['object_ref'], **object_operand(player, action['object_ref']))
    return result


def complete_action(mark):
    mark['result']='executed_pending'
    mark['operands_after']=action_operands(mark['_player'], mark['action'])
