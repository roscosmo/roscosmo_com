"""Authored interaction targets lowered to the existing queued ahead query."""
from copy import deepcopy

from .imported_properties import ImportedPropertyError

SIDES = {'below': (0, -1), 'above': (0, 1), 'left': (1, 0), 'right': (-1, 0)}
CAPABILITY = dict(host_editing=True, host_preview=True, persisted=True, undo_redo=True,
    runtime=False, export=False, hardware_validation='not_qualified',
    preview_requires='all_scenes_have_map_scene_bindings',
    field='machine_logic.interactables', action_kind='interact_ahead',
    schema='schemas/authoring/interaction-v1.schema.json',
    commands=['scene.machines.set', 'scene.flowcharts.set'],
    locations=['scene_transition_actions', 'scene_flowchart_actions'],
    recipients='stationary_behavior_instances', approach_sides=list(SIDES),
    eligibility='optional_target_world_bool', facing='same_actor_named_facing_reference',
    no_target='no_op_or_queued_scene_machine_event', delivery='existing_mixed_event_fifo',
    selection_time='query_delivery_in_current_transaction', offscreen=True,
    overlapping_targets='reject_at_admission_even_if_disabled',
    validation_error='INTERACTION_INVALID', readiness_error='INTERACTION_DEVICE_UNAVAILABLE')


class InteractionError(ImportedPropertyError):
    code = 'INTERACTION_INVALID'


def present(graph):
    """Readiness also detects a no-target-only action or a raw v3 query."""
    pending = [graph]
    while pending:
        row = pending.pop()
        if type(row) is dict:
            if 'interactables' in row or 'interaction_targets' in row or row.get('kind') == 'interact_ahead':
                return True
            pending.extend(row.values())
        elif type(row) is list:
            pending.extend(row)
    return False


def lower(graph):
    """Only a private graph copy is changed; authors never persist bridges."""
    from .world_reference_project import declarations
    from .facing_source import DIRECTIONS
    from .behavior_interface_source import ports

    def fail(path, message):
        raise InteractionError(f'{path}: {message}')

    rows = graph.pop('interactables', [])
    used, pending, has_action = set(), [graph, rows], False
    while pending:
        value = pending.pop()
        if type(value) is str:
            used.add(value)
        elif type(value) is dict:
            has_action = has_action or value.get('kind') == 'interact_ahead'
            pending.extend(value.values())
        elif type(value) is list:
            pending.extend(value)
    if type(rows) is not list or len(rows) > 128:
        fail('interactables', 'requires at most 128 declarations')
    if not rows and not has_action:
        return
    source, map_scene = graph.get('instance_behaviors'), graph.get('map_scene')
    if not isinstance(source, dict) or source.get('version') != 3 or not isinstance(map_scene, dict):
        fail('interactables', 'requires a map Scene and version 3 behavior instances')
    refs = {name: (ref, kind) for name, ref, kind in declarations(graph)}
    ref_rows = {r['reference_id']: r for r in graph['world_references']}
    instances = source.get('instances', [])
    targets, seen = [], set()
    for row in rows:
        if (type(row) is not dict or not {'instance_ref', 'input_event_ref', 'approach_sides'} <= set(row)
                or set(row) - {'instance_ref', 'input_event_ref', 'approach_sides', 'enabled_when'}):
            fail('interactables', 'requires instance_ref, input_event_ref, approach_sides and optional enabled_when')
        name, event, sides = row['instance_ref'], row['input_event_ref'], row['approach_sides']
        if type(name) is not str or name in seen:
            fail('interactables', 'invalid or duplicate instance_ref')
        seen.add(name)
        matches = [i for i in instances if isinstance(i, dict) and i.get('instance_id') == name]
        if len(matches) != 1:
            fail(name, 'requires one existing behavior instance')
        instance = matches[0]
        definitions = [b for b in source.get('behaviors', []) if isinstance(b, dict)
                       and b.get('behavior_id') == instance.get('behavior_ref')]
        if len(definitions) != 1:
            fail(name, 'requires one existing behavior definition')
        definition = definitions[0]
        interface = ports(definition)
        if (type(event) is not str or not event or
                not any(e.get('event_id') == event for e in definition['machine_logic']['events']) or
                interface is not None and event not in interface['inputs'] or
                any(o.get('instance_ref') == name and o.get('event_ref') == event for o in source.get('outgoing', []))):
            fail(name, 'input_event_ref must identify a behavior input, not an output')
        if (type(sides) is not list or not sides or any(type(s) is not str or s not in SIDES for s in sides)
                or len(set(sides)) != len(sides)):
            fail(name, 'approach_sides requires unique above/below/left/right sides')
        target = deepcopy(row)
        condition = target.get('enabled_when')
        if condition is not None:
            if (type(condition) is not dict or set(condition) != {'reference_ref', 'equals'} or
                    type(condition['reference_ref']) is not str or condition['reference_ref'] not in refs or
                    type(condition['equals']) is not bool):
                fail(name, 'enabled_when requires a world Boolean reference and Boolean equals')
            ref, kind = refs[condition['reference_ref']]
            entity = instance['entity']
            if kind != 'bool' or ref.asset_id != entity['asset_id'] or ref.owner_id != entity['owner_id']:
                fail(name, 'eligibility must be a Boolean property of the target actor')
            target['enabled_when'] = dict(reference=deepcopy(ref_rows[condition['reference_ref']]['target']),
                                          equals=condition['equals'])
        targets.append(target)

    addresses = {}
    def actions(items, path):
        if not isinstance(items, list):
            return
        for index, action in enumerate(items):
            if not isinstance(action, dict) or action.get('kind') != 'interact_ahead':
                continue
            location = f'{path}.actions[{index}]'
            if (not {'kind', 'entity_ref', 'facing_ref'} <= set(action) or
                    set(action) - {'kind', 'entity_ref', 'facing_ref', 'no_target'}):
                fail(location, 'requires entity_ref, facing_ref and optional no_target')
            name = action['facing_ref']
            if type(name) is not str or name not in refs or ref_rows[name].get('semantic') != 'facing':
                fail(location, 'facing_ref must declare named facing semantics')
            facing, _ = refs[name]
            if facing.owner_id != action['entity_ref'] or facing.asset_id != map_scene['asset_ref']:
                fail(location, 'facing must belong to the querying actor on this map')
            occupants = [o for o in map_scene['occupancy'] if o['entity_ref'] == action['entity_ref']]
            if len(occupants) != 1:
                fail(location, 'querying actor must be registered in map occupancy')
            fallback = action.get('no_target')
            if 'no_target' in action:
                if (type(fallback) is not dict or set(fallback) != {'machine_ref', 'event_ref'} or
                        fallback['machine_ref'] not in [m['machine_id'] for m in graph['machines']] or
                        fallback['event_ref'] not in [e['event_id'] for e in graph['events']]):
                    fail(location, 'no_target requires an existing Scene machine and named event')
            key = (name, None if fallback is None else (fallback['machine_ref'], fallback['event_ref']))
            if key not in addresses:
                ordinal = len(addresses)
                event = f'ps_interaction_{ordinal}'
                while event in used:
                    ordinal += 1
                    event = f'ps_interaction_{ordinal}'
                used.add(event)
                machine = graph['machines'][0]['machine_id']
                query = dict(actor=deepcopy(ref_rows[occupants[0]['x_ref']]['target']),
                    facing=deepcopy(ref_rows[name]['target']), facings=dict(DIRECTIONS),
                    eligible=[r['instance_ref'] for r in targets],
                    cell_width=map_scene['cell_width'], cell_height=map_scene['cell_height'],
                    interaction_targets=deepcopy(targets))
                if fallback is not None:
                    query['no_target'] = deepcopy(fallback)
                source['bridges'].append(dict(machine_ref=machine, event_ref=event,
                    target_event_ref='interaction', query=query))
                graph['events'].append(dict(event_id=event, display_name='Interact ahead'))
                addresses[key] = (machine, event)
            machine, event = addresses[key]
            items[index] = dict(kind='send_event', machine_ref=machine, event_ref=event)

    for route in graph.get('routes', []):
        actions(route.get('actions'), f"routes[{route.get('route_id', '?')}]")
        for i, outcome in enumerate(route.get('outcomes', [])):
            actions(outcome.get('actions'), f"routes[{route.get('route_id', '?')}].outcomes[{i}]")
    for chart in graph.get('flowcharts', []):
        for node in chart.get('nodes', []):
            actions(node.get('actions'), f"flowcharts[{chart.get('flowchart_id', '?')}].nodes[{node.get('node_id', '?')}]")
