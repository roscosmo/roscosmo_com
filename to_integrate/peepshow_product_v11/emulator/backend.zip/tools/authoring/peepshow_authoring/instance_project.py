"""Shared instance source admission and scoped host preview; no installed export."""
from dataclasses import replace
from .instance_event_source import CAPABILITY as EVENT_CAPABILITY
from .behavior_interface_source import CAPABILITY as INTERFACE_CAPABILITY
from .facing_source import CAPABILITY as FACING_CAPABILITY
from .behavior_response import CAPABILITY as RESPONSE_CAPABILITY
from .behavior_destinations import CAPABILITY as DESTINATION_CAPABILITY

FIELD = 'instance_behaviors'
CAPABILITY = {
    'destinations': DESTINATION_CAPABILITY,
    'event_responses': RESPONSE_CAPABILITY,
    'event_addressing': EVENT_CAPABILITY,
    'interfaces': INTERFACE_CAPABILITY,
    'facing': FACING_CAPABILITY,
    'status': 'host_preview', 'host_editing': True, 'host_preview': True,
    'preview_requires': 'all_scenes_have_map_scene_bindings',
    'runtime': False, 'export': False, 'hardware_validation': 'not_qualified',
    'field': 'machine_logic.instance_behaviors', 'source_version': 3, 'source_versions': [1, 2, 3],
    'spatial_schema': 'schemas/authoring/instance-behaviors-v3.schema.json',
    'spatial_fields': ['entity_x', 'entity_y'],
    'collision_guard': 'collision.compare',
    'schema': 'schemas/authoring/instance-behaviors-v3.schema.json',
    'schemas_by_version': {str(v): f'schemas/authoring/instance-behaviors-v{v}.schema.json'
                           for v in (1, 2, 3)},
    'target_bindings': {
        'source_version': 3, 'field': 'instances[].target',
        'property_owner_field': 'behaviors[].properties[].owner',
        'owners': ['self', 'target'], 'target_fields': ['entity_x', 'entity_y'],
        'target_writable': False, 'requires_complete_xy_pair': True,
        'requires_distinct_entity_on_same_map': True,
        'unused_target': 'must_be_null',
    },
    'adjacency_queries': {
        'source_version': 3, 'field': 'behaviors[].adjacency_queries',
        'guard': 'adjacency.compare', 'operators': ['eq', 'ne'],
        'result_type': 'bool', 'semantics': 'one_cardinal_cell',
        'diagonal_matches': False, 'overlap_matches': False,
        'requires_visible_target': False,
    },
    'outgoing_events': {
        'source_version': 3, 'field': 'outgoing',
        'fields': ['instance_ref', 'event_ref', 'machine_ref', 'target_event_ref'],
        'direction': 'instance_to_scene_machine',
        'emit_action': 'send_event', 'emit_machine_ref': 'self',
        'delivery': 'existing_mixed_event_fifo', 'binding_scope': 'per_instance',
        'implicit_broadcast': False,
    },
    'legacy_schema': 'schemas/authoring/instance-behaviors-v1.schema.json',
    'commands': ['scene.machines.set', 'scene.machines.clear'],
    'persisted': True, 'undo_redo': True,
    'validation': 'final_project_transaction_and_load',
    'validation_error': 'INSTANCE_SOURCE_INVALID',
    'readiness_error': 'INSTANCE_RUNTIME_UNAVAILABLE',
    'state_scope': 'per_instance', 'definition_scope': 'shared',
    'property_values': 'imported_map_defaults_and_overrides',
    'writer_policy': 'exclusive_declared_owner',
    'public_resource_admission': False,
}


def readiness_issues(bundle):
    from .map_scene_source import readiness_issues as map_issues
    return map_issues(bundle) + [dict(code='INSTANCE_RUNTIME_UNAVAILABLE',
                 path=f"scenes[{s['scene_id']}].machine_logic.{FIELD}",
                 message='Shared instance preview requires map_scene bindings; public device package export remains unavailable.')
            for s in bundle.scenes if FIELD in s.get('machine_logic', {})]


def validate_bundle(bundle):
    """Validate the final candidate, never partial commands or mutable live state.

    The existing private compiler checks bindings, ownership, graphs and mixed
    routing. Its 64-entry verification queue accommodates the existing event-chain
    ceiling; this is not a promise about an installed device's queue allocation.
    """
    from .project import ValidationIssue
    from .world_logic_source import prepare
    from .instance_source import compile_instance_source
    if not bundle.valid:
        return bundle
    issues = []
    for scene in bundle.scenes:
        graph = scene.get('machine_logic', {})
        try:
            from .map_scene_source import validate_scene
            validate_scene(bundle, scene)
        except (ValueError, KeyError, TypeError, AttributeError, IndexError, OverflowError) as exc:
            issues.append(ValidationIssue('MAP_SCENE_INVALID',
                f"scenes[{scene['scene_id']}].machine_logic.map_scene", str(exc)))
            continue
        if FIELD not in graph:
            continue
        try:
            from .execution_scope_source import lifecycle_proof_scene
            proof, _ = lifecycle_proof_scene(bundle.project, scene)
            proof_bundle = bundle if proof is scene else replace(bundle,
                scenes=tuple(proof if s['scene_id'] == scene['scene_id'] else s for s in bundle.scenes))
            projected, world, source = prepare(proof_bundle, scene['scene_id'])
            from .response_conditions import structural_bundle
            compile_instance_source(structural_bundle(projected), scene['scene_id'], world, source.routes,
                                    source.instance_source, queue_capacity=64,
                                    flow_attachments=source.flows, authoring_scene_exits=True)
        except (ValueError, KeyError, TypeError, AttributeError, IndexError, OverflowError) as exc:
            from .actor_output_response import describe_error
            issues.append(ValidationIssue('INSTANCE_SOURCE_INVALID',
                f"scenes[{scene['scene_id']}].machine_logic.{FIELD}", describe_error(scene, str(exc))))
    return replace(bundle, issues=tuple(issues))
