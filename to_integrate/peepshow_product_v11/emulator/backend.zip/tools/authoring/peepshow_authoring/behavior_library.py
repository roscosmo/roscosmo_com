"""Explicit project reuse of existing v3 shared-behavior definitions."""
from copy import deepcopy
from dataclasses import replace

COMMANDS = ('project.behavior.set', 'project.behavior.remove', 'scene.behavior.link',
            'scene.behavior.unlink', 'scene.behavior.make_independent')
CAPABILITY = dict(project_field='behavior_definitions', graph_field='instance_behaviors.behavior_links',
    commands=list(COMMANDS), schema='schemas/authoring/behavior-library-v1.schema.json',
    command_schema='schemas/authoring/behavior-library-command-v1.schema.json',
    definition_schema='schemas/authoring/instance-behaviors-v3.schema.json#/$defs/behavior',
    maximum_project_definitions=64, maximum_links_per_scene=16,
    definition_kind='shared_behavior_v3', arbitrary_machine_definitions=False,
    instance_state='independent', external_bindings='existing_instance_and_output_bindings',
    link_edits='propagate_on_next_preview_preparation', overrides=False,
    independent_copy='behavior_and_linked_flow_closures_with_same_local_alias',
    missing_definition='authored_execution_diagnostic', readiness_scope='instantiated_links',
    implicit_detach=False, persistence='explicit_save', undo_redo=True,
    host_preview=True, runtime=False, export=False)


class LibraryError(ValueError):
    def __init__(self, path, message):
        super().__init__(message)
        self.path = path


def resolve(envelope, project, link, path, *, independent=False):
    aliases = [row['behavior_id'] for row in envelope.get('behavior_links', [])]
    local = {row['behavior_id'] for row in envelope.get('behaviors', [])}
    if len(aliases) != len(set(aliases)) or local.intersection(aliases):
        raise LibraryError(path+'.behavior_links', 'Local behaviors and links must have distinct identities')
    ref = link['definition_ref']
    at = path+'.behavior_links['+link['behavior_id']+'] -> project.behavior_definitions['+ref+']'
    definitions = [row for row in project.get('behavior_definitions', []) if row['behavior_id'] == ref]
    if len(definitions) != 1:
        raise LibraryError(at, 'Missing or duplicate project behavior definition; instances are preserved')
    result = deepcopy(definitions[0])
    result['behavior_id'] = link['behavior_id']
    if independent:
        from .flow_library import materialize
        graph = result['machine_logic']
        links = graph.get('flowchart_links', [])
        if links:
            copies = materialize(graph, {f['flowchart_id']: f for f in project.get('flowchart_definitions', [])},
                                 links, at+'.machine_logic', copy_mode=True)
            graph.setdefault('flowcharts', []).extend(copies)
            graph.pop('flowchart_links')
    return result


def prepare(bundle):
    from .project import ValidationIssue
    scenes = deepcopy(bundle.scenes)
    issues = list(bundle.issues)
    for scene in scenes:
        envelope = scene.get('machine_logic', {}).get('instance_behaviors')
        if envelope is None:
            continue
        path = 'scenes['+scene['scene_id']+'].machine_logic.instance_behaviors'
        links = envelope.get('behavior_links', [])
        try:
            if links and (bundle.project.get('execution_semantics') != 'terminal_order_v1' or envelope.get('version') != 3):
                raise LibraryError(path, 'Project behavior links require terminal_order_v1 and shared behavior v3')
            needed = {row['behavior_ref'] for row in envelope.get('instances', [])}
            imported = [resolve(envelope, bundle.project, link, path) for link in links if link['behavior_id'] in needed]
            envelope.setdefault('behaviors', []).extend(imported)
            envelope.pop('behavior_links', None)
        except (ValueError, KeyError, TypeError) as exc:
            issues.append(ValidationIssue('BEHAVIOR_LIBRARY_INVALID', getattr(exc, 'path', path), str(exc)))
    project = deepcopy(bundle.project)
    project.pop('behavior_definitions', None)
    return replace(bundle, project=project, scenes=tuple(scenes), issues=tuple(issues))


def apply(project, scenes, command):
    from .authoring_foundation import schemas
    from .project import ProjectCommandError, _command_scene
    validator = schemas()[2].evolve(schema={'$ref': 'https://peepshow.dev/schema/authoring/behavior-library-command-v1.schema.json'})
    errors = list(validator.iter_errors(command))
    if errors:
        raise ProjectCommandError('BEHAVIOR_LIBRARY_COMMAND_INVALID', errors[0].message)
    if project.get('execution_semantics') != 'terminal_order_v1':
        raise ProjectCommandError('EXECUTION_SEMANTICS_MIGRATION_REQUIRED', 'Behavior library editing requires terminal_order_v1; no implicit conversion')
    kind = command['kind']
    rows = project.get('behavior_definitions', [])
    if kind.startswith('project.'):
        ref = command['definition']['behavior_id'] if kind.endswith('.set') else command['definition_ref']
        index = next((i for i, row in enumerate(rows) if row['behavior_id'] == ref), None)
        if kind.endswith('.set'):
            rows = deepcopy(rows)
            if index is None:
                rows.append(deepcopy(command['definition']))
            else:
                rows[index] = deepcopy(command['definition'])
            project['behavior_definitions'] = rows
        else:
            if index is None:
                raise ProjectCommandError('COMMAND_TARGET_UNKNOWN', 'Unknown project behavior')
            project['behavior_definitions'] = [row for row in rows if row['behavior_id'] != ref]
        return deepcopy(command)
    scene = _command_scene(scenes, command['scene_id'])
    graph = scene.get('machine_logic')
    if graph is None:
        raise ProjectCommandError('COMMAND_TARGET_UNKNOWN', 'Scene has no machine graph')
    envelope = graph.get('instance_behaviors')
    if envelope is None and kind == 'scene.behavior.link':
        envelope = dict(version=3, behaviors=[], instances=[], bridges=[])
        graph['instance_behaviors'] = envelope
    if envelope is None or envelope.get('version') != 3:
        raise ProjectCommandError('BEHAVIOR_LIBRARY_VERSION', 'Behavior links require the v3 shared behavior envelope')
    ref = command['behavior_id']
    links = envelope.get('behavior_links', [])
    index = next((i for i, row in enumerate(links) if row['behavior_id'] == ref), None)
    if kind == 'scene.behavior.link':
        if any(row['behavior_id'] == ref for row in envelope['behaviors']):
            raise ProjectCommandError('BEHAVIOR_LIBRARY_COLLISION', 'Local behavior already owns this identity')
        links = deepcopy(links)
        link = dict(behavior_id=ref, definition_ref=command['definition_ref'])
        if index is None:
            links.append(link)
        else:
            links[index] = link
        envelope['behavior_links'] = links
    else:
        if index is None:
            raise ProjectCommandError('COMMAND_TARGET_UNKNOWN', 'Unknown behavior link')
        if kind == 'scene.behavior.make_independent':
            path = 'scenes['+scene['scene_id']+'].machine_logic.instance_behaviors'
            try:
                copied = resolve(envelope, project, links[index], path, independent=True)
            except (ValueError, KeyError, TypeError) as exc:
                raise ProjectCommandError('BEHAVIOR_LIBRARY_COPY_INVALID', getattr(exc, 'path', path)+': '+str(exc)) from exc
            envelope['behaviors'].append(copied)
        envelope['behavior_links'] = [row for row in links if row['behavior_id'] != ref]
        if not envelope['behavior_links']:
            envelope.pop('behavior_links')
    return deepcopy(command)
