"""Private WOP1 numeric operands; not project schema, public export or SMG1."""
import struct

from .imported_properties import ImportedPropertyError
from .machine_limits import MACHINES, FLOWCHARTS

HEADER = struct.Struct('<4s7I')
BINDING = struct.Struct('<4I')
OPERAND = struct.Struct('<IIi')
QUERY_HEADER = struct.Struct('<4s8I')
QUERY = struct.Struct('<4I2i')
OCCUPANCY_QUERY = struct.Struct('<4I2iI')
FACING_STEPS = ((-1, 0), (1, 0), (0, -1), (0, 1))


def _number(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ImportedPropertyError('world operand integer out of range')
    return value


def _validate(bindings, guards, actions, machines, flows, queries=(), query_kinds=None):
    _number(machines, 1, MACHINES)
    _number(flows, 0, FLOWCHARTS)
    previous = None
    for field, index, kind, writer in bindings:
        _number(field, 1, 5)
        _number(index, 0, 0xffffffff)
        _number(kind, 0, 1)
        _number(writer, 0, 255)
        if (field <= 2 and index or field != 5 and kind or
                not (writer < machines or writer == 255 or 128 <= writer < 128 + flows) or
                previous is not None and (field, index) <= previous):
            raise ImportedPropertyError('invalid or duplicate world binding')
        previous = field, index
    for records, is_action in ((guards, False), (actions, True)):
        for binding, op, value in records:
            _number(binding, 0, len(bindings) + (0 if is_action else len(queries)) - 1)
            _number(op, 1, 7 if is_action and query_kinds is not None and any(k in (3, 4, 5, 6) for k in query_kinds) else 6)
            _number(value, -0x80000000, 0x7fffffff)
            if is_action and op == 7:
                _number(value, 0, len(queries) - 1)
                x, y = queries[value][:2]
                _number(x, 0, len(bindings) - 1)
                _number(y, 0, len(bindings) - 1)
                if (query_kinds[value] not in (3, 4, 5, 6) or binding != x or
                        bindings[x][3] == 255 or bindings[x][3] != bindings[y][3]):
                    raise ImportedPropertyError('destination move requires its query actor and one X/Y writer')
                continue
            if binding >= len(bindings):
                if op > 2 or value not in (0, 1):
                    raise ImportedPropertyError('query guard must compare a boolean')
                continue
            kind, writer = bindings[binding][2:]
            if is_action and op in (3, 6):
                _number(value, 0, len(bindings) - 1)
                if bindings[value][2]:
                    raise ImportedPropertyError('copy source must be an integer binding')
            if (is_action and writer == 255 or
                    kind and (value not in (0, 1) or op > (1 if is_action else 2))):
                raise ImportedPropertyError('invalid typed world operand')
    for qi, (x, y, width, height, dx, dy) in enumerate(queries):
        _number(x, 0, len(bindings) - 1)
        _number(y, 0, len(bindings) - 1)
        _number(width, 1, 0xffffffff)
        _number(height, 1, 0xffffffff)
        if query_kinds is not None and query_kinds[qi] in (5, 6):
            _number(dx, -0x80000000, 0x7fffffff)
            _number(dy, -0x80000000, 0x7fffffff)
            _number(dx * width, -0x80000000, 0x7fffffff)
            _number(dy * height, -0x80000000, 0x7fffffff)
            # Local behavior operands use distinct property slots before instance
            # binding. Their declared Self X/Y types are checked by compile_behavior.
            local_xy = bindings[x][0] == bindings[y][0] == 5 and x != y
            if (not local_xy and (bindings[x][0] != 3 or bindings[y][0] != 4 or bindings[x][1] != bindings[y][1])
                    or bindings[x][2] or bindings[y][2]):
                raise ImportedPropertyError('invalid explicit-cell actor coordinates')
            continue
        if query_kinds is not None and query_kinds[qi] in (3, 4):
            _number(dx, 0, min(len(bindings)-1, 0x7fffffff))
            _number(dy, 0, 0)
            local_xy = bindings[x][0] == bindings[y][0] == 5 and x != y
            if (len({x, y, dx}) != 3 or any(bindings[i][2] for i in (x, y, dx)) or
                    not local_xy and (bindings[x][0] != 3 or bindings[y][0] != 4 or bindings[x][1] != bindings[y][1]) or
                    bindings[dx][0] != 5):
                raise ImportedPropertyError('invalid facing-relative actor/facing bindings')
            continue
        if query_kinds is not None and query_kinds[qi] == 2:
            _number(dx, 0, min(len(bindings)-1, 0x7fffffff))
            _number(dy, 0, min(len(bindings)-1, 0x7fffffff))
            if len({x,y,dx,dy}) != 4 or any(bindings[i][2] for i in (x,y,dx,dy)):
                raise ImportedPropertyError('invalid adjacency coordinate bindings')
            continue
        _number(dx, -1, 1)
        _number(dy, -1, 1)
        if x == y or bindings[x][2] or bindings[y][2] or abs(dx) + abs(dy) != 1:
            raise ImportedPropertyError('invalid terrain query coordinates or direction')


def compile_operands(bindings, guards, actions, machines, flows=0, *, maximum_bytes=16 * 1024 * 1024):
    """Already-resolved numeric records. Ordering is semantic: never sort and
    silently renumber references. Host output budget is not target admission.
    """
    for records, width in ((bindings, 4), (guards, 3), (actions, 3)):
        if not isinstance(records, (list, tuple)) or any(
                not isinstance(r, (list, tuple)) or len(r) != width for r in records):
            raise ImportedPropertyError('invalid world operand record shape')
    total = HEADER.size + len(bindings) * BINDING.size + (len(guards) + len(actions)) * OPERAND.size
    _number(maximum_bytes, HEADER.size, 0xffffffff)
    if total > maximum_bytes:
        raise ImportedPropertyError('world operands exceed host output budget')
    _validate(bindings, guards, actions, machines, flows)
    return (HEADER.pack(b'WOP1', 1, total, len(bindings), len(guards), len(actions), machines, flows) +
            b''.join(BINDING.pack(*r) for r in bindings) +
            b''.join(OPERAND.pack(*r) for r in guards) + b''.join(OPERAND.pack(*r) for r in actions))


def decode_typed_operands(data, machines, flows=0):
    """Validate either ordinary or query-bearing operands, returning stored tables."""
    if len(data) >= 8 and struct.unpack_from('<I', data, 4)[0] in (2, 3, 4, 5, 6):
        return decode_query_operands(data, machines, flows)[:3]
    return decode_operands(data, machines, flows)


def decode_operands(data, machines, flows=0):
    if len(data) < HEADER.size:
        raise ImportedPropertyError('truncated world operands')
    magic, version, size, nb, ng, na, nm, nf = HEADER.unpack_from(data)
    if (magic != b'WOP1' or version != 1 or size != len(data) or (nm, nf) != (machines, flows) or
            HEADER.size + nb * BINDING.size + (ng + na) * OPERAND.size != size):
        raise ImportedPropertyError('invalid world operand header')
    offset = HEADER.size
    bindings = [BINDING.unpack_from(data, offset + i * BINDING.size) for i in range(nb)]
    offset += nb * BINDING.size
    guards = [OPERAND.unpack_from(data, offset + i * OPERAND.size) for i in range(ng)]
    offset += ng * OPERAND.size
    actions = [OPERAND.unpack_from(data, offset + i * OPERAND.size) for i in range(na)]
    _validate(bindings, guards, actions, machines, flows)
    return bindings, guards, actions


def compile_query_operands(bindings, guards, actions, queries, machines, flows=0, *,
                           maximum_bytes=16 * 1024 * 1024, occupancy=None):
    """Private revisions 2 terrain, 3 occupancy, 4 adjacency, 5 host-facing, 6 host-cell.

    The historical occupancy argument carries kinds 0/1, or 2 for adjacency.
    Kind 2 reinterprets dx/dy as Target X/Y binding indices, not offsets.
    Older revisions never accept that interpretation.

    Host-only revision 5 adds kinds 3/4: facing-relative terrain/occupancy.
    Their dx field is the facing binding, dy is reserved zero. Action 7 names
    that query and atomically steps its actor on the currently selected axis.
    Native Scene/package encoding must reject this revision until connected.

    Host-only revision 6 adds kinds 5/6: explicit grid-cell terrain/occupancy.
    dx/dy hold signed cell indices. Action 7 atomically sets both coordinates
    for these kinds, under one X/Y writer and the existing transaction journal.

    Numeric query guard index = stored binding count + query index. Never adds
    query results to mutable world storage. Ordinary export remains revision 1.
    """
    for records, width in ((bindings, 4), (guards, 3), (actions, 3), (queries, 6)):
        if not isinstance(records, (list, tuple)) or any(
                not isinstance(r, (list, tuple)) or len(r) != width for r in records):
            raise ImportedPropertyError('invalid query operand record shape')
    codec = QUERY if occupancy is None else OCCUPANCY_QUERY
    if occupancy is not None and (len(occupancy)!=len(queries) or
            any(type(v) is not int or v not in (0,1,2,3,4,5,6) for v in occupancy)):
        raise ImportedPropertyError('one explicit occupancy flag is required per query')
    total = QUERY_HEADER.size + len(bindings)*BINDING.size + (len(guards)+len(actions))*OPERAND.size + len(queries)*codec.size
    _number(maximum_bytes, QUERY_HEADER.size, 0xffffffff)
    if total > maximum_bytes or len(bindings)+len(queries) > 0xffffffff:
        raise ImportedPropertyError('query operands exceed output budget')
    _validate(bindings, guards, actions, machines, flows, queries, occupancy)
    version = 2 if occupancy is None else (6 if any(k in (5,6) for k in occupancy) else (5 if any(k in (3,4) for k in occupancy) else (4 if 2 in occupancy else 3)))
    return (QUERY_HEADER.pack(b'WOP1', version, total, len(bindings), len(guards), len(actions), machines, flows, len(queries)) +
            b''.join(BINDING.pack(*r) for r in bindings) +
            b''.join(OPERAND.pack(*r) for r in guards) +
            b''.join(OPERAND.pack(*r) for r in actions) + b''.join(
                codec.pack(*r, *(() if occupancy is None else (occupancy[i],))) for i,r in enumerate(queries)))


def decode_query_operands(data, machines, flows=0):
    """Return stored tables; revisions 3..6 append explicit query kinds."""
    if len(data) < QUERY_HEADER.size:
        raise ImportedPropertyError('truncated query operands')
    magic, version, size, nb, ng, na, nm, nf, nq = QUERY_HEADER.unpack_from(data)
    codec = OCCUPANCY_QUERY if version >= 3 else QUERY
    if (magic != b'WOP1' or version not in (2,3,4,5,6) or size != len(data) or (nm, nf) != (machines, flows) or
            nb+nq > 0xffffffff or QUERY_HEADER.size+nb*BINDING.size+(ng+na)*OPERAND.size+nq*codec.size != size):
        raise ImportedPropertyError('invalid query operand header')
    offset = QUERY_HEADER.size
    bindings = [BINDING.unpack_from(data, offset+i*BINDING.size) for i in range(nb)]
    offset += nb*BINDING.size
    guards = [OPERAND.unpack_from(data, offset+i*OPERAND.size) for i in range(ng)]
    offset += ng*OPERAND.size
    actions = [OPERAND.unpack_from(data, offset+i*OPERAND.size) for i in range(na)]
    offset += na*OPERAND.size
    records = [codec.unpack_from(data, offset+i*codec.size) for i in range(nq)]
    if version>=3 and any(r[6] not in (tuple(range(7)) if version==6 else ((0,1,2,3,4) if version==5 else ((0,1,2) if version==4 else (0,1)))) for r in records):
        raise ImportedPropertyError('invalid occupancy query flag')
    queries = [r[:6] for r in records]
    _validate(bindings, guards, actions, machines, flows, queries,
              [r[6] for r in records] if version>=3 else None)
    result = (bindings, guards, actions, queries)
    return result + ([r[6] for r in records],) if version >= 3 else result
