"""Private compilation maps for observed host response selection, never execution."""
from copy import deepcopy


CAPABILITY = dict(version=1, supported=True, host_preview=True, runtime=False,
    field='machine_execution.trace[].selected_response',
    schema='schemas/authoring/response-preview-selection-v1.schema.json',
    contexts=['ordinary_machine', 'shared_behavior', 'actor_output'],
    evidence='selected_path_at_dispatch', action_completion=False,
    transaction_result_field='result', rollback_result='rolled_back',
    missing_path='no_observed_authored_response_selection',
    scene_identity='dispatch_origin', instance_identity=True,
    revision_fields=['project_revision', 'preview_revision'], persisted=False)


def attach_sources(package, bundle):
    """Attach exact route maps to the host copy, before preview activation."""
    from .behavior_response import lower_scene, lower_behavior
    sources = {scene['scene_id']: scene for scene in bundle.scenes}
    for scene in package.scenes:
        source = sources[scene['scene_id']]
        mapping = {}
        lower_scene(source, source_map=mapping)
        scene['_response_sources'] = mapping
        context = scene.get('_world_template')
        if context is None or not hasattr(context, 'players'):
            continue
        shared = source.get('machine_logic', {}).get('instance_behaviors', {})
        definitions = {}
        for behavior in shared.get('behaviors', []):
            mapping = {}
            lower_behavior(behavior, shared['version'], source_map=mapping)
            definitions[behavior['behavior_id']] = mapping
        for index, player in enumerate(context.players):
            instance = context.combined.instances.instances[index]
            behavior_id = context.combined.behaviors[instance.behavior].bindings.behavior_id
            player._scene['_response_sources'] = deepcopy(definitions.get(behavior_id, {}))
            player._scene['_response_context'] = dict(behavior_ref=behavior_id, instance_ref=context.ids[index])


def selected_fields(player, route):
    """Called once after guards select a route, before any branch effects."""
    selected = player._scene.get('_response_sources', {}).get(route['route_id'])
    if selected is None:
        return {}
    selected = deepcopy(selected)
    selected.update(scene_id=player.scene_id,
                    from_state=player._machine_states.get(route['machine_ref']),
                    **player._scene.get('_response_context', {}))
    if selected.get('context') == 'actor_output':
        selected['from_state'] = player._world_context.instance_state(selected['instance_ref'])
    return dict(selected_response=selected)


def authored_trace(rows):
    """Keep the output instance visible instead of its private queue address."""
    result = deepcopy(rows)
    for row in result:
        selected = row.get('selected_response', {})
        if selected.get('context') == 'actor_output':
            row.pop('machine_id', None)
            row.update(instance_id=selected['instance_ref'], event_id=selected['event_ref'],
                       route_id=selected['route_id'], context='actor_output',
                       writer_machine_ref=selected['machine_ref'])
    return result
