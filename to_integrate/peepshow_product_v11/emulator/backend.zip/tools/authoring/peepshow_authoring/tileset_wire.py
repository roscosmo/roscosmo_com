"""Private TTB1 full-tile graphics, using the shared monochrome PNG converter."""
from dataclasses import dataclass
import struct

from PIL import Image
from .image_assets import ImageAssetError, import_masked_1bpp, resolve_project_path, MAX_SOURCE_DIMENSION
from .tiled_assets import integer, validate_record
from .tile_selection import used_tiles

HEADER = struct.Struct('<4s7I')
RECORD = struct.Struct('<4I')


@dataclass(frozen=True)
class CompiledTiles:
    data: bytes
    metadata_bytes: int
    pixel_mask_bytes: int
    tile_count: int


def compile_tiles(record, root, *, maximum_bytes=16 * 1024 * 1024):
    """Private bank only; no map export or firmware capability is granted."""
    validate_record(record, root)
    integer(maximum_bytes, 'host output budget', 32, 0xffffffff)
    source = resolve_project_path(root, record['source_path'], 'map.source_path')
    snapshot = record['snapshot']
    tw, th = snapshot['tilewidth'], snapshot['tileheight']
    sets = sorted(snapshot['tilesets'], key=lambda ts: ts['firstgid'])
    selected = used_tiles(snapshot)
    count = len(selected)
    plane = ((tw + 7) // 8) * th
    metadata = HEADER.size + count * RECORD.size
    if metadata + count * plane > maximum_bytes:
        raise ImageAssetError('Tile bank exceeds host output budget even without masks')
    records, payload = bytearray(), bytearray()
    for ts in sets:
        indices = [gid - ts['firstgid'] for gid in selected
                   if ts['firstgid'] <= gid < ts['firstgid'] + ts['tilecount']]
        if not indices:
            continue
        if ts.get('transparentcolor') or ts.get('tileoffset') not in (None, {'x': 0, 'y': 0}):
            raise ImageAssetError('Color-key transparency and tile offsets are not compiled yet; use PNG alpha and grid-aligned tiles')
        relative = (source.parent.relative_to(root.resolve()) / ts['image']).as_posix()
        path = resolve_project_path(root, relative, 'tileset.image')
        try:
            with Image.open(path) as image:
                iw, ih = image.size
                if image.format != 'PNG' or not 1 <= iw <= MAX_SOURCE_DIMENSION or not 1 <= ih <= MAX_SOURCE_DIMENSION:
                    raise ImageAssetError('Tileset requires a bounded PNG atlas')
        except OSError as exc:
            raise ImageAssetError(f'Tileset PNG could not be opened: {exc}') from exc
        margin = integer(ts.get('margin', 0), 'margin', 0, MAX_SOURCE_DIMENSION)
        spacing = integer(ts.get('spacing', 0), 'spacing', 0, MAX_SOURCE_DIMENSION)
        columns = integer(ts.get('columns'), 'columns', 1, MAX_SOURCE_DIMENSION)
        actual_columns = (iw - 2 * margin + spacing) // (tw + spacing)
        rows = (ih - 2 * margin + spacing) // (th + spacing)
        if columns != actual_columns or rows < 1 or ts['tilecount'] > columns * rows:
            raise ImageAssetError('Tileset columns/count exceed atlas geometry')
        if ts.get('imagewidth', iw) != iw or ts.get('imageheight', ih) != ih:
            raise ImageAssetError('Tileset image dimensions disagree with PNG')
        # Reserve the worst-case decoded planes for this batch before conversion.
        if metadata + len(payload) + len(indices) * plane * 2 > maximum_bytes:
            raise ImageAssetError('Tile conversion working batch exceeds host output budget')
        frames = [dict(frame_id=str(i), pivot_x=0, pivot_y=0, source_rect=dict(
            x=margin + (i % columns) * (tw + spacing),
            y=margin + (i // columns) * (th + spacing), width=tw, height=th))
            for i in indices]
        for frame in import_masked_1bpp(root, dict(asset_id=record['asset_id'], source_path=relative, frames=frames),
                                       _frame_bounds=(tw, th)):
            pixels = metadata + len(payload)
            payload.extend(frame.pixels)
            mask = 0 if frame.opaque else metadata + len(payload)
            payload.extend(frame.mask)
            records.extend(RECORD.pack(pixels, mask, plane, int(frame.opaque)))
    blob = HEADER.pack(b'TTB1', 1, metadata + len(payload), tw, th, count, HEADER.size, metadata) + records + payload
    return CompiledTiles(bytes(blob), metadata, len(payload), count)
