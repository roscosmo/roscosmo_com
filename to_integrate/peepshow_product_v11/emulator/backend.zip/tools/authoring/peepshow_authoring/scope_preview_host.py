"""Public, serialized host adapter; no audio driver or alternative executor."""
from copy import deepcopy

from .preview import PreviewError
from .protocol import ProtocolError


def negotiate(value):
    if type(value) is not dict or set(value) != {'version'} or type(value['version']) is not int or value['version'] != 1:
        raise ProtocolError('SCOPE_HOST_INVALID', 'scope_host must be {"version":1}')


def require(player):
    if not any('_scope_source' in s for s in player._package.scenes):
        raise PreviewError('scope host protocol was not negotiated for this preview')


def generation(player, value):
    if type(value) is not int or player._scope_input is None or value != player._scope_input.generation:
        raise PreviewError('stale or missing focus_generation')


def held(player, params):
    generation(player, params['focus_generation'])
    # JSON requests use arrays, not strings/iterables/coerced values.
    if type(params['held_sources']) is not list:
        raise PreviewError('held_sources must be an array')
    return player._scope_input._snapshot_sources(params['held_sources'])


FIELDS = {
    'input_snapshot': {'focus_generation', 'held_sources'},
    'audio_take': set(),
    'audio_stop_complete': {'audio_token', 'success'},
    'menu_finish': {'menu_token', 'focus_generation', 'held_sources'},
    'menu_cancel': {'menu_token'},
}


def operate(player, operation, params):
    require(player)
    if operation.startswith('menu_') and getattr(player, '_scope_menu', None) is None:
        raise PreviewError('current Scene has no scoped menu')
    extra = {}
    if operation == 'input_snapshot':
        sources = held(player, params)
        player._scope_input_snapshot(sources, generation=params['focus_generation'])
    elif operation == 'audio_take':
        extra['audio_commands'] = list(player._scope_audio_take())
    elif operation == 'audio_stop_complete':
        player._scope_audio_complete_stop(params['audio_token'], success=params['success'])
    elif operation == 'menu_finish':
        sources = held(player, params)
        player._menu_finish(params['menu_token'], held_sources=sources)
    elif operation == 'menu_cancel':
        player._menu_cancel_transition(params['menu_token'])
    else:
        raise PreviewError('unsupported scope host operation')
    return dict(player.snapshot(), **extra)


def resume(player, params):
    require(player)
    sources = held(player, params)
    # Reject invalid snapshots or unacknowledged audio without resuming clocks.
    candidate = deepcopy(player)
    candidate.resume()
    candidate._scope_input_snapshot(sources, generation=params['focus_generation'])
    events = candidate.advance(0)
    player.__dict__.clear()
    player.__dict__.update(candidate.__dict__)
    return events


def require_stopped_before_replacement(player):
    if player is None or not any('_scope_source' in s for s in player._package.scenes):
        return
    audio = player._scope_audio
    if audio.pending_stop is not None or any(audio.may_be_playing.values()):
        raise ProtocolError('PREVIEW_AUDIO_STOP_REQUIRED',
            'suspend preview and acknowledge its audio stop before replacing or invalidating the session')
