"""Host-only Tiled snapshots and property edits; no runtime map capability."""
from copy import deepcopy
import json

from .image_assets import resolve_project_path, ImageAssetError
from .imported_properties import (
    ImportedPropertyError, PropertyDefinition, PropertyKey, effective_defaults, plan_reimport,
)

# Host parser resource guards, not hardware map/cache admission limits.
MAX_SOURCE_BYTES = 16 * 1024 * 1024
MAX_CELLS = 1024 * 1024
MAX_OBJECTS = 4096
COMMANDS = ("map.import", "map.reimport", "map.property.set", "map.property.clear", "map.delete")


def fail(message):
    raise ImportedPropertyError(message)


def integer(value, name, low=0, high=2**31 - 1):
    if type(value) is not int or not low <= value <= high:
        fail(f"{name} must be an integer in {low}..{high}")
    return value


def properties(asset_id, owner, record, result):
    if record.get("class") or record.get("propertytype"):
        fail("Custom class inheritance is not supported; use explicit primitive properties")
    entries = record.get("properties", [])
    if not isinstance(entries, list):
        fail("properties must be an array")
    for prop in entries:
        if not isinstance(prop, dict) or set(prop) != {"name", "type", "value"}:
            fail("Properties require explicit name, type and value; class properties are unsupported")
        name = prop["name"]
        if not isinstance(name, str) or not name or len(name) > 128:
            fail("Property names must contain 1..128 characters")
        key = PropertyKey(asset_id, owner, name)
        if key in result:
            fail("Duplicate property identity")
        kind = ({"bool": "bool", "int": "int32", "string": "string"}.get(prop["type"])
                if isinstance(prop["type"], str) else None)
        if kind is None:
            fail("Only explicit bool, int32 and static string properties are supported")
        if kind == "string" and (not isinstance(prop["value"], str) or len(prop["value"]) > 4096):
            fail("Static property text exceeds the host import bound")
        result[key] = (PropertyDefinition(kind, prop["value"], -(2**31), 2**31-1)
                       if kind == "int32" else PropertyDefinition(kind, prop["value"]))


def definitions(asset_id, data, *, native=False):
    """Validate the admitted source subset and return stable owner properties."""
    if not isinstance(data, dict) or data.get("type") != "map":
        fail("Expected a Tiled JSON map")
    if data.get("orientation") != "orthogonal" or data.get("infinite", False) is not False:
        fail("Only finite orthogonal maps are supported")
    if data.get("renderorder", "right-down") != "right-down":
        fail("Only right-down render order is supported")
    width = integer(data.get("width"), "width", 1, 65535)
    height = integer(data.get("height"), "height", 1, 65535)
    if width * height > MAX_CELLS:
        fail("Map exceeds the host cell bound")
    tw = integer(data.get("tilewidth"), "tilewidth", 1, 256)
    th = integer(data.get("tileheight"), "tileheight", 1, 256)
    result = {}
    properties(asset_id, "map", data, result)
    tilesets = data.get("tilesets")
    if not isinstance(tilesets, list) or not (0 if native else 1) <= len(tilesets) <= 128:
        fail("Map requires 1..128 embedded image tilesets")
    ranges = []
    for ts in tilesets:
        if not isinstance(ts, dict) or "source" in ts:
            fail("External tilesets are not supported in this increment; embed the tileset in Tiled")
        if ts.get("tilewidth") != tw or ts.get("tileheight") != th:
            fail("Tileset dimensions must match the map grid")
        start = integer(ts.get("firstgid"), "firstgid", 1, 0x0fffffff)
        count = integer(ts.get("tilecount"), "tilecount", 1, MAX_CELLS)
        if start + count > 0x10000000 or any(start < end and start + count > begin for begin, end in ranges):
            fail("Tileset GID ranges overlap or overflow")
        ranges.append((start, start + count))
        if not isinstance(ts.get("image"), str) or not ts["image"]:
            fail("Tileset requires an image path")
        # Tileset identities need an explicit source manifest before editable
        # tile properties can survive firstgid changes. Reject rather than guess.
        if ts.get("properties") or ts.get("tiles") or ts.get("class"):
            fail("Tileset/tile properties, animations and class defaults are not supported yet")
    layers = data.get("layers")
    if not isinstance(layers, list) or not 1 <= len(layers) <= 128:
        fail("Map requires 1..128 layers")
    layer_ids, object_ids = set(), set()
    cell_count = 0
    for layer in layers:
        if not isinstance(layer, dict):
            fail("Layer must be an object")
        lid = integer(layer.get("id"), "layer.id", 1)
        if lid in layer_ids:
            fail("Duplicate layer ID")
        layer_ids.add(lid)
        for field, default in (("offsetx", 0), ("offsety", 0), ("x", 0), ("y", 0),
                               ("parallaxx", 1), ("parallaxy", 1), ("opacity", 1)):
            if layer.get(field, default) != default:
                fail("Layer offsets, parallax and partial opacity are unsupported")
        if layer.get("tintcolor") or layer.get("mode", "normal") != "normal":
            fail("Layer tint/blending is unsupported")
        properties(asset_id, f"layer:{lid}", layer, result)
        if layer.get("type") == "tilelayer":
            cells = layer.get("data")
            if (layer.get("width") != width or layer.get("height") != height or
                    not isinstance(cells, list) or len(cells) != width * height or
                    layer.get("compression") or layer.get("encoding") not in (None, "csv")):
                fail("Tile layers require full-map uncompressed JSON cell arrays")
            cell_count += len(cells)
            if cell_count > MAX_CELLS:
                fail("Combined layers exceed the host cell bound")
            for gid in cells:
                integer(gid, "tile GID", 0, 0x0fffffff)
                if gid and not (native and layer.get("id") == 3 and gid == 1) and not any(begin <= gid < end for begin, end in ranges):
                    fail("Tile GID is outside the declared tilesets")
        elif layer.get("type") == "objectgroup":
            objects = layer.get("objects")
            if not isinstance(objects, list):
                fail("Object layer requires an objects array")
            for obj in objects:
                if not isinstance(obj, dict):
                    fail("Map object must be an object")
                oid = integer(obj.get("id"), "object.id", 1)
                if oid in object_ids:
                    fail("Duplicate map object ID")
                object_ids.add(oid)
                if len(object_ids) > MAX_OBJECTS:
                    fail("Map exceeds the host object bound")
                if any(key in obj for key in ("template", "gid", "polygon", "polyline", "text", "ellipse")):
                    fail("Only plain rectangle/point map objects are supported initially")
                if obj.get("rotation", 0) != 0 or obj.get("type"):
                    fail("Rotated objects and class defaults are not supported initially")
                for field in ("x", "y", "width", "height"):
                    value = obj.get(field, 0)
                    if type(value) not in (int, float) or not -(2**31) <= value < 2**31 or int(value) != value:
                        fail("Object geometry must be integral int32 coordinates")
                    if field in ("width", "height") and value < 0:
                        fail("Object dimensions cannot be negative")
                properties(asset_id, f"object:{oid}", obj, result)
        else:
            fail("Group/image layers are not supported initially")
    return result


def edit_map(record):
    edits = record.get("edits")
    if not isinstance(edits, list):
        fail("Map edits must be an array")
    result = {}
    for edit in edits:
        if not isinstance(edit, dict) or set(edit) != {"owner_id", "property_id", "value"}:
            fail("Invalid map property edit")
        key = PropertyKey(record["asset_id"], edit["owner_id"], edit["property_id"])
        if key in result:
            fail("Duplicate map property edit")
        if isinstance(edit["value"], str) and len(edit["value"]) > 4096:
            fail("Static property text exceeds the host import bound")
        result[key] = edit["value"]
    return result


def validate_record(record, root):
    if not isinstance(record, dict) or set(record) != ({"asset_id", "import_version", "source_path", "snapshot", "edits"} | ({"source_kind"} if record.get("source_kind") == "native" else set()) | ({"base_colour"} if 'base_colour' in record else set())):
        fail("Invalid imported-map record")
    if record.get('base_colour', 'white') not in ('white', 'black'):
        fail('map_assets.base_colour must be white or black')
    if record["import_version"] != 1 or type(record["import_version"]) is not int:
        fail("Unsupported map import version")
    try:
        source = resolve_project_path(root, record["source_path"], "map.source_path")
        defs = definitions(record["asset_id"], record["snapshot"], native=record.get("source_kind") == "native")
        # Snapshot is authoritative until explicit reimport; source need not exist.
        for ts in record["snapshot"]["tilesets"]:
            resolve_project_path(root, (source.parent.relative_to(root.resolve()) / ts["image"]).as_posix(), "tileset.image")
    except ImageAssetError as exc:
        fail(str(exc))
    return effective_defaults(defs, edit_map(record))


def read_snapshot(root, source_path):
    try:
        path = resolve_project_path(root, source_path, "map.source_path")
        with path.open("rb") as stream:
            raw = stream.read(MAX_SOURCE_BYTES + 1)
        if len(raw) > MAX_SOURCE_BYTES:
            fail("Tiled JSON exceeds the host input bound")
        def unique(pairs):
            obj = {}
            for key, value in pairs:
                if key in obj:
                    fail("Duplicate JSON key")
                obj[key] = value
            return obj
        return json.loads(raw, object_pairs_hook=unique,
                          parse_constant=lambda value: fail("Non-finite JSON number"))
    except (OSError, ValueError, RecursionError) as exc:
        raise ImportedPropertyError(f"Cannot import Tiled JSON: {exc}") from exc


def apply_command(root, catalogs, command):
    from .project import ProjectCommandError, _require_command_fields, _stable_id
    kind = command["kind"]
    required = {"kind", "asset_id"}
    if kind == "map.import":
        required.add("source_path")
    elif kind in ("map.property.set", "map.property.clear"):
        required |= {"owner_id", "property_id"}
        if kind == "map.property.set":
            required.add("value")
    _require_command_fields(command, required, required | {"command_id"})
    issues = []
    _stable_id(command["asset_id"], "command.asset_id", issues)
    if issues:
        raise ProjectCommandError(issues[0].code, issues[0].message)
    found = [(cat, rec) for cat in catalogs for rec in cat.get("map_assets", [])
             if rec["asset_id"] == command["asset_id"]]
    try:
        if kind == "map.import":
            if found or any(rec.get("asset_id") == command["asset_id"] for cat in catalogs
                            for rec in cat.get("assets", []) + cat.get("audio_assets", [])):
                fail("Asset ID already exists")
            record = dict(asset_id=command["asset_id"], import_version=1,
                          source_path=command["source_path"],
                          snapshot=read_snapshot(root, command["source_path"]), edits=[])
            validate_record(record, root)
            catalogs[0].setdefault("map_assets", []).append(record)
        else:
            if len(found) != 1:
                fail("Unknown map asset")
            catalog, record = found[0]
            if kind == "map.delete":
                catalog["map_assets"].remove(record)
            elif kind == "map.reimport":
                if record.get("source_kind") == "native":
                    fail("Native maps use map.paint; reimport requires an imported source")
                incoming = read_snapshot(root, record["source_path"])
                plan = plan_reimport(definitions(record["asset_id"], record["snapshot"]),
                                     definitions(record["asset_id"], incoming), edit_map(record))
                if plan.conflicts:
                    fail("Reimport conflicts: " + "; ".join(
                        f"{c.key.owner_id}/{c.key.property_id}: {c.reason}" for c in plan.conflicts))
                record["snapshot"] = incoming
                validate_record(record, root)
            else:
                key = PropertyKey(record["asset_id"], command["owner_id"], command["property_id"])
                defs = definitions(record["asset_id"], record["snapshot"])
                if key not in defs:
                    fail("Unknown map property")
                edits = edit_map(record)
                if kind == "map.property.set":
                    edits[key] = deepcopy(command["value"])
                else:
                    edits.pop(key, None)
                effective_defaults(defs, edits)
                record["edits"] = [dict(owner_id=k.owner_id, property_id=k.property_id, value=v)
                                   for k, v in sorted(edits.items())]
                validate_record(record, root)
    except ImportedPropertyError as exc:
        raise ProjectCommandError("MAP_IMPORT_INVALID", str(exc)) from exc
    return {"kind": kind, "asset_id": command["asset_id"]}


def build_issues(bundle):
    if any(cat.get("map_assets") for cat in bundle.asset_catalogs):
        return [{"code": "TILEMAP_RUNTIME_UNAVAILABLE", "path": "map_assets",
                 "message": "Imported maps support explicitly bound map Scene preview; public device export remains unavailable."}]
    return []
