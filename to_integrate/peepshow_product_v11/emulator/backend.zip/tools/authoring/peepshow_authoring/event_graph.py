"""Conservative immediate-send cycle detection on addressed event handlers."""


def find_cycle(edges):
    """Return one closed address path, without recursion or guard evaluation."""
    pending = set(edges)
    while pending:
        leaves = {address for address in pending if not (edges[address] & pending)}
        if not leaves:
            break
        pending -= leaves
    if not pending:
        return ()
    path, positions = [], {}
    address = min(pending, key=repr)
    while address not in positions:
        positions[address] = len(path)
        path.append(address)
        address = min(edges[address] & pending, key=repr)
    return tuple(path[positions[address]:] + [address])
