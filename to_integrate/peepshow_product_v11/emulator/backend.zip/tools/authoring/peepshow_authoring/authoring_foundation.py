"""Incremental source admission; execution still uses the existing strict pipeline."""
from copy import deepcopy
from dataclasses import replace
from functools import lru_cache
import json
from pathlib import Path
from .protocol import MAX_REQUEST_BYTES
from .map_colour import CAPABILITY as MAP_COLOUR_CAPABILITY

MODE = 'incremental_v1'
COMMANDS = ('scene.map.attach', 'scene.map.detach', 'scene.entity.add',
    'scene.entity.set', 'scene.entity.remove', 'scene.machine.set',
    'scene.machine.remove', 'scene.machine.set_entry')
MAP_COMMANDS = ('map.create', 'map.paint', 'map.tilesets.set', 'map.update', 'map.base_colour.set')
VISIBILITY_COMMANDS = ('scene.visibility.group.set', 'scene.visibility.group.remove')
CAPABILITY = dict(version=1, create_parameter='authoring_mode', create_value=MODE,
    state_editing=dict(commands=['state.set_entry','state.delete'], nullable_scene_entry=True,
        delete_last_state=True, delete_entry_state=True, replacement_policy='none',
        machine_membership_removed=True, affected_entries_cleared=True,
        other_references='preserved_with_execution_issues', legacy_projects_unchanged=True,
        execution_contract_overrides={'machine_startup_v1': dict(scene_entry_used=False,
            entry_command='scene.machine.set_entry', nullable_machine_entry=True)}),
    map_base_colour=MAP_COLOUR_CAPABILITY,
    empty_project_parameter='create_initial_scene', commands=list(COMMANDS + MAP_COMMANDS),
    position_units='world_grid_cells', runtime_coordinate_units='pixels',
    generated_position_references='<entity_id>.x and <entity_id>.y',
    occupancy_and_camera_targets='entity_id', native_layers=dict(background=1,details=2,collision=3),
    native_collision_values=[0,1], visibility_controls=['world','layers','groups'], incomplete_preview=False,
    native_map_update=dict(command='map.update', native_only=True,
        command_schema='schemas/authoring/incremental-commands-v1.schema.json',
        fields=['asset_id', 'width', 'height', 'layers'], layer_fields=['layer_id', 'data'],
        complete_tile_layers_required=True, data_order='row_major', empty_cell=0,
        dimensions_min=1, dimensions_max=65535, max_combined_cells=1048576,
        max_request_bytes=MAX_REQUEST_BYTES,
        collision_layer_id=3, collision_values=[0, 1], tile_dimensions_editable=False,
        resize_policy='preserve_coordinates_empty_expansion_reject_painted_crop',
        same_size_data_replacement=True, scene_content_unchanged=True,
        affected_references='execution_issues_and_build_issues',
        persistence='session_until_project.save', undo_redo=True),
    execution_policy='existing_public_preview_and_export_readiness',
    hardware_validation='new_source_workflow_not_hardware_tested',
    unavailable_command_prefixes=[],
    actor_editing=dict(entity_storage='world.entities', target_bindings='entity_id',
        commands='existing_actor_and_template_commands', complete_setup_required=True,
        incomplete_error='ACTOR_ASSEMBLY_INCOMPLETE', templates_require_explicit_bindings=True,
        visual_bindings_field='world.entities[].visual_bindings',
        group_membership_on_duplicate='explicit_edit_required',
        reference_schema='schemas/authoring/incremental-world-reference-v1.schema.json',
        declarations_schema='schemas/authoring/incremental-world-declarations-v1.schema.json',
        instance_schema='schemas/authoring/incremental-instances-v1.schema.json'),
    visibility_groups=dict(field='world.map.visibility.groups', members='entity_id',
        commands=list(VISIBILITY_COMMANDS), command_schema='schemas/authoring/incremental-commands-v1.schema.json',
        empty_groups_saveable=True, unresolved_members_saveable=True, requires_machine=False),
    scene_field='world', entity_field='world.entities', machine_optional=True,
    schemas={name: 'schemas/authoring/incremental-' + name + '-v1.schema.json'
        for name in ('project', 'scene', 'machine', 'world', 'commands')},
    structural_validity='issues', execution_readiness='execution_issues',
    save_requires='structural_validity', save_operation='project.save',
    discard_operation='project.load', persistence='explicit_save', undo_redo=True,
    imported_object_layer_required=False, runtime_writer_required_for_placement=False,
    machine_delete='remove_owned_handlers_and_states_preserve_external_references',
    map_detach='preserve_entities_assets_and_bindings',
    map_delete='remove_asset_keep_unresolved_scene_references',
    legacy_conversion='not_implicit', resource_admission='existing_strict_pipeline')


def enabled(value):
    project = value.project if hasattr(value, 'project') else value
    return project.get('authoring_mode') == MODE


def unavailable_command(kind):
    return isinstance(kind, str) and kind.startswith(tuple(CAPABILITY['unavailable_command_prefixes']))


@lru_cache(maxsize=1)
def schemas():
    from referencing import Registry, Resource
    from jsonschema import Draft202012Validator
    folder = Path(__file__).resolve().parents[3] / 'schemas/authoring'
    docs = {p.name: json.loads(p.read_text(encoding='utf-8')) for p in folder.glob('*.schema.json')}
    project = docs['incremental-project-v1.schema.json']
    scene = docs['incremental-scene-v1.schema.json']
    registry = Registry()
    for name, doc in docs.items():
        resource = Resource.from_contents(doc)
        registry = registry.with_resource('https://peepshow.dev/schema/authoring/' + name, resource)
        registry = registry.with_resource((folder / name).as_uri(), resource)
        if '$id' in doc:
            registry = registry.with_resource(doc['$id'], resource)
    return (Draft202012Validator(project, registry=registry),
            Draft202012Validator(scene, registry=registry),
            Draft202012Validator(docs['incremental-commands-v1.schema.json'], registry=registry))


def check_command(command):
    from .project import ProjectCommandError
    errors = list(schemas()[2].iter_errors(command))
    if errors:
        # Show the matching command's shape, not all alternatives in oneOf.
        shape = next((s for s in schemas()[2].schema['oneOf'] if s['properties']['kind']['const'] == command.get('kind')), None)
        if shape is not None:
            errors = list(schemas()[2].evolve(schema=shape).iter_errors(command))
        error = errors[0]
        where = 'command' + ''.join(f'[{p}]' if isinstance(p,int) else '.'+p for p in error.absolute_path)
        raise ProjectCommandError('COMMAND_SHAPE_INVALID', where+': '+error.message)


def structural(value, validator, path, issues):
    from .project import ValidationIssue
    try:
        json.dumps(value, allow_nan=False)
    except (ValueError, TypeError) as exc:
        issues.append(ValidationIssue('AUTHORING_STRUCTURE_INVALID', path, str(exc)))
        return
    for error in validator.iter_errors(value):
        where = path + ''.join(f'[{part}]' if isinstance(part, int) else '.' + part for part in error.absolute_path)
        issues.append(ValidationIssue('AUTHORING_STRUCTURE_INVALID', where, error.message))
    # Schema checks shapes. Identity collisions are not unfinished references.
    pending = [(value, path)]
    identity_keys = ('scene_id', 'object_id', 'state_id', 'machine_id', 'route_id',
                     'event_id', 'entity_id', 'reference_id', 'variable_id', 'node_id',
                     'flowchart_id', 'action_id', 'handler_id', 'binding_id', 'page_id', 'entry_id', 'group_id')
    while pending:
        row, where = pending.pop()
        if isinstance(row, dict):
            pending.extend((v, where + '.' + k) for k, v in row.items())
        elif isinstance(row, list):
            keys = identity_keys + (('name',) if where.endswith('.properties') else ())
            if where == 'project.actor_templates.placements':
                # A Scene can contain many placements; the identity is the pair.
                keys = tuple(k for k in keys if k != 'scene_id')
            for key in keys:
                found = set()
                for i, item in enumerate(row):
                    if isinstance(item, dict) and isinstance(item.get(key), str):
                        if item[key] in found:
                            issues.append(ValidationIssue('AUTHORING_ID_DUPLICATE', f'{where}[{i}].{key}', 'Duplicate identity'))
                        found.add(item[key])
            pending.extend((v, f'{where}[{i}]') for i, v in enumerate(row))


def check_project(project, issues):
    structural(project, schemas()[0], 'project', issues)


def check_scene(scene, path, issues):
    structural(scene, schemas()[1], path, issues)


def finish(bundle):
    from .project import ValidationIssue
    issues = list(bundle.issues)
    if issues:
        return bundle
    ids = [s['scene_id'] for s in bundle.scenes]
    if len(ids) != len(set(ids)):
        issues.append(ValidationIssue('AUTHORING_ID_DUPLICATE', 'scenes', 'Duplicate Scene identity'))
    for scene in bundle.scenes:
        entities = scene.get('world', {}).get('entities', [])
        ids = [e['local_id'] for e in entities]
        if len(ids) != len(set(ids)):
            issues.append(ValidationIssue('AUTHORING_ID_DUPLICATE', f"scenes[{scene['scene_id']}].world.entities", 'Duplicate local entity identity'))
    placements = bundle.project.get('actor_templates', {}).get('placements', [])
    keys = [(p['scene_id'],p['instance_ref']) for p in placements]
    if len(keys) != len(set(keys)):
        issues.append(ValidationIssue('AUTHORING_ID_DUPLICATE', 'project.actor_templates.placements', 'Duplicate Scene/instance template link'))
    return replace(bundle, issues=tuple(issues))


def empty_scene(scene):
    scene['entry_state'] = None
    scene['states'] = []
    scene['world'] = dict(version=1, map=None, entities=[])
    return scene


def graph(scene):
    return scene.setdefault('machine_logic', dict(model='scene_machines_v1', seed=1,
        machines=[], events=[], input_receivers={}, timer_receivers={}, routes=[]))


def apply(scenes, command, catalogs=()):
    from .project import _require_command_fields, _command_scene, ProjectCommandError
    kind = command['kind']
    if kind == 'scene.machine.set_entry':
        from .machine_startup import set_entry
        return set_entry(scenes, command)
    extra = {'scene.map.attach': {'map'}, 'scene.map.detach': set(),
        'scene.entity.add': {'entity_id', 'display_name', 'position'},
        'scene.entity.set': {'entity_id', 'changes'}, 'scene.entity.remove': {'entity_id'},
        'scene.machine.set': {'machine'}, 'scene.machine.remove': {'machine_id'}}[kind]
    required = {'kind', 'scene_id'} | extra
    _require_command_fields(command, required, required | {'command_id'})
    scene = _command_scene(scenes, command['scene_id'])
    world = scene.setdefault('world', dict(version=1, map=None, entities=[]))
    if kind == 'scene.map.attach':
        world['map'] = deepcopy(command['map'])
    elif kind == 'scene.map.detach':
        world['map'] = None
    elif kind == 'scene.entity.add':
        used = {e['local_id'] for e in world['entities']}
        spec = world.get('map') or {}
        for catalog in catalogs:
            for record in catalog.get('map_assets', []):
                if record['asset_id'] == spec.get('asset_ref'):
                    used.update(o['id'] for layer in record['snapshot']['layers']
                        if layer['type'] == 'objectgroup' for o in layer['objects'])
        local_id = next(i for i in range(1, 65536) if i not in used)
        world['entities'].append(dict(entity_id=command['entity_id'], local_id=local_id,
            display_name=command['display_name'], position=deepcopy(command['position']),
            visual_ref=None, position_writer=None, properties=[]))
    elif kind in ('scene.entity.set', 'scene.entity.remove'):
        entity = next((e for e in world['entities'] if e['entity_id'] == command['entity_id']), None)
        if entity is None:
            raise ProjectCommandError('COMMAND_TARGET_UNKNOWN', 'Unknown Scene entity')
        if kind.endswith('.remove'):
            world['entities'].remove(entity)
        else:
            changes = command['changes']
            if type(changes) is not dict or not changes or changes.keys() - {'display_name', 'position', 'visual_ref', 'position_writer', 'properties', 'local_id', 'visual_bindings'}:
                raise ProjectCommandError('COMMAND_SHAPE_INVALID', 'Unsupported entity change')
            entity.update(deepcopy(changes))
    elif kind == 'scene.machine.set':
        machine = deepcopy(command['machine'])
        if type(machine) is not dict or not isinstance(machine.get('machine_id'), str):
            raise ProjectCommandError('COMMAND_SHAPE_INVALID', 'machine requires machine_id')
        rows = graph(scene)['machines']
        rows[:] = [m for m in rows if m['machine_id'] != machine['machine_id']] + [machine]
    else:
        g = graph(scene)
        machine = next((m for m in g['machines'] if m['machine_id'] == command['machine_id']), None)
        if machine is None:
            raise ProjectCommandError('COMMAND_TARGET_UNKNOWN', 'Unknown machine')
        other_states = {state for m in g['machines'] if m is not machine for state in m['states']}
        owned = set(machine['states']) - other_states
        g.get('layout', {}).pop(command['machine_id'], None)
        g['machines'].remove(machine)
        g['routes'] = [r for r in g['routes'] if r.get('machine_ref') != command['machine_id']]
        scene['states'] = [s for s in scene['states'] if s['state_id'] not in owned]
        if scene['entry_state'] in owned:
            scene['entry_state'] = None
        # Other sends, input bindings, owners and entity bindings remain repairable.
    return deepcopy(command)


def project_for_execution(bundle, *, _terminal=True, _debug_calls=None):
    """Produce a private execution view; never save generated object-layer plumbing."""
    from .project import ValidationIssue
    from .entity_editing import remap, names, template_bindings
    from .machine_startup import enabled as startup_enabled, prepare
    if startup_enabled(bundle):
        bundle = prepare(bundle)
    from .behavior_library import prepare as prepare_behaviors
    bundle = prepare_behaviors(bundle)
    from .flow_library import prepare as prepare_library
    bundle = prepare_library(bundle)
    from .shared_triggers import prepare as prepare_triggers
    bundle = prepare_triggers(bundle)
    from .callable_flows import prepare as prepare_calls
    bundle = prepare_calls(bundle, debug_calls=_debug_calls)
    project = deepcopy(bundle.project)
    project.pop('authoring_mode', None)
    template_bindings(project, bundle.scenes)
    scenes = deepcopy(list(bundle.scenes))
    catalogs = deepcopy(list(bundle.asset_catalogs))
    issues = list(bundle.issues)
    def problem(code, path, message):
        issues.append(ValidationIssue(code, path, message))
    maps = {r['asset_id']: r for cat in catalogs for r in cat.get('map_assets', [])}
    if not scenes:
        problem('AUTHORING_SCENE_REQUIRED', 'project.scene_sources', 'Add a Scene before Run/build')
    if project.get('entry_scene') not in {s['scene_id'] for s in scenes}:
        problem('AUTHORING_ENTRY_REQUIRED', 'project.entry_scene', 'Choose an existing entry Scene')
    # Local placements are materialized per Scene; package map snapshots remain shared.
    for scene in scenes:
        path = f"scenes[{scene['scene_id']}]"
        world = scene.pop('world', None)
        needs_machine = bool(world and world['map'] is not None) or 'machine_logic' in scene
        if needs_machine and not scene.get('machine_logic', {}).get('machines'):
            problem('AUTHORING_MACHINE_REQUIRED', path + '.machine_logic.machines', 'The current map/machine execution profile requires a configured machine; source editing does not')
        if not world:
            continue
        spec = world['map']
        if spec is None:
            if world['entities']:
                problem('AUTHORING_MAP_REQUIRED', path + '.world.map', 'Attach a map for these world entities')
            continue
        record = maps.get(spec['asset_ref'])
        if record is None:
            problem('AUTHORING_REFERENCE_UNRESOLVED', path + '.world.map.asset_ref', 'Map asset is missing')
            continue
        source = deepcopy(spec)
        snapshot = record['snapshot']
        if not snapshot['tilesets']:
            problem('AUTHORING_TILESET_REQUIRED', f'assets.maps[{record["asset_id"]}].tilesets', 'Assign tile artwork before map execution')
        # Existing runtime identity remains asset + entity. Choose explicit local IDs;
        # an imported object layer is optional and is never modified in saved source.
        local_ids = {e['local_id'] for e in world['entities']}
        imported_ids = {o['id'] for l in snapshot['layers'] if l['type'] == 'objectgroup' for o in l['objects']}
        if local_ids & imported_ids:
            problem('AUTHORING_ENTITY_CONFLICT', path + '.world.entities', 'Scene local identity conflicts with an imported object; explicitly reassign it')
        layer_id = max((l['id'] for l in snapshot['layers']), default=0) + 1
        # Materialization is per Scene via map_scene.local_entities; empty layer shared safely.
        existing = next((l for l in snapshot['layers'] if l.get('_authoring_execution')), None)
        if existing is not None:
            layer_id = existing['id']
        else:
            snapshot['layers'].append(dict(id=layer_id, name='Scene entities', type='objectgroup', objects=[], _authoring_execution=True))
        source.update(version=1, object_layer=layer_id, local_entities=[])
        g = graph(scene)
        if any(k in g for k in ('map_scene', 'world_positions')):
            problem('AUTHORING_COMPONENT_CONFLICT', path + '.machine_logic', 'Map/positions belong to Scene world in incremental source')
        positions = []
        entity_names = set(names(dict(world=world)))
        for ri, ref in enumerate(g.get('world_references', [])):
            owner = ref['target']['owner_id']
            if owner != 'map' and not owner.startswith('layer:') and owner not in entity_names:
                problem('AUTHORING_REFERENCE_UNRESOLVED', path+f'.machine_logic.world_references[{ri}].target.owner_id', 'World reference entity is missing')
        for ii, instance in enumerate(g.get('instance_behaviors', {}).get('instances', [])):
            for field in ('entity', 'target'):
                target = instance.get(field)
                if target is not None and target['owner_id'] not in entity_names:
                    problem('AUTHORING_REFERENCE_UNRESOLVED', path+f'.machine_logic.instance_behaviors.instances[{ii}].{field}.owner_id', 'Behavior entity binding is missing')
        g.update(remap(g, names(dict(world=world))))
        refs = g.setdefault('world_references', [])
        visuals = {o['object_id']: o for o in scene.get('objects', [])}
        machines = {m['machine_id'] for m in g['machines']}
        for entity in world['entities']:
            ep = path + f".world.entities[{entity['entity_id']}]"
            pos = entity['position']
            if not 0 <= pos['x']*spec['cell_width'] < snapshot['width']*snapshot['tilewidth'] or not 0 <= pos['y']*spec['cell_height'] < snapshot['height']*snapshot['tileheight']:
                problem('AUTHORING_POSITION_OUTSIDE_MAP', ep + '.position', 'Initial cell is outside the attached map')
            writer = entity['position_writer']
            if writer is not None and writer not in machines:
                problem('AUTHORING_REFERENCE_UNRESOLVED', ep + '.position_writer', 'Position writer machine is missing')
            owner = f"object:{entity['local_id']}"
            source['local_entities'].append(dict(id=entity['local_id'], name=entity['display_name'],
                x=pos['x']*spec['cell_width'], y=pos['y']*spec['cell_height'],
                width=spec['cell_width'], height=spec['cell_height'], properties=deepcopy(entity['properties'])))
            for axis in ('x', 'y'):
                ref = dict(reference_id=entity['entity_id'] + '.' + axis,
                    target=dict(asset_id=spec['asset_ref'], field='entity_' + axis, owner_id=owner, value_type='int32'))
                if writer is not None:
                    ref['writer'] = dict(kind='machine', id=writer)
                existing_ref = next((r for r in refs if r['target'].get('owner_id') == owner and r['target']['field'] == 'entity_' + axis), None)
                if existing_ref is None:
                    refs.append(ref)
                elif writer is not None and existing_ref.get('writer') != ref.get('writer'):
                    problem('AUTHORING_WRITER_CONFLICT', ep+'.position_writer', 'Position writer conflicts with the explicit coordinate reference')
            visual = entity['visual_ref']
            if visual is not None:
                if visual not in visuals:
                    problem('AUTHORING_REFERENCE_UNRESOLVED', ep + '.visual_ref', 'Visual object is missing')
                else:
                    positions.append(dict(object_ref=visual, asset_id=spec['asset_ref'], entity_ref=owner, offset_x=0, offset_y=0))
            for index, binding in enumerate(entity.get('visual_bindings', [])):
                if binding['object_ref'] not in visuals:
                    problem('AUTHORING_REFERENCE_UNRESOLVED', ep+f'.visual_bindings[{index}].object_ref', 'Visual object is missing')
                positions.append(dict(binding, asset_id=spec['asset_ref'], entity_ref=owner))
        entity_lookup = {e['entity_id']: e for e in world['entities']}
        source['occupancy'] = []
        for index, row in enumerate(spec['occupancy']):
            entity = entity_lookup.get(row['entity_ref'])
            if entity is None:
                problem('AUTHORING_REFERENCE_UNRESOLVED', path + f'.world.map.occupancy[{index}].entity_ref', 'Occupancy entity is missing')
                continue
            owner = f"object:{entity['local_id']}"
            item = dict(entity_ref=owner, **{axis+'_ref':next(r['reference_id'] for r in refs
                if r['target'].get('owner_id') == owner and r['target']['field'] == 'entity_'+axis) for axis in ('x','y')})
            if 'solid_when' in row:
                item['solid_when'] = deepcopy(row['solid_when'])
            source['occupancy'].append(item)
        if source['camera']['mode'] == 'follow':
            target = entity_lookup.get(source['camera'].get('target_ref'))
            if target is None:
                problem('AUTHORING_REFERENCE_UNRESOLVED', path+'.world.map.camera.target_ref', 'Camera target entity is missing')
            else:
                source['camera']['target_ref'] = f"object:{target['local_id']}"
        for gi, group in enumerate(source.get('visibility', {}).get('groups', [])):
            if not group['members']:
                problem('AUTHORING_GROUP_EMPTY', path+f'.world.map.visibility.groups[{gi}].members', 'Choose at least one visible actor before execution')
            for mi, member in enumerate(group['members']):
                entity = entity_lookup.get(member['entity_ref'])
                mp = path+f'.world.map.visibility.groups[{gi}].members[{mi}].entity_ref'
                if entity is None:
                    problem('AUTHORING_REFERENCE_UNRESOLVED', mp, 'Visibility group entity is missing')
                else:
                    member['entity_ref'] = f"object:{entity['local_id']}"
                    if not any(p['entity_ref'] == member['entity_ref'] for p in positions):
                        problem('AUTHORING_VISUAL_REQUIRED', mp, 'Bind artwork to this entity before executing its visibility group')
        g['map_scene'] = source
        g['world_positions'] = positions
    prepared = replace(bundle, project=project, scenes=tuple(scenes), asset_catalogs=tuple(catalogs), issues=tuple(issues))
    from .terminal_order import enabled as terminal_enabled, lower_scene, proof_bundle
    if _terminal and terminal_enabled(bundle) and not issues:
        try:
            proof = proof_bundle(prepared)
            from .scene_machines import validate
            from .instance_project import validate_bundle
            for scene in proof.scenes:
                validate(proof.project, scene)
            proof = validate_bundle(proof)
            if proof.issues:
                return replace(prepared, issues=proof.issues)
            prepared = replace(prepared, scenes=tuple(lower_scene(s, project)[0] for s in scenes))
        except ValueError as exc:
            return replace(prepared, issues=(ValidationIssue('TERMINAL_ORDER_UNAVAILABLE', 'scenes', str(exc)),))
    return prepared


def execution_issues(bundle):
    if not enabled(bundle) or not bundle.valid:
        return []
    from .project import _check_scene, _check_project, ValidationIssue
    from .instance_project import validate_bundle
    from .world_reference_project import check_project
    projected = project_for_execution(bundle)
    issues = list(projected.issues)
    retained_count = len(issues)
    from .draft_states import issues as state_issues
    from .machine_startup import enabled as startup_enabled
    for scene in (projected.scenes if startup_enabled(bundle) else bundle.scenes):
        issues.extend(state_issues(scene, require_scene_entry=not startup_enabled(bundle)))
    if not issues:
        try:
            _check_project(projected.project, issues)
            from .actor_templates import validate as validate_actor_templates
            validate_actor_templates(projected.project, projected.scenes, projected.asset_catalogs,
                frames={f.frame_id for f in bundle.frames}, animations={a['animation_id'] for a in bundle.animations},
                audio={a['cue_id'] for a in bundle.audio_cues})
            for s in projected.scenes:
                _check_scene(s, s['scene_id'], {f.frame_id:f for f in bundle.frames},
                    {a['animation_id'] for a in bundle.animations}, {a['cue_id'] for a in bundle.audio_cues},
                    issues, {a['animation_id']:a for a in bundle.animations}, variable_project=projected.project)
            check_project(projected.scenes, projected.asset_catalogs, issues)
            if not issues:
                issues.extend(validate_bundle(projected).issues)
        except (ValueError, KeyError, TypeError, AttributeError, IndexError, StopIteration) as exc:
            issues.append(ValidationIssue('AUTHORING_EXECUTION_INCOMPLETE', 'scenes', str(exc)))
    if startup_enabled(bundle):
        from .machine_startup import authored_paths
        issues = issues[:retained_count] + authored_paths(bundle, projected, issues[retained_count:])
    return [dict(code=i.code, path=i.path, message=i.message) for i in issues]


def executable(bundle):
    if not enabled(bundle):
        return bundle
    from .compiler import EggCompileError
    issues = execution_issues(bundle)
    if issues:
        raise EggCompileError('; '.join(i['path'] + ': ' + i['message'] for i in issues))
    return project_for_execution(bundle)
