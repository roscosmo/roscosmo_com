"""Explicit project links and independent copies of typed callable flows."""
from copy import deepcopy
from dataclasses import replace

COMMANDS = ('project.flowchart.set','project.flowchart.remove','scene.flowchart.link',
            'scene.flowchart.unlink','scene.flowchart.make_independent')
CAPABILITY = dict(project_field='flowchart_definitions', graph_field='flowchart_links',
    commands=list(COMMANDS), schema='schemas/authoring/flow-library-v1.schema.json',
    command_schema='schemas/authoring/flow-library-command-v1.schema.json',
    definition_schema='schemas/authoring/callable-flow-v1.schema.json',
    maximum_project_definitions=64, maximum_links_per_graph=16,
    contexts=['ordinary_machine','shared_behavior'], nested_dependencies='project_definition_namespace',
    external_references='explicit_parameters_only', link_edits='propagate_on_next_preview_preparation',
    independent_copy='root_and_transitive_dependencies_with_same_local_alias',
    overrides=False, implicit_detach=False, missing_definition='authored_execution_diagnostic',
    readiness_scope='participating_call_dependencies',
    definition_kinds=['typed_flowcharts'], persistence='explicit_save', undo_redo=True, host_preview=True, runtime=False, export=False)


class LibraryError(ValueError):
    def __init__(self,path,message):
        super().__init__(message);self.path=path


def materialize(graph, definitions, links, path, *, copy_mode=False):
    """Resolve closure privately. Nothing is written back unless copy was requested."""
    existing={f['flowchart_id'] for f in graph.get('flowcharts',[])}
    aliases=[link['flowchart_id'] for link in graph.get('flowchart_links',[])]
    if len(set(aliases))!=len(aliases) or existing & set(aliases):
        raise LibraryError(path+'.flowchart_links','Local definitions and links must have distinct identities')
    used=existing|set(aliases)
    result=[]
    serial=0
    def allocate():
        nonlocal serial
        while True:
            serial+=1;name=('copy.' if copy_mode else 'linked.')+str(serial)
            if name not in used:
                used.add(name);return name
    def captures(value,where):
        if isinstance(value,list):
            for i,child in enumerate(value):captures(child,where+'['+str(i)+']')
        elif isinstance(value,dict):
            for key,child in value.items():
                if key in ('layout','label','display_name'):
                    continue
                if key in ('variable_ref','variable_scope','object_ref','reference_ref','property_ref',
                           'destination_ref','entity_ref','machine_ref','instance_ref','event_ref','state_ref'):
                    if not isinstance(child,dict) or 'parameter_ref' not in child:
                        raise LibraryError(where+'.'+key,'Project helpers require explicit parameter bindings, not captured Scene references')
                captures(child,where+'.'+key)
    for link in links:
        mapping={link['definition_ref']:link['flowchart_id']};active=set();done=set()
        def visit(ref):
            at=path+'.flowchart_links['+link['flowchart_id']+'] -> project.flowchart_definitions['+ref+']'
            if ref in active:
                raise LibraryError(at,'Recursive project helper dependency')
            if ref in done:return
            if ref not in definitions:
                raise LibraryError(at,'Missing project flow definition; link and calls are preserved')
            if len(active)>=4:
                raise LibraryError(at,'Project helper nesting exceeds four')
            definition=deepcopy(definitions[ref])
            if 'parameters' not in definition or 'outputs' not in definition:
                raise LibraryError(at,'Only typed callable definitions may be linked')
            captures(definition['nodes'],at+'.nodes')
            active.add(ref)
            for node in definition['nodes']:
                if node.get('kind')=='call':
                    dependency=node['flowchart_ref']
                    if dependency not in mapping:mapping[dependency]=allocate()
                    visit(dependency);node['flowchart_ref']=mapping[dependency]
            active.remove(ref);done.add(ref)
            definition['flowchart_id']=mapping[ref];result.append(definition)
            if len(result)+len(existing)>16:
                raise LibraryError(at,'Linked/local callable closure exceeds sixteen definitions')
        visit(link['definition_ref'])
    return result


def prepare(bundle):
    from .project import ValidationIssue
    scenes=deepcopy(bundle.scenes);issues=list(bundle.issues)
    rows=bundle.project.get('flowchart_definitions',[])
    definitions={f['flowchart_id']:f for f in rows}
    if len(definitions)!=len(rows):
        issues.append(ValidationIssue('FLOW_LIBRARY_INVALID','project.flowchart_definitions','Duplicate project flow identity'))
    for scene in scenes:
        graph=scene.get('machine_logic',{})
        graphs=[(graph,'scenes['+scene['scene_id']+'].machine_logic')]
        graphs += [(b['machine_logic'],graphs[0][1]+'.instance_behaviors.behaviors['+b['behavior_id']+'].machine_logic')
                   for b in graph.get('instance_behaviors',{}).get('behaviors',[])]
        for graph,path in graphs:
            links=graph.get('flowchart_links',[])
            if not links:graph.pop('flowchart_links',None);continue
            try:
                if bundle.project.get('execution_semantics')!='terminal_order_v1':
                    raise LibraryError(path+'.flowchart_links','Project links require terminal_order_v1')
                wanted=set()
                def calls(value):
                    if isinstance(value,dict):
                        if value.get('kind')=='call':wanted.add(value.get('flowchart_ref'))
                        for child in value.values():calls(child)
                    elif isinstance(value,list):
                        for child in value:calls(child)
                calls(graph.get('routes',[]));calls(graph.get('flowcharts',[]))
                imported=materialize(graph,definitions,[link for link in links if link['flowchart_id'] in wanted],path)
                graph.setdefault('flowcharts',[]).extend(imported)
                graph.pop('flowchart_links')
            except (LibraryError,KeyError,TypeError) as exc:
                issues.append(ValidationIssue('FLOW_LIBRARY_INVALID',getattr(exc,'path',path),str(exc)))
    project=deepcopy(bundle.project);project.pop('flowchart_definitions',None)
    return replace(bundle,project=project,scenes=tuple(scenes),issues=tuple(issues))


def apply(project,scenes,command):
    from .project import ProjectCommandError,_command_scene
    from .authoring_foundation import schemas
    # Use the same registry as other public authoring commands.
    validator=schemas()[2].evolve(schema={'$ref':'https://peepshow.dev/schema/authoring/flow-library-command-v1.schema.json'})
    errors=list(validator.iter_errors(command))
    if errors:raise ProjectCommandError('FLOW_LIBRARY_COMMAND_INVALID',errors[0].message)
    if project.get('execution_semantics')!='terminal_order_v1':
        raise ProjectCommandError('EXECUTION_SEMANTICS_MIGRATION_REQUIRED','Project flow editing requires terminal_order_v1; no implicit conversion')
    kind=command['kind'];rows=project.get('flowchart_definitions',[])
    if kind.startswith('project.'):
        ref=command.get('definition',{}).get('flowchart_id',command.get('definition_ref'))
        index=next((i for i,f in enumerate(rows) if f['flowchart_id']==ref),None)
        if kind=='project.flowchart.set':
            rows=deepcopy(rows)
            if index is None:rows.append(deepcopy(command['definition']))
            else:rows[index]=deepcopy(command['definition'])
            project['flowchart_definitions']=rows
        else:
            if index is None:raise ProjectCommandError('COMMAND_TARGET_UNKNOWN','Unknown project definition')
            project['flowchart_definitions']=[f for f in rows if f['flowchart_id']!=ref]
        return deepcopy(command)
    scene=_command_scene(scenes,command['scene_id']);graph=scene.get('machine_logic')
    if 'behavior_ref' in command:
        behavior=next((b for b in (graph or {}).get('instance_behaviors',{}).get('behaviors',[]) if b['behavior_id']==command['behavior_ref']),None)
        graph=behavior['machine_logic'] if behavior else None
    if graph is None:raise ProjectCommandError('COMMAND_TARGET_UNKNOWN','Unknown machine graph')
    ref=command['flowchart_id'];links=graph.get('flowchart_links',[])
    index=next((i for i,l in enumerate(links) if l['flowchart_id']==ref),None)
    if kind=='scene.flowchart.link':
        if any(f['flowchart_id']==ref for f in graph.get('flowcharts',[])):
            raise ProjectCommandError('FLOW_LIBRARY_COLLISION','A local definition already owns this identity')
        links=deepcopy(links);link=dict(flowchart_id=ref,definition_ref=command['definition_ref'])
        if index is None:links.append(link)
        else:links[index]=link
        graph['flowchart_links']=links
    else:
        if index is None:raise ProjectCommandError('COMMAND_TARGET_UNKNOWN','Unknown flow link')
        if kind=='scene.flowchart.make_independent':
            try:copies=materialize(graph,{f['flowchart_id']:f for f in rows},[links[index]],'scenes['+command['scene_id']+']',copy_mode=True)
            except (LibraryError, KeyError, TypeError) as exc:
                raise ProjectCommandError('FLOW_LIBRARY_COPY_INVALID',
                    getattr(exc, 'path', 'scenes['+command['scene_id']+'].machine_logic.flowchart_links['+ref+']')+': '+str(exc)) from exc
            graph.setdefault('flowcharts',[]).extend(copies)
        graph['flowchart_links']=[l for l in links if l['flowchart_id']!=ref]
        if not graph['flowchart_links']:graph.pop('flowchart_links')
    return deepcopy(command)
