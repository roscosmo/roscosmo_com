"""Pure preview timeline mirrored by ps_object_effect; not a public action yet."""
from dataclasses import dataclass

U32_MAX = (1 << 32) - 1
OK, ARGUMENT, EXHAUSTED, EMPTY, STALE = range(5)
IDLE, RUNNING, COMPLETE = range(3)
INVERT, SHAKE = 1, 2


def unsigned(value, maximum=U32_MAX):
    return type(value) is int and 0 <= value <= maximum


@dataclass(frozen=True)
class EffectSpec:
    kind: int
    duration_ms: int
    step_ms: int
    amplitude: int = 0
    completion: int = 0
    machine: int = 0
    event: int = 0

    def valid(self):
        return (unsigned(self.kind, 2) and self.kind != 0
                and unsigned(self.duration_ms) and self.duration_ms != 0
                and unsigned(self.step_ms) and self.step_ms != 0
                and unsigned(self.completion, 1)
                and unsigned(self.machine, 255) and unsigned(self.event, 255)
                and unsigned(self.amplitude, 32767)
                and (self.amplitude == 0 if self.kind == INVERT else self.amplitude > 0))


class EffectTimeline:
    """Caller owns object identity, scene admission and completion queue capacity."""

    def __init__(self, activation):
        if not unsigned(activation) or activation == 0:
            raise ValueError('nonzero scene activation required')
        self.activation = activation
        self.generation = self.elapsed_ms = self.state = self.paused = 0
        self.spec = None

    def start(self, spec):
        if not isinstance(spec, EffectSpec) or not spec.valid():
            return ARGUMENT
        if self.generation == U32_MAX:
            return EXHAUSTED
        self.spec = spec
        self.generation += 1
        self.elapsed_ms = 0
        self.state = RUNNING
        return OK

    def advance(self, elapsed_ms):
        if not unsigned(elapsed_ms):
            return ARGUMENT
        if self.state == RUNNING and not self.paused:
            self.elapsed_ms = min(self.spec.duration_ms, self.elapsed_ms + elapsed_ms)
            if self.elapsed_ms == self.spec.duration_ms:
                self.state = COMPLETE if self.spec.completion else IDLE
        return OK

    def pause(self, paused):
        if not unsigned(paused, 1):
            return ARGUMENT
        self.paused = paused
        return OK

    def cancel(self):
        self.state = IDLE
        return OK

    def sample(self):
        if self.state != RUNNING:
            return (0, 0, 0)
        phase = self.elapsed_ms // self.spec.step_ms
        if self.spec.kind == INVERT:
            return (0, 0, phase & 1)
        amplitude = self.spec.amplitude
        return ((0, 0, 0), (amplitude, 0, 0), (-amplitude, 0, 0),
                (0, amplitude, 0), (0, -amplitude, 0))[phase % 5]

    def next_ms(self):
        if self.state != RUNNING or self.paused:
            return 0
        return min(self.spec.duration_ms - self.elapsed_ms,
                   self.spec.step_ms - self.elapsed_ms % self.spec.step_ms)

    def awake(self):
        return int(self.state == RUNNING and not self.paused)

    def take(self, activation, generation):
        if (activation, generation) != (self.activation, self.generation):
            return STALE, None
        if self.state != COMPLETE or self.paused:
            return EMPTY, None
        self.state = IDLE
        return OK, (activation, generation, self.spec.machine, self.spec.event)
