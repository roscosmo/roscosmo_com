"""Host library bounds and non-destructive package asset selection."""
from dataclasses import replace

# Source-library work bound, not a device frame-table allowance. A 4096px
# sheet of 16px tiles fits in the authoring library in its entirety.
MAX_SOURCE_FRAMES = 65536


def capability():
    return dict(maximum_frames_per_asset=MAX_SOURCE_FRAMES,
                package_selection='authored_references',
                preserves_unused_source=True)


def package_assets(bundle):
    """Retain every declared runtime reference; never use observed preview activity.

    Walk scene source, including all State overrides, branches, shared-instance
    definitions, flowcharts and selectors. Library templates and editor metadata
    are not runtime roots. Animation and cue dependencies are then closed over.
    Source validation remains authoritative for missing/malformed references.
    """
    frames, animations, cues = set(), set(), set()
    pending = list(bundle.scenes)
    while pending:
        value = pending.pop()
        if isinstance(value, (list, tuple)):
            pending.extend(value)
        elif isinstance(value, dict):
            for key, child in value.items():
                if key in ('editor', 'layout'):
                    continue
                if key in ('frame_ref', 'visual_ref') and isinstance(child, str):
                    frames.add(child)
                elif key == 'phase_visual_refs' and isinstance(child, list):
                    frames.update(ref for ref in child if isinstance(ref, str))
                elif key == 'animation_ref' and isinstance(child, str):
                    animations.add(child)
                elif key in ('cue_ref', 'navigation_sfx') and isinstance(child, str):
                    cues.add(child)
                elif isinstance(child, (dict, list, tuple)):
                    pending.append(child)
    selected_animations = tuple(a for a in bundle.animations if a['animation_id'] in animations)
    for animation in selected_animations:
        frames.update(animation['frame_refs'])
    selected_cues = tuple(c for c in bundle.audio_cues if c['cue_id'] in cues)
    audio_ids = {cue['asset_ref'] for cue in selected_cues}
    assets = tuple({**asset, 'frames': [f for f in asset['frames'] if f['frame_id'] in frames]}
                   for asset in bundle.assets if any(f['frame_id'] in frames for f in asset['frames']))
    return replace(bundle, assets=assets, animations=selected_animations,
                   frames=tuple(f for f in bundle.frames if f.frame_id in frames),
                   audio_assets=tuple(a for a in bundle.audio_assets if a.asset_id in audio_ids),
                   audio_cues=selected_cues)
