"""Reusable private layered-map build adapter; not a service capability grant.

Explicit stable layer IDs select visual order, objects and data-only collision.
The original source/snapshot is never mutated. Existing wire codecs own packing.
"""
from copy import deepcopy
from .processing_cache import cached_map
from dataclasses import dataclass
from pathlib import Path
import xml.etree.ElementTree as ET

from .image_assets import resolve_project_path
from .imported_properties import ImportedPropertyError
from .tiled_assets import read_snapshot, validate_record, MAX_SOURCE_BYTES
from .tilemap_wire import compile_map, CompiledMap
from .tileset_wire import compile_tiles, CompiledTiles
from .terrain_wire import compile_terrain
from .tile_selection import used_tiles


def read_atlas_snapshot(root, source_path):
    """Resolve simple external TSX atlases into the existing embedded snapshot.

    Same project-relative path restrictions as other image imports. Unsupported
    TSX features are rejected, never silently stripped. Reimport is explicit.
    """
    root = Path(root).resolve()
    source = resolve_project_path(root, source_path, 'map.source_path')
    snapshot = read_snapshot(root, source_path)
    if not isinstance(snapshot, dict) or not isinstance(snapshot.get('tilesets'), list):
        raise ImportedPropertyError('Map requires a tileset array')
    for index, entry in enumerate(snapshot['tilesets']):
        if not isinstance(entry, dict):
            raise ImportedPropertyError('Tileset must be an object')
        if 'source' not in entry:
            continue
        if set(entry) != {'firstgid', 'source'}:
            raise ImportedPropertyError('External tileset requires only firstgid and source')
        # Resolve from map directory, with containment checked before reading.
        tsx = resolve_project_path(source.parent, entry['source'], 'tileset.source')
        try:
            with tsx.open('rb') as stream:
                raw = stream.read(MAX_SOURCE_BYTES + 1)
            if len(raw) > MAX_SOURCE_BYTES:
                raise ImportedPropertyError('TSX exceeds the host input bound')
            text = raw.decode('utf-8-sig')
            if '<!DOCTYPE' in text.upper() or '<!ENTITY' in text.upper():
                raise ImportedPropertyError('TSX document types/entities are unsupported')
            atlas = ET.fromstring(text)
        except (OSError, UnicodeError, ET.ParseError) as exc:
            raise ImportedPropertyError(f'Cannot read tileset {entry["source"]}: {exc}') from exc
        numbers = {'tilewidth', 'tileheight', 'tilecount', 'columns', 'spacing', 'margin'}
        if (atlas.tag != 'tileset' or set(atlas.attrib) - numbers - {'version', 'tiledversion', 'name'}
                or len(atlas) != 1 or atlas[0].tag != 'image'):
            raise ImportedPropertyError('Only a plain static TSX image atlas is supported')
        image = atlas[0]
        if set(image.attrib) != {'source', 'width', 'height'} or len(image):
            raise ImportedPropertyError('TSX image requires source/width/height and PNG alpha transparency')
        image_path = resolve_project_path(tsx.parent, image.attrib['source'], 'tileset.image')
        normalized = {'firstgid': entry['firstgid'], 'name': atlas.get('name', ''),
                      'image': image_path.relative_to(source.parent).as_posix()}
        try:
            normalized.update({key: int(value) for key, value in atlas.attrib.items() if key in numbers})
            normalized.update(imagewidth=int(image.attrib['width']), imageheight=int(image.attrib['height']))
        except ValueError as exc:
            raise ImportedPropertyError('TSX atlas geometry must be integral') from exc
        snapshot['tilesets'][index] = normalized
    return snapshot


@dataclass(frozen=True)
class CompiledLayeredMap:
    layout: CompiledMap
    tiles: CompiledTiles
    terrain: bytes
    visual_record: dict
    source_gids: tuple


@cached_map
def compile_layered_map(record, root, *, background_layers, object_layer,
                        collision_layer, maximum_bytes=16 * 1024 * 1024):
    """Compile the initial two-background profile with an explicit collision role.

    Collision cells use this map's grid. Independent-grid callers can use the
    terrain compiler directly. Visibility never decides collision membership.
    No actor behavior, solidity or animation is inferred from object names.
    """
    root = Path(root).resolve()
    validate_record(record, root)
    if not isinstance(background_layers, (tuple, list)) or len(background_layers) != 2:
        raise ImportedPropertyError('This editor profile requires two background layer IDs')
    roles = (*background_layers, object_layer, collision_layer)
    if any(type(value) is not int or value <= 0 for value in roles) or len(set(roles)) != 4:
        raise ImportedPropertyError('Layer roles require distinct positive IDs')
    layers = {layer['id']: layer for layer in record['snapshot']['layers']}
    if set(layers) != set(roles):
        raise ImportedPropertyError('Every source layer needs one explicit supported role')
    for lid in (*background_layers, collision_layer):
        if layers[lid]['type'] != 'tilelayer':
            raise ImportedPropertyError(f'Layer {lid} must be a tile layer')
    if layers[object_layer]['type'] != 'objectgroup':
        raise ImportedPropertyError('Actor layer must be an object layer')
    collision_owner = f'layer:{collision_layer}'
    if layers[collision_layer].get('properties') or any(
            edit['owner_id'] == collision_owner for edit in record['edits']):
        raise ImportedPropertyError('Collision-only layer cannot own runtime properties')
    terrain = compile_terrain(record, root, collision_layer, maximum_bytes=maximum_bytes)
    visual = deepcopy(record)
    visual['snapshot']['layers'] = [deepcopy(layers[lid]) for lid in (*background_layers, object_layer)]
    layout = compile_map(visual, root, maximum_bytes=maximum_bytes)
    tiles = compile_tiles(visual, root, maximum_bytes=maximum_bytes)
    return CompiledLayeredMap(layout, tiles, terrain, visual, used_tiles(visual['snapshot']))
