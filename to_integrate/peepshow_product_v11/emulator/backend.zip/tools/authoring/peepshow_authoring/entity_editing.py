"""Private assembly editing view over independent Scene entities.

The existing assembly algorithms work on a temporary materialized map. Only
changed Scene components are reconciled; map assets and unrelated drafts stay
untouched. Numeric object identities never become authored target bindings.
"""
from copy import deepcopy
from dataclasses import replace


def names(scene):
    return {e['entity_id']: f"object:{e['local_id']}"
            for e in scene.get('world', {}).get('entities', [])}


def remap(value, entities):
    """Remap entity references, excluding behavior-local namespaces and layout."""
    result = deepcopy(value)
    pending = [result]
    while pending:
        row = pending.pop()
        if isinstance(row, list):
            pending.extend(row)
        elif isinstance(row, dict):
            for key, item in row.items():
                if key in ('behaviors', 'layout'):
                    continue
                if key in ('owner_id', 'entity_ref', 'target_ref', 'target_entity_ref') and isinstance(item, str):
                    row[key] = entities.get(item, item)
                elif isinstance(item, (dict, list)):
                    pending.append(item)
    return result


def authored_paths(value):
    """Inspection references point at saved source, not the temporary map view."""
    pending = [value]
    while pending:
        row = pending.pop()
        if isinstance(row, list):
            pending.extend(row)
        elif isinstance(row, dict):
            path = row.get('source_path')
            if isinstance(path, list) and path[:2] == ['machine_logic','map_scene']:
                row['source_path'] = ['world','map'] + path[2:]
            pending.extend(v for v in row.values() if isinstance(v, (dict,list)))
    return value


def template_bindings(project, scenes, *, reverse=False):
    by_scene = {s['scene_id']: names(s) for s in scenes}
    if reverse:
        by_scene = {sid: {v:k for k,v in rows.items()} for sid,rows in by_scene.items()}
    definitions = {t['template_id']:t for t in project.get('actor_templates', {}).get('definitions', [])}
    for placement in project.get('actor_templates', {}).get('placements', []):
        mapping = by_scene.get(placement['scene_id'], {})
        template = definitions.get(placement['template_ref'], {})
        for slot in template.get('bindings', []):
            if slot['kind'] == 'entity':
                key = slot['binding_id']
                value = placement['bindings'].get(key)
                if isinstance(value, str):
                    placement['bindings'][key] = mapping.get(value, value)


def reconcile(original, before, after):
    """Keep original source byte-for-value when the private component did not change."""
    result = deepcopy(original)
    config = after['machine_logic']['map_scene']
    old_entities = {e['local_id']:e for e in original['world']['entities']}
    old_local = {e['id']:e for e in before['machine_logic']['map_scene']['local_entities']}
    entities = []
    used = {e['entity_id'] for e in old_entities.values()}
    for local in config.get('local_entities', []):
        entity = deepcopy(old_entities.get(local['id']))
        if entity is None:
            from .actor_templates import require
            require(local['name'] not in used, 'Actor identity conflicts with an existing Scene entity')
            used.add(local['name'])
            entity = dict(entity_id=local['name'], local_id=local['id'], display_name=local['name'],
                          position={}, visual_ref=None, position_writer=None, properties=[])
        if local != old_local.get(local['id']):
            entity.update(display_name=local['name'], properties=deepcopy(local['properties']),
                          position=dict(x=local['x']//config['cell_width'], y=local['y']//config['cell_height']))
        owner = f"object:{local['id']}"
        bindings = [p for p in after['machine_logic']['world_positions'] if p['entity_ref'] == owner]
        previous = [p for p in before['machine_logic']['world_positions'] if p['entity_ref'] == owner]
        if bindings != previous:
            entity['visual_ref'] = None
            entity['visual_bindings'] = [{k:deepcopy(p[k]) for k in ('object_ref','offset_x','offset_y')} for p in bindings]
        entities.append(entity)
    result['world']['entities'] = entities
    mapping = {v:k for k,v in names(result).items()}
    # Removed identities are still needed for diagnostics/result paths.
    mapping.update({v:k for k,v in names(original).items()})
    graph = deepcopy(after['machine_logic'])
    graph.pop('map_scene')
    graph.pop('world_positions')
    explicit = {r['reference_id'] for r in original.get('machine_logic', {}).get('world_references', [])}
    generated = {r['reference_id']:r for r in before['machine_logic'].get('world_references', []) if r['reference_id'] not in explicit}
    graph['world_references'] = [r for r in graph.get('world_references', []) if r != generated.get(r['reference_id'])]
    if not graph['world_references'] and 'world_references' not in original.get('machine_logic', {}):
        graph.pop('world_references')
    result['machine_logic'] = remap(graph, mapping)
    for key in set(before) | set(after):
        if key != 'machine_logic' and before.get(key) != after.get(key):
            if key in after:
                result[key] = remap(after[key], mapping)
            else:
                result.pop(key, None)
    old_config = before['machine_logic']['map_scene']
    for key in ('occupancy', 'camera', 'visibility'):
        if config.get(key) != old_config.get(key):
            value = remap(config.get(key), mapping)
            if key == 'occupancy':
                value = [{k:v for k,v in row.items() if k not in ('x_ref','y_ref')} for row in value]
            if value is None:
                result['world']['map'].pop(key, None)
            else:
                result['world']['map'][key] = value
    return result


def apply(bundle, project, scenes, catalogs, command):
    from .authoring_foundation import project_for_execution, schemas
    from .project import ProjectCommandError
    from . import actor_assembly, actor_templates
    kind = command['kind']
    schema = 'actor-template-command-v1.schema.json' if kind in actor_templates.COMMANDS else 'actor-assembly-command-v1.schema.json'
    error = next(schemas()[0].evolve(schema={'$ref':schema}).iter_errors(command), None)
    if error is not None:
        raise ProjectCommandError('COMMAND_SHAPE_INVALID', error.message)
    view = project_for_execution(replace(bundle, project=project, scenes=tuple(scenes), asset_catalogs=tuple(catalogs)))
    working = deepcopy(list(view.scenes))
    before = deepcopy(working)
    public_project = deepcopy(project)
    projected_project = deepcopy(view.project)
    target = next((s for s in scenes if s['scene_id'] == command.get('scene_id')), None)
    editing_command = remap(command, names(target)) if target else deepcopy(command)
    if kind == 'scene.actor_template.place' or kind == 'scene.actor_template.set_bindings' or kind == 'scene.actor_template.link':
        tref = command.get('template_ref')
        if tref is None:
            tref = actor_templates.link(project,command['scene_id'],command['instance_ref'])['template_ref']
        for slot in actor_templates.definition(project,tref)['bindings']:
            if slot['kind'] == 'entity' and slot['binding_id'] in editing_command['bindings']:
                key = slot['binding_id']
                editing_command['bindings'][key] = names(target).get(editing_command['bindings'][key], editing_command['bindings'][key])
    try:
        if kind == 'scene.actor_template.place':
            destination = next(s for s in working if s['scene_id'] == command['scene_id'])
            # Placing a template explicitly adds its shared definition and instance.
            # It never creates a machine to satisfy an unresolved owner binding.
            destination['machine_logic'].setdefault('instance_behaviors',
                dict(version=3, behaviors=[], instances=[], bridges=[], outgoing=[]))
        if kind in actor_templates.COMMANDS:
            result = actor_templates.apply_command(projected_project, working, view.asset_catalogs, editing_command)
        else:
            result = actor_assembly.apply_command(working, view.asset_catalogs, editing_command)
            actor_templates.sync_target_binding(projected_project, working, view.asset_catalogs, editing_command)
            if kind == 'scene.actor.remove' and 'actor_templates' in projected_project:
                projected_project['actor_templates']['placements'][:] = [p for p in projected_project['actor_templates']['placements']
                    if (p['scene_id'],p['instance_ref']) != (command['scene_id'],command['instance_ref'])]
        for index, (old, new) in enumerate(zip(before, working)):
            if new != old:
                scenes[index] = reconcile(scenes[index], old, new)
        if 'actor_templates' in projected_project:
            public_project['actor_templates'] = deepcopy(projected_project['actor_templates'])
            template_bindings(public_project, scenes, reverse=True)
            project['actor_templates'] = public_project['actor_templates']
        mapping = {v:k for s in scenes if s['scene_id'] == command.get('scene_id') for k,v in names(s).items()}
        if target:
            mapping.update({v:k for k,v in names(target).items()})
        result = remap(result, mapping)
        if 'suggested_bindings' in result:
            template = actor_templates.definition(project,command['template_id'])
            for slot in template['bindings']:
                if slot['kind'] == 'entity':
                    key = slot['binding_id']
                    result['suggested_bindings'][key] = mapping.get(result['suggested_bindings'][key], result['suggested_bindings'][key])
        return authored_paths(result)
    except ProjectCommandError:
        raise
    except (KeyError, TypeError, ValueError, StopIteration, AttributeError, IndexError) as exc:
        raise ProjectCommandError('ACTOR_ASSEMBLY_INCOMPLETE',
            'Complete the selected actor/map setup before this operation: ' + str(exc)) from exc


def inspect(bundle, scene, identity):
    from .authoring_foundation import project_for_execution
    from .actor_assembly import inspect_source
    view = project_for_execution(bundle)
    projected = next(s for s in view.scenes if s['scene_id'] == scene['scene_id'])
    result = inspect_source(projected, view.asset_catalogs, identity)
    return authored_paths(remap(result, {v:k for k,v in names(scene).items()}))
