"""Conditional device capabilities, separate from the broader editing grammar."""
from copy import deepcopy
from .map_export import PROFILE_ID, public_profile


def annotate(machine, menu, inventory):
    machine, menu, inventory = deepcopy((machine, menu, inventory))

    def device(row, **subset):
        row.update(runtime=True, export=True, status='development_restricted',
            export_profile_id=PROFILE_ID, export_requires_project_readiness=True,
            device_support='subset', device_subset=subset,
            hardware_validation='reference_dungeon_tested_edited_projects_require_testing')

    device(machine['map_scene'], all_scenes_map_bound=True, background_layers=2,
           base_colours=['white', 'black'])
    device(machine['instance_behaviors'], source_versions=[1, 2, 3], independent_state=True)
    device(machine['event_responses'], ordinary=True, shared=True)
    device(machine['event_addressing'], queued=True)
    device(machine['facing'], cardinal=True)
    device(machine['destinations'], cell_kinds=['adjacent'],
           directions=['left', 'right', 'up', 'down'], facing_relative=False)
    device(machine['instance_behaviors']['destinations'], cell_kinds=['adjacent'],
           directions=['left', 'right', 'up', 'down'], facing_relative=False)
    device(machine['instance_behaviors']['event_responses'], shared=True)
    device(machine['instance_behaviors']['event_addressing'], queued=True)
    device(machine['instance_behaviors']['interfaces'], named_outputs=True)
    device(machine['instance_behaviors']['facing'], cardinal=True)
    device(machine['interactions'], approach_sides=True, no_target='no_op')
    device(machine['camera'], modes=['manual', 'follow'], action_kinds=[])
    machine['map_scene']['camera_component'] = deepcopy(machine['camera'])
    device(machine['world_properties'], existing_world_operands=True)
    device(machine['collision_queries'], terrain=True, bounds=True, occupancy=True)
    device(machine['actor_assembly'], expanded_source_admitted=True)
    device(menu, source_versions=[2], presentation=['scene_objects'], modes=['pause'],
           all_scenes_require_component=True, inventory=True)
    menu['requires_for_execution'] = ['project_build_readiness', 'device_exact_admission']
    for key in ('navigation_wrapper', 'object_editing'):
        device(menu[key], source_versions=[2], presentation=['scene_objects'])
    device(inventory, requires='v2_object_menu_in_all_scenes', persistence='between_scenes',
           collection='accepted_position_change')
    machine['map_export_profile'] = public_profile()
    return machine, menu, inventory
