"""Private compiler admission for shared behavior property operands.

Not project syntax, a graph compiler, wire records or a public capability.
The caller supplies behavior operands in evaluator order and existing world
writer tags; this module never allocates Scene-machine slots. Graph admission
must separately prove that Scene/flow code cannot use the reserved writer.
Property defaults/overrides remain in the existing imported map data.
"""
from dataclasses import dataclass

from .imported_properties import ImportedPropertyError
from .tilemap_wire import HEADER, ENTITY
from .world_operands_wire import decode_typed_operands as decode_operands
from .world_references import WorldReference


@dataclass(frozen=True)
class BehaviorProperty:
    name: str
    value_type: str
    writable: bool
    field: str = 'property'
    owner: str = 'self'


@dataclass(frozen=True)
class BehaviorBindings:
    behavior_id: str
    properties: tuple


@dataclass(frozen=True)
class InstanceAssignment:
    instance_id: str
    behavior_id: str
    entity: WorldReference
    writer: int
    target: WorldReference | None = None


@dataclass(frozen=True)
class BoundInstance:
    instance_id: str
    behavior: int
    entity: WorldReference
    writer: int
    bindings: tuple
    target: WorldReference | None = None


@dataclass(frozen=True)
class InstanceBindings:
    behaviors: tuple
    instances: tuple


@dataclass(frozen=True)
class InstanceQuery:
    actor_x: int
    actor_y: int
    facing: int
    width: int
    height: int
    facings: tuple
    targets: tuple
    interaction_targets: tuple | None = None
    no_target: tuple | None = None


def compile_instance_bindings(world, behaviors, assignments):
    """Pure, all-or-nothing binding admission. Input ordering is semantic.

    Local names resolve on Self, or on an explicitly bound read-only Target.
    Target admits only a complete integer X/Y pair, not arbitrary aliases.
    Each entity has one behavior in this first slice.
    Shared writer tags do not imply shared properties or shared instance State.
    """
    def fail(message):
        raise ImportedPropertyError(message)

    def identity(value):
        return type(value) is str and bool(value)

    if not isinstance(behaviors, (tuple, list)) or not isinstance(assignments, (tuple, list)):
        fail('behavior and instance tables must be arrays')
    bindings, _, actions = decode_operands(world.operands, len(world.machine_sources),
                                           len(world.flow_sources))
    slots = {ref: i for i, ref in enumerate(world.binding_sources)}
    if len(slots) != len(bindings):
        fail('world binding source table does not match operands')
    header = HEADER.unpack_from(world.map.data)
    entities = {f'object:{ENTITY.unpack_from(world.map.data, header[14] + i*ENTITY.size)[0]}'
                for i in range(header[11])}
    behavior_ids = {}
    admitted = []
    for behavior in behaviors:
        if (not isinstance(behavior, BehaviorBindings) or not identity(behavior.behavior_id) or
                behavior.behavior_id in behavior_ids or
                not isinstance(behavior.properties, (tuple, list))):
            fail('invalid or duplicate behavior identity')
        names = set()
        for prop in behavior.properties:
            if (not isinstance(prop, BehaviorProperty) or not identity(prop.name) or
                    prop.name in names or prop.value_type not in ('bool', 'int32') or
                    type(prop.writable) is not bool or
                    prop.field not in ('property', 'entity_x', 'entity_y') or
                    prop.owner not in ('self', 'target') or
                    (prop.owner == 'target' and (prop.writable or prop.field == 'property')) or
                    (prop.field != 'property' and prop.value_type != 'int32')):
                fail('invalid, duplicate or unsupported behavior property')
            names.add(prop.name)
        target_fields = [p.field for p in behavior.properties if p.owner == 'target']
        if target_fields and sorted(target_fields) != ['entity_x', 'entity_y']:
            fail('Target requires exactly one read-only X/Y pair')
        behavior_ids[behavior.behavior_id] = len(admitted)
        admitted.append(BehaviorBindings(behavior.behavior_id, tuple(behavior.properties)))

    result, ids, owners, written = [], set(), set(), set()
    scene_actions = {row[0] for row in actions}
    for row in assignments:
        if (not isinstance(row, InstanceAssignment) or not identity(row.instance_id) or
                row.instance_id in ids or not identity(row.behavior_id) or
                row.behavior_id not in behavior_ids):
            fail('invalid, duplicate or unknown instance/behavior identity')
        entity = row.entity
        if (not isinstance(entity, WorldReference) or entity.field != 'entity_x' or
                entity.property_id or entity.owner_id not in entities or entity not in slots or
                entity in owners):
            fail('instance requires a unique declared map entity')
        if (type(row.writer) is not int or not
                (0 <= row.writer < len(world.machine_sources) or
                 128 <= row.writer < 128 + len(world.flow_sources))):
            fail('instance writer is not an admitted world writer')
        behavior = behavior_ids[row.behavior_id]
        uses_target = any(p.owner == 'target' for p in admitted[behavior].properties)
        target = row.target
        if uses_target:
            if (not isinstance(target, WorldReference) or target.field != 'entity_x' or
                    target.property_id or target.asset_id != entity.asset_id or
                    target.owner_id not in entities or target not in slots or target == entity):
                fail('Target requires a distinct declared entity on the Self map')
        elif target is not None:
            fail('unused Target binding')
        local = []
        for prop in admitted[behavior].properties:
            owner = target if prop.owner == 'target' else entity
            ref = WorldReference(owner.asset_id, prop.field, owner.owner_id,
                                 prop.name if prop.field == 'property' else '')
            if ref not in slots:
                fail(f'missing instance property {row.instance_id}.{prop.name}')
            slot = slots[ref]
            record = bindings[slot]
            if record[2] != int(prop.value_type == 'bool'):
                fail(f'wrong instance property type: {row.instance_id}.{prop.name}')
            if prop.writable:
                if record[3] != row.writer or slot in written or slot in scene_actions:
                    fail(f'competing or wrong property writer: {row.instance_id}.{prop.name}')
                written.add(slot)
            local.append(slot)
        ids.add(row.instance_id)
        owners.add(entity)
        result.append(BoundInstance(row.instance_id, behavior, entity, row.writer, tuple(local), target))
    return InstanceBindings(tuple(admitted), tuple(result))


def compile_instance_query(world, table, actor, facing, facings, eligible, width, height):
    """Lower eligible stable instance IDs to (X, Y, instance, behavior).

    Stationary aligned targets only. Explicitly eligible instances participate
    in overlap checks; unrelated render objects do not. No property is used as
    the identity of an instance.
    """
    def fail(message):
        raise ImportedPropertyError(message)

    if not isinstance(table, InstanceBindings):
        fail('interaction requires admitted instance bindings')
    rebuilt = compile_instance_bindings(world, table.behaviors, [
        InstanceAssignment(r.instance_id, table.behaviors[r.behavior].behavior_id,
                           r.entity, r.writer, r.target) for r in table.instances])
    if rebuilt != table:
        fail('instance bindings do not match this world')
    if (not isinstance(actor, WorldReference) or actor.field != 'entity_x' or actor.property_id or
            not isinstance(facing, WorldReference) or facing.asset_id != actor.asset_id or
            facing.owner_id != actor.owner_id or facing.field != 'property' or
            any(type(v) is not int or not 0 < v <= 0x7fffffff for v in (width, height))):
        fail('invalid interaction actor, Facing or grid')
    if (not isinstance(eligible, (tuple, list)) or
            any(type(v) is not str for v in eligible) or len(set(eligible)) != len(eligible)):
        fail('invalid or duplicate eligible instance')
    if not isinstance(facings, (tuple, list)) or len(facings) != 4:
        fail('Facing requires four cardinal mappings')
    values, directions = set(), set()
    for row in facings:
        if (not isinstance(row, (tuple, list)) or len(row) != 3 or
                any(type(v) is not int for v in row) or not -2**31 <= row[0] < 2**31 or
                tuple(row[1:]) not in ((-1, 0), (1, 0), (0, -1), (0, 1)) or
                row[0] in values or tuple(row[1:]) in directions):
            fail('invalid or duplicate Facing mapping')
        values.add(row[0])
        directions.add(tuple(row[1:]))
    bindings, _, _ = decode_operands(world.operands, len(world.machine_sources), len(world.flow_sources))
    slots = {ref: i for i, ref in enumerate(world.binding_sources)}

    def slot(ref):
        if ref not in slots or bindings[slots[ref]][2] != 0:
            fail(f'missing or noninteger interaction binding: {ref}')
        return slots[ref]

    ax, ay, f = slot(actor), slot(WorldReference(actor.asset_id, 'entity_y', actor.owner_id)), slot(facing)
    header = HEADER.unpack_from(world.map.data)
    positions = {}
    for i in range(header[11]):
        row = ENTITY.unpack_from(world.map.data, header[14] + i*ENTITY.size)
        positions[f'object:{row[0]}'] = row[2:4]
    ox, oy = positions[actor.owner_id]
    instances = {r.instance_id: (i, r) for i, r in enumerate(table.instances)}
    targets, occupied = [], set()
    for name in eligible:
        if name not in instances:
            fail('unknown eligible instance')
        index, instance = instances[name]
        entity = instance.entity
        if entity.asset_id != actor.asset_id or entity.owner_id == actor.owner_id:
            fail('interaction target must be another entity on the actor map')
        x, y = slot(entity), slot(WorldReference(entity.asset_id, 'entity_y', entity.owner_id))
        if bindings[x][3] != 255 or bindings[y][3] != 255:
            fail('interactable positions must be read-only in this slice')
        px, py = positions[entity.owner_id]
        if (px-ox) % width or (py-oy) % height:
            fail('interactable is not aligned to the interaction grid')
        cell = ((px-ox)//width, (py-oy)//height)
        if cell in occupied:
            fail('overlapping eligible interactables')
        occupied.add(cell)
        targets.append((x, y, index, instance.behavior))
    return InstanceQuery(ax, ay, f, width, height, tuple(tuple(r) for r in facings), tuple(targets))
