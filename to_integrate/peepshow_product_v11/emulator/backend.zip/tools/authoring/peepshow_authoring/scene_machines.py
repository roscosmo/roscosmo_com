"""Scene-owned machine source contract and legacy-IR projection for host preview."""
from copy import deepcopy
from .presentation_selectors import COMMANDS as SELECTOR_COMMANDS, variable_comparison_capability
from .machine_export import public_profile, MAX_EFFECT_TARGETS, SCENE_EXIT_TRIGGERS, ACTION_KINDS
from .machine_limits import MACHINES, STATES, ROUTES, LOWERED_BINDINGS, NAMED_EVENTS, EVENTS, INPUTS, TIMERS
from . import flowcharts
from .world_authoring import CAPABILITY as WORLD_CAPABILITY
from .instance_project import CAPABILITY as INSTANCE_CAPABILITY
from .map_scene_source import CAPABILITY as MAP_SCENE_CAPABILITY
from .calendar_schedule import CAPABILITY as CALENDAR_CAPABILITY
from .event_graph import find_cycle
from .scene_collision_source import CAPABILITY as COLLISION_CAPABILITY
from .v2_export import public_object_inversion_profile
from .instance_event_source import CAPABILITY as EVENT_CAPABILITY, InstanceEventError
from .facing_source import CAPABILITY as FACING_CAPABILITY
from .destination_source import CAPABILITY as DESTINATION_CAPABILITY, DestinationError
from .interaction_source import CAPABILITY as INTERACTION_CAPABILITY, InteractionError
from .camera_source import CAPABILITY as CAMERA_CAPABILITY, CameraError
from .visibility_source import CAPABILITY as VISIBILITY_CAPABILITY, VisibilityError
from .execution_scope_source import CAPABILITY as SCOPE_CAPABILITY, ExecutionScopeError
from .behavior_response import SCENE_CAPABILITY as RESPONSE_CAPABILITY, COMMANDS as RESPONSE_COMMANDS
from .inventory_conditions import CAPABILITY as INVENTORY_CONDITION_CAPABILITY
from .actor_assembly import CAPABILITY as ACTOR_CAPABILITY

MODEL = "scene_machines_v1"
COMMANDS = ("scene.machines.set", "scene.machines.clear")
CAPABILITY = {
    'actor_assembly': ACTOR_CAPABILITY,
    'event_responses': RESPONSE_CAPABILITY,
    'inventory_conditions': INVENTORY_CONDITION_CAPABILITY,
    'event_addressing': EVENT_CAPABILITY,
    'facing': FACING_CAPABILITY,
    'destinations': DESTINATION_CAPABILITY,
    'interactions': INTERACTION_CAPABILITY,
    'camera': CAMERA_CAPABILITY,
    'visibility': VISIBILITY_CAPABILITY,
    'execution_scopes': SCOPE_CAPABILITY,
    'schema': 'schemas/authoring/machine-logic-v1.schema.json',
    'map_scene': MAP_SCENE_CAPABILITY,
    'instance_behaviors': INSTANCE_CAPABILITY,
    'world_properties': WORLD_CAPABILITY,
    'collision_queries': COLLISION_CAPABILITY,
    'object_inversion': public_object_inversion_profile(),
    'object_clips': {'host_editing': True, 'host_preview': True, 'runtime': True,
        'export': True, 'status': 'development_restricted', 'hardware_validation': 'pending',
        'action_kinds': ['object.play_clip', 'object.cancel_clip'],
        'ownership': 'object.visual_ref', 'target_kind': 'sprite',
        'maximum_instances': 8, 'maximum_device_targets': 8, 'maximum_steps': 12,
        'end_policies': ['restore', 'hold_last'], 'completion': 'addressed_named_event',
        'replacement': 'restart_without_old_completion', 'shell_resume': 'preserve',
        'scene_exit': 'cancel', 'base_animation': 'continues_underneath'},
    'scene_inversion': {'host_editing': True, 'host_preview': True, 'runtime': True,
        'export': True, 'status': 'development_restricted', 'hardware_validation': 'pending',
        'action_kind': 'scene.set_inversion', 'modes': ['normal', 'inverted', 'toggle'],
        'ownership': 'machine.scene_writes', 'property': 'inversion',
        'fresh_entry': 'normal', 'shell_resume': 'preserve', 'shell_affected': False},
    'relative_timers': {'host_editing': True, 'host_preview': True,
        'random_delay': {'host_editing': True, 'host_preview': True, 'runtime': True,
            'export': True, 'status': 'development_restricted', 'hardware_validation': 'pending',
            'minimum_field': 'delay_ms', 'maximum_field': 'delay_max_ms', 'inclusive': True,
            'minimum_ms': 10, 'maximum_ms': 86400000, 'mode': 'one_shot',
            'sampling': 'once_per_arm', 'random_algorithm': 'xorshift32_reject_range_v1',
            'seed_scope': 'shared_scene', 'equal_bounds': 'fixed_no_draw'},
        'modes': ['one_shot', 'periodic'], 'default_mode': 'one_shot',
        'periodic': {'runtime': True, 'export': True, 'status': 'development_restricted',
                     'cadence': 'anchored_deadline', 'late_delivery': 'coalesce_one',
                     'suspension': 'pause_remaining', 'scene_exit': 'cancel'},
        'maximum_combined_timers': TIMERS},
    "calendar_schedules": CALENDAR_CAPABILITY,
    "model": MODEL, "host_editing": True, "host_preview": True,
    "object_effects": {"host_editing": True, "host_preview": True, "runtime": True,
        "export": True, "action_kinds": ["object.play_effect"], "kinds": ["invert", "shake"],
        "target_kind": "sprite", "ownership": "machine.effect_writes", "per_object": 1,
        "maximum_instances": 64, "maximum_duration_ms": 4294967295,
        "maximum_device_instances": MAX_EFFECT_TARGETS, "maximum_device_targets": MAX_EFFECT_TARGETS,
        "export_profile": "hw6_machines_resident_v1", "status": "development_restricted",
        "cadence": "best_effort_current_phase_no_replay", "awake_during_effect": True,
        "maximum_step_ms": 4294967295, "maximum_amplitude": 32767,
        "replacement": "cancel_without_completion", "completion": "addressed_named_event",
        "shell_resume": "preserve", "scene_exit": "cancel",
        "completion_order": "before_timers_then_object_id"},
    "retain_state": {"host_editing": True, "host_preview": True, "runtime": True,
        "export": True, "scope": "machine", "lifetime": "package_session", "default": False},
    "scene_replacement": {"runtime": True, "export": True, "maximum_scenes": 8,
        "triggers": list(SCENE_EXIT_TRIGGERS), "action_kinds": list(ACTION_KINDS), "maximum_actions": 7,
        "transaction": "settled_event_chain", "conflict_policy": "reject_entire_transaction",
        "hardware_validation": "pending",
        "maximum_exit_startup_audio_cues": 8, "mixed_execution_models": False},
    "flowcharts": flowcharts.CAPABILITY,
    "local_time_conditions": flowcharts.LOCAL_TIME_CAPABILITY,
    "scene_activated": {"host_editing": True, "host_preview": True,
        "runtime": True, "export": True, "maximum_bindings": 1,
        "addressing": "explicit_named_event", "delivery": "before_first_presentation",
        "shell_resume": False},
    "runtime": True, "export": True, "export_profile": public_profile(), "commands": list(COMMANDS + RESPONSE_COMMANDS),
    "maximum_machines": MACHINES, "maximum_states": STATES, "maximum_events": NAMED_EVENTS,
    "maximum_total_events": EVENTS, "maximum_inputs": INPUTS, "maximum_routes": ROUTES,
    "maximum_outcomes": 8, "maximum_queue": 32, "maximum_event_chain": 64,
    "transaction_boundary": "external_event_chain", "maximum_chain_audio_cues": 8,
    "presentation_selectors": {"host_editing": True, "host_preview": True, "runtime": True, "export": True,
        "commands": list(SELECTOR_COMMANDS), "update_mode": "replace_all_selectors",
        "requires_scene_machines": True, "target_kind": "sprite",
        "exclusive_property": "visual_ref", "evaluation": "settled_event_chain_and_fresh_entry",
        "hardware_evidence": "internal_single_scene_pet_two_units",
        "maximum_selectors": 8, "maximum_rules": 8, "maximum_predicate_tokens": 16,
        "maximum_predicate_depth": 8, "minimum_boolean_children": 2, "maximum_boolean_children": 8,
        "maximum_clip_steps": 12, "maximum_clip_frames": 4, "clip_loop_policy": "loop",
        "conditions": ["machine_state", "variable_compare", "all", "any", "not"],
        "variable_comparison": variable_comparison_capability(),
        "predicate_schema": "schemas/authoring/presentation-selector-predicate-v1.schema.json",
        "outputs": ["animation_ref", "visual_ref"],
        "selection": "first_match_with_fallback", "changed_selection": "restart", "unchanged_selection": "preserve_phase"},
    "maximum_lowered_bindings": LOWERED_BINDINGS + flowcharts.MAX_NODES * 64, "entry": "declared_state",
    "entry_graphs": False, "event_payloads": False, "implicit_broadcast": False,
    "event_cycles": "addressed_handlers_acyclic", "immediate_send_graph": {
        "node": "machine_event_address", "same_machine_sends": True,
        "cross_machine_replies": True, "conditional_cycles": "rejected_conservatively",
        "flowchart_sends": "included", "scheduled_completions": "separate_roots"},
    "machine_layout": True, "route_layout": False,
    "action_kinds": ["object.play_clip", "object.cancel_clip", "scene.set_inversion", "set_variable", "send_event", "play_sfx", "request_render", "exit_to_shell", "run_flowchart", "object.play_effect",
                     "start_timer", "restart_timer", "cancel_timer", "object.set_position", "object.move_by",
                     "object.set_visibility", "object.set_frame", "object.clear_frame", "object.set_inversion", "menu.open"],
    "weight_unit": "integer_percent", "remainder": "no_change",
    "random_algorithm": "xorshift32_reject100_v1", "seed_scope": "fresh_scene",
    "writer_policy": "exclusive_declared_owner",
    "timer_modes": ["time.scene_elapsed", "time.state_entry_elapsed", "time.local_schedule"],
}


def fail(message, code="MACHINE_MODEL_INVALID"):
    from .project import ProjectCommandError
    raise ProjectCommandError(code, message)


def shape(value, required, optional=()):
    if not isinstance(value, dict) or not set(required) <= value.keys() or value.keys() - set(required) - set(optional):
        fail(f"expected fields {sorted(required)}; optional {sorted(optional)}")


def ident(value):
    from .project import STABLE_ID
    if not isinstance(value, str) or not STABLE_ID.fullmatch(value):
        fail("expected a stable ID")
    return value


def records(value, key, limit):
    if not isinstance(value, list) or len(value) > limit:
        fail(f"{key}: expected an array of at most {limit} records")
    result = {}
    for record in value:
        if not isinstance(record, dict):
            fail(f"{key}: expected an object")
        ref = ident(record.get(key))
        if ref in result:
            fail(f"duplicate {key}: {ref}")
        result[ref] = record
    return result


def validate(project, scene):
    from .actor_output_response import describe_error
    from .project import ProjectCommandError
    authored_scene = scene
    try:
        from .world_logic_source import project as project_world
        from .imported_properties import ImportedPropertyError
        from .execution_scope_source import configuration as scope_configuration
        from .inventory_conditions import validate_scene as validate_inventory_conditions, proof_scene
        validate_inventory_conditions(project, scene)
        scopes = scope_configuration(scene)
        scene = project_world(proof_scene(scene)).scene
        if scopes is not None:
            # Ordinary menu actions still need authored machine ownership after
            # world lowering removes instance partition metadata.
            scene['machine_logic']['execution_scopes'] = scopes
        _validate(project, scene)
    except (InstanceEventError, DestinationError, InteractionError, CameraError, VisibilityError, ExecutionScopeError) as exc:
        fail(describe_error(authored_scene, str(exc)), exc.code)
    except ImportedPropertyError as exc:
        fail(describe_error(authored_scene, str(exc)), 'WORLD_REFERENCE_INVALID')
    except ProjectCommandError as exc:
        fail(describe_error(authored_scene, exc.message), exc.code)
    except (KeyError, TypeError, AttributeError) as exc:
        fail(f"malformed machine source: {exc}")


def _validate(project, scene):
    """Validate machine structure; existing validators check projected guards/actions."""
    from .scene_objects import PROPERTY_KEYS
    from .scoped_variables import enabled
    from .presentation_text_source import scene_bindings
    try:
        scene_bindings(project, scene)
    except ValueError as error:
        fail(str(error), 'OBJECT_TEXT_INVALID')
    if "machine_logic" not in scene:
        return
    graph = scene["machine_logic"]
    if scene.get("schema_version") != 2 or not enabled(project):
        fail("scene machines require a V2 scene and scoped_v1 variables")
    if scene.get("routes") or scene.get("event_handlers") or scene.get("entry_graph"):
        fail("explicitly replace legacy routes/handlers/entry graph when opting into machines")
    shape(graph, {"model", "seed", "machines", "events", "input_receivers", "timer_receivers", "routes"}, {"layout", "presentation_selectors", "flowcharts", "scene_activated", "time_reconcile", "world_references", "execution_scopes"})
    from .world_reference_project import declarations
    from .imported_properties import ImportedPropertyError
    try:
        declarations(graph)
    except ImportedPropertyError as exc:
        fail(str(exc), 'WORLD_REFERENCE_INVALID')
    if graph["model"] != MODEL or type(graph["seed"]) is not int or not 1 <= graph["seed"] <= 0xffffffff:
        fail("unknown machine model or seed outside 1..4294967295")
    machines = records(graph["machines"], "machine_id", MACHINES)
    events = records(graph["events"], "event_id", NAMED_EVENTS)
    if len(scene['input_actions']) > INPUTS or len(events) + len(scene['input_actions']) + len(scene.get('event_bindings', [])) > EVENTS:
        fail('machine input or combined event capacity exceeded', 'MACHINE_BUDGET')
    routes = records(graph["routes"], "route_id", ROUTES)
    if not machines:
        fail("at least one machine is required")
    for binding in ('scene_activated', 'time_reconcile'):
        if binding not in graph:
            continue
        activation = graph[binding]
        shape(activation, {"machine_ref", "event_ref"})
        if ident(activation["machine_ref"]) not in machines or ident(activation["event_ref"]) not in events:
            fail(f"{binding} must address an existing machine and named event")
    states = records(scene["states"], "state_id", STATES)
    objects = {o["object_id"]: o for o in scene["objects"]}
    variables = {("scene", v["variable_id"]) for v in scene["variables"]} | {
        ("package", v["variable_id"]) for v in project.get("package_variables", [])}
    state_owners, writers = {}, {}

    def own(key, machine):
        if key in writers:
            fail(f"writer {machine} conflicts with {writers[key]} for {key}", "MACHINE_WRITER_CONFLICT")
        writers[key] = machine

    for machine_id, machine in machines.items():
        shape(machine, {"machine_id", "display_name", "states", "entry_state", "variable_writes", "object_writes"}, {"retain_state", "effect_writes", "scene_writes"})
        scene_writes = machine.get('scene_writes', [])
        if not isinstance(scene_writes, list) or any(p != 'inversion' for p in scene_writes):
            fail('scene_writes supports only inversion')
        for prop in scene_writes:
            own(('scene', prop), machine_id)
        effect_writes = machine.get('effect_writes', [])
        if not isinstance(effect_writes, list) or len(effect_writes) > 64:
            fail('effect_writes must contain at most 64 sprite references')
        for ref in effect_writes:
            if ident(ref) not in objects or objects[ref]['kind'] != 'sprite':
                fail('effect ownership requires an existing sprite')
            own(('effect', ref), machine_id)
        if type(machine.get("retain_state", False)) is not bool:
            fail("retain_state must be boolean")
        if not isinstance(machine["display_name"], str) or not machine["display_name"].strip() or len(machine["display_name"]) > 128:
            fail("machine display_name must be nonempty text up to 128 characters")
        refs = machine["states"]
        if not isinstance(refs, list) or not refs or any(not isinstance(r, str) or r not in states or r in state_owners for r in refs) or len(set(refs)) != len(refs):
            fail("each state must belong to exactly one machine")
        if machine["entry_state"] not in refs:
            fail(f"{machine_id}: entry state must belong to its machine")
        state_owners.update({ref: machine_id for ref in refs})
        if not isinstance(machine["variable_writes"], list) or len(machine["variable_writes"]) > 32:
            fail("variable_writes must contain at most 32 declarations")
        for variable in machine["variable_writes"]:
            shape(variable, {"scope", "variable_ref"})
            key = (ident(variable["scope"]), ident(variable["variable_ref"]))
            if key not in variables:
                fail(f"unknown variable {key}")
            own(("variable", *key), machine_id)
        if not isinstance(machine["object_writes"], list) or len(machine["object_writes"]) > 64:
            fail("object_writes must contain at most 64 declarations")
        for obj in machine["object_writes"]:
            shape(obj, {"object_ref", "properties"})
            if ident(obj["object_ref"]) not in objects or not isinstance(obj["properties"], list) or not obj["properties"]:
                fail("unknown object or empty property ownership")
            for prop in obj["properties"]:
                if not isinstance(prop, str) or prop not in PROPERTY_KEYS:
                    fail("unknown object property")
                own(("object", obj["object_ref"], prop), machine_id)
    if set(state_owners) != set(states):
        fail("every scene state must belong to a machine")
    definitions = flowcharts.validate(scene, writers, variables, objects, machines)
    from .response_conditions import is_guard, validate_guard
    for route in graph['routes']:
        for guard in route.get('guards', []):
            if is_guard(guard):
                try:
                    validate_guard(guard, list(machines.values()))
                except ValueError as exc:
                    fail(f"{route['route_id']}: {exc}")
    if 'time_reconcile' in graph and not flowcharts.uses_local_time(scene):
        fail('time_reconcile requires local-time flowchart or response conditions')
    from .presentation_selectors import validate as validate_selectors
    validate_selectors(project, scene, writers)
    from .machine_startup import enabled as startup_enabled
    if not startup_enabled(project) and not any(m["entry_state"] == scene["entry_state"] for m in machines.values()):
        fail("scene entry_state must also be its owning machine's entry_state")

    def require_writer(key, machine):
        if machine is None or writers.get(key) != machine:
            fail(f"writer {machine or 'scene handler'} cannot modify {key}; owner is {writers.get(key)}", "MACHINE_WRITER_CONFLICT")

    for state_id, state in states.items():
        for override in state["object_overrides"]:
            for prop in override.keys() - {"object_ref"}:
                require_writer(("object", override["object_ref"], prop), state_owners[state_id])
    for event in events.values():
        shape(event, {"event_id", "display_name"})
        if not isinstance(event["display_name"], str) or not 1 <= len(event["display_name"]) <= 128:
            fail("event display_name must be nonempty text up to 128 characters")
    inputs = {b["action_id"] for b in scene["input_actions"]}
    timers = {b["binding_id"]: b for b in scene.get("event_bindings", [])}
    if len(timers) > TIMERS:
        fail(f"at most {TIMERS} combined relative/calendar timers are supported", "MACHINE_BUDGET")
    if set(events) & (inputs | set(timers)):
        fail("named events and input/timer binding IDs must be distinct")
    for field, expected in (("input_receivers", inputs), ("timer_receivers", set(timers))):
        receivers = graph[field]
        if not isinstance(receivers, dict) or set(receivers) != expected:
            fail(f"{field}: explicitly address every binding")
        for binding, receiver in receivers.items():
            if receiver is None and field == "timer_receivers" and timers[binding]["event_type"] != "time.state_entry_elapsed":
                continue
            if not isinstance(receiver, str) or receiver not in machines:
                fail(f"{binding}: unknown receiving machine")
    action_properties = {"object.set_position": ("x", "y"), "object.move_by": ("x", "y"),
                         "object.set_visibility": ("visible",), "object.set_frame": ("visual_ref",),
                         "object.clear_frame": ("visual_ref",), "object.select_visual": ("visual_ref",),
                         "object.set_inversion": ("inverted",)}

    def check_action(action, owner):
        if not isinstance(action, dict):
            fail("action must be an object")
        kind = action.get('kind')
        if kind in ('menu.open', 'menu.close'):
            from .execution_scope_source import validate_action
            validate_action(graph, action, owner, scene.get('menu_component'))
        elif kind == 'scene.set_inversion':
            shape(action, {'kind', 'mode'})
            if action['mode'] not in ('normal', 'inverted', 'toggle') or owner not in machines:
                fail('scene inversion requires a machine owner and normal/inverted/toggle mode')
            require_writer(('scene', 'inversion'), owner)
        elif kind in ('object.play_clip', 'object.cancel_clip'):
            shape(action, {'kind', 'object_ref'} | ({'animation_ref', 'end_policy'} if kind == 'object.play_clip' else set()),
                  {'completion'} if kind == 'object.play_clip' else set())
            require_writer(('object', ident(action['object_ref']), 'visual_ref'), owner)
            if kind == 'object.play_clip':
                ident(action['animation_ref'])
                if action['end_policy'] not in ('restore', 'hold_last'):
                    fail('clip end policy must be restore or hold_last')
                if 'completion' in action:
                    completion = action['completion']
                    shape(completion, {'machine_ref', 'event_ref'})
                    if ident(completion['machine_ref']) not in machines or ident(completion['event_ref']) not in events:
                        fail('unknown clip completion recipient or named event')
        elif kind == 'object.play_effect':
            from .object_effects import EffectSpec, INVERT, SHAKE
            shape(action, {'kind', 'object_ref', 'effect', 'duration_ms', 'step_ms'},
                  {'amplitude', 'completion'})
            require_writer(('effect', ident(action['object_ref'])), owner)
            if owner not in machines:
                fail('effect actions require a machine owner')
            if action['effect'] not in ('invert', 'shake'):
                fail('unsupported object effect')
            if not EffectSpec(INVERT if action['effect'] == 'invert' else SHAKE,
                              action['duration_ms'], action['step_ms'], action.get('amplitude', 0)).valid():
                fail('invalid effect duration, step or amplitude')
            if 'completion' in action:
                completion = action['completion']
                shape(completion, {'machine_ref', 'event_ref'})
                if ident(completion['machine_ref']) not in machines or ident(completion['event_ref']) not in events:
                    fail('unknown effect completion recipient or named event')
        elif kind == 'run_flowchart':
            shape(action, {'kind', 'flowchart_ref'})
            if owner not in machines or ident(action['flowchart_ref']) not in definitions:
                fail('flowchart calls require a machine caller and existing flowchart')
        elif kind == 'send_event':
            shape(action, {'kind', 'machine_ref', 'event_ref'})
            if ident(action['machine_ref']) not in machines or ident(action['event_ref']) not in events:
                fail('unknown addressed event or recipient')
        elif kind == 'set_variable':
            require_writer(('variable', action.get('variable_scope', 'scene'), ident(action.get('variable_ref'))), owner)
        elif kind in action_properties:
            if kind == 'object.select_visual':
                shape(action, {'kind', 'object_ref'}, {'animation_ref', 'visual_ref'})
                if not isinstance(owner, tuple) or ('animation_ref' in action) == ('visual_ref' in action):
                    fail('select_visual requires a flowchart owner and exactly one visual')
                ident(action.get('animation_ref', action.get('visual_ref')))
            for prop in action_properties[kind]:
                if kind == 'object.set_position' and prop not in action:
                    continue
                if kind == 'object.move_by' and 'd' + prop not in action:
                    continue
                require_writer(('object', ident(action.get('object_ref')), prop), owner)
        elif kind in {'start_timer', 'restart_timer', 'cancel_timer'}:
            timer = timers.get(ident(action.get('timer_ref')))
            if timer is None or timer['event_type'] != 'time.scene_elapsed':
                fail('timer control must reference an authored scene timer')
        elif owner is None:
            fail('scene schedule handlers may only manage timers and send events')
        elif isinstance(owner, tuple) and kind not in {'play_sfx', 'request_render'}:
            fail('unsupported flowchart action')

    for ref, chart in definitions.items():
        for action in flowcharts.actions(chart):
            check_action(action, ('flowchart', ref))
    for route in routes.values():
        from .execution_scope_source import validate_route
        validate_route(route)
        shape(route, {"route_id", "machine_ref", "event_ref", "from_states", "guards"},
              {"actions", "target_state", "target_scene", "scene_exit_ref", "outcomes"})
        machine = route["machine_ref"]
        if machine is not None and (not isinstance(machine, str) or machine not in machines):
            fail("unknown route machine")
        event = ident(route["event_ref"])
        if "target_scene" in route and "scene_exit_ref" not in route:
            fail("machine scene exits must reference a declared scene exit")
        receivers = {**graph["input_receivers"], **graph["timer_receivers"]}
        if event not in events and (event not in receivers or receivers[event] != machine):
            fail("route receiver does not match its input/timer binding")
        if event in events and machine is None:
            fail("named events require a machine recipient")
        refs = route["from_states"]
        if not isinstance(refs, list) or (machine is None and refs) or (machine is not None and not refs) or any(not isinstance(s, str) or state_owners.get(s) != machine for s in refs):
            fail("transition source states must belong to the receiving machine")
        if "outcomes" in route:
            if route.keys() & {"actions", "target_state", "target_scene", "scene_exit_ref"}:
                fail("weighted routes put actions and targets inside outcomes")
            outcomes = route["outcomes"]
            if not isinstance(outcomes, list) or not 1 <= len(outcomes) <= 8:
                fail("weighted route requires 1..8 outcomes")
            total = 0
            for outcome in outcomes:
                shape(outcome, {"weight", "actions"}, {"target_state"})
                if type(outcome["weight"]) is not int or not 1 <= outcome["weight"] <= 100:
                    fail("weight must be an integer percentage in 1..100")
                total += outcome["weight"]
            if total > 100:
                fail("outcome weights exceed 100 percent")
        else:
            if "actions" not in route:
                fail("route requires actions")
            outcomes = [route]
        for outcome in outcomes:
            if not isinstance(outcome['actions'], list) or len(outcome['actions']) > 8:
                fail('at most eight ordered actions are supported')
            if outcome.keys() & {'target_scene', 'scene_exit_ref'}:
                exits = {e['scene_exit_id']: e['target_scene'] for e in scene.get('scene_exits', [])}
                if (machine is None or 'target_state' in outcome or
                        outcome.get('scene_exit_ref') not in exits or
                        outcome.get('target_scene') != exits[outcome['scene_exit_ref']]):
                    fail('Scene exit requires a machine receiver and matching declared Scene destination')
                if len(outcome.get('actions', [])) > 7:
                    fail('Scene exit supports at most seven actions before its destination request')
                if any(isinstance(a, dict) and a.get('kind') == 'exit_to_shell' for a in outcome['actions']):
                    fail('Scene replacement cannot also suspend into the shell')
            if "target_state" in outcome and (machine is None or state_owners.get(ident(outcome["target_state"])) != machine):
                fail("transition wires cannot cross machine boundaries", "MACHINE_CROSS_TRANSITION")
            for action in outcome["actions"]:
                check_action(action, machine)
                kind = action.get("kind")
    for binding, receiver in graph["timer_receivers"].items():
        if receiver is None and sum(r["event_ref"] == binding for r in routes.values()) != 1:
            fail(f"{binding}: a scene-level schedule requires exactly one handler")
    if "scene_activated" in graph:
        activation = graph["scene_activated"]
        pending, reached = [(activation["machine_ref"], activation["event_ref"])], set()
        while pending:
            address = pending.pop()
            if address in reached:
                continue
            reached.add(address)
            for route in routes.values():
                if (route["machine_ref"], route["event_ref"]) != address:
                    continue
                for outcome in route.get("outcomes", [route]):
                    actions = list(outcome["actions"])
                    for action in outcome["actions"]:
                        if action["kind"] == "run_flowchart":
                            actions.extend(flowcharts.actions(definitions[action["flowchart_ref"]]))
                    if outcome.keys() & {"target_scene", "scene_exit_ref"} or any(a["kind"] == "exit_to_shell" for a in actions):
                        fail("scene activation chains cannot leave or suspend the scene")
                    pending.extend((a["machine_ref"], a["event_ref"]) for a in actions if a["kind"] == "send_event")
    # Merge every alternative for an address, including sends hidden by a call.
    adjacency = {}
    for route in routes.values():
        targets = adjacency.setdefault((route['machine_ref'], route['event_ref']), set())
        for outcome in route.get('outcomes', [route]):
            actions = list(outcome['actions'])
            for action in outcome['actions']:
                if action['kind'] == 'run_flowchart':
                    actions.extend(flowcharts.actions(definitions[action['flowchart_ref']]))
            targets.update((a['machine_ref'], a['event_ref']) for a in actions if a['kind'] == 'send_event')
    cycle = find_cycle(adjacency)
    if cycle:
        path = ' -> '.join(f'{machine}.{event}' for machine, event in cycle)
        fail(f'immediate event cycles are unsupported: {path}', 'MACHINE_EVENT_CYCLE')
    from .scene_exit_analysis import definite_conflicts
    conflicts = definite_conflicts(graph)
    if conflicts:
        route, destinations = conflicts[0]
        fail(f"Scene exit conflict in route '{route}': enters different Scenes {', '.join(destinations)} in one event chain",
             'MACHINE_SCENE_EXIT_CONFLICT')
    layout = graph.get("layout", {})
    if not isinstance(layout, dict) or set(layout) - set(machines):
        fail("layout must be keyed by stable machine IDs")
    for position in layout.values():
        shape(position, {"x", "y"})
        if any(type(v) is not int or not -100000 <= v <= 100000 for v in position.values()):
            fail("layout coordinates must be bounded integers")


def project_scene(scene):
    """Use existing action/guard compiler, with private non-exportable route bindings."""
    if "machine_logic" not in scene:
        return scene
    from .world_logic_source import project as project_world
    from .inventory_conditions import proof_scene
    scene = project_world(proof_scene(scene)).scene
    result = deepcopy(scene)
    graph = result.pop("machine_logic")
    if result['entry_state'] is None:
        # Private transport record only. Runtime machine state never aliases it.
        used_states = {s['state_id'] for s in result['states']}
        anchor = 'preview.scene'
        suffix = 0
        while anchor in used_states:
            suffix += 1
            anchor = f'preview.scene.{suffix}'
        result['states'].append(dict(state_id=anchor, display_name='Scene', object_overrides=[]))
        result['entry_state'] = anchor
    from .response_conditions import is_guard
    result["routes"], result["event_handlers"] = [], []
    bindings = result.setdefault("event_bindings", [])
    used = {b["binding_id"] for b in bindings} | {b["action_id"] for b in result["input_actions"]}
    for binding in bindings:
        if binding["event_type"] in {"time.scene_elapsed", "time.local_schedule"}:
            result["event_handlers"].append({"handler_id": binding["binding_id"],
                                             "event_ref": binding["binding_id"], "guards": [], "actions": []})
    for ri, route in enumerate(graph["routes"]):
        for oi, outcome in enumerate(route.get("outcomes", [route])):
            key = f"machine.{ri}.{oi}"
            if key in used:
                fail(f"reserved preview binding collision: {key}")
            used.add(key)
            bindings.append({"binding_id": key, "event_type": "time.scene_elapsed",
                             "configuration": {"delay_ms": 10, "start_policy": "action"}})
            result["event_handlers"].append({
                "handler_id": key, "event_ref": key,
                "guards": deepcopy([g for g in route['guards'] if not is_guard(g)]),
                "actions": [flowcharts.project_action(a) for a in outcome["actions"]],
                **{k: outcome[k] for k in ("target_state", "target_scene", "scene_exit_ref") if k in outcome},
            })
    for key, guards, actions in flowcharts.records_for_projection(scene):
        if key in used:
            fail(f'reserved preview binding collision: {key}')
        used.add(key)
        bindings.append(dict(binding_id=key, event_type='time.scene_elapsed', configuration=dict(delay_ms=10, start_policy='action')))
        result['event_handlers'].append(dict(handler_id=key, event_ref=key, guards=deepcopy(guards),
                                             actions=[flowcharts.project_action(a) for a in actions]))
    if len(used) > CAPABILITY['maximum_lowered_bindings']:
        fail('machine preview exceeds the host projection budget', 'MACHINE_BUDGET')
    return result


def apply_command(scenes, command):
    from .project import _require_command_fields, _command_scene
    setting = command["kind"] == "scene.machines.set"
    required = {"kind", "scene_id"} | ({"machine_logic"} if setting else set())
    _require_command_fields(command, required, required | {"command_id"})
    scene = _command_scene(scenes, command["scene_id"])
    if setting:
        scene["machine_logic"] = deepcopy(command["machine_logic"])
    else:
        scene.pop("machine_logic", None)
    return deepcopy(command)


def sample_delay(seed, minimum, maximum=None):
    """Native inclusive one-shot sampler; no draw for fixed or equal bounds."""
    if maximum is None or maximum == minimum:
        return seed, minimum
    width = maximum - minimum + 1
    limit = 0xffffffff - 0xffffffff % width
    for _ in range(16):
        seed ^= (seed << 13) & 0xffffffff
        seed ^= seed >> 17
        seed ^= (seed << 5) & 0xffffffff
        if 0 < seed <= limit:
            return seed, minimum + (seed - 1) % width
    from .preview import PreviewError
    raise PreviewError('machine random delay admission exhausted')


def sample_percent(seed):
    """Uniform over 0..99 for nonzero xorshift32 states; bounded rejection."""
    for _ in range(16):
        seed ^= (seed << 13) & 0xffffffff
        seed ^= seed >> 17
        seed ^= (seed << 5) & 0xffffffff
        if seed <= 4294967200:
            return seed, (seed - 1) % 100
    from .preview import PreviewError
    raise PreviewError("machine random range admission exhausted")
