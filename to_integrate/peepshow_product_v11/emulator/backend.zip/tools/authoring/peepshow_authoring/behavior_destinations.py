"""Self-relative checked destinations in reusable behavior responses.

Uses the existing query operands and transaction journal. No retained result,
extra machine, or hidden event is introduced. Only private copies are lowered.
"""
from .destination_source import DestinationError
from .scene_collision_source import DIRECTIONS

CAPABILITY = dict(host_editing=True, host_preview=True, persisted=True, undo_redo=True,
    runtime=False, export=False, hardware_validation='not_qualified', source_version=3,
    field='behaviors[].destinations', schema='schemas/authoring/behavior-destination-v1.schema.json',
    command_schema='schemas/authoring/behavior-destination-command-v1.schema.json',
    commands=['scene.behavior.destination.set', 'scene.behavior.destination.remove', 'scene.response.set'],
    actor='self', grid='enclosing_map_scene', maximum_destinations=128,
    cell_kinds=['adjacent', 'cell'], directions=list(DIRECTIONS), facing_relative=True,
    facing_reference_field='cell.facing_ref', explicit_cell=True,
    guard_kinds=['destination.clear', 'destination.blocked'], action_kind='destination.move',
    check_lifetime='same_response_path', check_across_events=False,
    invalidating_writes='position_occupancy_or_used_facing', out_of_bounds='blocked', failed_query='reject_transaction',
    implicit_facing=False, implicit_turn=False, validation_error='INSTANCE_SOURCE_INVALID',
    command_error='DESTINATION_INVALID', map_error='MAP_SCENE_INVALID')
COMMANDS = tuple(CAPABILITY['commands'][:2])


def lower(source, grid, facings):
    """After response/port/facing lowering; return extra queries and move identities."""
    from .project import STABLE_ID
    rows = source.pop('destinations', [])
    path = f"behavior[{source['behavior_id']}].destinations"

    def require(ok, message):
        if not ok:
            raise DestinationError(f'{path}: {message}')

    require(type(rows) is list and len(rows) <= 128, 'requires at most 128 declarations')
    graph = source['machine_logic']
    names, pending = set(), [source, rows]
    while pending:
        value = pending.pop()
        if type(value) is str:
            names.add(value)
        elif type(value) is dict:
            pending.extend(value.values())
        elif type(value) is list:
            pending.extend(value)
    kinds = {'destination.clear', 'destination.blocked', 'destination.move'}
    used_operations = any(item.get('kind') in kinds for route in graph['routes']
                          for item in [*route.get('guards', []), *route.get('actions', [])] if type(item) is dict)
    if not rows and not used_operations:
        return [], {}
    require(isinstance(grid, (tuple, list)) and len(grid) == 2 and
            all(type(n) is int and n > 0 for n in grid), 'requires the enclosing map grid')
    coordinates = []
    for field in ('entity_x', 'entity_y'):
        matches = [p for p in source['properties'] if p.get('owner') == 'self' and p.get('field') == field]
        require(len(matches) == 1 and matches[0]['value_type'] == 'int32', 'requires one Self X/Y property pair')
        coordinates.append(matches[0])
    x, y = (p['name'] for p in coordinates)
    width, height = grid
    destinations, queries, moves, dependencies = {}, [], {}, {}
    for row in rows:
        require(type(row) is dict and set(row) == {'destination_id', 'cell', 'include_actors'},
                'requires destination_id, cell and include_actors')
        ref, cell = row['destination_id'], row['cell']
        require(type(ref) is str and STABLE_ID.fullmatch(ref) and ref not in destinations,
                'invalid or duplicate destination_id')
        require(type(row['include_actors']) is bool and type(cell) is dict, f'{ref}: invalid cell/actor policy')
        facing = cell.get('kind') == 'adjacent' and cell.get('direction') == 'facing'
        absolute = cell.get('kind') == 'cell'
        if facing:
            require(set(cell) == {'kind', 'direction', 'facing_ref'} and type(cell['facing_ref']) is str
                    and cell['facing_ref'] in facings, f'{ref}: requires a named Self facing property')
            dx, dy, query_kind = cell['facing_ref'], 0, 3 + int(row['include_actors'])
        elif absolute:
            require(set(cell) == {'kind', 'x', 'y'} and all(type(cell[a]) is int and
                    -2**31 <= cell[a] < 2**31 for a in ('x', 'y')), f'{ref}: invalid explicit grid cell')
            dx, dy, query_kind = cell['x'], cell['y'], 5 + int(row['include_actors'])
            require(-2**31 <= dx * width < 2**31 and -2**31 <= dy * height < 2**31,
                    f'{ref}: grid cell exceeds coordinate range')
        else:
            require(set(cell) == {'kind', 'direction'} and cell['kind'] == 'adjacent' and
                    type(cell['direction']) is str and cell['direction'] in DIRECTIONS, f'{ref}: invalid adjacent direction')
            dx, dy = DIRECTIONS[cell['direction']]
            query_kind = row['include_actors']
        query = 'ps_behavior_destination_0'
        while query in names:
            query = 'ps_behavior_destination_' + str(int(query.rsplit('_', 1)[1]) + 1)
        names.add(query)
        queries.append((query, x, y, width, height, dx, dy, query_kind))
        destinations[ref] = (query, facing or absolute, x if facing or absolute or dx else y,
                             0 if facing or absolute else dx * width or dy * height)
        dependencies[ref] = {x, y}
        if row['include_actors']:
            dependencies[ref].update(p['name'] for p in source['properties'] if p['value_type'] == 'bool')
        if facing:
            dependencies[ref].add(cell['facing_ref'])

    def selected(item):
        ref = item.get('destination_ref')
        require(set(item) == {'kind', 'destination_ref'} and type(ref) is str and ref in destinations,
                'requires a declared destination_ref and no extra fields')
        return ref

    for route in graph['routes']:
        proven = set()
        for i, guard in enumerate(route['guards']):
            if guard.get('kind') in ('destination.clear', 'destination.blocked'):
                ref = selected(guard)
                blocked = guard['kind'] == 'destination.blocked'
                if not blocked:
                    proven.add(ref)
                route['guards'][i] = dict(kind='collision.compare', query_ref=destinations[ref][0], operator='eq', value=blocked)
        for i, action in enumerate(route['actions']):
            if action.get('kind') == 'destination.move':
                ref = selected(action)
                require(ref in proven, f"{route['route_id']}.actions[{i}]: {ref}: move requires a clear check on this path after the last position/occupancy/used-facing write")
                query, dynamic, coordinate, amount = destinations[ref]
                require(all(p['writable'] for p in coordinates) if dynamic else
                        next(p['writable'] for p in coordinates if p['name'] == coordinate), f'{ref}: move requires writable Self coordinates')
                replacement = dict(kind='property.add', property_ref=coordinate, value=amount)
                route['actions'][i] = replacement
                if dynamic:
                    moves[id(replacement)] = query
                proven.clear()
            elif action.get('kind') == 'run_flowchart':
                proven.clear()
            elif action.get('kind') in ('property.set', 'property.add'):
                proven.difference_update(ref for ref in list(proven) if action.get('property_ref') in dependencies[ref])
    return queries, moves


def apply_command(scenes, command):
    from copy import deepcopy
    from .project import _command_scene, _require_command_fields, ProjectCommandError
    setting = command['kind'] == COMMANDS[0]
    required = {'kind', 'scene_id', 'behavior_ref', 'destination' if setting else 'destination_id'}
    _require_command_fields(command, required, required | {'command_id'})
    graph = _command_scene(scenes, command['scene_id']).get('machine_logic', {})
    source = graph.get('instance_behaviors', {})
    behavior = next((b for b in source.get('behaviors', []) if b['behavior_id'] == command['behavior_ref']), None)
    if source.get('version') != 3 or behavior is None:
        raise ProjectCommandError('DESTINATION_INVALID', 'Requires an existing version-3 behavior')
    row = command.get('destination')
    ref = row.get('destination_id') if setting and type(row) is dict else command.get('destination_id')
    if type(ref) is not str or not ref:
        raise ProjectCommandError('DESTINATION_INVALID', 'Requires destination_id')
    rows = behavior.setdefault('destinations', [])
    index = next((i for i, r in enumerate(rows) if r['destination_id'] == ref), None)
    if setting:
        if index is None:
            rows.append(deepcopy(row))
        else:
            rows[index] = deepcopy(row)
    elif index is None:
        raise ProjectCommandError('DESTINATION_INVALID', 'Unknown destination_id')
    else:
        del rows[index]
    return deepcopy(command)
