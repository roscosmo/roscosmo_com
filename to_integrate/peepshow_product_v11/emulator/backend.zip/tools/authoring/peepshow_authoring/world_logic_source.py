"""Authored world operations projected onto the existing private transaction path.

No installed export or public map-preview grant. Names disappear during lowering.
"""
from copy import deepcopy
from dataclasses import dataclass, field, replace

from .imported_properties import ImportedPropertyError
from .world_reference_project import declarations


@dataclass
class Projection:
    scene: dict
    bindings: list
    guards: list
    actions: list
    routes: dict
    flows: dict
    selectors: list = field(default_factory=list)
    selector_guards: dict = field(default_factory=dict)
    positions: list = field(default_factory=list)
    queries: list = field(default_factory=list)
    query_guards: list = field(default_factory=list)
    destination_moves: list = field(default_factory=list)
    instance_source: dict | None = None
    camera: dict | None = None
    camera_actions: dict = field(default_factory=dict)
    visibility: dict | None = None
    visibility_actions: dict = field(default_factory=dict)


def project(scene, *, _execution_scopes=False):
    from .behavior_response import lower_scene
    scene = lower_scene(scene)
    result = Projection(deepcopy(scene), [], [], [], {}, {})
    graph = result.scene.get('machine_logic')
    if graph is None:
        return result
    # Ownership is validated against authored identities in scene_machines.validate.
    # This private structural-validation copy removes instance identities below;
    # do not revalidate authored partitions against that different namespace.
    # Public preview/export entrypoints reject scoped sources before projection.
    graph.pop('execution_scopes', None)
    from .camera_source import configuration as camera_configuration
    result.camera = camera_configuration(graph)
    from .visibility_source import configuration as visibility_configuration
    result.visibility = visibility_configuration(graph)
    camera_graph = deepcopy(graph)  # Only source validation uses this snapshot.
    from .interaction_source import lower as lower_interactions
    lower_interactions(graph)
    from .instance_event_source import lower as lower_instance_events
    result.instance_source = lower_instance_events(graph)
    from .destination_source import lower as lower_destinations
    dynamic_moves = lower_destinations(graph)
    refs = {name: (ref, kind) for name, ref, kind in declarations(graph)}
    from .scene_collision_source import declarations as collision_queries
    result.queries = collision_queries(result.scene, refs)
    from .facing_source import lower_scene as lower_facing
    lower_facing(graph)
    # Validated separately against the complete project by instance_project.
    # Ordinary/public execution must pass its explicit readiness gate.
    graph.pop('instance_behaviors', None)
    from .world_position_source import declarations as positions
    result.positions = positions(scene)
    graph.pop('world_positions', None)
    graph.pop('map_scene', None)
    graph.pop('collision_queries', None)
    machines = {m['machine_id'] for m in graph['machines']}
    flows = {f['flowchart_id'] for f in graph.get('flowcharts', [])}
    owners, targets = {}, set()

    def fail(message):
        raise ImportedPropertyError(message)

    for row in graph.get('world_references', []):
        identity = row['reference_id']
        ref, kind = refs[identity]
        if ref in targets:
            fail('duplicate world target declaration; reuse its reference_id')
        targets.add(ref)
        writer = row.get('writer')
        owner = None
        if writer is not None:
            if type(writer) is not dict or set(writer) != {'kind', 'id'}:
                fail('world writer requires kind and id')
            category, name = writer['kind'], writer['id']
            if type(category) is not str or type(name) is not str or category not in ('machine', 'flow'):
                fail('invalid world writer')
            if name not in (machines if category == 'machine' else flows):
                fail('unknown world writer')
            owner = (category, name)
        owners[identity] = owner
        result.bindings.append((ref, kind, owner))
    graph.pop('world_references', None)

    def operand(value, owner=None, action=False):
        if not action and type(value) is dict and value.get('kind') == 'collision.compare':
            if (set(value) != {'kind', 'query_ref', 'operator', 'value'} or
                    type(value['query_ref']) is not str or
                    value['query_ref'] not in {q[0] for q in result.queries} or
                    value['operator'] not in ('eq', 'ne') or type(value['value']) is not bool):
                fail('collision.compare requires a declared Scene query and Boolean EQ/NE')
            record = (value['query_ref'], value['operator'], value['value'])
            for name, *prior in result.query_guards:
                if tuple(prior) == record:
                    return name
            name = f'qg{len(result.query_guards)}'
            result.query_guards.append((name, *record))
            return name
        copying = action and type(value) is dict and value.get('kind') in ('world.copy', 'world.subtract')
        fields = {'kind', 'reference_ref', 'source_ref' if copying else 'value'} | (set() if action else {'operator'})
        if type(value) is not dict or set(value) != fields:
            fail('invalid world operand fields')
        identity = value['reference_ref']
        if type(identity) is not str or identity not in refs:
            fail('unknown world reference_ref')
        ref, kind = refs[identity]
        op = value['kind'].removeprefix('world.') if action else value['operator']
        literal = value.get('value')
        allowed = ('set', 'add', 'copy', 'min', 'max', 'subtract') if action else ('eq', 'ne', 'lt', 'le', 'gt', 'ge')
        if type(op) is not str or op not in allowed:
            fail('invalid world operator')
        if copying:
            source = value['source_ref']
            if (type(source) is not str or source not in refs or
                    kind != 'int32' or refs[source][1] != 'int32'):
                fail('world copy requires declared integer source and destination')
            literal = refs[source][0]
        elif type(literal) is not (bool if kind == 'bool' else int):
            fail('world literal has the wrong primitive type')
        if not copying and kind == 'int32' and not -(2**31) <= literal < 2**31:
            fail('world literal is outside int32')
        if kind == 'bool' and op not in (('set',) if action else ('eq', 'ne')):
            fail('boolean world operands allow SET and EQ/NE only')
        if action:
            if owner is None or owners[identity] != owner:
                fail('world action does not belong to the declared writer')
            if value['kind'] != 'world.' + op:
                fail('world action kind and operator disagree')
            name = f'a{len(result.actions)}'
            result.actions.append((name, ref, owner, op.upper(), literal))
            if id(value) in dynamic_moves:
                result.destination_moves.append((name, dynamic_moves[id(value)]))
        else:
            if value['kind'] != 'world.compare':
                fail('invalid world guard kind')
            for name, prior_ref, prior_op, prior_value in result.guards:
                if (prior_ref, prior_op, prior_value) == (ref, op.upper(), literal):
                    return name
            name = f'g{len(result.guards)}'
            result.guards.append((name, ref, op.upper(), literal))
        return name

    def actions(rows, owner, location):
        if type(rows) is not list or len(rows) > 8:
            fail('at most eight ordered actions are supported')
        ordinary, inserts = [], []
        for row in rows:
            kind = row.get('kind') if isinstance(row, dict) else None
            if isinstance(kind, str) and kind.startswith('world.'):
                inserts.append((len(ordinary), operand(row, owner, True)))
            elif isinstance(kind, str) and kind.startswith('camera.'):
                from .camera_source import action as camera_action
                result.camera_actions.setdefault(location, {})[len(ordinary)] = camera_action(row, camera_graph, str(location))
                # A normal presentation action preserves the action slot and
                # bounded accounting. Host metadata supplies its camera command.
                ordinary.append(dict(kind='request_render'))
            elif isinstance(kind, str) and kind.startswith('visibility.'):
                from .visibility_source import action as visibility_action
                result.visibility_actions.setdefault(location, {})[len(ordinary)] = visibility_action(row, camera_graph, str(location))
                ordinary.append(dict(kind='request_render'))
            else:
                ordinary.append(row)
        return ordinary, inserts

    for route in graph['routes']:
        if type(route['guards']) is not list or len(route['guards']) > 8:
            fail('at most eight route guards are supported')
        ordinary, guards = [], []
        for row in route['guards']:
            if isinstance(row, dict) and row.get('kind') in ('world.compare', 'collision.compare'):
                guards.append(operand(row))
            else:
                ordinary.append(row)
        route['guards'] = ordinary
        inserts = []
        for oi, outcome in enumerate(route.get('outcomes', [route])):
            if 'target_scene' in outcome and len(outcome['actions']) > 7:
                fail('Scene exit supports at most seven actions')
            outcome['actions'], addition = actions(outcome['actions'],
                ('machine', route['machine_ref']) if route['machine_ref'] is not None else None,
                ('route', route['route_id'], oi))
            inserts.append(addition)
        result.routes[route['route_id']] = dict(guards=guards, actions=inserts)
    from .flowcharts import predicate_size, predicate_leaves
    for chart in graph.get('flowcharts', []):
        nodes = {}
        for node in chart['nodes']:
            if node['kind'] == 'actions':
                node['actions'], inserts = actions(node['actions'], ('flow', chart['flowchart_id']),
                                                   ('flow', chart['flowchart_id'], node['node_id']))
                nodes[node['node_id']] = dict(actions=inserts)
            elif node['kind'] == 'decision':
                rows = []
                for branch in node['branches']:
                    added = branch.pop('world_guards', [])
                    if type(added) is not list:
                        fail('world_guards must be an array')
                    predicate_leaves(branch['when'])
                    if predicate_size(branch['when']) + 2 * len(added) > 16:
                        fail('flow predicate capacity exceeded')
                    rows.append([operand(g) for g in added])
                nodes[node['node_id']] = dict(guards=rows)
        result.flows[chart['flowchart_id']] = nodes
    # Preserve original predicates separately. The ordinary validator/compiler
    # receives shape-equivalent State leaves, never a public world export grant.
    # Typed world leaves are validated here and compiled only by the private adapter.
    result.selectors = deepcopy(graph.get('presentation_selectors', []))
    def selector_operand(value):
        name = operand(value)
        result.selector_guards[(value['reference_ref'], value['operator'], value['value'])] = name

    def ordinary(value):
        if value.get('kind') == 'world.compare':
            machine = graph['machines'][0]
            return dict(machine_ref=machine['machine_id'], state_ref=machine['entry_state'])
        if 'not' in value:
            return {**value, 'not': ordinary(value['not'])}
        for op in ('all', 'any'):
            if op in value:
                return {**value, op: [ordinary(v) for v in value[op]]}
        return value

    # Scoped-variable and structural checks remain with the normal validator.
    def check(value, depth=0):
        if depth > 8:
            fail('selector predicate nesting exceeds eight levels')
        if not isinstance(value, dict):
            fail('invalid selector predicate')
        if value.get('kind') == 'world.compare':
            selector_operand(value)
        elif 'not' in value:
            check(value['not'], depth+1)
        else:
            for op in ('all', 'any'):
                if op in value:
                    if not isinstance(value[op], list) or not 2 <= len(value[op]) <= 8:
                        fail('selector all/any requires two to eight predicates')
                    for child in value[op]:
                        check(child, depth+1)

    for selector in graph.get('presentation_selectors', []):
        for rule in selector.get('rules', []):
            if 'when' in rule:
                check(rule['when'])
                rule['when'] = ordinary(rule['when'])
    if _execution_scopes and 'execution_scopes' in scene.get('machine_logic', {}):
        graph['execution_scopes'] = deepcopy(scene['machine_logic']['execution_scopes'])
        # This ordinary-logic projection has no instance declarations. The map
        # compiler retains the full authored partition for final SCP1 encoding.
        for scope in ('gameplay', 'menu'):
            graph['execution_scopes'][scope]['instances'] = []
    return result


def prepare(bundle, scene_id, *, _execution_scopes=False):
    """Return projected bundle, world tables and attachments for one map Scene."""
    from .world_references import compile_references
    from .scene_machines import validate
    if not bundle.valid:
        raise ImportedPropertyError('project must validate')
    scene = next(s for s in bundle.scenes if s['scene_id'] == scene_id)
    validate(bundle.project, scene)
    projected = project(scene, _execution_scopes=_execution_scopes)
    assets = {ref.asset_id for ref, _, _ in projected.bindings} | {r['asset_id'] for r in projected.positions}
    if len(assets) != 1:
        raise ImportedPropertyError('private world logic requires exactly one map asset')
    records = [r for c in bundle.asset_catalogs for r in c.get('map_assets', []) if r['asset_id'] in assets]
    if len(records) != 1:
        raise ImportedPropertyError('missing or ambiguous world map')
    graph = projected.scene['machine_logic']
    record = records[0]
    if 'map_scene' in scene['machine_logic']:
        from .map_scene_source import visual_record
        record = visual_record(record, scene['machine_logic']['map_scene'])
    lowered = compile_references(record, bundle.root, projected.bindings, projected.guards, projected.actions,
        [m['machine_id'] for m in graph['machines']], [f['flowchart_id'] for f in graph.get('flowcharts', [])])
    from .scene_collision_source import lower as lower_queries
    lowered = lower_queries(lowered, projected.queries, projected.query_guards, projected.destination_moves)
    scenes = tuple(project(s, _execution_scopes=_execution_scopes).scene for s in bundle.scenes)
    return replace(bundle, scenes=scenes), lowered, projected


def compile_source(bundle, scene_id):
    from .world_routes import compile_world_machine_logic
    projected, lowered, source = prepare(bundle, scene_id)
    payload = compile_world_machine_logic(projected, scene_id, lowered, source.routes,
        flow_attachments=source.flows, _flowcharts=True, _object_effects=True, _calendars=True, _periodic=True)
    return payload, lowered


def selector_data(source, lowered):
    return source.selectors, {key: lowered.guard_sources.index(name)
                              for key, name in source.selector_guards.items()}


def compile_position_source(bundle, scene_id):
    from .world_position_source import lower
    _, lowered, source = prepare(bundle, scene_id)
    return lower(source.scene, lowered.map, source.positions), lowered


def compile_selector_source(bundle, scene_id):
    """Private selector bytes + matching WOP1 tables; not an installed package."""
    from .presentation_selectors import compile_selectors
    projected, lowered, source = prepare(bundle, scene_id)
    scene = deepcopy(source.scene)
    selectors, indices = selector_data(source, lowered)
    scene['machine_logic']['presentation_selectors'] = selectors
    return compile_selectors(projected, scene, _world_guard=lambda v:
        indices[(v['reference_ref'], v['operator'], v['value'])]), lowered


def preview_source(bundle, scene_id, *, write_capacity):
    """Private logic-only preview, not map rendering or installed lifecycle."""
    from .world_preview import create_world_preview
    projected, lowered, source = prepare(bundle, scene_id)
    if any('target_scene' in outcome for route in source.scene['machine_logic']['routes']
           for outcome in route.get('outcomes', [route])):
        raise ImportedPropertyError('private world source preview does not support Scene replacement yet')
    # Only this explicit private adapter omits map catalogs from ordinary visual
    # package construction. The original bundle and public export gates stay intact.
    catalogs = tuple({k: v for k, v in c.items() if k != 'map_assets'} for c in projected.asset_catalogs)
    projected = replace(projected, asset_catalogs=catalogs)
    return create_world_preview(projected, scene_id, lowered, source.routes,
        flow_attachments=source.flows, write_capacity=write_capacity,
        selector_data=selector_data(source, lowered), position_source=source.positions)
