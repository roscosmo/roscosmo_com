"""Editable event response graphs, lowered privately to bounded local routes.

Legacy decisions precede effects, matching the existing leaf executor.
The terminal-order adapter also uses this grammar for admission, but executes
individual nodes without hoisting their decisions.
"""
from copy import deepcopy
from .response_preview import CAPABILITY as TRACE_CAPABILITY
from . import response_conditions

COMMANDS = ('scene.response.set', 'scene.response.remove')

CAPABILITY = dict(field='behaviors[].machine_logic.routes[].response',
    schema='schemas/authoring/behavior-response-v1.schema.json', source_version=3,
    node_kinds=['decision', 'actions', 'return'], conditions=['collision.compare', 'adjacency.compare', 'property.compare', 'destination.clear', 'destination.blocked'],
    branch_fields=['when_true', 'when_false'], branch_labels=True,
    return_target='target_state', omitted_target='stay', terminal_kinds=['stay','state'], maximum_nodes=32,
    maximum_paths=32, maximum_decisions_per_path=8, maximum_actions_per_path=8,
    decisions_after_actions=False, cycles=False, nested_calls=False,
    host_editing=True, host_preview=True, persisted=True, undo_redo=True,
    preview_trace=TRACE_CAPABILITY,
    runtime=False, export=False, hardware_validation='not_qualified',
    commands=[*COMMANDS, 'scene.machines.set'], ordinary_scene_flows='unchanged',
    command_schema='schemas/authoring/event-response-command-v1.schema.json',
    editing=dict(unit='one_handler', behavior_address='behavior_ref',
                 validation='atomic_command_batch', legacy_conversion='explicit_replace_legacy',
                 implicit_machine_or_event_creation=False))


def lower_behavior(behavior, version, *, ordinary=False, source_map=None, terminal_order=False):
    result = deepcopy(behavior)
    graph = result.get('machine_logic', {})
    routes = graph.get('routes', [])
    expanded = []
    used = {r.get('route_id') for r in routes if type(r) is dict and type(r.get('route_id')) is str}
    for route in routes:
        if type(route) is not dict or 'response' not in route:
            expanded.append(route)
            continue
        context = 'scene' if ordinary else 'behavior'
        path = f"{context}[{result.get('behavior_id')}].routes[{route.get('route_id')}].response"
        def check(ok, message):
            if not ok:
                raise ValueError(f'{path}: {message}')
        check(version == 3, 'requires source version 3')
        check(set(route) == {'route_id', 'machine_ref', 'event_ref', 'from_states', 'response'},
              'response replaces route guards/actions/destination; put these inside its nodes')
        check(type(route['from_states']) is list and all(type(s) is str for s in route['from_states']),
              'from_states must be State names')
        for other in routes:
            if other is route or type(other) is not dict:
                continue
            check(not (other.get('machine_ref') == route['machine_ref'] and
                       other.get('event_ref') == route['event_ref'] and
                       type(other.get('from_states')) is list and
                       any(s in other['from_states'] for s in route['from_states'])),
                  'one response per event and source State; combine alternatives in a decision')
        response = route['response']
        check(type(response) is dict and set(response) == {'root', 'nodes'}, 'requires root and nodes')
        rows = response['nodes']
        check(type(rows) is list and 1 <= len(rows) <= 32, 'requires 1..32 nodes')
        nodes = {}
        for node in rows:
            check(type(node) is dict and type(node.get('node_id')) is str and node['node_id'], 'node requires an identity')
            check(node['node_id'] not in nodes, 'duplicate node identity')
            nodes[node['node_id']] = node
        check(type(response['root']) is str and response['root'] in nodes, 'unknown root')
        pending = [(response['root'], [], [], (), [])]
        reached, leaves = set(), []
        inverse = dict(eq='ne', ne='eq', lt='ge', ge='lt', le='gt', gt='le')
        while pending:
            nid, guards, actions, visited, decisions = pending.pop()
            check(type(nid) is str and nid in nodes, f'unknown edge destination {nid!r}')
            check(nid not in visited, f'cycle at node {nid}')
            check(len(pending) + len(leaves) < 32, 'exceeds 32 paths')
            node = nodes[nid]
            reached.add(nid)
            visited = visited + (nid,)
            kind = node.get('kind')
            if kind == 'decision':
                check(set(node) == {'node_id', 'kind', 'label', 'condition', 'when_true', 'when_false'}, f'{nid}: invalid decision fields')
                check(type(node['label']) is str and 0 < len(node['label']) <= 128, f'{nid}: decision needs a label')
                check(len(guards) < 8, f'{nid}: at most eight decisions per path')
                check(terminal_order or not actions, f'{nid}: decisions must precede actions under this execution contract')
                condition = node['condition']
                check(type(condition) is dict, f'{nid}: invalid condition')
                destination = condition.get('kind') in ('destination.clear', 'destination.blocked')
                key = 'destination_ref' if destination else ('property_ref' if condition.get('kind') == 'property.compare' else 'query_ref')
                if ordinary:
                    if response_conditions.is_condition(condition):
                        try:
                            response_conditions.validate(condition, graph.get('machines', []))
                        except ValueError as exc:
                            check(False, f'{nid}: {exc}')
                    check(response_conditions.is_condition(condition) or
                          ('operator' in condition and type(condition['operator']) is str and condition['operator'] in inverse)
                          or condition.get('kind') in ('destination.clear','destination.blocked'),
                          f'{nid}: condition requires a supported comparison')
                    check(condition.get('kind') not in ('property.compare','adjacency.compare'),
                          f'{nid}: use Scene references in an ordinary response')
                elif destination:
                    check(set(condition) == {'kind', 'destination_ref'}, f'{nid}: invalid destination condition')
                else:
                    check(set(condition) == {'kind', key, 'operator', 'value'} and
                      condition.get('kind') in CAPABILITY['conditions'] and
                      type(condition.get('operator')) is str and condition['operator'] in inverse,
                      f'{nid}: unsupported condition')
                check(ordinary or key != 'query_ref' or (type(condition['value']) is bool and condition['operator'] in ('eq', 'ne')),
                      f'{nid}: spatial condition requires a boolean EQ/NE comparison')
                namespace = ('destinations' if destination else 'properties' if key == 'property_ref' else
                             'collision_queries' if condition.get('kind') == 'collision.compare' else 'adjacency_queries')
                identity = 'destination_id' if destination else 'name' if key == 'property_ref' else 'query_id'
                if not ordinary:
                    check(type(condition[key]) is str and any(type(row) is dict and row.get(identity) == condition[key]
                          for row in result.get(namespace, [])), f'{nid}: unknown {key} {condition[key]!r}')
                for port, negate in [('when_false', True), ('when_true', False)]:
                    edge = node[port]
                    check(type(edge) is dict and set(edge) == {'label', 'next'} and
                          type(edge['label']) is str and 0 < len(edge['label']) <= 128,
                          f'{nid}.{port}: requires label and next')
                    guard = deepcopy(condition)
                    if ordinary and response_conditions.is_condition(condition):
                        guard = dict(kind=response_conditions.GUARD_KIND, condition=guard, expected=not negate)
                    elif negate:
                        if guard.get('kind') in ('destination.clear','destination.blocked'):
                            guard['kind'] = 'destination.blocked' if guard['kind']=='destination.clear' else 'destination.clear'
                        else:
                            guard['operator'] = inverse[guard['operator']]
                    pending.append((edge['next'], guards + [guard], actions, visited,
                                    decisions + [dict(node_id=nid, port=port, label=edge['label'], result=not negate)]))
            elif kind == 'actions':
                check(set(node) == {'node_id', 'kind', 'actions', 'next'} and type(node['actions']) is list,
                      f'{nid}: invalid action node')
                check(len(actions) + len(node['actions']) <= 8, f'{nid}: at most eight actions per path')
                pending.append((node['next'], guards, actions + node['actions'], visited, decisions))
            elif kind == 'return':
                allowed = [{'node_id', 'kind'}, {'node_id', 'kind', 'target_state'}]
                if ordinary:
                    allowed.append({'node_id', 'kind', 'scene_exit_ref', 'target_scene'})
                check(set(node) in allowed, f'{nid}: return requires Stay, State, or an ordinary-machine Scene exit, exclusively')
                terminal = {k: deepcopy(v) for k, v in route.items() if k != 'response'}
                name = f"{route['route_id']}_branch_{len(leaves)}"
                while name in used:
                    name += '_'
                used.add(name)
                terminal.update(route_id=name, guards=guards, actions=deepcopy(actions))
                if 'target_state' in node:
                    check(type(node['target_state']) is str and any(type(s) is dict and s.get('state_id') == node['target_state']
                          for s in result.get('states', [])), f'{nid}: unknown destination State')
                    terminal['target_state'] = node['target_state']
                if 'scene_exit_ref' in node:
                    check(all(type(node[k]) is str and node[k] for k in ('scene_exit_ref','target_scene')),
                          f'{nid}: Scene exit and destination must be nonempty identifiers')
                    terminal.update(scene_exit_ref=node['scene_exit_ref'], target_scene=node['target_scene'])
                leaves.append(terminal)
                if source_map is not None:
                    ending = dict(node_id=nid, kind='stay')
                    if 'target_state' in node:
                        ending.update(kind='state', target_state=node['target_state'])
                    if 'target_scene' in node:
                        ending.update(kind='scene', scene_exit_ref=node['scene_exit_ref'], target_scene=node['target_scene'])
                    source_map[name] = dict(version=1, route_id=route['route_id'],
                        machine_ref=route['machine_ref'], event_ref=route['event_ref'],
                        node_path=list(visited), decisions=deepcopy(decisions), ending=ending)
            else:
                check(False, f'{nid}: unsupported node kind')
        check(reached == set(nodes), 'unreachable nodes')
        expanded.extend(leaves)
    graph['routes'] = expanded
    return result


SCENE_CAPABILITY = dict(CAPABILITY, field='machine_logic.routes[].response',
    schema='schemas/authoring/event-response-v1.schema.json',
    contexts=['ordinary_machine','shared_behavior'],
    triggers=['input','named_event','timer'], terminal_kinds=['stay','state','scene_exit'],
    scene_terminal_fields=['scene_exit_ref','target_scene'], scene_restart='explicit_self_scene_exit',
    conditions=['variable_compare','world.compare','facing.compare','collision.compare','destination.clear','destination.blocked','inventory.compare',
                'machine_state','time_available','time_of_day_range'],
    state_time_conditions=response_conditions.CAPABILITY)
SCENE_CAPABILITY.pop('source_version')  # Version 3 belongs to shared behavior source only.


def lower_scene(scene, *, source_map=None):
    """Use the same graph grammar; ordinary validation enforces Scene ownership."""
    from .actor_output_response import lower as lower_actor_outputs
    scene, actor_outputs = lower_actor_outputs(scene)
    if not any('response' in r for r in scene.get('machine_logic', {}).get('routes', [])):
        return scene
    result = deepcopy(scene)
    holder = dict(behavior_id=scene['scene_id'], states=scene['states'], machine_logic=scene['machine_logic'])
    try:
        result['machine_logic'] = lower_behavior(holder, 3, ordinary=True, source_map=source_map)['machine_logic']
    except ValueError as exc:
        from .imported_properties import ImportedPropertyError
        message = str(exc)
        for name in sorted(actor_outputs, key=len, reverse=True):
            origin = actor_outputs[name]
            message = message.replace(name, f"instance[{origin['instance_ref']}].output_responses[{origin['event_ref']}]")
        raise ImportedPropertyError(message) from exc
    if source_map is not None:
        for selected in source_map.values():
            origin = actor_outputs.get(selected['route_id'])
            if origin is not None:
                selected.update(origin)
    return result


def apply_command(scenes, command):
    """Edit one authored handler without reconstructing its containing graph."""
    from .project import _require_command_fields, _command_scene, ProjectCommandError
    setting = command['kind'] == 'scene.response.set'
    required = {'kind', 'scene_id', 'route' if setting else 'route_id'}
    optional = {'command_id', 'behavior_ref'} | ({'replace_legacy'} if setting else set())
    _require_command_fields(command, required, required | optional)

    def reject(message):
        raise ProjectCommandError('EVENT_RESPONSE_EDIT_INVALID', message)

    scene = _command_scene(scenes, command['scene_id'])
    graph = scene.get('machine_logic')
    if scene.get('schema_version') != 2 or not isinstance(graph, dict):
        reject('Response editing requires an existing version-2 Scene machine graph')
    if 'behavior_ref' in command:
        ref = command['behavior_ref']
        source = graph.get('instance_behaviors', {})
        if type(ref) is not str or source.get('version') != 3:
            reject('Shared response editing requires an explicit behavior_ref and version-3 behavior source')
        behavior = next((b for b in source['behaviors'] if b['behavior_id'] == ref), None)
        if behavior is None:
            reject('Unknown behavior_ref: ' + ref)
        graph = behavior['machine_logic']
    if setting:
        route = command['route']
        fields = {'route_id', 'machine_ref', 'event_ref', 'from_states', 'response'}
        if type(route) is not dict or set(route) - {'trigger_scope'} != fields:
            reject('route requires route_id, machine_ref, event_ref, from_states and response')
        ref = route['route_id']
        if type(command.get('replace_legacy', False)) is not bool:
            reject('replace_legacy must be Boolean')
    else:
        ref = command['route_id']
    if type(ref) is not str or not ref:
        reject('route_id must be nonempty text')
    routes = graph['routes']
    index = next((i for i, r in enumerate(routes) if r['route_id'] == ref), None)
    if index is not None and 'response' not in routes[index]:
        if not setting or not command.get('replace_legacy', False):
            reject('Existing legacy route requires explicit replace_legacy=true when setting a response')
    if setting:
        if index is None:
            routes.append(deepcopy(route))
        else:
            routes[index] = deepcopy(route)
    else:
        if index is None:
            reject('Unknown response route_id: ' + ref)
        del routes[index]
    # Full project validation runs after the command batch, before publication.
    return deepcopy(command)
