"""Direct authored instance inputs lowered to existing bounded event routing.

Only copied compilation graphs are changed. No extra machine, synchronous call,
broadcast, or public device-export permission is introduced.
"""
from .imported_properties import ImportedPropertyError


CAPABILITY = {
    'action_kind': 'send_event',
    'schema': 'schemas/authoring/send-event-v1.schema.json',
    'recipient_fields': ['machine_ref', 'instance_ref'],
    'recipient_count': 1,
    'event_field': 'event_ref',
    'instance_event_namespace': 'recipient_behavior_named_events',
    'locations': ['scene_transition_actions', 'scene_flowchart_actions'],
    'instance_send': {
        'host_editing': True, 'host_preview': True, 'persisted': True,
        'undo_redo': True, 'runtime': False, 'export': False,
        'hardware_validation': 'not_qualified',
        'preview_requires': 'all_scenes_have_map_scene_bindings',
        'author_bridge_required': False,
        'delivery': 'existing_mixed_event_fifo',
        'implicit_broadcast': False, 'synchronous': False,
        'validation_error': 'INSTANCE_EVENT_INVALID',
    },
}


class InstanceEventError(ImportedPropertyError):
    code = 'INSTANCE_EVENT_INVALID'


def lower(graph):
    """Normalize a private graph copy; return its matching instance source.

Generated addresses share an existing machine slot but are not handlers of that
machine. Routing redirects each queued delivery to exactly one instance input.
The public source retains only the actual recipient and event.
"""
    source = graph.get('instance_behaviors')
    addresses = {}
    # Reserve references as well as declarations. A generated event must never
    # accidentally make an otherwise broken authored reference valid.
    used, visited, pending = set(), set(), [graph]
    while pending:
        value = pending.pop()
        if isinstance(value, str):
            used.add(value)
        elif isinstance(value, (dict, list)) and id(value) not in visited:
            visited.add(id(value))
            pending.extend(value.values() if isinstance(value, dict) else value)

    def fail(path, message):
        raise InstanceEventError(f'{path}: {message}')

    def actions(rows, path):
        if not isinstance(rows, list):
            return  # The ordinary graph validator diagnoses structural errors.
        for index, action in enumerate(rows):
            if not isinstance(action, dict) or 'instance_ref' not in action:
                continue
            location = f'{path}[{index}]'
            if set(action) != {'kind', 'instance_ref', 'event_ref'} or action['kind'] != 'send_event':
                fail(location, 'send_event requires exactly one recipient: instance_ref or machine_ref, plus event_ref')
            instance_id, event_id = action['instance_ref'], action['event_ref']
            if not isinstance(instance_id, str) or not instance_id or not isinstance(event_id, str) or not event_id:
                fail(location, 'instance_ref and event_ref must be nonempty names')
            if not isinstance(source, dict):
                fail(location, f'instance {instance_id!r} requires instance_behaviors')
            instances = source.get('instances')
            behaviors = source.get('behaviors')
            if not isinstance(instances, list) or not isinstance(behaviors, list):
                fail(location, 'instance_behaviors requires instance and behavior arrays')
            matches = [i for i in instances if isinstance(i, dict) and i.get('instance_id') == instance_id]
            if len(matches) != 1:
                fail(location, f'unknown or ambiguous instance_ref {instance_id!r}')
            definitions = [b for b in behaviors if isinstance(b, dict) and
                           b.get('behavior_id') == matches[0].get('behavior_ref')]
            if len(definitions) != 1:
                fail(location, f'instance {instance_id!r} has no unique behavior definition')
            behavior_graph = definitions[0].get('machine_logic')
            from .behavior_interface_source import ports
            declared = ports(definitions[0])
            if declared is not None and event_id not in declared['inputs']:
                fail(location, f'instance {instance_id!r}: {event_id!r} is not a declared input')
            events = behavior_graph.get('events') if isinstance(behavior_graph, dict) else None
            if not isinstance(events, list) or not any(isinstance(e, dict) and e.get('event_id') == event_id for e in events):
                fail(location, f'instance {instance_id!r} has no named input event {event_id!r}')
            # Outputs are not inputs. Do not allow a direct send to use an output
            # binding as an unexpected forwarding hop back into the Scene.
            outputs = source.get('outgoing', [])
            if isinstance(outputs, list) and any(isinstance(o, dict) and
                    o.get('instance_ref') == instance_id and o.get('event_ref') == event_id for o in outputs):
                fail(location, f'{instance_id!r}.{event_id} is a bound output, not an input')
            key = (instance_id, event_id)
            if key not in addresses:
                machines, named, bridges = graph.get('machines'), graph.get('events'), source.get('bridges')
                if not isinstance(machines, list) or not machines or not isinstance(machines[0], dict) or not isinstance(named, list) or not isinstance(bridges, list):
                    fail(location, 'direct sends require a Scene machine, named events and instance bridge array')
                ordinal = len(addresses)
                name = f'ps_instance_input_{ordinal}'
                while name in used:
                    ordinal += 1
                    name = f'ps_instance_input_{ordinal}'
                machine = machines[0].get('machine_id')
                addresses[key] = (machine, name)
                used.add(name)
                named.append(dict(event_id=name, display_name=f'Instance input {len(addresses)}'))
                bridges.append(dict(machine_ref=machine, event_ref=name,
                    instance_ref=instance_id, target_event_ref=event_id))
            machine, name = addresses[key]
            rows[index] = dict(kind='send_event', machine_ref=machine, event_ref=name)

    for route in graph.get('routes', []):
        if not isinstance(route, dict):
            continue
        path = f"machine_logic.routes[{route.get('route_id', '?')}]"
        actions(route.get('actions'), path + '.actions')
        for index, outcome in enumerate(route.get('outcomes', [])):
            if isinstance(outcome, dict):
                actions(outcome.get('actions'), f'{path}.outcomes[{index}].actions')
    for chart in graph.get('flowcharts', []):
        if not isinstance(chart, dict):
            continue
        for node in chart.get('nodes', []):
            if isinstance(node, dict):
                actions(node.get('actions'), f"machine_logic.flowcharts[{chart.get('flowchart_id', '?')}].nodes[{node.get('node_id', '?')}].actions")
    return source
