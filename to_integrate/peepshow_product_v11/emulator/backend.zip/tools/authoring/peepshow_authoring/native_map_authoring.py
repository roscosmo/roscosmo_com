"""Map painting transactions change snapshots, never an on-disk Tiled source."""
from copy import deepcopy
from .tiled_assets import integer, validate_record, MAX_CELLS
from .imported_properties import ImportedPropertyError


def update_snapshot(record, command, root):
    """Validate a complete grid replacement before changing the catalog record."""
    path = f"map_assets[{record['asset_id']}].snapshot"
    if record.get('source_kind') != 'native':
        raise ImportedPropertyError('map.update requires a native map; use map.reimport for imports')
    old = record['snapshot']
    width = integer(command['width'], path+'.width', 1, 65535)
    height = integer(command['height'], path+'.height', 1, 65535)
    layers = [layer for layer in old['layers'] if layer['type'] == 'tilelayer']
    if width * height * len(layers) > MAX_CELLS:
        raise ImportedPropertyError(path+'.layers: combined layers exceed the host cell bound')
    supplied = command['layers']
    ids = [row['layer_id'] for row in supplied]
    if len(ids) != len(set(ids)) or set(ids) != {layer['id'] for layer in layers}:
        raise ImportedPropertyError(path+'.layers: supply every existing tile layer exactly once')
    arrays = {row['layer_id']: row['data'] for row in supplied}
    ranges = [(ts['firstgid'], ts['firstgid']+ts['tilecount']) for ts in old['tilesets']]
    resized = (width, height) != (old['width'], old['height'])
    for layer in layers:
        lp = path+f".layers[{layer['id']}].data"
        data = arrays[layer['id']]
        if len(data) != width * height:
            raise ImportedPropertyError(lp+': length must equal width * height')
        for index, tile in enumerate(data):
            cp = lp+f'[{index}]'
            integer(tile, cp, 0, 0x0fffffff)
            if layer['id'] == 3:
                if tile not in (0, 1):
                    raise ImportedPropertyError(cp+': collision must be 0 (clear) or 1 (blocked)')
            elif tile and not any(start <= tile < end for start, end in ranges):
                raise ImportedPropertyError(cp+': tile GID is outside the declared tilesets')
            if resized:
                x, y = index % width, index // width
                previous = layer['data'][y*old['width']+x] if x < old['width'] and y < old['height'] else 0
                if tile != previous:
                    raise ImportedPropertyError(cp+f': resizing must preserve cell ({x}, {y}); new cells must be empty')
        if resized:
            for index, tile in enumerate(layer['data']):
                x, y = index % old['width'], index // old['width']
                if tile and (x >= width or y >= height):
                    raise ImportedPropertyError(lp+f'[{index}]: shrinking would discard painted cell ({x}, {y})')
    candidate = deepcopy(record)
    snapshot = candidate['snapshot']
    snapshot.update(width=width, height=height)
    for layer in snapshot['layers']:
        if layer['type'] == 'tilelayer':
            layer.update(width=width, height=height, data=deepcopy(arrays[layer['id']]))
    validate_record(candidate, root)
    record['snapshot'] = snapshot


def apply(root, catalogs, command, scenes=()):
    from .project import _require_command_fields, ProjectCommandError, _stable_id
    kind = command['kind']
    extra = {'map.create': {'width','height','tile_width','tile_height'},
             'map.paint': {'layer_id','cells'}, 'map.tilesets.set': {'tilesets'},
             'map.update': {'width','height','layers'}, 'map.base_colour.set': {'base_colour'}}[kind]
    required = {'kind','asset_id'} | extra
    optional = {'base_colour'} if kind == 'map.create' else {'inherit_attachments'} if kind == 'map.base_colour.set' else set()
    _require_command_fields(command, required, required | {'command_id'} | optional)
    problems = []
    _stable_id(command['asset_id'], 'command.asset_id', problems)
    if problems:
        raise ProjectCommandError(problems[0].code, problems[0].message)
    records = [r for c in catalogs for r in c.get('map_assets', [])]
    record = next((r for r in records if r['asset_id'] == command['asset_id']), None)
    try:
        if kind == 'map.create':
            if record is not None or any(r.get('asset_id') == command['asset_id'] for c in catalogs for r in c.get('assets',[]) + c.get('audio_assets',[])):
                raise ImportedPropertyError('Asset ID already exists')
            w = integer(command['width'], 'width', 1, 65535)
            h = integer(command['height'], 'height', 1, 65535)
            tw = integer(command['tile_width'], 'tile_width', 1, 256)
            th = integer(command['tile_height'], 'tile_height', 1, 256)
            if w*h*3 > MAX_CELLS:
                raise ImportedPropertyError('Combined map layers exceed the host cell bound')
            layers = [dict(id=i+1, name=n, type='tilelayer', width=w, height=h, data=[0]*(w*h))
                      for i,n in enumerate(('Background', 'Details', 'Collision'))]
            record = dict(asset_id=command['asset_id'], import_version=1, source_kind='native',
                base_colour=command.get('base_colour', 'white'),
                source_path=command['asset_id']+'.tmj', edits=[],
                snapshot=dict(type='map', orientation='orthogonal', renderorder='right-down', infinite=False,
                    width=w, height=h, tilewidth=tw, tileheight=th, tilesets=[], layers=layers))
            catalogs[0].setdefault('map_assets', []).append(record)
        elif record is None:
            raise ImportedPropertyError('Unknown map asset')
        elif kind == 'map.base_colour.set':
            from .map_colour import set_colour
            set_colour(record, command, scenes)
        elif kind == 'map.update':
            update_snapshot(record, command, root)
        elif kind == 'map.tilesets.set':
            record['snapshot']['tilesets'] = deepcopy(command['tilesets'])
        else:
            snapshot = record['snapshot']
            layer = next((l for l in snapshot['layers'] if l['id'] == command['layer_id'] and l['type']=='tilelayer'), None)
            if layer is None:
                raise ImportedPropertyError('Paint requires an existing tile layer')
            cells = command['cells']
            if type(cells) is not list or not 1 <= len(cells) <= 65536:
                raise ImportedPropertyError('Paint requires 1..65536 cell edits')
            seen = set()
            for cell in cells:
                if type(cell) is not dict or set(cell) != {'x','y','tile'}:
                    raise ImportedPropertyError('Cell edit requires x, y, tile')
                x = integer(cell['x'],'cell.x',0,snapshot['width']-1)
                y = integer(cell['y'],'cell.y',0,snapshot['height']-1)
                tile = integer(cell['tile'],'cell.tile',0,0x0fffffff)
                if record.get('source_kind') == 'native' and layer['id'] == 3 and tile not in (0,1):
                    raise ImportedPropertyError('Native collision paint is 0 (clear) or 1 (blocked)')
                if (x,y) in seen:
                    raise ImportedPropertyError('Duplicate cell in one paint operation')
                seen.add((x,y))
                layer['data'][y*snapshot['width']+x] = tile
        validate_record(record, root)
    except (ImportedPropertyError, TypeError, KeyError) as exc:
        raise ProjectCommandError('MAP_EDIT_INVALID', str(exc)) from exc
    return dict(kind=kind, asset_id=command['asset_id'])
