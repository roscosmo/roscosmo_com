"""Typed, bounded calls expanded into the existing candidate response executor."""
from copy import deepcopy
from dataclasses import replace

MAX_DEPTH = 4
MAX_NODES = 32
CAPABILITY = dict(field='machine_logic.flowcharts', discriminator='parameters_and_outputs',
    schema='schemas/authoring/callable-flow-v1.schema.json',
    commands=['scene.flowcharts.set', 'scene.machines.set', 'scene.response.set'],
    invocation='response_call_node', call_node_kind='call', call_fields=['flowchart_ref','arguments','continuations'],
    types=['int32','boolean','direction','variable','object','actor','property','destination','event'],
    value_arguments='literals_only', reference_access=['read','write'],
    actor_members=['x','y'], outputs='stable_identity_caller_continuation',
    maximum_depth=MAX_DEPTH, maximum_expanded_response_nodes=MAX_NODES,
    maximum_parameters=8, maximum_outputs=8, recursion=False, waits=False,
    writer_policy='caller_must_already_own_resolved_target',
    contexts=['ordinary_machine','shared_behavior'], project_definitions=True,
    legacy_fixed_reference_flows='unchanged', host_preview=True, runtime=False, export=False,
    trace_field='machine_execution.trace[].terminal_response.node_path',
    call_path_format='<call-node>/<flowchart-id>/<helper-node>', trace_action_completion=False)


class CallError(ValueError):
    def __init__(self, path, message):
        super().__init__(message)
        self.path = path


def prepare(bundle, *, debug_calls=None):
    from .project import ValidationIssue
    scenes = deepcopy(bundle.scenes)
    issues = list(bundle.issues)
    for scene in scenes:
        graphs = [(scene.get('machine_logic', {}), None, 'scenes['+scene['scene_id']+'].machine_logic')]
        for behavior in scene.get('machine_logic', {}).get('instance_behaviors', {}).get('behaviors', []):
            graphs.append((behavior['machine_logic'], behavior,
                graphs[0][2]+'.instance_behaviors.behaviors['+behavior['behavior_id']+'].machine_logic'))
        for graph, behavior, path in graphs:
            try:
                expand(graph, scene, behavior, bundle.project, path, debug_calls=debug_calls)
            except (CallError, KeyError, TypeError, AttributeError) as exc:
                issues.append(ValidationIssue('FLOW_CALL_INVALID', getattr(exc,'path',path), str(exc)))
    return replace(bundle, scenes=tuple(scenes), issues=tuple(issues))


def expand(graph, scene, behavior, project, path, *, debug_calls=None):
    flows = {f['flowchart_id']: f for f in graph.get('flowcharts', []) if 'parameters' in f or 'outputs' in f}
    calls = any(n.get('kind') == 'call' for r in graph.get('routes', []) for n in r.get('response', {}).get('nodes', []))
    if not flows and not calls:
        return
    def fail(where, message):
        raise CallError(where, message)
    if project.get('execution_semantics') != 'terminal_order_v1':
        fail(path, 'Typed calls require terminal_order_v1; existing flows are not migrated')
    if len(flows) != sum('parameters' in f or 'outputs' in f for f in graph.get('flowcharts', [])):
        fail(path+'.flowcharts', 'Duplicate callable identity')
    if len(flows) > 16:
        fail(path+'.flowcharts', 'At most 16 callable definitions')

    def resolve(value, environment, where):
        if isinstance(value, list):
            return [resolve(v, environment, where) for v in value]
        if not isinstance(value, dict):
            return value
        if 'parameter_ref' in value:
            if set(value) - {'parameter_ref','member'}:
                fail(where, 'Invalid parameter expression')
            name = value['parameter_ref']
            if name not in environment:
                fail(where, 'Unknown parameter '+str(name))
            declaration, actual = environment[name]
            if declaration['type'] == 'actor':
                if 'member' not in value:
                    return actual
                if value.get('member') not in ('x','y'):
                    fail(where, 'Actor references require member x or y')
                return actual + '.' + value['member']
            if 'member' in value:
                fail(where, 'Only actor parameters have members')
            return deepcopy(actual)
        result = {k:resolve(v,environment,where) for k,v in value.items() if k!='binding'}
        if 'binding' in value:
            binding = resolve(value['binding'], environment, where)
            if not isinstance(binding,dict) or set(binding) & set(result):
                fail(where, 'Binding must supply nonconflicting reference fields')
            result.update(binding)
        return result

    def parameter_refs(value):
        if isinstance(value,dict):
            if 'parameter_ref' in value:
                yield value['parameter_ref']
            for child in value.values():
                yield from parameter_refs(child)
        elif isinstance(value,list):
            for child in value:
                yield from parameter_refs(child)

    def bind(flow, arguments, parent, where):
        declarations = flow.get('parameters')
        if not isinstance(declarations,list) or len(declarations)>8:
            fail(where, 'Requires up to eight typed parameters')
        names = [d['parameter_id'] for d in declarations]
        if len(set(names)) != len(names) or set(arguments) != set(names):
            fail(where, 'Arguments must bind each declared parameter exactly once')
        env = {}
        variables = {('package',v['variable_id']):v for v in project.get('package_variables',[])}
        variables.update({('scene',v['variable_id']):v for v in scene.get('variables',[])})
        properties = {v['name']:v for v in (behavior or {}).get('properties',[])}
        for declaration in declarations:
            name=declaration['parameter_id']; kind=declaration['type']; access=declaration.get('access','read')
            at=where+'.arguments['+name+']'; original=arguments[name]
            if kind not in CAPABILITY['types'] or access not in ('read','write'):
                fail(at, 'Unknown parameter type/access')
            if access=='write':
                for ref in parameter_refs(original):
                    if ref not in parent or parent[ref][0].get('access','read')!='write':
                        fail(at, 'A nested call cannot elevate a read-only parameter')
            if isinstance(original,dict) and set(original)=={'parameter_ref'}:
                forwarded=parent.get(original['parameter_ref'])
                if forwarded is None or forwarded[0]['type']!=kind or forwarded[0].get('value_type')!=declaration.get('value_type'):
                    fail(at, 'Nested parameter type mismatch')
            actual=resolve(original,parent,at)
            if kind in ('int32','boolean','direction'):
                valid = ((kind=='int32' and type(actual) is int and -2147483648<=actual<=2147483647) or
                         (kind=='boolean' and type(actual) is bool) or
                         (kind=='direction' and actual in ('up','down','left','right')))
                if not valid or access!='read':
                    fail(at, 'Value parameters require a typed read-only literal')
            elif kind=='variable':
                if not isinstance(actual,dict) or set(actual)!={'variable_scope','variable_ref'}:
                    fail(at, 'Variable binding requires variable_scope and variable_ref')
                target=variables.get((actual['variable_scope'],actual['variable_ref']))
                if target is None or target['value_type']!=declaration.get('value_type'):
                    fail(at, 'Variable type/reference mismatch')
                owner=next((m for m in graph.get('machines',[]) if m['machine_id']==route['machine_ref']),{})
                if access=='write' and dict(scope=actual['variable_scope'],variable_ref=actual['variable_ref']) not in owner.get('variable_writes',[]):
                    fail(at, 'Caller does not own writable variable '+str(actual))
            elif kind=='event':
                if access!='read' or not isinstance(actual,dict) or set(actual) not in ({'machine_ref','event_ref'},{'instance_ref','event_ref'}):
                    fail(at, 'Event binding requires an actual machine/instance and input event')
                if 'machine_ref' in actual:
                    if actual['machine_ref'] not in {m['machine_id'] for m in graph.get('machines',[])} or actual['event_ref'] not in {e['event_id'] for e in graph.get('events',[])}:
                        fail(at, 'Unknown event recipient or input')
                else:
                    instances=scene.get('machine_logic',{}).get('instance_behaviors',{})
                    instance=next((i for i in instances.get('instances',[]) if i['instance_id']==actual['instance_ref']),None)
                    receiver=next((b for b in instances.get('behaviors',[]) if instance and b['behavior_id']==instance['behavior_ref']),{})
                    if actual['event_ref'] not in receiver.get('interface',{}).get('inputs',[]):
                        fail(at, 'Unknown behavior instance input')
            else:
                if type(actual) is not str:
                    fail(at, 'Reference binding must be an identity')
                owner=next((m for m in graph.get('machines',[]) if m['machine_id']==route['machine_ref']),{})
                if kind=='object' and access=='write' and not any(w['object_ref']==actual and w['properties'] for w in owner.get('object_writes',[])):
                    fail(at, 'Caller does not own writable object '+actual)
                if kind=='actor' and access=='write' and not any(e['entity_id']==actual and e.get('position_writer')==route['machine_ref'] for e in scene.get('world',{}).get('entities',[])):
                    fail(at, 'Caller does not own entity position '+actual)
                if kind=='property' and access=='write' and not properties.get(actual,{}).get('writable',False):
                    fail(at, 'Behavior property is not writable: '+actual)
                if kind=='object' and actual not in {v['object_id'] for v in scene.get('objects',[])}:
                    fail(at, 'Unknown object')
                if kind=='actor' and actual not in {v['entity_id'] for v in scene.get('world',{}).get('entities',[])}:
                    fail(at, 'Unknown independent entity')
                if kind=='property' and (actual not in properties or properties[actual]['value_type']!=declaration.get('value_type')):
                    fail(at, 'Behavior property type/reference mismatch')
                if kind=='destination' and actual not in {v['destination_id'] for v in (behavior or graph).get('destinations',[])}:
                    fail(at, 'Unknown checked destination')
            env[name]=(declaration,actual)
        return env

    def check_write(action, env, where):
        kind=action.get('kind','')
        field = ('binding' if kind=='set_variable' else 'object_ref' if kind.startswith('object.') else
                 ('property_ref' if 'property_ref' in action else 'reference_ref') if kind.startswith(('world.','facing.')) else
                 'property_ref' if kind.startswith('property.') else
                 'destination_ref' if kind=='destination.move' else None)
        if field is None:
            return
        refs=list(parameter_refs(action.get(field)))
        if not refs:
            fail(where, 'Typed flow writes must use an explicit writable parameter')
        if any(ref not in env or env[ref][0].get('access','read')!='write' for ref in refs):
            fail(where, 'Cannot write through a read-only parameter')

    for route in graph.get('routes',[]):
        response=route.get('response')
        if not response or not any(n.get('kind')=='call' for n in response['nodes']):
            continue
        where=path+'.routes['+route['route_id']+'].response'
        expanded=[]
        used=set()
        aliases={}
        def append(node):
            if node['node_id'] in used or len(expanded)>=MAX_NODES:
                fail(where, 'Expanded response exceeds 32 unique nodes')
            used.add(node['node_id']);expanded.append(node)
        def instantiate(body, env, prefix, stack, exits=None):
            nodes=body['nodes']; local={n['node_id']:n for n in nodes}
            if len(local)!=len(nodes) or body['root'] not in local:
                fail(where, 'Duplicate node or missing root')
            ids={name:prefix+name for name in local}
            # Validate the authored graph before control-only returns disappear.
            reached=set()
            pending=[(body['root'],frozenset())]
            work=0
            while pending:
                current,visited=pending.pop();work+=1
                if current not in local or current in visited or work>1024:
                    fail(where, 'Missing edge, cycle or excessive path work in callable graph')
                reached.add(current);node=local[current];kind=node['kind']
                if kind=='actions': edges=[node['next']]
                elif kind=='decision':edges=[node[p]['next'] for p in ('when_true','when_false')]
                elif kind=='call':edges=list(node['continuations'].values())
                elif kind=='return':edges=[]
                else:fail(where, 'Only actions, decisions, calls and returns are supported; no waits')
                pending.extend((edge,visited|{current}) for edge in edges)
            if reached!=set(local):fail(where, 'All nodes in a called graph must be reachable')
            call_entries={}
            for node in nodes:
                if node['kind']!='call':
                    continue
                at=where+'.nodes['+ids[node['node_id']]+']'
                if set(node)!={'node_id','kind','flowchart_ref','arguments','continuations'}:
                    fail(at, 'Call requires flowchart_ref, arguments and continuations')
                ref=node['flowchart_ref']
                if ref not in flows or ref in stack or len(stack)>=MAX_DEPTH:
                    fail(at, 'Unknown callable, recursion or nesting exceeds four')
                flow=flows[ref]
                if set(flow) - {'flowchart_id','display_name','parameters','outputs','root','nodes','layout'}:
                    fail(at, 'Typed flows use caller ownership; legacy writer declarations are not accepted')
                outputs=[o['output_id'] for o in flow.get('outputs',[])]
                if not 1<=len(outputs)<=8 or len(set(outputs))!=len(outputs) or set(node['continuations'])!=set(outputs):
                    fail(at, 'Connect every declared output exactly once')
                targets={out:ids.get(target) for out,target in node['continuations'].items()}
                if None in targets.values():
                    fail(at, 'Output continuation must name a caller node')
                actuals=bind(flow,node['arguments'],env,at)
                if debug_calls is not None:
                    debug_calls.append(dict(scene_id=scene['scene_id'],
                        behavior_id=None if behavior is None else behavior['behavior_id'],
                        route_id=route['route_id'], call_node_id=ids[node['node_id']],
                        flowchart_ref=ref, authored_path=at,
                        parameters=[dict(declaration=deepcopy(d), binding=deepcopy(a)) for d,a in actuals.values()],
                        continuations=deepcopy(targets),
                        returns={ids[node['node_id']]+'/'+ref+'/'+n['node_id']:n['output_ref']
                                 for n in flow['nodes'] if n['kind']=='return'}))
                call_entries[ids[node['node_id']]]=instantiate(flow,actuals,ids[node['node_id']]+'/'+ref+'/',stack+(ref,),targets)
            for node in nodes:
                if node['kind']=='call':
                    continue
                nid=ids[node['node_id']]; at=where+'.nodes['+nid+']'
                if node['kind']=='return' and exits is not None:
                    if set(node)!={'node_id','kind','output_ref'} or node['output_ref'] not in exits:
                        fail(at, 'Callable return must select a declared output, never a caller State')
                    append(dict(node_id=nid,kind='actions',actions=[],next=exits[node['output_ref']]))
                    continue
                if exits is not None:
                    for action in node.get('actions',[]):
                        check_write(action,env,at)
                        if action.get('kind')=='run_flowchart':
                            fail(at, 'Use a typed call node for nested helpers')
                result=resolve(node,env,at);result['node_id']=nid
                if node['kind']=='actions':result['next']=ids.get(node['next'],node['next'])
                if node['kind']=='decision':
                    for port in ('when_true','when_false'):
                        result[port]['next']=ids.get(node[port]['next'],node[port]['next'])
                append(result)
            # Resolve control-only call and return nodes without introducing events.
            aliases.update(call_entries)
            return ids[body['root']]
        root=instantiate(response,{},'',())
        def target(value):
            seen=set()
            while value in aliases:
                if value in seen:fail(where, 'Call/return control cycle')
                seen.add(value);value=aliases[value]
            return value
        for node in expanded:
            if 'next' in node:node['next']=target(node['next'])
            for port in ('when_true','when_false'):
                if port in node:node[port]['next']=target(node[port]['next'])
        route['response']=dict(root=target(root),nodes=expanded)
    if 'flowcharts' in graph:
        graph['flowcharts']=[f for f in graph['flowcharts'] if f['flowchart_id'] not in flows]
        if not graph['flowcharts']:graph.pop('flowcharts')
