"""Bounded Menu navigation; lifecycle and variable application use existing owners.

This is host metadata, never executable device bytecode or generated authored
States. All publication happens on the preview's ordinary private candidate.
"""
from copy import deepcopy

from .preview import PreviewError, PreviewInputResult, StateScenePreview
from .presentation_selectors import matches


def variables(player):
    result = {}
    for index, row in enumerate(player._graph['variables']):
        definition = player._scoped_variables.get(row['variable_id'])
        if definition is not None:
            value = player._variables[index]
            result[definition['scope'], definition['variable_id']] = (
                index, definition, bool(value) if definition['value_type'] == 'bool' else value)
    return result


def condition(player, predicate):
    if type(predicate) is bool:
        return predicate
    return matches(predicate, player._machine_states, {k: v[2] for k, v in variables(player).items()},
                   inventory_counts=player._inventory_state['counts'])


class MenuSession:
    def __init__(self, source):
        self.source = deepcopy(source)
        self.pages = {p['page_id']: p for p in source['pages']}
        self.clear()

    def clear(self):
        self.visible = False
        self.stack = []
        self.frames = {}
        self.drafts = {}

    def initialize(self, player):
        self.clear()
        values = variables(player)
        for draft in self.source['drafts']:
            ref = draft['source']
            key = ref['variable_scope'], ref['variable_ref']
            if key not in values:
                raise PreviewError('Menu draft source is missing: ' + draft['draft_id'])
            self.drafts[draft['draft_id']] = values[key][2]
        self.stack = [self.source['root_page']]
        self.settle(player)
        return dict(menu_id=self.source['menu_id'], page_id=self.stack[0])

    def settle(self, player):
        page = self.pages[self.stack[-1]]
        rows = []
        for entry in page['entries']:
            visible = condition(player, entry.get('visible_when', True))
            if 'inventory_item_ref' in entry:
                visible = visible and player._inventory_state['counts'].get(entry['inventory_item_ref'], 0) > 0
            enabled = condition(player, entry.get('enabled_when', True))
            if visible:
                rows.append(dict(entry, enabled=enabled))
        frame = self.frames.get(page['page_id'])
        if frame is None:
            initial = page.get('initial_entry')
            draft = page.get('initial_draft')
            if draft is not None:
                initial = next((e['entry_id'] for e in rows if e['kind'] == 'choice'
                    and e['draft_ref'] == draft and e['value'] == self.drafts[draft]), None)
            frame = dict(selected=initial, scroll=0)
            self.frames[page['page_id']] = frame
        eligible = [r['entry_id'] for r in rows if r['enabled']]
        if frame['selected'] not in eligible:
            ordered = [e['entry_id'] for e in page['entries']]
            start = ordered.index(frame['selected']) if frame['selected'] in ordered else 0
            frame['selected'] = next((i for i in ordered[start:] if i in eligible),
                                     next((i for i in reversed(ordered[:start]) if i in eligible),None))
        count = self.source['presentation'].get('visible_rows',64)
        frame['scroll'] = min(frame['scroll'], max(0, len(rows)-count))
        if frame['selected'] is not None:
            index = next(i for i, r in enumerate(rows) if r['entry_id'] == frame['selected'])
            frame['scroll'] = min(frame['scroll'], index)
            frame['scroll'] = max(frame['scroll'], index-count+1)
        return page, frame, rows

    def page_changed(self, player):
        # Same modal session and paused clocks. Only the held gesture fence
        # changes: a held Activate/Back must not activate the next page as well.
        player._scope_input._handoff('menu', 'menu_page_changed')
        self.settle(player)

    def navigate(self, player, operation, source=None):
        page, frame, rows = self.settle(player)
        previous_selection = (page['page_id'], frame['selected'])
        eligible = [r for r in rows if r['enabled']]
        if operation in ('previous', 'next'):
            if not eligible:
                return False
            index = next(i for i, r in enumerate(eligible) if r['entry_id'] == frame['selected'])
            if 'neighbors' in page:
                direction={'JOY_LEFT':'left','JOY_RIGHT':'right','JOY_UP':'up','JOY_DOWN':'down'}.get(source)
                target=page['neighbors'].get(frame['selected'],{}).get(direction)
                index=next((i for i,r in enumerate(eligible) if r['entry_id']==target),index)
            else:
                index += -1 if operation == 'previous' else 1
                index = index % len(eligible) if self.source['wrap'] else max(0, min(index, len(eligible)-1))
            chosen = eligible[index]
            frame['selected'] = chosen['entry_id']
            if page.get('choice_mode') == 'stage_on_navigation':
                self.drafts[chosen['draft_ref']] = chosen['value']
        elif operation == 'back':
            if len(self.stack) > 1:
                self.stack.pop()
                self.page_changed(player)
            else:
                player._menu_close(held_sources=player._scope_input.held, budget_ms=player._menu_action_budget_ms)
        elif operation == 'activate':
            selected = next((r for r in eligible if r['entry_id'] == frame['selected']), None)
            if selected is None:
                return False
            if selected['kind'] == 'inventory':
                return True  # Inspectable item; no consumption or implicit action.
            if selected['kind']=='event':
                player._apply_binding(None,'MENU','named',selected['event_ref'],_receiver=selected['machine_ref'])
                if player._machine_rejection:
                    raise PreviewError(player._machine_rejection)
                return True
            if selected['kind'] == 'submenu':
                self.stack.append(selected['page_ref'])
                self.page_changed(player)
            elif selected['kind'] == 'choice':
                self.drafts[selected['draft_ref']] = selected['value']
                result = page.get('choice_result', 'stay')
                if result == 'back':
                    self.stack.pop()
                    self.page_changed(player)
                elif result == 'confirm':
                    player._menu_close(held_sources=player._scope_input.held,
                        budget_ms=player._menu_action_budget_ms, confirm=True)
            else:
                player._menu_close(held_sources=player._scope_input.held,
                    budget_ms=player._menu_action_budget_ms, confirm=selected['operation'] == 'confirm')
        if operation in ('previous', 'next', 'back', 'activate') and self.visible and self.stack:
            page, frame, _ = self.settle(player)
            cue_ref = self.source.get('navigation_sfx')
            if (cue_ref is not None and player._scope_menu.pending is None
                    and previous_selection != (page['page_id'], frame['selected'])):
                cue = next(c for c in player._audio_cues if c['cue_id'] == cue_ref)
                player._scope_audio.stage('menu', dict(kind='play_sfx', **{
                    key: cue[key] for key in ('cue_id', 'asset_id', 'priority', 'volume')}))
        return True

    def apply(self, player):
        owner = self.source.get('apply_owner')
        authored = player._scope_sources[player.scene_id]['machine_logic']
        machine = next((m for m in authored['machines'] if m['machine_id'] == owner), None)
        if machine is None or player._scope_timing.scope('machines', owner) != 'gameplay':
            raise PreviewError('Menu apply owner is unavailable')
        writes = {(w['scope'], w['variable_ref']) for w in machine['variable_writes']}
        values, operations = variables(player), []
        for draft in self.source['drafts']:
            ref = draft['source']
            key = ref['variable_scope'], ref['variable_ref']
            if key not in writes or key not in values or draft['draft_id'] not in self.drafts:
                raise PreviewError('Menu apply binding is unavailable: ' + draft['draft_id'])
            index, definition, _ = values[key]
            value = self.drafts[draft['draft_id']]
            if (type(value) is not (bool if definition['value_type'] == 'bool' else int)
                    or definition['value_type'] == 'int32' and not definition['minimum'] <= value <= definition['maximum']):
                raise PreviewError('Menu draft value is invalid: ' + draft['draft_id'])
            operations.append(dict(kind=1, operation=1, variable_index=index, value=int(value)))
        # One variable-only transaction, no State re-entry, synthetic event
        # chain, timer restart, or implicit turn. The enclosing lifecycle owns
        # the candidate and publishes all values together after owner receipts.
        route = dict(route_id='menu_component.apply', target_scene=None,
                     target_state_index=None, operations=tuple(operations))
        StateScenePreview._execute_route(player, route, 'MENU_CONFIRM', 'confirm', self.source['menu_id'])
        return dict(machine_ref=owner, drafts=deepcopy(self.drafts), writes=len(operations))

    def snapshot(self, player):
        result = dict(menu_id=self.source['menu_id'], visible=self.visible,
                      stack=list(self.stack), drafts=deepcopy(self.drafts))
        if not self.stack:
            return dict(result, page_id=None, selected_entry=None, scroll_offset=0, rows=[])
        page, frame, rows = self.settle(player)
        start, count = frame['scroll'], self.source['presentation'].get('visible_rows',64)
        return dict(result, page_id=page['page_id'], title=page['title'],
            selected_entry=frame['selected'], scroll_offset=start, visible_entry_count=len(rows),
            can_scroll_previous=start > 0, can_scroll_next=start+count < len(rows),
            rows=[dict(entry_id=e['entry_id'], label=e['label'], enabled=e['enabled'],
                       disabled_reason=e.get('disabled_reason'), selected=e['entry_id'] == frame['selected'],
                       chosen=e['kind'] == 'choice' and self.drafts[e['draft_ref']] == e['value'],
                       **({'inventory_count': player._inventory_state['counts'][e['inventory_item_ref']]}
                          if 'inventory_item_ref' in e else {}))
                  for e in rows[start:start+count]])

    def render(self, player):
        if self.source['presentation'].get('kind')=='objects':
            return player._framebuffer
        from .system_fonts import runtime_text_pixels
        state = self.snapshot(player)
        view = self.source['presentation']
        x, y, width, height = (view[k] for k in ('x','y','width','height'))
        buffer = bytearray(player._framebuffer)
        for py in range(y, y+height):
            for px in range(x, x+width):
                player._write_bit(buffer, px, py, 0)
        def label(value, px, py, available, color=1):
            for dx, dy in runtime_text_pixels(value, view['font_id'], 1, 'left', available, 8):
                player._write_bit(buffer, px+dx, py+dy, color)
        label(state['title'], x, y, width-16)
        if state['can_scroll_previous'] or state['can_scroll_next']:
            label('^' if state['can_scroll_previous'] else 'v', x+width-8, y, 8)
        for i, row in enumerate(state['rows']):
            top = y+8+i*view['row_height']
            if row['selected']:
                for py in range(top, top+view['row_height']):
                    for px in range(x, x+width):
                        player._write_bit(buffer, px, py, 1)
            color = int(not row['selected'])
            marker = '-' if not row['enabled'] else '*' if row['chosen'] else ' '
            label(marker, x, top, 8, color)
            label(row['label'], x+16, top, width-16, color)
        return bytes(buffer)


def dispatch(player, source, event, action):
    session, focus = player._menu_component, player._scope_input
    if focus.scope == 'gameplay':
        if 'open' not in session.source:
            return None  # Ordinary game routes own explicit Open Menu actions.
        if action != session.source['open']['action_ref']:
            return None
        # The component owns this trigger while its condition is true. A false
        # condition permits an ordinary handler (e.g. B restarts when Caught).
        if event != 'press' or not condition(player, session.source['open'].get('when', True)):
            return None
        operation = 'open'
    else:
        operation = next((name for name, refs in session.source['input_map'].items() if action in refs), None)
        if operation is None or event != 'press' and not (event == 'repeat' and operation in ('previous','next')):
            focus.finish('unmapped_menu_consumed')
            return PreviewInputResult(source, event, action, False, None)
    candidate = deepcopy(player)
    candidate._scope_input.begin_action(source, event, action)
    if operation == 'open':
        candidate._menu_open(held_sources=candidate._scope_input.held,
            budget_ms=candidate._menu_action_budget_ms, hide_world=session.source['hide_world'])
        accepted = True
    else:
        accepted = candidate._menu_component.navigate(candidate, operation, source)
    candidate._render_framebuffer()
    candidate._scope_input.finish('menu_component_delivered' if accepted else 'menu_no_selection')
    from .scope_menu import publish
    publish(player, candidate)
    return PreviewInputResult(source, event, action, accepted, None)
