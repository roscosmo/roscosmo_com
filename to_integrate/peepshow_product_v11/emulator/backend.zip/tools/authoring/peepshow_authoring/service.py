"""Long-running host service for the PeepShow authoring toolchain."""

from __future__ import annotations

from dataclasses import asdict
import base64
import hashlib
import sys
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
from typing import Any, TextIO
from .scoped_variables import CAPABILITY as SCOPED_VARIABLE_CAPABILITY
from .scene_entry import CAPABILITY as SCENE_ENTRY_CAPABILITY
from .scene_machines import CAPABILITY as SCENE_MACHINES_CAPABILITY
from .menu_component import CAPABILITY as MENU_COMPONENT_CAPABILITY
from .inventory_source import CAPABILITY as INVENTORY_CAPABILITY

from .audio_assets import (
    AUDIO_BLOCK_SAMPLES,
    AUDIO_MAX_ASSETS,
    AUDIO_MAX_BANK_BYTES,
    AUDIO_MAX_CUES,
    AUDIO_SAMPLE_RATE_HZ,
    AudioAssetError,
    decode_ima_adpcm,
    pcm16_wav,
)
from .compatibility import build_compatibility_report
from .v2_export import PROFILE_ID as V2_EXPORT_PROFILE_ID, public_v2_export_profile, public_v2_audio_profile, public_v2_text_profile, public_object_clipping_profile, public_object_inversion_profile
from .compiler import EggCompileError, build_egg, build_preview_package, build_readiness_issues, export_metadata
from .egg_format import EggFormatError, parse_egg
from .project import (
    ProjectBundle,
    ProjectCommandError,
    apply_project_commands,
    create_project,
    load_project,
    save_project,
)
from .preview import PreviewError, StateScenePreview
from .scene_object_authoring import (
    OBJECT_COMMANDS, COMMON_SCENE_COMMANDS, STATE_MANAGEMENT_COMMANDS, LOCAL_GRAPH_COMMANDS,
    SCENE_CONNECTION_COMMANDS, execution_model,
)
from .scene_objects import (
    SceneObjectError, initialize_objects, resolve_object,
    plan_object_migration, materialize_object_migration,
)
from .target_profile import (
    TARGET_PROFILE_ID,
    TARGET_SAMPLED_SFX,
    TARGET_STATE_SCENE_EVENTS,
    public_target_profile,
)
from .protocol import (
    PROTOCOL_VERSION,
    ProtocolError,
    ServiceRequest,
    encode_message,
    error_response,
    parse_request,
    success_response,
)


from . import authoring_foundation, execution_semantics
from .preview_debug import CAPABILITY as PREVIEW_DEBUG_CAPABILITY

SERVICE_API_VERSION = 134

# Copy source/preview capabilities; do not broaden their grammars or mutate the
# legacy guards used by non-map exports. Public builds negotiate a map subset.
from .map_export_discovery import annotate as _map_export_capabilities
SCENE_MACHINES_CAPABILITY, MENU_COMPONENT_CAPABILITY, INVENTORY_CAPABILITY = _map_export_capabilities(
    SCENE_MACHINES_CAPABILITY, MENU_COMPONENT_CAPABILITY, INVENTORY_CAPABILITY)
UNDO_LIMIT = 32
SERVICE_NAME = "peepshow_authoring"
SERVICE_OPERATIONS = (
    "service.hello",
    "service.shutdown",
    "project.create",
    "project.load",
    "project.validate",
    "project.normalize",
    "project.inventory.inspect",
    "project.actor.inspect",
    "project.actor_template.inspect",
    "project.settings.get",
    "project.build_package",
    "project.compatibility_report",
    "project.apply_commands",
    "project.object_migration_preview",
    "project.object_migration_apply",
    "project.save",
    "project.undo",
    "project.redo",
    "project.scene_thumbnails",
    "project.audio_audition",
    "project.preview_debug",
    "project.preview_reset",
    "project.preview_state",
    "project.preview_scene_base",
    "project.preview_input",
    "project.preview_advance",
    "project.preview_set_local_time",
    "project.preview_suspend",
    "project.preview_resume",
    "project.preview_input_snapshot",
    "project.preview_audio_take",
    "project.preview_audio_stop_complete",
    "project.preview_menu_finish",
    "project.preview_menu_cancel",
)


def _safe_issue_path(value: str) -> str:
    path = Path(value)
    if path.is_absolute():
        return path.name or "project"
    return value


def _issues(bundle: ProjectBundle) -> list[dict[str, str]]:
    return [
        {
            "code": issue.code,
            "path": _safe_issue_path(issue.path),
            "message": issue.message,
        }
        for issue in bundle.issues
    ]


def _project_summary(bundle: ProjectBundle) -> dict[str, Any]:
    project = bundle.project
    return {
        "project_id": project.get("project_id"),
        "project_name": project.get("project_name"),
        "package_id": project.get("package", {}).get("package_id"),
        "target_profile": project.get("selected_target_profile"),
        "entry_scene": project.get("entry_scene"),
        "scene_count": len(bundle.scenes),
        "asset_frame_count": len(bundle.frames),
        "animation_count": len(bundle.animations),
        "audio_asset_count": len(bundle.audio_assets),
        "audio_cue_count": len(bundle.audio_cues),
    }


def _semantic_sha256(bundle: ProjectBundle) -> str | None:
    return hashlib.sha256(bundle.canonical_bytes()).hexdigest() if bundle.valid else None


def _require_fields(params: dict[str, Any], required: set[str]) -> None:
    missing = required - params.keys()
    unknown = params.keys() - required
    if missing or unknown:
        raise ProtocolError(
            "OPERATION_PARAMS_INVALID",
            "operation parameters do not match the service API",
            details={"missing": sorted(missing), "unknown": sorted(unknown)},
        )


def _timer_source_layout_capability() -> dict[str, Any]:
    return {
        "supported": True,
        "editor_only": True,
        "runtime_encoded": False,
        "commands": ["editor.state_graph.set_node_position"],
        "event_types": ["time.scene_elapsed", "time.state_entry_elapsed"],
        "node_id_format": "timer-{binding_id}",
        "delete_with_binding": True,
    }


def _timer_handler_layout_capability() -> dict[str, Any]:
    return {
        "supported": True,
        "editor_only": True,
        "routing_version": 1,
        "commands": ["editor.state_graph.set_handler_layout"],
        "addressing": ["scene_id", "handler_id"],
        "storage": "project.editor.state_graph.scenes[scene_id].handlers[handler_id]",
        "termination_position": True,
        "rail_max": 8,
        "guard_token_max": 8,
        "action_token_max": 8,
        "coordinate_min": -100000,
        "coordinate_max": 100000,
        "token_positions": ["condition", "guards", "actions"],
        "condition_and_guards_mutually_exclusive": True,
        "token_fraction_min": 0.02,
        "token_fraction_max": 0.98,
        "local_target_socket": True,
        "update_mode": "replace_layout",
        "clear_with_null": True,
    }


def _scene_capabilities(bundle: ProjectBundle) -> dict[str, Any]:
    if not bundle.valid:
        return {}
    from .authoring_foundation import enabled, execution_issues, project_for_execution, CAPABILITY
    if enabled(bundle):
        problems = execution_issues(bundle)
        if problems:
            result = {s['scene_id']: dict(schema_version=2, execution_model=execution_model(s), host_editing=True,
                host_preview=False, preview_issues=problems, export_ready=False,
                scope_host_preview=dict(version=1, scope_ready=False, issues=problems)) for s in bundle.scenes}
        else:
            result = _scene_capabilities(project_for_execution(bundle))
        for row in result.values():
            row['source_authoring_mode'] = authoring_foundation.MODE
            row['authoring_foundation'] = deepcopy(CAPABILITY)
            facilities = deepcopy(SCENE_MACHINES_CAPABILITY)
            facilities['schema'] = CAPABILITY['schemas']['machine']
            facilities['actor_assembly'].update(new_entity_storage='world.entities',
                entity_references='entity_id', hardware_validation='new_source_workflow_not_hardware_tested')
            facilities['actor_assembly']['templates']['entity_bindings'] = 'entity_id'
            facilities['visibility'].update(field='world.map.visibility', group_field='world.map.visibility.groups',
                group_membership='scene_entity_ids', schema=CAPABILITY['schemas']['world'],
                group_command_schema=CAPABILITY['schemas']['commands'], incomplete_groups_saveable=True)
            facilities['world_properties'].update(reference_schema=CAPABILITY['actor_editing']['reference_schema'],
                declarations_schema=CAPABILITY['actor_editing']['declarations_schema'], requires_scene_machines=False)
            facilities['world_properties']['position_bindings'].update(field='world.entities[].visual_ref / visual_bindings',
                schema=CAPABILITY['schemas']['world'], commands=['scene.entity.set'])
            facilities['instance_behaviors'].update(schema=CAPABILITY['actor_editing']['instance_schema'],
                spatial_schema=CAPABILITY['actor_editing']['instance_schema'], source_versions=[3],
                schemas_by_version={'3':CAPABILITY['actor_editing']['instance_schema']})
            facilities['instance_behaviors']['target_bindings']['entity_namespace'] = 'entity_id'
            facilities['map_scene'].update(field='world.map', schema=CAPABILITY['schemas']['world'],
                imported_object_layer_required=False)
            from .terminal_order import enabled as terminal_enabled
            if terminal_enabled(bundle):
                contract = execution_semantics.capability()['contracts'][execution_semantics.TERMINAL]
                row['execution_contract'] = deepcopy(contract)
                row['egg_export'] = False
                facilities['destination_before_actions'] = False
                facilities['flowcharts'].update(destination_before_actions=False, runtime=False, export=False,
                    typed_calls=deepcopy(contract['callable_flows']))
                if 'flowcharts' in row and row['flowcharts'] is not None:
                    row['flowcharts'].update(destination_before_actions=False, runtime=False, export=False,
                        typed_calls=deepcopy(contract['callable_flows']))
                facilities['event_responses'].update(decisions_after_actions=True,
                    contexts=contract['contexts'], runtime=False, export=False)
                facilities['event_responses']['state_time_conditions']['machine_state']['sampling'] = 'at_authored_decision_node'
                for response in (facilities['event_responses'], facilities['instance_behaviors']['event_responses']):
                    response['decisions_after_actions'] = True
                    response['shared_triggers'] = deepcopy(contract['shared_triggers'])
                    response['typed_calls'] = deepcopy(contract['callable_flows'])
                    response['flow_library'] = deepcopy(contract['flow_library'])
                    response['preview_trace'] = dict(contract['terminal_trace'], supported=True,
                        action_completion=False, host_preview=True, runtime=False)
                facilities['destinations'].update(schema='schemas/authoring/incremental-destination-v1.schema.json',
                    entity_namespace='entity_id', invalidating_writes=contract['destination_invalidators'])
                facilities['instance_behaviors']['destinations']['invalidating_writes'] = contract['destination_invalidators']
                def restrict(value):
                    if isinstance(value, dict):
                        for key, child in value.items():
                            if key in ('runtime', 'export'):
                                value[key] = False
                            else:
                                restrict(child)
                    elif isinstance(value, list):
                        for child in value:
                            restrict(child)
                restrict(facilities)
            if terminal_enabled(bundle):
                row['flow_library'] = deepcopy(contract['flow_library'])
                row['behavior_library'] = deepcopy(contract['behavior_library'])
                facilities['instance_behaviors']['project_library'] = deepcopy(contract['behavior_library'])
            row['scene_machines'] = facilities
            row['world_properties'] = deepcopy(facilities['world_properties'])
            row['instance_behaviors'] = deepcopy(facilities['instance_behaviors'])
            row['supported_commands'] = [c for c in OBJECT_COMMANDS + COMMON_SCENE_COMMANDS
                if not authoring_foundation.unavailable_command(c)] + list(authoring_foundation.COMMANDS)
            if terminal_enabled(bundle):
                row['supported_commands'] += contract['flow_library']['commands'] + contract['behavior_library']['commands']
        return result
    export_ready = not build_readiness_issues(bundle)
    from .map_export import applies, PROFILE_ID as map_profile
    map_package = applies(bundle)
    from .execution_scope_source import readiness_issues as scope_issues, report as scope_report
    preview_issues = scope_issues(bundle, preview=True)
    adapter_issues = scope_issues(bundle, preview=True, scope_host=True)
    object_package = any(scene["schema_version"] == 2 for scene in bundle.scenes)
    return {
        scene["scene_id"]: {
            "schema_version": scene["schema_version"],
            "execution_model": execution_model(scene),
            "host_editing": True,
            "host_preview": not preview_issues,
            "preview_issues": deepcopy(preview_issues),
            "scope_host_preview": {"version": 1, "scope_ready": not adapter_issues,
                                   "issues": deepcopy(adapter_issues),
                                   "requires_reset_option": {"scope_host": {"version": 1}}},
            "preview_readiness_scope": "whole_project",
            "execution_scope_ownership": scope_report(scene),
            "scoped_variables": deepcopy(SCOPED_VARIABLE_CAPABILITY) if scene["schema_version"] == 2 else None,
            "entry_graph": deepcopy(SCENE_ENTRY_CAPABILITY) if scene["schema_version"] == 2 and "machine_logic" not in scene else None,
            "scene_machines": deepcopy(SCENE_MACHINES_CAPABILITY) if scene["schema_version"] == 2 else None,
            "menu_component": deepcopy(MENU_COMPONENT_CAPABILITY) if scene["schema_version"] == 2 else None,
            "presentation_selectors": deepcopy(SCENE_MACHINES_CAPABILITY["presentation_selectors"]) if "machine_logic" in scene else None,
            "flowcharts": deepcopy(SCENE_MACHINES_CAPABILITY["flowcharts"]) if "machine_logic" in scene else None,
            "world_properties": deepcopy(SCENE_MACHINES_CAPABILITY["world_properties"]) if "machine_logic" in scene else None,
            "local_time_conditions": deepcopy(SCENE_MACHINES_CAPABILITY["local_time_conditions"]) if "machine_logic" in scene else None,
            "scene_activated": deepcopy(SCENE_MACHINES_CAPABILITY["scene_activated"]) if "machine_logic" in scene else None,
            "retain_state": deepcopy(SCENE_MACHINES_CAPABILITY["retain_state"]) if "machine_logic" in scene else None,
            "machine_scene_replacement": deepcopy(SCENE_MACHINES_CAPABILITY["scene_replacement"]) if "machine_logic" in scene else None,
            "object_effects": deepcopy(SCENE_MACHINES_CAPABILITY["object_effects"]) if "machine_logic" in scene else None,
            "object_clips": deepcopy(SCENE_MACHINES_CAPABILITY["object_clips"]) if "machine_logic" in scene else None,
            "object_inversion": public_object_inversion_profile() if scene["schema_version"] == 2 else None,
            "scene_inversion": deepcopy(SCENE_MACHINES_CAPABILITY["scene_inversion"]) if "machine_logic" in scene else None,
            "egg_export": True,
            "export_ready": export_ready,
            "export_profile_id": (map_profile if map_package else SCENE_MACHINES_CAPABILITY["export_profile"]["profile_id"] if "machine_logic" in scene else V2_EXPORT_PROFILE_ID if object_package else None),
            "export_readiness_scope": "whole_project",
            "supported_commands": list(OBJECT_COMMANDS + COMMON_SCENE_COMMANDS) if scene["schema_version"] == 2 else None,
            "object_display_names": scene["schema_version"] == 2,
            "runtime_text": scene["schema_version"] == 2,
            "runtime_text_profile": public_v2_text_profile() if scene["schema_version"] == 2 else None,
            "legacy_command_catalog": scene["schema_version"] == 1,
            "state_management_commands": list(STATE_MANAGEMENT_COMMANDS),
            "graph_construction_commands": True,
            "timer_handler_layout": _timer_handler_layout_capability(),
            "timer_source_layout": _timer_source_layout_capability(),
            'relative_timers': SCENE_MACHINES_CAPABILITY['relative_timers'] if 'machine_logic' in scene else None,
            'instance_behaviors': deepcopy(SCENE_MACHINES_CAPABILITY['instance_behaviors']) if 'machine_logic' in scene else None,
            "calendar_schedules": ({**SCENE_MACHINES_CAPABILITY['calendar_schedules'],
                                    "supported": True, "event_type": "time.local_schedule"}
                                   if 'machine_logic' in scene else
                                   {"supported": scene["schema_version"] == 2,
                                    "event_type": "time.local_schedule", "maximum_per_scene": 1}),
            "local_graph_commands": list(LOCAL_GRAPH_COMMANDS),
            "scene_connection_commands": True,
            "connection_commands": list(SCENE_CONNECTION_COMMANDS),
            "scene_entry_modes": (["fresh_machine_states"] if "machine_logic" in scene else
                                  ["fresh_default", "fresh_entry_graph"] if scene["schema_version"] == 2 else ["fresh_default"]),
            "scene_exit_action_kinds": ["play_sfx"],
            "multi_scene_export": True,
            "audio_export": public_v2_audio_profile() if scene["schema_version"] == 2 else None,
            "route_destination_kinds": ["state", "system_exit", "scene"],
        } for scene in bundle.scenes
    }


def _placement_ownership(bundle: ProjectBundle) -> dict[str, Any]:
    from .authoring_foundation import enabled
    if enabled(bundle):
        return {'scenes': {s['scene_id']: {'entities': deepcopy(s.get('world', {}).get('entities', [])),
            'runtime_ownership_checked_on_execution': True} for s in bundle.scenes}}
    scenes: dict[str, Any] = {}
    for scene in bundle.scenes:
        scene_id = scene.get("scene_id")
        if scene.get("schema_version") == 2:
            objects = scene["objects"]
            live = initialize_objects(objects)
            clips = {clip["animation_id"]: clip for clip in bundle.animations}
            states = {}
            for state in scene["states"]:
                overrides = {item["object_ref"]: item for item in state["object_overrides"]}
                states[state["state_id"]] = {
                    "changes": {ref: {"local_properties": sorted(set(item) - {"object_ref"}), "animated": False} for ref, item in overrides.items()},
                    "resolved_elements": [
                        {**{key: value for key, value in obj.items() if key not in {"object_id", "defaults", "animation_ref", "display_name"}},
                         **resolve_object(obj, live[obj["object_id"]], overrides.get(obj["object_id"], {}), clips, 0),
                         "element_id": obj["object_id"]} for obj in objects
                    ],
                }
            scenes[scene_id] = {
                "execution_model": "scene_objects", "derived_read_only": True,
                "objects": deepcopy(objects), "states": states,
                "state_scoped_element_ids": sorted(obj["object_id"] for obj in objects
                    if not obj["defaults"]["visible"] and any(
                        item.get("visible") is True and item["object_ref"] == obj["object_id"]
                        for state in scene["states"] for item in state["object_overrides"])),
            }
            continue
        render_models = scene.get("render_models", [])
        if not isinstance(scene_id, str) or not render_models:
            continue

        render_model = render_models[0]
        render_model_id = render_model.get("visual_id")
        base_elements = render_model.get("elements", [])
        waiting_visuals = {
            item["waiting_visual_id"]: item
            for item in scene.get("waiting_visuals", [])
            if isinstance(item, dict) and isinstance(item.get("waiting_visual_id"), str)
        }
        state_results: dict[str, Any] = {}
        state_visible_ids: set[str] = set()
        for state in scene.get("states", []):
            state_id = state.get("state_id")
            if not isinstance(state_id, str):
                continue
            overrides = {
                item["element_ref"]: item
                for item in state.get("placement_overrides", [])
                if isinstance(item, dict) and isinstance(item.get("element_ref"), str)
            }
            state_visible_ids.update(
                element_id
                for element_id, override in overrides.items()
                if override.get("visible") is True
            )
            waiting_visual = waiting_visuals.get(state.get("waiting_visual_ref"), {})
            animated_ids = {
                item["source_element_ref"]
                for item in waiting_visual.get("elements", [])
                if isinstance(item, dict) and isinstance(item.get("source_element_ref"), str)
            }
            changes: dict[str, Any] = {}
            resolved_elements: list[dict[str, Any]] = []
            for base_element in base_elements:
                element = deepcopy(base_element)
                element_id = element.get("element_id")
                override = overrides.get(element_id, {})
                local_properties: list[str] = []
                if "x" in override or "y" in override:
                    local_properties.append("position")
                    if "x" in override:
                        element["x"] = override["x"]
                    if "y" in override:
                        element["y"] = override["y"]
                if "visible" in override:
                    local_properties.append("visible")
                    element["visible"] = override["visible"]
                if "visual_ref" in override:
                    local_properties.append("visual_ref")
                    element["visual_ref"] = override["visual_ref"]
                animated = element_id in animated_ids
                if local_properties or animated:
                    changes[element_id] = {
                        "local_properties": local_properties,
                        "animated": animated,
                    }
                resolved_elements.append(element)
            state_results[state_id] = {
                "changes": changes,
                "resolved_elements": resolved_elements,
            }

        scenes[scene_id] = {
            "render_model_id": render_model_id,
            "state_scoped_element_ids": sorted(
                element_id
                for element in base_elements
                for element_id in [element.get("element_id")]
                if isinstance(element_id, str)
                if element.get("visible", True) is False
                and element_id in state_visible_ids
            ),
            "states": state_results,
        }
    return {"scenes": scenes}


class AuthoringService:
    """Single-session deterministic facade over the headless authoring API."""

    def __init__(self) -> None:
        self._bundle: ProjectBundle | None = None
        self._project_revision = 0
        self._preview: StateScenePreview | None = None
        self._preview_revision = 0
        self._saved_sha256: str | None = None
        self._undo_stack: list[ProjectBundle] = []
        self._redo_stack: list[ProjectBundle] = []
        self.shutdown_requested = False
        self._debug = None
        self._preview_update = "not_started"
        self._preview_scene_identities = {}
        from .processing_cache import ProcessingCache
        self._processing_cache = ProcessingCache()

    def _dirty(self) -> bool:
        if self._bundle is None:
            return False
        return _semantic_sha256(self._bundle) != self._saved_sha256

    def _remember_undo(self, bundle: ProjectBundle) -> None:
        self._undo_stack.append(bundle)
        if len(self._undo_stack) > UNDO_LIMIT:
            del self._undo_stack[0 : len(self._undo_stack) - UNDO_LIMIT]
        self._redo_stack.clear()

    def _invalidate_preview(self) -> None:
        if self._debug is not None:
            self._debug.abort()
            self._debug = None
        self._preview = None
        self._preview_revision += 1
        self._preview_update = "not_started"

    def _prepare_preview_edit(self, updated: ProjectBundle):
        from .preview_edit import execution_identity, visual_candidate
        from .preview_dependencies import identities, stale_scenes, marked_copy
        if self._debug is not None:
            if execution_identity(self._bundle) != execution_identity(updated):
                raise ProtocolError('PREVIEW_DEBUG_EDIT_REQUIRES_STOP', 'Abort pending work and stop debugging before executable edits')
            return 'preserved', self._preview, self._preview_scene_identities
        current = identities(updated) if self._preview is not None else {}
        baseline = self._preview_scene_identities
        if self._preview is not None:
            active = self._preview._scene['scene_id']
            if current.get(active) is not None and current.get(active) == baseline.get(active):
                return "preserved", marked_copy(self._preview, stale_scenes(baseline, current)), baseline
        elif execution_identity(self._bundle) == execution_identity(updated):
            return "preserved", None, baseline
        try:
            candidate = visual_candidate(self._bundle, updated, self._preview)
        except (ValueError, KeyError, TypeError) as exc:
            raise ProtocolError("PREVIEW_VISUAL_UPDATE_FAILED", str(exc)) from exc
        if candidate is not None:
            active = candidate._scene['scene_id']
            baseline = {**baseline, active: current[active]}
            return "visual_updated", marked_copy(candidate, stale_scenes(baseline, current)), baseline
        from .scope_preview_host import require_stopped_before_replacement
        require_stopped_before_replacement(self._preview)
        return "restart_required", None, {}

    def _finish_preview_edit(self, prepared) -> None:
        outcome, candidate, baseline = prepared
        had_preview = self._preview is not None
        if outcome == "restart_required":
            self._invalidate_preview()
        elif candidate is not None:
            self._preview = candidate
        self._preview_scene_identities = baseline
        self._preview_update = outcome if had_preview else "not_started"

    def _project_document_result(self, bundle: ProjectBundle) -> dict[str, Any]:
        from .world_authoring import report as world_report
        from .machine_startup import report as participation_report
        from .preview_dependencies import report as dependency_report
        from .map_colour import diagnostics as map_colour_diagnostics
        return {
            "project_revision": self._project_revision,
            "valid": bundle.valid,
            "preview_revision": self._preview_revision,
            "preview_update": self._preview_update,
            "preview_dependencies": dependency_report(self._preview),
            "preview_snapshot": self._preview_result(self._preview.snapshot())
                if self._preview_update == "visual_updated" and self._preview is not None else None,
            "map_colour_issues": map_colour_diagnostics(bundle),
            "issues": _issues(bundle),
            "build_issues": build_readiness_issues(bundle),
            "execution_issues": authoring_foundation.execution_issues(bundle),
            "execution_semantics": execution_semantics.report(bundle.project),
            "machine_participation": participation_report(bundle),
            "world_authoring": world_report(bundle),
            "document": bundle.normalized() if bundle.valid else None,
            "placement_ownership": _placement_ownership(bundle) if bundle.valid else None,
            "scene_capabilities": _scene_capabilities(bundle),
            "summary": _project_summary(bundle),
            "dirty": self._dirty(),
            "can_undo": bool(self._undo_stack),
            "can_redo": bool(self._redo_stack),
            "undo_limit": UNDO_LIMIT,
        }

    def _current_bundle(
        self,
        params: dict[str, Any],
        operation_fields: set[str] | None = None,
    ) -> ProjectBundle:
        _require_fields(params, {"project_revision"} | (operation_fields or set()))
        if self._bundle is None:
            raise ProtocolError("PROJECT_NOT_LOADED", "load a project before this operation")
        revision = params["project_revision"]
        if not isinstance(revision, int) or isinstance(revision, bool):
            raise ProtocolError("PROJECT_REVISION_INVALID", "project_revision must be an integer")
        if revision != self._project_revision:
            raise ProtocolError(
                "PROJECT_REVISION_STALE",
                "operation targets an outdated project revision",
                details={"current_project_revision": self._project_revision},
            )
        return self._bundle

    def _hello(self, params: dict[str, Any]) -> dict[str, Any]:
        _require_fields(params, set())
        from .asset_library import capability as asset_library_capability
        from .preview_edit import CAPABILITY as preview_editing
        return {
            "service": SERVICE_NAME,
            "service_api_version": SERVICE_API_VERSION,
            "preview_editing": deepcopy(preview_editing),
            "authoring_foundation": deepcopy(authoring_foundation.CAPABILITY),
            "execution_semantics": execution_semantics.capability(),
            "preview_debugging": deepcopy(PREVIEW_DEBUG_CAPABILITY),
            "asset_library": asset_library_capability(),
            "tiled_import": {
                "status": "development_restricted", "runtime_encoded": True, "preview": True,
                "export_profile_id": SCENE_MACHINES_CAPABILITY['map_export_profile']['profile_id'],
                "export_requires_project_readiness": True,
                "preview_requires": "all_scenes_have_map_scene_bindings",
                "commands": ["map.import", "map.reimport", "map.property.set", "map.property.clear", "map.delete"],
                "source": "finite_orthogonal_json_embedded_image_tilesets",
                "properties": ["bool", "int32", "static_string"],
                "persisted": True, "undo_redo": True,
            },
            "scoped_variables": deepcopy(SCOPED_VARIABLE_CAPABILITY),
            "entry_graph": deepcopy(SCENE_ENTRY_CAPABILITY),
            "scene_machines": deepcopy(SCENE_MACHINES_CAPABILITY),
            "menu_component": deepcopy(MENU_COMPONENT_CAPABILITY),
            "inventory": deepcopy(INVENTORY_CAPABILITY),
            "protocol_version": PROTOCOL_VERSION,
            "operations": list(SERVICE_OPERATIONS),
            "project_settings": {
                "read_operation": "project.settings.get", "edit_command": "project.settings.set",
                "replacement": "whole_settings_object", "persisted": True,
                "undo_redo": True, "runtime_encoded": False,
                "sfx_import": {"status": "persisted_only", "import_applied": False,
                               "normalization": ["none", "peak"],
                               "target_peak_dbfs": {"minimum": -60, "maximum": 0, "integer": True}},
                "runtime_preferences": {"status": "persisted_only", "firmware_enforced": False,
                                        "inactivity_timeout_ms": {"minimum": 1000, "maximum": 86400000,
                                                                  "nullable": True, "integer": True}},
            },
            "asset_metadata": {"tags": {"supported": True, "commands": ["asset.set_tags", "audio_asset.set_tags"],
                                        "maximum_count": 16, "maximum_length": 32, "case_sensitive": True,
                                        "runtime_encoded": False},
                               "animation_display_names": {
                                   "supported": True, "commands": ["animation.upsert"],
                                   "minimum_length": 1, "maximum_length": 64,
                                   "optional": True, "runtime_encoded": False,
                                   "update_mode": "replace_record", "omission_clears": True,
                               }},
            "timer_source_layout": _timer_source_layout_capability(),
            "package_export": {
                "operation": "project.build_package",
                "container_versions": [1, 2],
                "v2_profile": public_v2_export_profile(),
                "machine_profile": deepcopy(SCENE_MACHINES_CAPABILITY["export_profile"]),
                "map_profile": deepcopy(SCENE_MACHINES_CAPABILITY['map_export_profile']),
                "readiness_field": "build_issues",
                "admission_diagnostics": {
                    "machine_failed_export_analysis": True,
                    "report_operation": "project.compatibility_report",
                    "failure_report_field": "details.compatibility_report",
                    "budget_field": "budgets.waiting_visual_sequences",
                    "object_attribution": "contributing_objects_not_minimal_cause",
                    "exact_device_admission_required": True,
                },
            },
            "scene_creation": {
                "project_operation": "project.create",
                "scene_command": "scene.add",
                "entry_scene_command": "project.set_entry_scene",
                "version_parameter": "scene_schema_version",
                "supported_versions": [1, 2],
                "default_version": 1,
                "scene_add_inherits_version": False,
                "initial_state_id": "start",
                "initial_scene_id_parameter": "initial_scene_id",
                "initial_scene_id_default": "main",
                "empty_scene_is_editable_draft": True,
            },
            "scene_object_authoring": {
                "display_names": {"supported": True, "command": "object.rename", "maximum_length": 96,
                                  "fallback": "object_id", "runtime_encoded": False},
                "status": "restricted_firmware_available", "schema_version": 2,
                "execution_model": "scene_objects", "egg_export": True, "firmware_available": True,
                "export_profile_id": V2_EXPORT_PROFILE_ID,
                "export_requires_project_readiness": True,
                "commands": list(OBJECT_COMMANDS + COMMON_SCENE_COMMANDS),
                "state_management_commands": list(STATE_MANAGEMENT_COMMANDS),
                "absolute_axes": {"x": "right", "y": "down"},
                "relative_axes": {"dx": "right", "dy": "up"},
                "object_clipping": public_object_clipping_profile(),
                "object_inversion": public_object_inversion_profile(),
                "override_properties": ["x", "y", "visible", "visual_ref", "inverted"],
                "clip_loop_policies": ["loop"],
                "runtime_playback_controls": False,
                "graph_construction_commands": True,
                "local_graph_commands": list(LOCAL_GRAPH_COMMANDS),
                "scene_connection_commands": True,
                "connection_commands": list(SCENE_CONNECTION_COMMANDS),
                "scene_entry_modes": ["fresh_default", "fresh_entry_graph"],
                "scene_exit_action_kinds": ["play_sfx"],
                "multi_scene_export": True,
                "audio_export": public_v2_audio_profile(),
                "runtime_text": public_v2_text_profile(),
                "route_destination_kinds": ["state", "system_exit", "scene"],
            },
            "target_profiles": {
                "default_profile_id": TARGET_PROFILE_ID,
                "available": [public_target_profile()],
            },
            "state_scene_presentation": {
                "record_format": "RND2",
                "load_compatible_formats": ["RND1", "RND2"],
                "package_layers": ["BACKGROUND", "SCENE", "UI"],
                "system_layers": ["OVERLAY"],
                "element_kinds": [
                    "sprite",
                    "line",
                    "outline_rect",
                    "filled_rect",
                    "circle",
                    "ellipse",
                    "filled_circle",
                    "filled_ellipse",
                ],
                "line_directions": ["down_right", "up_right"],
                "visibility": True,
                "z_order": True,
                "element_commands": [
                    "placement_object.add",
                    "render_element.add",
                    "render_element.delete",
                    "render_element.set_bounds",
                    "render_element.set_kind",
                    "render_element.set_layer",
                    "render_element.set_z_order",
                ],
                "state_override_commands": [
                    "state_placement.set_override",
                    "state_placement.clear_override",
                ],
                "asset_commands": [
                    "asset.set_tags",
                    "asset.upsert",
                    "asset.delete",
                ],
                "general_frame_animation": {
                    "state_placeable": False,
                    "purpose": "reserved for future SEQUENCE authoring",
                    "commands": [
                    "animation.upsert",
                    "animation.delete",
                    ],
                },
                "waiting_animation": {
                    "sprite_only": True,
                    "phase_count": {"minimum": 1, "maximum": 4},
                    "combined_step_count": {"minimum": 1, "maximum": 12},
                    "element_count_maximum": 32,
                    "quantum_ms": {"minimum": 1, "maximum": 60000},
                    "cycle_policies": ["loop"],
                    "commands": [
                        "waiting_visual.upsert",
                        "waiting_visual.delete",
                        "state.set_waiting_visual",
                        "render_element.bind_waiting_animation",
                        "render_element.clear_waiting_animation",
                    ],
                },
                "logical_inputs": [
                    "BUTTON_A",
                    "BUTTON_B",
                    "BUTTON_L",
                    "BUTTON_R",
                    "BUTTON_START",
                    "JOY_LEFT",
                    "JOY_RIGHT",
                    "JOY_UP",
                    "JOY_DOWN",
                    "JOY_UP_LEFT",
                    "JOY_UP_RIGHT",
                    "JOY_DOWN_LEFT",
                    "JOY_DOWN_RIGHT",
                ],
                "logical_input_events": ["press", "release", "hold", "repeat"],
                "joystick_policies": ["four_way", "eight_way"],
                "runtime_text": True,
                "runtime_text_profile": public_v2_text_profile(),
                "build_time_text": {
                    "source_format": "system_font_text",
                    "font_ids": ["peepshow.system.8x8.basic.v1"],
                    "character_set": "printable_ascii_plus_newline",
                    "glyph_cell": {"width": 8, "height": 8},
                    "scale": {"minimum": 1, "maximum": 8, "integer_only": True},
                    "ink": "black",
                    "background": "transparent",
                    "frames_per_asset": 1,
                    "commands": ["asset.upsert", "asset.delete"],
                },
                "element_actions": {
                    "target": "destination_state_render_model",
                    "atomic_with_variable_actions": True,
                    "kinds": [
                        "set_element_visibility",
                        "set_element_position",
                        "set_element_frame",
                        "set_element_waiting_animation",
                    ],
                    "waiting_visual_linkage": {
                        "visibility": True,
                        "position": True,
                        "frame_selection_replaces_animation": False,
                        "animation_selection": {
                            "source": "waiting_visual_element",
                            "timeline_policies": ["preserve", "rebase"],
                            "requires_matching_cadence_and_step_count": True,
                        },
                    },
                },
                "system_actions": ["exit_to_shell"],
            },
            "state_scene_graph": {
                "compiled_format": "STG1",
                "compiled_format_version": 6,
                "load_compatible_versions": [1, 2, 3, 4, 5, 6],
                "scene_timers": {
                    "event_type": "time.scene_elapsed",
                    "start_policies": ["scene_entry", "action"],
                    "actions": ["start_timer", "restart_timer", "cancel_timer"],
                    "handler_collection": "event_handlers",
                    "handler_target_optional": True,
                    "element_actions_require_target_state": True,
                    "editor_layout": _timer_handler_layout_capability(),
                },
                "calendar_schedules": {
                    "event_type": "time.local_schedule", "scene_schema_versions": [2],
                    "maximum_per_scene": 1, "ownership": "scene", "start_policy": "scene_entry",
                    "modes": ["daily", "today_offset", "next_occurrence"],
                    "time_of_day_seconds": {"minimum": 0, "maximum": 86399},
                    "day_offset": {"minimum": 0, "maximum": 32767, "mode": "today_offset"},
                    "handler_collection": "event_handlers", "handler_target_optional": True,
                    "unset_clock": "wait_for_explicit_time_set", "clock_edit": "skip_crossed_occurrences",
                    "suspension": "defer_without_moving_deadline", "late_daily": "coalesce_one",
                    "scene_replacement": "cancel_and_fresh_arm", "timer_actions": [],
                    "editor_layout": _timer_handler_layout_capability(),
                    "status": "available_pending_validation",
                    "preview_clock": "project.preview_set_local_time",
                },
                "command_batch_maximum": 64,
                "target_scene_actions": ["play_sfx"],
                "scene_commands": ["scene.add", "scene.rename", "project.set_entry_scene"],
                "scene_flow_commands": [
                    "editor.scene_flow.set_node_position",
                    "editor.scene_flow.set_package_entry_position",
                    "editor.scene_flow.add_reference",
                    "editor.scene_flow.set_reference_position",
                    "editor.scene_flow.set_reference_target",
                    "editor.scene_flow.delete_reference",
                    "editor.scene_flow.set_exit_reference",
                    "editor.scene_flow.set_route_layout",
                ],
                "peepos_trigger_commands": [],
                "peepos_trigger_catalog": [
                    {
                        "kind": "step_count",
                        "label": "Step count",
                        "detail": "Daily step count reached a configured value",
                        "support": "contract_only",
                        "requires": [
                            "authoring_schema",
                            "compiler",
                            "preview",
                            "firmware_event_dispatch",
                            "target_capability",
                        ],
                    },
                    {
                        "kind": "delay_elapsed",
                        "label": "Timer",
                        "detail": "Bounded delay elapsed",
                        "support": "contract_only",
                        "requires": ["authoring_schema", "compiler", "preview", "firmware_event_dispatch"],
                    },
                    {
                        "kind": "local_schedule",
                        "label": "Date and time",
                        "detail": "Local calendar schedule matched",
                        "support": "available_pending_validation",
                        "requires": ["scene_schema_v2", "valid_local_time"],
                    },
                    {
                        "kind": "device_active",
                        "label": "Device active",
                        "detail": "PeepOS activated the package",
                        "support": "contract_only",
                        "requires": ["authoring_schema", "compiler", "preview", "firmware_event_dispatch"],
                    },
                    {
                        "kind": "device_inactive",
                        "label": "Device inactive",
                        "detail": "PeepOS suspended active interaction",
                        "support": "contract_only",
                        "requires": ["authoring_schema", "compiler", "preview", "firmware_event_dispatch"],
                    },
                    {
                        "kind": "wake_resume",
                        "label": "Wake or resume",
                        "detail": "A declared wake or resume reason occurred",
                        "support": "contract_only",
                        "requires": ["authoring_schema", "compiler", "preview", "firmware_event_dispatch"],
                    },
                    {
                        "kind": "animation_complete",
                        "label": "Animation complete",
                        "detail": "A bounded animation reached completion",
                        "support": "contract_only",
                        "requires": ["authoring_schema", "compiler", "preview", "firmware_event_dispatch"],
                    },
                    {
                        "kind": "audio_marker",
                        "label": "Audio marker",
                        "detail": "A cue marker or completion event occurred",
                        "support": "contract_only",
                        "requires": ["authoring_schema", "compiler", "preview", "firmware_event_dispatch"],
                    },
                    {
                        "kind": "peripheral_event",
                        "label": "Peripheral event",
                        "detail": "A capability-approved sensor or peripheral event occurred",
                        "support": "contract_only",
                        "requires": ["target_capability", "authoring_schema", "compiler", "preview", "firmware_event_dispatch"],
                    },
                ],
                "limits": {
                    "states": 64,
                    "render_models": 1,
                    "variables": 32,
                    "input_actions": 32,
                    "scene_exits": 32,
                    "compiled_event_bindings": int(
                        TARGET_STATE_SCENE_EVENTS["binding_count_max"]
                    ),
                    "routes": 128,
                    "guards_per_route": 8,
                    "actions_per_route": 8,
                    "route_waypoints": 8,
                },
                "route_layout_version": 3,
                "editor_layout_commands": [
                    "editor.state_graph.set_node_position",
                    "editor.state_graph.set_entry_layout",
                    "editor.state_graph.delete_system_exit",
                    "editor.state_graph.set_route_layout",
                    "editor.state_graph.set_handler_layout",
                ],
                "state_commands": [
                    "state.create",
                    "state.add",
                    "state.delete",
                    "state.rename",
                    "state.set_entry",
                    "state.set_waiting_visual",
                ],
                "state_placement_commands": [
                    "state_placement.set_override",
                    "state_placement.clear_override",
                ],
                "render_model_commands": [
                    "render_model.set_focus_index",
                ],
                "variable_commands": [
                    "variable.add",
                    "variable.update",
                    "variable.delete",
                ],
                "input_action_commands": [
                    "input_action.add",
                    "input_action.update",
                    "input_action.delete",
                ],
                "event_binding_commands": [
                    "event_binding.add",
                    "event_binding.update",
                    "event_binding.delete",
                ],
                "event_handler_commands": [
                    "event_handler.add",
                    "event_handler.update",
                    "event_handler.delete",
                ],
                "route_commands": [
                    "route.create_trigger",
                    "route.rebind_trigger",
                    "route.add",
                    "route.delete",
                    "route.set_action_ref",
                    "route.set_event_ref",
                    "route.set_sources",
                    "route.set_target",
                ],
                "scene_exit_commands": [
                    "scene_exit.add",
                    "scene.restart.add",
                    "scene_exit.set_target",
                    "scene_exit.delete",
                ],
                "guard_commands": [
                    "route.guard.add",
                    "route.guard.delete",
                    "route.guard.move",
                    "route.set_guard",
                ],
                "action_commands": [
                    "route.action.add",
                    "route.action.delete",
                    "route.action.move",
                    "route.set_action",
                ],
                "policy_commands": [
                    "scene.set_reactive_wait_default",
                    "scene.set_interaction_policy",
                    "scene.set_joystick_policy",
                ],
                "generic_delete_policy": "reject_if_referenced",
            },
            "state_scene_audio": {
                "host_package_support": True,
                "target_playback_status": TARGET_SAMPLED_SFX[
                    "target_playback_status"
                ],
                "source_format": "wav_pcm",
                "compiled_format": TARGET_SAMPLED_SFX["compiled_format"],
                "sample_rate_hz": AUDIO_SAMPLE_RATE_HZ,
                "channels": int(TARGET_SAMPLED_SFX["channels"]),
                "block_samples": AUDIO_BLOCK_SAMPLES,
                "maximum_duration_ms": TARGET_SAMPLED_SFX[
                    "maximum_duration_ms"
                ],
                "maximum_assets": AUDIO_MAX_ASSETS,
                "maximum_cues": AUDIO_MAX_CUES,
                "maximum_bank_bytes": AUDIO_MAX_BANK_BYTES,
                "voice_limit": int(TARGET_SAMPLED_SFX["voice_limit"]),
                "route_action": TARGET_SAMPLED_SFX["route_action"],
                "survives_same_package_scene_replacement": TARGET_SAMPLED_SFX[
                    "survives_same_package_scene_replacement"
                ],
                "asset_commands": ["audio_asset.upsert", "audio_asset.delete", "audio_asset.set_tags"],
                "cue_commands": ["audio_cue.upsert", "audio_cue.delete"],
                "audition_operation": "project.audio_audition",
                "unsupported": list(TARGET_SAMPLED_SFX["unsupported"]),
            },
            "project_loaded": self._bundle is not None,
            "project_revision": self._project_revision if self._bundle is not None else None,
        }

    def _shutdown(self, params: dict[str, Any]) -> dict[str, Any]:
        _require_fields(params, set())
        self.shutdown_requested = True
        return {"shutdown": True}

    def _activate_bundle(self, bundle: ProjectBundle) -> dict[str, Any]:
        self._bundle = bundle
        self._project_revision += 1
        self._preview = None
        self._preview_revision += 1
        self._preview_update = "not_started"
        self._saved_sha256 = _semantic_sha256(bundle)
        self._undo_stack.clear()
        self._redo_stack.clear()
        return {
            "project_revision": self._project_revision,
            "source_name": bundle.root.name,
            **self._project_document_result(bundle),
        }

    def _create(self, params: dict[str, Any]) -> dict[str, Any]:
        _require_fields(params, {"path"} | (set(params) & {"scene_schema_version", "initial_scene_id", "authoring_mode", "create_initial_scene", "execution_semantics"}))
        path = params["path"]
        if not isinstance(path, str) or not path:
            raise ProtocolError("PROJECT_PATH_INVALID", "path must be non-empty text")
        try:
            bundle = create_project(Path(path), scene_schema_version=params.get("scene_schema_version", 1),
                                    initial_scene_id=params.get('initial_scene_id', 'main'), authoring_mode=params.get('authoring_mode'),
                                    create_initial_scene=params.get('create_initial_scene', True), execution_semantics=params.get('execution_semantics'))
        except ProjectCommandError as exc:
            raise ProtocolError(exc.code, exc.message) from exc
        return self._activate_bundle(bundle)

    def _load(self, params: dict[str, Any]) -> dict[str, Any]:
        _require_fields(params, {"path"})
        path = params["path"]
        if not isinstance(path, str) or not path:
            raise ProtocolError("PROJECT_PATH_INVALID", "path must be non-empty text")
        bundle = load_project(Path(path))
        return self._activate_bundle(bundle)

    def _validate(self, params: dict[str, Any]) -> dict[str, Any]:
        from .map_colour import diagnostics as map_colour_diagnostics
        bundle = self._current_bundle(params)
        return {
            "project_revision": self._project_revision,
            "valid": bundle.valid,
            "execution_semantics": execution_semantics.report(bundle.project),
            "issues": _issues(bundle),
            "execution_issues": authoring_foundation.execution_issues(bundle),
            "map_colour_issues": map_colour_diagnostics(bundle),
            "build_issues": build_readiness_issues(bundle),
            "semantic_sha256": (
                hashlib.sha256(bundle.canonical_bytes()).hexdigest() if bundle.valid else None
            ),
        }

    def _settings_get(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params)
        return {"project_revision": self._project_revision,
                "settings": deepcopy(bundle.project.get("settings", {}))}

    def _inventory_inspect(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params)
        if not bundle.valid:
            raise ProtocolError('PROJECT_INVALID', 'project must validate before inventory inspection',
                                details={'issues': _issues(bundle)})
        from .inventory_source import inspect_source
        return dict(project_revision=self._project_revision,
                    **inspect_source(bundle.project, bundle.scenes))

    def _actor_inspect(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params, {'scene_id', 'instance_ref'})
        if not bundle.valid:
            raise ProtocolError('PROJECT_INVALID', 'project must validate before actor inspection')
        from .actor_assembly import inspect_source
        from .imported_properties import ImportedPropertyError
        scene = next((s for s in bundle.scenes if s['scene_id'] == params['scene_id']), None)
        if scene is None or type(params['instance_ref']) is not str:
            raise ProtocolError('ACTOR_ASSEMBLY_INVALID', 'Unknown Scene or invalid instance identity')
        try:
            if authoring_foundation.enabled(bundle):
                from .entity_editing import inspect as inspect_entity
                result = inspect_entity(bundle, scene, params['instance_ref'])
            else:
                result = inspect_source(scene, bundle.asset_catalogs, params['instance_ref'])
        except ImportedPropertyError as exc:
            raise ProtocolError('ACTOR_ASSEMBLY_INVALID', str(exc)) from exc
        except (KeyError, TypeError, StopIteration, AttributeError, IndexError) as exc:
            raise ProtocolError('ACTOR_ASSEMBLY_INCOMPLETE',
                'Complete the selected actor/map setup before inspecting its assembly') from exc
        from .actor_templates import library
        result['template_link'] = deepcopy(next((p for p in library(bundle.project)['placements']
            if (p['scene_id'], p['instance_ref']) == (params['scene_id'], params['instance_ref'])), None))
        return dict(project_revision=self._project_revision, **result)

    def _actor_template_inspect(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params, {'template_ref'})
        if not bundle.valid:
            raise ProtocolError('PROJECT_INVALID', 'project must validate before template inspection')
        from .actor_templates import inspect_source
        try:
            return dict(project_revision=self._project_revision, **inspect_source(bundle.project, params['template_ref']))
        except ProjectCommandError as exc:
            raise ProtocolError(exc.code, exc.message) from exc

    def _normalize(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params)
        if not bundle.valid:
            raise ProtocolError(
                "PROJECT_INVALID",
                "project must validate before normalization",
                details={"issues": _issues(bundle)},
            )
        return {
            "project_revision": self._project_revision,
            "document": bundle.normalized(),
            "scene_capabilities": _scene_capabilities(bundle),
            "canonical_sha256": hashlib.sha256(bundle.canonical_bytes()).hexdigest(),
        }

    def _build_package(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params)
        readiness = build_readiness_issues(bundle)
        if readiness:
            raise ProtocolError(
                "PACKAGE_NOT_READY",
                "\n".join(issue["message"] for issue in readiness),
                details={"issues": readiness, "project_revision": self._project_revision,
                         "compatibility_report": build_compatibility_report(bundle)},
            )
        if not bundle.valid:
            raise ProtocolError(
                "PROJECT_INVALID",
                "project must validate before package compilation",
                details={"issues": _issues(bundle), "project_revision": self._project_revision,
                         "compatibility_report": build_compatibility_report(bundle)},
            )
        try:
            blob = build_egg(bundle)
            metadata = export_metadata(bundle, blob)
        except (EggCompileError, EggFormatError) as exc:
            raise ProtocolError("PACKAGE_BUILD_FAILED", str(exc), details={
                "project_revision": self._project_revision,
                "compatibility_report": build_compatibility_report(bundle),
            }) from exc
        report = build_compatibility_report(bundle, blob)
        return {
            "project_revision": self._project_revision,
            "package": {
                **metadata,
                "blob_base64": base64.b64encode(blob).decode("ascii"),
            },
            "compatibility_report": report,
        }

    def _compatibility_report(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params)
        try:
            blob = build_egg(bundle) if bundle.valid and not build_readiness_issues(bundle) else None
        except EggCompileError as exc:
            raise ProtocolError("PACKAGE_BUILD_FAILED", str(exc)) from exc
        return {
            "project_revision": self._project_revision,
            "report": build_compatibility_report(bundle, blob),
        }

    def _scene_thumbnails(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params)
        if not bundle.valid:
            raise ProtocolError(
                "PROJECT_INVALID",
                "project must validate before scene thumbnail generation",
                details={"issues": _issues(bundle)},
            )
        try:
            package = build_preview_package(bundle)
            thumbnails = [
                {
                    "scene_id": str(scene["scene_id"]),
                    "framebuffer": StateScenePreview(package, str(scene["scene_id"])).snapshot()["framebuffer"],
                }
                for scene in package.scenes
            ]
        except (EggCompileError, EggFormatError, PreviewError) as exc:
            raise ProtocolError("SCENE_THUMBNAILS_FAILED", str(exc)) from exc
        return {
            "project_revision": self._project_revision,
            "thumbnails": thumbnails,
        }

    def _audio_audition(self, params: dict[str, Any]) -> dict[str, Any]:
        fields = {'cue_id'}
        if 'scope_host' in params:
            from .scope_preview_host import negotiate
            negotiate(params['scope_host'])
            fields.add('scope_host')
        bundle = self._current_bundle(params, fields)
        cue_id = params["cue_id"]
        if not isinstance(cue_id, str) or not cue_id:
            raise ProtocolError("AUDIO_CUE_INVALID", "cue_id must be non-empty text")
        if not bundle.valid:
            raise ProtocolError(
                "PROJECT_INVALID",
                "project must validate before audio audition",
                details={"issues": _issues(bundle)},
            )
        try:
            package = build_preview_package(bundle, scope_host='scope_host' in params)
            cue = next(
                (item for item in package.audio_cues if item["cue_id"] == cue_id),
                None,
            )
            if cue is None:
                raise ProtocolError("AUDIO_CUE_NOT_FOUND", f"audio cue '{cue_id}' is not present")
            asset = package.audio_assets[int(cue["asset_index"])]
            samples = decode_ima_adpcm(
                asset["adpcm"],
                int(asset["sample_count"]),
                int(asset["block_count"]),
                int(asset["block_samples"]),
            )
            wav = pcm16_wav(samples)
        except (EggCompileError, EggFormatError, AudioAssetError) as exc:
            raise ProtocolError("AUDIO_AUDITION_FAILED", str(exc)) from exc
        return {
            "project_revision": self._project_revision,
            "cue": {
                "cue_id": cue["cue_id"],
                "asset_id": cue["asset_id"],
                "priority": cue["priority"],
                "volume": cue["volume"],
            },
            "audio": {
                "encoding": "wav_pcm_s16le",
                "sample_rate_hz": asset["sample_rate_hz"],
                "channels": asset["channels"],
                "sample_count": asset["sample_count"],
                "duration_ms": asset["duration_ms"],
                "wav_base64": base64.b64encode(wav).decode("ascii"),
            },
        }

    def _apply_commands(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params, {"commands"})
        try:
            updated, applied = apply_project_commands(bundle, params["commands"])
        except ProjectCommandError as exc:
            raise ProtocolError(exc.code, exc.message) from exc
        preserved = self._prepare_preview_edit(updated)
        self._remember_undo(bundle)
        self._bundle = updated
        self._project_revision += 1
        self._finish_preview_edit(preserved)
        return {
            **self._project_document_result(updated),
            "applied_commands": list(applied),
        }

    def _object_migration_preview(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params, {"scene_id", "accept_continuous_animation"})
        if not isinstance(params["scene_id"], str) or type(params["accept_continuous_animation"]) is not bool:
            raise ProtocolError("OPERATION_PARAMS_INVALID", "scene_id must be text and animation acceptance must be boolean")
        try:
            plan = plan_object_migration(bundle, params["scene_id"], accept_continuous_animation=params["accept_continuous_animation"])
        except SceneObjectError as exc:
            raise ProtocolError(exc.issue.code, exc.issue.message) from exc
        return {"project_revision": self._project_revision, "plan": asdict(plan), "can_apply": not plan.issues}

    def _object_migration_apply(self, params: dict[str, Any]) -> dict[str, Any]:
        from .project import _check_scene
        bundle = self._current_bundle(params, {"scene_id", "source_revision", "accept_continuous_animation"})
        preview = self._object_migration_preview({key: value for key, value in params.items() if key != "source_revision"})
        if params["source_revision"] != preview["plan"]["source_revision"]:
            raise ProtocolError("MIGRATION_SOURCE_CHANGED", "preview migration again against the current project")
        try:
            plan = plan_object_migration(bundle, params["scene_id"], accept_continuous_animation=params["accept_continuous_animation"])
            scene, clips = materialize_object_migration(bundle, plan, accept_continuous_animation=params["accept_continuous_animation"])
            updated = bundle
            if clips:
                updated, _ = apply_project_commands(bundle, [{"kind": "animation.upsert", "animation": clip} for clip in clips])
            issues = []
            _check_scene(scene, params["scene_id"], {frame.frame_id: frame for frame in updated.frames},
                         {clip["animation_id"] for clip in updated.animations}, {cue["cue_id"] for cue in updated.audio_cues},
                         issues, {clip["animation_id"]: clip for clip in updated.animations})
            if issues:
                raise ProtocolError("MIGRATION_INVALID", "migration did not validate", details={"issues": [asdict(item) for item in issues]})
            updated = replace(updated, scenes=tuple(scene if item["scene_id"] == scene["scene_id"] else item for item in updated.scenes))
        except (SceneObjectError, ProjectCommandError) as exc:
            if isinstance(exc, SceneObjectError):
                raise ProtocolError(exc.issue.code, exc.issue.message) from exc
            raise ProtocolError(exc.code, exc.message) from exc
        self._remember_undo(bundle)
        self._bundle = updated
        self._project_revision += 1
        self._invalidate_preview()
        return self._project_document_result(updated)

    def _save(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params)
        try:
            saved_sources = save_project(bundle)
        except ProjectCommandError as exc:
            raise ProtocolError(exc.code, exc.message) from exc
        self._saved_sha256 = _semantic_sha256(bundle)
        return {
            **self._project_document_result(bundle),
            "saved_sources": list(saved_sources),
        }

    def _undo(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params)
        if not self._undo_stack:
            raise ProtocolError("UNDO_UNAVAILABLE", "there is no command to undo")
        preserved = self._prepare_preview_edit(self._undo_stack[-1])
        self._redo_stack.append(bundle)
        self._bundle = self._undo_stack.pop()
        self._project_revision += 1
        self._finish_preview_edit(preserved)
        return self._project_document_result(self._bundle)

    def _redo(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params)
        if not self._redo_stack:
            raise ProtocolError("REDO_UNAVAILABLE", "there is no command to redo")
        preserved = self._prepare_preview_edit(self._redo_stack[-1])
        self._undo_stack.append(bundle)
        if len(self._undo_stack) > UNDO_LIMIT:
            del self._undo_stack[0 : len(self._undo_stack) - UNDO_LIMIT]
        self._bundle = self._redo_stack.pop()
        self._project_revision += 1
        self._finish_preview_edit(preserved)
        return self._project_document_result(self._bundle)

    def _preview_result(self, snapshot: dict[str, Any]) -> dict[str, Any]:
        from .preview_dependencies import report
        return {
            "preview_dependencies": report(self._preview),
            "project_revision": self._project_revision,
            "preview_revision": self._preview_revision,
            **snapshot,
        }

    def _current_preview(
        self,
        params: dict[str, Any],
        operation_fields: set[str],
    ) -> StateScenePreview:
        self._current_bundle(params, operation_fields | {"preview_revision"})
        if self._preview is None:
            raise ProtocolError("PREVIEW_NOT_STARTED", "reset a selected-scene preview before this operation")
        revision = params["preview_revision"]
        if not isinstance(revision, int) or isinstance(revision, bool):
            raise ProtocolError("PREVIEW_REVISION_INVALID", "preview_revision must be an integer")
        if revision != self._preview_revision:
            raise ProtocolError(
                "PREVIEW_REVISION_STALE",
                "operation targets an outdated preview revision",
                details={"current_preview_revision": self._preview_revision},
            )
        return self._preview

    def _preview_reset(self, params: dict[str, Any]) -> dict[str, Any]:
        fields = {"scene_id"}
        debug_mode=params.get('debug_mode')
        if 'debug_mode' in params:
            fields.add('debug_mode')
            if debug_mode not in ('logic','state','run') or 'state_id' in params:
                raise ProtocolError('PREVIEW_DEBUG_COMMAND_INVALID', 'debug_mode requires logic/state/run without state_id')
        if "scope_host" in params:
            from .scope_preview_host import negotiate
            negotiate(params['scope_host'])
            fields.add('scope_host')
        if "state_id" in params:
            fields.add("state_id")
        bundle = self._current_bundle(params, fields)
        scene_id = params["scene_id"]
        state_id = params.get("state_id")
        if not isinstance(scene_id, str) or not scene_id:
            raise ProtocolError("PREVIEW_SCENE_INVALID", "scene_id must be non-empty text")
        if state_id is not None and (not isinstance(state_id, str) or not state_id):
            raise ProtocolError("PREVIEW_STATE_INVALID", "state_id must be non-empty text when provided")
        if not bundle.valid:
            raise ProtocolError(
                "PROJECT_INVALID",
                "project must validate before preview",
                details={"issues": _issues(bundle)},
            )
        problems = authoring_foundation.execution_issues(bundle)
        if problems:
            raise ProtocolError('PREVIEW_NOT_READY', 'Finish the reported execution requirements before Run',
                                details={'issues': problems, 'project_revision': self._project_revision})
        try:
            package = build_preview_package(bundle, scope_host='scope_host' in params)
            preview = StateScenePreview(package, scene_id, state_id, _defer_activation=debug_mode is not None)
            debugger=None
            if debug_mode is not None:
                from .preview_debug import Session
                debugger=Session(preview,self._project_revision,debug_mode)
                debugger.startup()
                preview=debugger.committed
        except (EggCompileError, EggFormatError, PreviewError) as exc:
            raise ProtocolError("PREVIEW_START_FAILED", str(exc)) from exc
        from .preview_dependencies import identities
        self._preview_scene_identities = identities(bundle)
        self._debug = debugger
        self._preview = preview
        self._preview_revision += 1
        result = self._preview_result(preview.snapshot())
        result["entry_events"] = deepcopy(preview.entry_audio_events)
        if debugger is not None:
            result['debugger']=debugger.snapshot()
            result['debugger']['host_audio_stop_required']=preview._scope_input is None
        return result

    def _preview_state(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params, {"scene_id", "state_id"})
        scene_id = params["scene_id"]
        state_id = params["state_id"]
        if not isinstance(scene_id, str) or not scene_id:
            raise ProtocolError("PREVIEW_SCENE_INVALID", "scene_id must be non-empty text")
        if not isinstance(state_id, str) or not state_id:
            raise ProtocolError("PREVIEW_STATE_INVALID", "state_id must be non-empty text")
        if not bundle.valid:
            raise ProtocolError(
                "PROJECT_INVALID",
                "project must validate before preview",
                details={"issues": _issues(bundle)},
            )
        try:
            package = build_preview_package(bundle)
            preview = StateScenePreview(package, scene_id, state_id)
        except (EggCompileError, EggFormatError, PreviewError) as exc:
            raise ProtocolError("PREVIEW_STATE_FAILED", str(exc)) from exc
        return self._preview_result(preview.snapshot())

    def _preview_scene_base(self, params: dict[str, Any]) -> dict[str, Any]:
        bundle = self._current_bundle(params, {"scene_id"})
        scene_id = params["scene_id"]
        if not isinstance(scene_id, str) or not scene_id:
            raise ProtocolError("PREVIEW_SCENE_INVALID", "scene_id must be non-empty text")
        if not bundle.valid:
            raise ProtocolError(
                "PROJECT_INVALID",
                "project must validate before preview",
                details={"issues": _issues(bundle)},
            )

        scenes = deepcopy(list(bundle.scenes))
        scene = next(
            (item for item in scenes if item.get("scene_id") == scene_id),
            None,
        )
        if scene is None:
            raise ProtocolError("PREVIEW_SCENE_INVALID", f"scene '{scene_id}' is not present")
        for state in scene.get("states", []):
            if isinstance(state, dict):
                state.pop("placement_overrides", None)
                if scene.get("schema_version") == 2:
                    state["object_overrides"] = []
        preview_bundle = replace(bundle, scenes=tuple(scenes))
        try:
            package = build_preview_package(preview_bundle)
            preview = StateScenePreview(
                package,
                scene_id,
                include_waiting_visuals=False,
            )
        except (EggCompileError, EggFormatError, PreviewError) as exc:
            raise ProtocolError("PREVIEW_SCENE_BASE_FAILED", str(exc)) from exc
        snapshot = preview.snapshot()
        return self._preview_result(
            {
                "placement": {
                    "kind": "scene_base",
                    "scene_id": scene_id,
                    "display_name": "Base Placement",
                },
                "framebuffer": snapshot["framebuffer"],
            }
        )

    def _preview_debug(self, params):
        from .preview_debug import Session
        payload = {k:v for k,v in params.items() if k not in ('project_revision','preview_revision')}
        validator = authoring_foundation.schemas()[2].evolve(schema={'$ref':'https://peepshow.dev/schema/authoring/preview-debug-command-v1.schema.json'})
        errors = list(validator.iter_errors(payload))
        if errors:
            raise ProtocolError('PREVIEW_DEBUG_COMMAND_INVALID', errors[0].message)
        preview = self._current_preview(params, set(payload))
        command = payload['command']
        if command == 'start':
            if self._debug is not None:
                raise ProtocolError('PREVIEW_DEBUG_BUSY', 'Stop the current debugger session first')
            self._debug = Session(preview, self._project_revision, payload['mode'])
        session = self._debug
        if session is None:
            raise ProtocolError('PREVIEW_DEBUG_NOT_STARTED', 'Start debugging first')
        if command != 'start' and payload['debug_revision'] != session.revision:
            raise ProtocolError('PREVIEW_DEBUG_REVISION_STALE', 'Debugger command targets an outdated cursor',
                                details={'debug_revision': session.revision})
        was_pending = session.iterator is not None
        try:
            if command == 'startup':session.startup()
            elif command == 'input':session.submit(payload['logical_source'], payload.get('event_kind','press'), payload.get('focus_generation'))
            elif command == 'advance':session.advance_time(payload['elapsed_ms'])
            elif command in ('suspend','resume'):session.lifecycle(command, {k:v for k,v in payload.items() if k in ('focus_generation','held_sources')})
            elif command == 'host':session.lifecycle(payload['host_operation'],payload['params'])
            elif command == 'step':session.run(payload['mode'])
            elif command == 'continue':session.run()
            elif command == 'mode':session.mode=payload['mode']
            elif command == 'breakpoints':session.set_breakpoints(payload['breakpoints'])
            elif command in ('abort','stop'):session.abort()
        except PreviewError as exc:
            raise ProtocolError('PREVIEW_DEBUG_EXECUTION_FAILED', str(exc)) from exc
        if command != 'inspect':session.revision += 1
        self._preview = session.committed
        # Publish effects only on the call that actually settles the transaction.
        settled = session.outcome == 'committed' and (was_pending or command in ('startup','input','advance','suspend','resume','host'))
        result = session.input_result if settled and session.transaction == 'input' else None
        response = self._preview_result(self._preview.snapshot(result))
        if settled:response.update(session.effects())
        response['debugger'] = session.snapshot()
        response['debugger']['host_audio_stop_required'] = command=='start' and self._preview._scope_input is None
        if command == 'stop':
            self._debug=None
            if getattr(self._preview, '_entry_pending', False):self._preview=None
        return response

    def _preview_input(self, params: dict[str, Any]) -> dict[str, Any]:
        fields = {"logical_source"}
        if "event_kind" in params:
            fields.add("event_kind")
        if "focus_generation" in params:
            fields.add('focus_generation')
        preview = self._current_preview(params, fields)
        logical_source = params["logical_source"]
        event_kind = params.get("event_kind", "press")
        if not isinstance(logical_source, str) or not logical_source:
            raise ProtocolError("PREVIEW_INPUT_INVALID", "logical_source must be non-empty text")
        try:
            if preview._scope_input is not None:
                if type(params.get('focus_generation')) is not int:
                    raise PreviewError('scoped input requires integer focus_generation stamped when enqueued')
                result = preview.apply_input(logical_source, event_kind, _focus_generation=params['focus_generation'])
            else:
                if 'focus_generation' in params:
                    raise PreviewError('focus_generation requires a scoped preview session')
                result = preview.apply_input(logical_source, event_kind)
        except PreviewError as exc:
            raise ProtocolError("PREVIEW_INPUT_FAILED", str(exc)) from exc
        return self._preview_result(preview.snapshot(result))

    def _preview_advance(self, params: dict[str, Any]) -> dict[str, Any]:
        preview = self._current_preview(params, {"elapsed_ms"})
        try:
            events = preview.advance(params["elapsed_ms"])
        except PreviewError as exc:
            raise ProtocolError("PREVIEW_ADVANCE_FAILED", str(exc)) from exc
        snapshot = preview.snapshot()
        snapshot["timer_events"] = [asdict(event) for event in events]
        return self._preview_result(snapshot)

    def _preview_set_local_time(self, params: dict[str, Any]) -> dict[str, Any]:
        preview = self._current_preview(params, {"local_time"})
        try:
            preview.set_local_time(params["local_time"])
        except PreviewError as exc:
            raise ProtocolError("PREVIEW_TIME_INVALID", str(exc)) from exc
        return self._preview_result(preview.snapshot())

    def _preview_suspend(self, params: dict[str, Any]) -> dict[str, Any]:
        preview = self._current_preview(params, set())
        preview.suspend()
        return self._preview_result(preview.snapshot())

    def _preview_resume(self, params: dict[str, Any]) -> dict[str, Any]:
        fields = {'focus_generation', 'held_sources'} if self._preview is not None and self._preview._scope_input is not None else set()
        preview = self._current_preview(params, fields)
        try:
            if fields:
                from .scope_preview_host import resume
                events = resume(preview, params)
            else:
                preview.resume()
                events = preview.advance(0)
        except PreviewError as exc:
            raise ProtocolError('PREVIEW_RESUME_FAILED', str(exc)) from exc
        snapshot = preview.snapshot()
        snapshot["timer_events"] = [asdict(event) for event in events]
        return self._preview_result(snapshot)

    def _preview_scope_operation(self, operation, params):
        from .scope_preview_host import FIELDS, operate
        preview = self._current_preview(params, FIELDS[operation])
        try:
            return self._preview_result(operate(preview, operation, params))
        except PreviewError as exc:
            raise ProtocolError('PREVIEW_SCOPE_FAILED', str(exc)) from exc

    def handle(self, request: ServiceRequest) -> dict[str, Any]:
        if request.operation in {"project.load", "project.create", "service.shutdown"}:
            self._processing_cache.clear()
        from .preview_dependencies import StalePreviewScene, report
        original = self._preview
        # Stale destinations require whole-operation rollback, including timer
        # advancement and queued events before a transition is requested.
        guarded = (original is not None and bool(report(original)['stale_scenes'])
                   and request.operation.startswith('project.preview_')
                   and request.operation != 'project.preview_reset')
        if guarded:
            self._preview = deepcopy(original)
        try:
            with self._processing_cache.active():
                return self._handle(request)
        except StalePreviewScene as exc:
            self._preview = original
            raise ProtocolError('PREVIEW_SCENE_RESTART_REQUIRED', str(exc),
                                details={'scene_id': exc.scene_id, 'project_revision': self._project_revision,
                                         'preview_revision': self._preview_revision}) from exc
        except Exception:
            if guarded:
                self._preview = original
            raise

    def _handle(self, request: ServiceRequest) -> dict[str, Any]:
        from .scope_preview_host import FIELDS
        if self._debug is not None and request.operation != 'project.preview_debug':
            if request.operation.startswith('project.preview_') or request.operation in ('project.create','project.load','project.object_migration_apply'):
                raise ProtocolError('PREVIEW_DEBUG_OWNS_EXECUTION', 'Use debugger controls or stop the debugger first')
            if request.operation == 'service.shutdown':
                self._debug.abort();self._debug=None
        if request.operation in {'project.preview_reset', 'project.create', 'project.load',
                'project.object_migration_apply', 'service.shutdown'}:
            from .scope_preview_host import require_stopped_before_replacement
            require_stopped_before_replacement(self._preview)
        for operation in FIELDS:
            if request.operation == 'project.preview_' + operation:
                return self._preview_scope_operation(operation, request.params)
        handlers = {
            "service.hello": self._hello,
            "service.shutdown": self._shutdown,
            "project.create": self._create,
            "project.load": self._load,
            "project.validate": self._validate,
            "project.normalize": self._normalize,
            "project.settings.get": self._settings_get,
            "project.inventory.inspect": self._inventory_inspect,
            "project.actor.inspect": self._actor_inspect,
            "project.actor_template.inspect": self._actor_template_inspect,
            "project.build_package": self._build_package,
            "project.compatibility_report": self._compatibility_report,
            "project.apply_commands": self._apply_commands,
            "project.object_migration_preview": self._object_migration_preview,
            "project.object_migration_apply": self._object_migration_apply,
            "project.save": self._save,
            "project.undo": self._undo,
            "project.redo": self._redo,
            "project.scene_thumbnails": self._scene_thumbnails,
            "project.audio_audition": self._audio_audition,
            "project.preview_debug": self._preview_debug,
            "project.preview_reset": self._preview_reset,
            "project.preview_state": self._preview_state,
            "project.preview_scene_base": self._preview_scene_base,
            "project.preview_input": self._preview_input,
            "project.preview_advance": self._preview_advance,
            "project.preview_set_local_time": self._preview_set_local_time,
            "project.preview_suspend": self._preview_suspend,
            "project.preview_resume": self._preview_resume,
        }
        handler = handlers.get(request.operation)
        if handler is None:
            raise ProtocolError(
                "OPERATION_UNKNOWN",
                f"unknown operation '{request.operation}'",
                request_id=request.request_id,
                details={"operations": list(SERVICE_OPERATIONS)},
            )
        try:
            return handler(request.params)
        except ProtocolError as exc:
            if exc.request_id is None:
                exc.request_id = request.request_id
            raise


def run_service(input_stream: TextIO, output_stream: TextIO) -> int:
    service = AuthoringService()
    for line in input_stream:
        if not line.strip():
            continue
        request: ServiceRequest | None = None
        try:
            request = parse_request(line)
            result = service.handle(request)
            response = success_response(request.request_id, result)
        except ProtocolError as exc:
            response = error_response(exc)
        except (KeyError, OSError, TypeError, ValueError) as exc:
            response = error_response(
                ProtocolError(
                    "SERVICE_OPERATION_FAILED",
                    str(exc),
                    request_id=request.request_id if request is not None else None,
                )
            )
        output_stream.write(encode_message(response) + "\n")
        output_stream.flush()
        if service.shutdown_requested:
            break
    return 0


def main() -> int:
    return run_service(sys.stdin, sys.stdout)


if __name__ == "__main__":
    raise SystemExit(main())
