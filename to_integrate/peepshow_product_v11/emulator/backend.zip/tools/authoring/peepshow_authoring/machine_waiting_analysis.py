"""Conservative, bounded proof of autonomous visual combinations from wire data.

This is admission analysis, not a second game executor. Variables, time, timer
arming and probabilities are deliberately over-approximated. Every route address
is offered as a possible root. Only machine states, selected looping visuals and
active one-shot identities are tracked. Transient effects do not exempt any
combination. Exhaustion returns no proof and leaves the old bound in force.
"""
from collections import deque
from itertools import product

MAX_CONFIGURATIONS = 4096
MAX_WORK = 500000
MAX_CHAIN = 128


class Incomplete(Exception):
    pass


def _replace(values, index, value):
    return values[:index] + (value,) + values[index + 1:]


def _predicate(tokens, states):
    stack = []
    for op, x, y, _, _ in tokens:
        if op == 1:
            stack.append(frozenset((states[x] == y,)))
        elif op in (2, 6, 7):
            stack.append(frozenset((False, True)))
        elif op == 3:
            stack[-1] = frozenset(not value for value in stack[-1])
        else:
            right, left = stack.pop(), stack.pop()
            stack.append(frozenset(a and b if op == 4 else a or b for a in left for b in right))
    return stack[0]


class Analysis:
    def __init__(self, scene):
        self.scene, self.graph = scene, scene['graph']
        self.work = 0
        self.routes = {}
        for route in self.graph['routes']:
            self.routes.setdefault((route['machine'], route['event']), []).append(route)

    def charge(self):
        self.work += 1
        if self.work > MAX_WORK:
            raise Incomplete('work_limit')

    def actions(self, config, queue, actions):
        paths = {(config, queue)}
        for op, ref, event, _, _ in actions:
            following = set()
            for current, pending in paths:
                self.charge()
                states, visuals, clips = current
                if op == 4:
                    if len(pending) >= MAX_CHAIN:
                        raise Incomplete('chain_limit')
                    following.add((current, pending + ((ref, event),)))
                elif op == 9:
                    following.update(self.flow(current, pending, self.graph['flowcharts'][ref]))
                else:
                    if op == 8:
                        kind, effect = self.graph['effects'][ref]
                        if kind == 4:
                            visual = self.graph['visuals'][effect]
                            visuals = _replace(visuals, visual['object_index'], visual['clip_index'])
                        elif kind == 8:
                            clip = self.graph['clips'][effect]
                            clips = _replace(clips, clip['object_index'], effect)
                        elif kind == 9:
                            clips = _replace(clips, effect, -1)
                        # Static frame overrides and held-last samples can only
                        # suppress a base loop. Keep that loop in the bound.
                    following.add(((states, visuals, clips), pending))
            paths = following
        return paths

    def flow(self, config, queue, chart):
        if 'nodes' not in chart:
            raise Incomplete('missing_flow_data')
        pending = {(chart['root'], config, queue)}
        finished = set()
        while pending:
            offset, current, events = pending.pop()
            self.charge()
            node = chart['nodes'][offset]
            if node['kind'] == 0:
                finished.add((current, events))
            elif node['kind'] == 1:
                for following, queued in self.actions(current, events, node['actions']):
                    pending.add((node['next'], following, queued))
            else:
                for target, tokens in node['branches']:
                    values = _predicate(tokens, current[0])
                    if True in values:
                        pending.add((target, current, events))
                    if False not in values:
                        break
                else:
                    pending.add((node['next'], current, events))
        return finished

    def receiver(self, config, queue, address):
        states, visuals, clips = config
        results = set()
        for route in self.routes.get(address, ()):
            machine = route['machine']
            if machine != 255 and not route['sources'] & (1 << states[machine]):
                continue
            for _, target, actions in route['outcomes']:
                following = states if target == 255 else _replace(states, machine, target)
                results.update(self.actions((following, visuals, clips), queue, actions))
            if sum(o[0] for o in route['outcomes']) < 100:
                results.add((config, queue))
            if not route['guards']:
                return results
            # Unknown guards may fail, allowing the next matching route.
        results.add((config, queue))
        return results

    def settle(self, config, address):
        pending = {(config, (address,), 0)}
        finished = set()
        while pending:
            current, queue, count = pending.pop()
            self.charge()
            if not queue:
                finished.add(current)
                continue
            if count >= MAX_CHAIN:
                raise Incomplete('chain_limit')
            for following, queued in self.receiver(current, queue[1:], queue[0]):
                pending.add((following, queued, count + 1))
        return finished

    def run(self):
        graph = self.graph
        # A retained scene can return in any of its owned states. Runtime resets
        # visual objects and one-shots on replacement, then runs activation.
        entries = [tuple(s for s, owner in enumerate(graph['owners']) if owner == m)
                   if graph.get('retain_mask', 0) & (1 << m) else (state,)
                   for m, state in enumerate(graph['entry'])]
        visuals = tuple(obj['clip_index'] for obj in self.scene['objects'])
        clips = (-1,) * len(visuals)
        reached, pending, autonomous = set(), deque(), set()

        def add(config):
            if config in reached:
                return
            if len(reached) >= MAX_CONFIGURATIONS:
                raise Incomplete('configuration_limit')
            reached.add(config)
            pending.append(config)
            if all(clip < 0 for clip in config[2]):
                autonomous.add(config[1])

        for states in product(*entries):
            self.charge()
            initial = (states, visuals, clips)
            add(initial)  # Also covers activation-free initial admission.
            if graph.get('scene_activated'):
                for result in self.settle(initial, tuple(graph['scene_activated'])):
                    add(result)
        while pending:
            current = pending.popleft()
            for address in self.routes:
                for result in self.settle(current, address):
                    add(result)
            for obj, ref in enumerate(current[2]):
                if ref < 0:
                    continue
                clip = graph['clips'][ref]
                expired = (current[0], current[1], _replace(current[2], obj, -1))
                # Acknowledge the last frame and settle completion atomically
                # with respect to autonomous admission, matching Runtime.
                if clip['completion']:
                    for result in self.settle(expired, (clip['machine'], clip['event'])):
                        add(result)
                else:
                    add(expired)
        return dict(complete=True, configurations=len(reached), work=self.work,
                    autonomous_visuals=autonomous)


def autonomous_visuals(scene):
    try:
        return Analysis(scene).run()
    except Incomplete as error:
        return dict(complete=False, reason=str(error))
