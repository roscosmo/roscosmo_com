"""Prove unconditional conflicting Scene requests; runtime covers unknown cases.

This deliberately does not merge mutually exclusive guarded/weighted choices.
It is not a reachability proof or a promise that dynamic chains cannot conflict.
"""


def definite_conflicts(graph):
    charts = {c['flowchart_id']: c for c in graph.get('flowcharts', [])}
    states = {m['machine_id']: m['states'] for m in graph['machines']}
    addresses = {}
    for route in graph['routes']:
        addresses.setdefault((route['machine_ref'], route['event_ref']), []).append(route)
    memo = {}

    def sends(actions):
        result = set()
        for action in actions:
            # This proof covers ordinary Scene receivers only. Instance inputs
            # (like legacy bridge endpoints) require mixed execution analysis;
            # they must not crash the public export-unavailable diagnostic.
            if action['kind'] == 'send_event' and 'machine_ref' in action:
                result.add((action['machine_ref'], action['event_ref']))
            elif action['kind'] == 'run_flowchart':
                chart = charts[action['flowchart_ref']]
                nodes = {n['node_id']: n for n in chart['nodes']}
                cache = {}

                def visit(ref):
                    if ref in cache:
                        return cache[ref]
                    node = nodes[ref]
                    if node['kind'] == 'return':
                        value = set()
                    elif node['kind'] == 'actions':
                        value = sends(node['actions']) | visit(node['next'])
                    else:
                        paths = [visit(node['default']), *(visit(b['next']) for b in node['branches'])]
                        value = set.intersection(*paths)
                    cache[ref] = value
                    return value

                result.update(visit(chart['root']))
        return result

    def outcome_destinations(outcome):
        result = {outcome['target_scene']} if 'target_scene' in outcome else set()
        for address in sends(outcome['actions']):
            result.update(guaranteed(address))
        return result

    def guaranteed(address):
        if address in memo:
            return memo[address]
        # Cycles are rejected by the existing event graph validator. Keep this
        # helper independently bounded if called on an unvalidated graph.
        memo[address] = set()
        variants = []
        for state in states.get(address[0], [None]):
            candidates = [r for r in addresses.get(address, [])
                          if state is None or state in r['from_states']]
            if not candidates or candidates[0]['guards']:
                variants.append(set())
                continue
            route = candidates[0]
            outcomes = route.get('outcomes', [route])
            choices = [outcome_destinations(o) for o in outcomes]
            if 'outcomes' in route and sum(o['weight'] for o in outcomes) < 100:
                choices.append(set())
            variants.append(set.intersection(*choices))
        memo[address] = set.intersection(*variants) if variants else set()
        return memo[address]

    conflicts = []
    for route in graph['routes']:
        for outcome in route.get('outcomes', [route]):
            destinations = outcome_destinations(outcome)
            if len(destinations) > 1:
                conflicts.append((route['route_id'], sorted(destinations)))
    return conflicts
