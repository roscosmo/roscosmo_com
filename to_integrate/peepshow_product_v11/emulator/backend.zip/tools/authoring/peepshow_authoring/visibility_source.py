"""Map presentation masks within the existing host event transaction."""
from copy import deepcopy

from .imported_properties import ImportedPropertyError

COMMANDS = ('scene.visibility.group.set', 'scene.visibility.group.remove')

CAPABILITY = dict(host_editing=True, host_preview=True, persisted=True, undo_redo=True,
    runtime=False, export=False, hardware_validation='not_qualified',
    field='machine_logic.map_scene.visibility', schema='schemas/authoring/map-visibility-v1.schema.json',
    commands=[*COMMANDS, 'scene.machines.set','scene.flowcharts.set', 'scene.response.set'],
    action_kinds=['visibility.world','visibility.layer','visibility.group'],
    locations=['scene_transition_actions','scene_flowchart_actions'],
    layer_namespace='map_scene.background_layers', world_membership='world_positions',
    world_default=True, layer_default='imported_layer_visible',
    individual_actor_action='object.set_visibility', groups=True,
    group_field='map_scene.visibility.groups', group_membership='world_position_entities',
    group_visuals='all_world_position_bindings_for_each_member', maximum_groups=32,
    maximum_members_per_group=64, overlapping_groups='all_must_be_visible',
    group_default=True, group_membership_on_duplicate='explicit_edit_required',
    group_command_schema='schemas/authoring/visibility-group-command-v1.schema.json',
    hides_screen_ui=False, affects_collision=False, suspends_gameplay=False,
    suspends_audio=False, suspends_timelines=False, device_read_savings_proven=False,
    validation_error='VISIBILITY_INVALID', readiness_error='VISIBILITY_DEVICE_UNAVAILABLE')


class VisibilityError(ImportedPropertyError):
    code = 'VISIBILITY_INVALID'


def layer(value, source, path):
    if type(value) is not int or value not in source.get('background_layers', []):
        raise VisibilityError(f'{path}: layer_ref must select a background visual layer')
    return value


def configuration(graph):
    source = graph.get('map_scene', {})
    if 'visibility' not in source:
        return None
    config = source['visibility']
    if type(config) is not dict or set(config) - {'world','layers','groups'}:
        raise VisibilityError('visibility: expected optional world, layers and groups')
    if type(config.get('world', True)) is not bool or type(config.get('layers', [])) is not list:
        raise VisibilityError('visibility: world must be Boolean and layers must be an array')
    layers = []
    seen = set()
    for row in config.get('layers', []):
        if type(row) is not dict or set(row) != {'layer_ref','visible'} or type(row['visible']) is not bool:
            raise VisibilityError('visibility.layers: expected layer_ref and Boolean visible')
        lid = layer(row['layer_ref'], source, 'visibility.layers')
        if lid in seen:
            raise VisibilityError('visibility.layers: duplicate layer_ref')
        seen.add(lid)
        layers.append(dict(row))
    from .project import STABLE_ID
    groups = config.get('groups', [])
    if type(groups) is not list or len(groups) > 32:
        raise VisibilityError('visibility.groups: at most 32 groups')
    actors = {r['entity_ref'] for r in graph.get('world_positions', [])}
    identities = set()
    normalized = []
    for row in groups:
        if (type(row) is not dict or set(row) - {'group_id','display_name','members','visible'} or
                not {'group_id','members'} <= set(row) or type(row['group_id']) is not str or
                not STABLE_ID.fullmatch(row['group_id']) or row['group_id'] in identities or
                type(row.get('visible', True)) is not bool or
                ('display_name' in row and (type(row['display_name']) is not str or not 1 <= len(row['display_name']) <= 128))):
            raise VisibilityError('visibility.groups: invalid/duplicate group identity or fields')
        members = row['members']
        if type(members) is not list or not 1 <= len(members) <= 64:
            raise VisibilityError('visibility.groups: requires 1..64 actor members')
        seen = set()
        for member in members:
            if (type(member) is not dict or set(member) != {'entity_ref'} or type(member['entity_ref']) is not str or
                    member['entity_ref'] not in actors or member['entity_ref'] in seen):
                raise VisibilityError('visibility.groups: members must be unique world-position actor entities')
            seen.add(member['entity_ref'])
        identities.add(row['group_id'])
        normalized.append(dict(deepcopy(row), visible=row.get('visible', True)))
    return dict(world=config.get('world', True), layers=layers, groups=normalized)


def action(value, graph, path):
    config = configuration(graph)
    if config is None:
        raise VisibilityError(f'{path}: visibility action requires map_scene.visibility')
    kind = value['kind']
    required = {'kind','visible'} | ({'layer_ref'} if kind == 'visibility.layer' else {'group_ref'} if kind == 'visibility.group' else set())
    if kind not in CAPABILITY['action_kinds'] or set(value) != required or type(value['visible']) is not bool:
        raise VisibilityError(f'{path}: invalid visibility action fields')
    if kind == 'visibility.layer':
        layer(value['layer_ref'], graph['map_scene'], path)
    if kind == 'visibility.group' and (type(value['group_ref']) is not str or
            value['group_ref'] not in {r['group_id'] for r in config['groups']}):
        raise VisibilityError(f'{path}: unknown visibility group_ref')
    return dict(value)


def attach(context, source):
    context.visibility_actions = deepcopy(source.visibility_actions)
    if source.visibility is None:
        return
    spatial = context.spatial
    context.visibility = dict(world=source.visibility['world'],
        layers=dict(zip(spatial.layer_ids, spatial.layer_visible)), groups={})
    for row in source.visibility['layers']:
        context.visibility['layers'][row['layer_ref']] = row['visible']
    for row in source.visibility.get('groups', []):
        members = {m['entity_ref'] for m in row['members']}
        context.visibility['groups'][row['group_id']] = dict(visible=row['visible'],
            members=deepcopy(row['members']), objects=[p['object_ref'] for p in source.positions if p['entity_ref'] in members])


def execute(context, command):
    if context.visibility is None:
        raise VisibilityError('visibility command has no map configuration')
    if command['kind'] == 'visibility.world':
        context.visibility['world'] = command['visible']
    elif command['kind'] == 'visibility.layer':
        context.visibility['layers'][command['layer_ref']] = command['visible']
    else:
        context.visibility['groups'][command['group_ref']]['visible'] = command['visible']


def actor_visible(context, object_ref):
    state = context.visibility
    return state is None or (state['world'] and all(g['visible'] for g in state['groups'].values()
                                                   if object_ref in g['objects']))


def snapshot(context):
    state = context.visibility
    return dict(world=state['world'], layers=[dict(layer_ref=lid, visible=visible,
        effective_visible=state['world'] and visible) for lid,visible in state['layers'].items()],
        groups=[dict(group_id=ref, members=deepcopy(row['members']), visible=row['visible'],
                     effective_visible=state['world'] and row['visible']) for ref,row in state['groups'].items()])


def apply_command(scenes, command):
    from .project import _command_scene, _require_command_fields, ProjectCommandError
    setting = command['kind'] == COMMANDS[0]
    required = {'kind', 'scene_id', 'group' if setting else 'group_id'}
    _require_command_fields(command, required, required | {'command_id'})
    scene = _command_scene(scenes, command['scene_id'])
    graph = scene.get('machine_logic', {})
    config = scene['world']['map'] if 'world' in scene else graph.get('map_scene')
    if config is None:
        raise ProjectCommandError('VISIBILITY_INVALID', 'Actor visibility groups require a map Scene')
    row = command.get('group')
    ref = row.get('group_id') if setting and type(row) is dict else command.get('group_id')
    if type(ref) is not str or not ref:
        raise ProjectCommandError('VISIBILITY_INVALID', 'Requires group_id')
    rows = config.setdefault('visibility', {}).setdefault('groups', [])
    index = next((i for i,r in enumerate(rows) if r['group_id'] == ref), None)
    if setting:
        if index is None:
            rows.append(deepcopy(row))
        else:
            rows[index] = deepcopy(row)
    elif index is None:
        raise ProjectCommandError('VISIBILITY_INVALID', 'Unknown group_id')
    else:
        del rows[index]
    return deepcopy(command)
