"""Asset appearance and explicit migration of legacy Scene overrides."""
VALUES = ('white', 'black')

CAPABILITY = dict(field='map_assets[].base_colour', values=list(VALUES), default='white',
    create_command='map.create', edit_command='map.base_colour.set',
    command_schema='schemas/authoring/incremental-commands-v1.schema.json',
    asset_schema='schemas/authoring/map-asset-colour-v1.schema.json',
    legacy_policy='preserve_attachment_override', diagnostics_field='map_colour_issues',
    resolution_parameter='inherit_attachments', resolution_default=False,
    resolution_effect='remove_all_attachment_colour_overrides_for_this_asset',
    host_preview=True, export=True, runtime_action=False, undo_redo=True,
    persistence='session_until_project.save')


def effective(record, attachment):
    return attachment.get('base_colour', record.get('base_colour', 'white'))


def attachments(scenes, asset_id):
    for scene in scenes:
        for parent, child in (('world', 'map'), ('machine_logic', 'map_scene')):
            container = scene.get(parent)
            spec = container.get(child) if isinstance(container, dict) else None
            field = parent+'.'+child
            if isinstance(spec, dict) and spec.get('asset_ref') == asset_id:
                yield f"scenes[{scene['scene_id']}].{field}.base_colour", spec


def diagnostics(bundle):
    result = []
    for catalog in bundle.asset_catalogs:
        for record in catalog.get('map_assets', []):
            if not isinstance(record, dict) or 'asset_id' not in record:
                continue
            rows = list(attachments(bundle.scenes, record['asset_id']))
            colours = {effective(record, spec) for _, spec in rows if effective(record, spec) in VALUES}
            for path, spec in rows:
                if 'base_colour' in spec:
                    result.append(dict(code='MAP_BASE_COLOUR_CONFLICT' if len(colours) > 1 else 'MAP_BASE_COLOUR_LEGACY_OVERRIDE',
                        path=path, asset_id=record['asset_id'], severity='warning',
                        message='Legacy attachment colour is preserved. Use map.base_colour.set with inherit_attachments=true to adopt one asset colour explicitly.'))
    return result


def set_colour(record, command, scenes):
    from .imported_properties import ImportedPropertyError
    colour = command['base_colour']
    if colour not in VALUES:
        raise ImportedPropertyError('base_colour must be white or black')
    adopt = command.get('inherit_attachments', False)
    if type(adopt) is not bool:
        raise ImportedPropertyError('inherit_attachments must be boolean')
    overrides = [(path, spec) for path, spec in attachments(scenes, record['asset_id']) if 'base_colour' in spec]
    if overrides and not adopt:
        raise ImportedPropertyError('Legacy attachment colours require explicit resolution with inherit_attachments=true: '+', '.join(p for p, _ in overrides))
    record['base_colour'] = colour
    if adopt:
        for _, spec in overrides:
            del spec['base_colour']
