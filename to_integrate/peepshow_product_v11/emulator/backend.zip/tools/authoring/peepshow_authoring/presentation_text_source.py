"""Scoped source tokens shared by semantic checks, compilation and preview."""
from .presentation_text_wire import analyze_tokens, resolve_tokens


def source_tokens(text):
    if not isinstance(text, list) or not 1 <= len(text) <= 16:
        raise ValueError('text tokens require an array of 1..16 records')
    result = []
    for token in text:
        if not isinstance(token, dict):
            raise ValueError('text token must be an object')
        if set(token) == {'kind', 'text'} and token['kind'] == 'literal':
            literal = token['text']
            if (not isinstance(literal, str) or not literal or len(literal) > 256 or
                    any(c != '\n' and not 32 <= ord(c) <= 126 for c in literal)):
                raise ValueError('literal token requires printable ASCII or LF')
            result.append(('literal', literal))
        elif set(token) == {'kind', 'variable_scope', 'variable_ref'} and token['kind'] == 'variable':
            from .project import STABLE_ID
            scope, ref = token['variable_scope'], token['variable_ref']
            if scope not in ('scene', 'package') or not isinstance(ref, str) or not STABLE_ID.fullmatch(ref):
                raise ValueError('variable token requires an explicit scope and stable variable ID')
            result.append(('variable', (scope, ref)))
        else:
            raise ValueError('unknown text token or fields')
    return result


def text_bounds(obj):
    from .system_fonts import SYSTEM_FONT_8X8_BASIC_ID
    if (obj.get('font_id') != SYSTEM_FONT_8X8_BASIC_ID or type(obj.get('scale')) is not int or
            not 1 <= obj['scale'] <= 8 or obj.get('alignment') not in ('left', 'center', 'right')):
        raise ValueError('invalid text font, scale or alignment')
    return dict(style=obj['scale'] - 1 + 8 * ('left', 'center', 'right').index(obj['alignment']),
                width=obj.get('width'), height=obj.get('height'))


def compile_binding(obj, definitions):
    """Definitions are an ordered (scope, ID) map, matching machine wire order."""
    keys = list(definitions)
    variables = [(int(v['initial']), v.get('minimum', 0), v.get('maximum', 1),
                  255, int(v['value_type'] == 'bool')) for v in definitions.values()]
    tokens = []
    for kind, argument in source_tokens(obj['text']):
        if kind == 'variable':
            if argument not in definitions:
                raise ValueError('text references an unknown scope-qualified variable')
            argument = keys.index(argument)
        tokens.append((kind, argument))
    bounds = text_bounds(obj)
    analysis = analyze_tokens(tokens, variables, **bounds)
    return tokens, variables, bounds, analysis


def resolved_source(obj, definitions, values=None):
    if isinstance(obj['text'], str):
        return obj['text']
    tokens, variables, bounds, _ = compile_binding(obj, definitions)
    if values is None:
        snapshot = [v[0] for v in variables]
    else:
        snapshot = []
        for key, declaration in definitions.items():
            if key not in values:
                raise ValueError('missing settled scoped variable')
            value = values[key]
            expected = bool if declaration['value_type'] == 'bool' else int
            if type(value) is not expected:
                raise ValueError('settled text value does not match declared type')
            snapshot.append(int(value))
    return resolve_tokens(tokens, variables, snapshot, **bounds)


def scene_bindings(project, scene):
    from .presentation_selectors import variable_definitions
    definitions = variable_definitions(project, scene)
    result = []
    for index, obj in enumerate(scene.get('objects', [])):
        if obj.get('kind') == 'text' and isinstance(obj.get('text'), list):
            if 'machine_logic' not in scene:
                raise ValueError('token text requires Scene machines')
            tokens, _, _, _ = compile_binding(obj, definitions)
            result.append((index, tokens))
    return result
