"""Private MNC1 transport. Compiled identities are supplied, never guessed.

This transports the complete V2 object-menu description; it is not an export
capability grant. The containing Scene must admit the same identity tables.
"""
import struct
from .machine_wire import require
from .menu_device_bindings import bind_menu
from .menu_navigation_wire import NONE

HEADER = struct.Struct('<4sHHI8HQ8HIII')
ENTRY = struct.Struct('<HHIHHI')
TOKEN = struct.Struct('<BBHi')
BINDING = struct.Struct('<4H')
OVERRIDE = struct.Struct('<HHhh')
COMPARE = ('eq', 'ne', 'lt', 'le', 'gt', 'ge')


def component_shape(data):
    """Check the transport envelope for association, not semantic admission.

    Native Scene admission still validates predicates, owners and all indices.
    """
    require(type(data) is bytes and len(data) >= HEADER.size, 'MNC1: truncated component')
    row = HEADER.unpack_from(data)
    (magic, version, header, size, machines, events, states, variables, objects,
     items, cues, instances, object_mask, machine_mask, owner, cue, hide,
     inputs, drafts, entries, bindings, navigation, tokens, reserved) = row
    require((magic, version, header, size) == (b'MNC1', 1, HEADER.size, len(data)) and
            0 < machines <= 16 and 0 < events <= 256 and 0 < states <= 256 and
            variables <= 64 and 0 < objects <= 64 and items <= 64 and
            machine_mask < 1 << machines and object_mask < 1 << objects and
            (owner == NONE or owner < machines) and (cue == NONE or cue < cues) and
            hide <= 1 and not reserved and
            header + inputs*4 + drafts*2 + entries*ENTRY.size +
            bindings*(BINDING.size + 3*OVERRIDE.size) + tokens*TOKEN.size + navigation == size,
            'MNC1: invalid component envelope')
    from .menu_navigation_wire import HEADER as NAV_HEADER, PAGE, ENTRY as NAV_ENTRY, DRAFT
    require(navigation >= NAV_HEADER.size, 'MNC1: truncated navigation')
    nav = NAV_HEADER.unpack_from(data, size-navigation)
    require(nav[0:3] == (b'MNV1', 1, navigation) and nav[3] > 0 and
            nav[4] == entries and nav[5] == drafts and nav[6] < nav[3] and
            nav[7] <= 1 and 0 < nav[8] <= 64 and not nav[9] and
            NAV_HEADER.size + nav[3]*PAGE.size + entries*NAV_ENTRY.size + drafts*DRAFT.size == navigation,
            'MNC1: navigation disagrees with component')
    return dict(machine_count=machines, event_count=events, state_count=states,
                object_count=objects, instance_count=instances, inventory_count=items)


def compile_component(project, scene, *, states, instance_count, **identities):
    bound = bind_menu(project, scene, **identities)
    tables = {k: tuple(v) for k, v in identities.items()}
    tables['states'] = tuple(states)
    require(len(set(states)) == len(states) and
            {s['state_id'] for s in scene['states']} <= set(states),
            'MENU_DEVICE_BINDING: compiled state table does not cover source')
    counts = tuple(len(tables[k]) for k in
                   ('machines','events','states','variables','objects','inventory','cues'))
    require(all(n < NONE for n in counts), 'MENU_DEVICE_BINDING: table too large')
    require(type(instance_count) is int and 0 <= instance_count < NONE,
            'MENU_DEVICE_BINDING: invalid compiled instance count')
    pool = []

    def tokens(value):
        if type(value) is bool:
            return [(int(value),0,0,0)]
        if 'machine_ref' in value:
            return [(2,0,tables['machines'].index(value['machine_ref']),
                     tables['states'].index(value['state_ref']))]
        if 'variable_ref' in value:
            return [(3,COMPARE.index(value['operator']),
                     tables['variables'].index((value['variable_scope'],value['variable_ref'])),
                     int(value['value']))]
        if value.get('kind') == 'inventory.compare':
            return [(4,COMPARE.index(value['operator']),
                     tables['inventory'].index(value['item_ref']),value['value'])]
        if 'not' in value:
            return tokens(value['not']) + [(5,0,0,0)]
        name = 'all' if 'all' in value else 'any'
        result = []
        for i, child in enumerate(value[name]):
            result.extend(tokens(child))
            if i: result.append((6 if name == 'all' else 7,0,0,0))
        return result

    def predicate(value):
        rows = tokens(value)
        require(1 <= len(rows) <= 16, 'MENU_DEVICE_BINDING: predicate exceeds 16 tokens')
        offset = len(pool)
        pool.extend(rows)
        return len(rows), offset

    entries = bytearray()
    for row in bound.entries:
        vn, vo = predicate(row['visible'])
        en, eo = predicate(row['enabled'])
        entries.extend(ENTRY.pack(row['inventory'],vn,vo,en,0,eo))
    bindings = bytearray()
    for row in bound.presentation['bindings']:
        bindings.extend(BINDING.pack(*(row[k] for k in ('object','page','entry','quantity'))))
        for field in ('when_chosen','when_selected','when_disabled'):
            override = row.get(field,{})
            mask = sum(1 << i for i,k in enumerate(('visible','inverted','x','y')) if k in override)
            flags = int(override.get('visible',False)) | (int(override.get('inverted',False)) << 1)
            bindings.extend(OVERRIDE.pack(mask,flags,override.get('x',0),override.get('y',0)))
    inputs = b''.join(struct.pack('<4B',*r,0) for r in bound.inputs)
    drafts = b''.join(struct.pack('<H',v) for v in bound.drafts)
    payload = inputs + drafts + entries + bindings + b''.join(TOKEN.pack(*r) for r in pool) + bound.navigation.data
    return HEADER.pack(b'MNC1',1,HEADER.size,HEADER.size+len(payload),*counts,instance_count,
        bound.menu_objects,bound.menu_machines,bound.apply_owner,bound.navigation_cue,
        int(bound.hide_world),len(bound.inputs),len(bound.drafts),len(bound.entries),
        len(bound.presentation['bindings']),len(bound.navigation.data),len(pool),0) + payload
