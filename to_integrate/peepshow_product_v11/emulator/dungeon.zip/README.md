# Canonical authorable dungeon

## Checked Patrol destinations: API110

Each Patrol Turn has one clear/blocked decision. Its declaration names the
adjacent cell for Self; the clear branch moves to that checked destination and
the blocked branch changes direction. The map supplies the step size. The recipe
uses `scene.behavior.destination.set` and `scene.response.set`, preserving
independent state and move-both/check-both ordering. The saved Patrol template
contains the same source. No authored pixel arithmetic or collision relay is
needed for these movement branches.

Actor visibility groups are also available through public authoring commands;
the game does not add test-only buttons to demonstrate them. Read
`docs/03 Engine API/Actor_Groups_and_Behavior_Destinations.md`. These additions
remain host-preview facilities; no new device-export qualification is implied.

## Saved reusable objects: API108

The public recipe saves Chest, Door and Patrol templates in the project library.
Both existing Patrol B placements are explicitly linked to Patrol, preserving
their position, connections and gameplay. Select a saved template to place another
complete setup with named external bindings. Explicit component-group overrides,
Apply setup, Reset override and Make independent are host-tested operations.
Read `Actor_Template_Contract.md` for scope; device export remains unavailable.

## Chest and Door reuse: API107

Chest's Opened output now owns an inspectable response: play its own clip and
sound, then send Unlock directly to Door. There is no Player feedback handler to
rebuild when placing another Chest. Complete duplication copies that response
and remaps its visual target. Choose the new Door recipient explicitly and set
that Door's collision condition to the new Chest's Opened property. Clear/rebind
its copied room-exit output if it should stay in the current room.

The checked-in game retains one pair per room. Public tests construct additional
pairs, verifying independent feedback/state and the same approach restrictions.
This is source editing and host preview; device export remains unavailable.

## Complete Patrol reuse: API106

The recipe builds Patrol A once per room, then places B using
`scene.actor.duplicate` at column 13 / row 3 with `copy_connections: true`.
Its visuals, facing, collision, target and Caught binding come with it, together
with the authored turn/check/loss actions. Both rooms retain the same two-Patrol
gameplay: move A, move B, check A, check B.

B is a Scene-local placement, so authors can change its cell or bindings without
editing the shared map. The old B marker in `map.tmj` remains unbound; it is not
an additional actor. Use `project.actor.inspect` to find the active placement.
Shared behavior/art remain shared. Duplication itself remains independent;
API108 separately links these B placements to the saved Patrol template. Source
editing and host preview are supported; device export is not.

## Rebuilt from empty: API102

Potion and Shield are now walk-on pickups in both rooms. Potion appears with its
count on the Items menu; Shield becomes available in Equipment after collection.
Sword is always available. A stages equipment, Apply confirms it, and Cancel
discards that pending choice. Potion use/health is not implemented.

Inventory and consumed pickups survive room changes. Loss restart restores the
floor pickups and zero counts, and resets equipped Shield to false. These rules
are explicit public catalog, Pickup and menu bindings. The recipe builds them
from an empty project; no hidden event relay or sprite-name inference is used.
See `docs/03 Engine API/Inventory_and_Pickup_Contract.md`. Host preview only;
device export remains unavailable.

The recipe creates an empty inventory and adds each item individually through
public commands. `project.inventory.inspect` exposes the exact pickup/menu
connections for a selected item. API102 changes these editing operations while
preserving the API101 saved project and gameplay.

All ordinary and shared handlers now use the same response grammar. Simple
handlers are event -> actions -> Stay/State, without artificial conditions.
Restart and room changes end at declared Scene exits; only ordinary game-level
machines may select those destinations. Open Menu remains an explicit action
on Playing/B. Source/preview support does not grant device export.

The recipe creates patrol handlers with public `scene.response.set` commands,
independently of the containing graph. Check Target now also uses an explicit
Beside player / Not beside player decision, emitting Caught only on the first
branch. Patrol ordering and gameplay are unchanged.

Player direction inputs use that same structure and public command. For example:
Right -> Is the cell right of Player clear? Clear -> Face right, Move there,
Finish player turn, Stay. Blocked -> Face right, Stay. There is one handler per
direction, with its decision visible directly from the input.

Menu navigation now uses V2 normal-object presentation: text on the Pause root,
graphics for Sword/Shield on Equipment, and separate focus/choice markers.
The small square follows the cursor; the underline shows the pending equipment
choice (`when_chosen`). Moving focus alone does not choose it. A stages the
choice; Apply commits it and Cancel discards it. Labels remain
editor metadata. These are placed objects, not a required menu renderer/layout.
The same response graph grammar also works in ordinary machine input, event and
timer handlers. See `docs/03 Engine API/Composable_Logic_and_Menu_Design.md`.
Machines may be separated by responsibility; this example's count is not a rule.

Patrol Turn responses are now authored decision graphs: Cell clear? -> Clear:
move then Stay; Blocked: face opposite then enter the opposite State. One Turn
handler per direction State. See `docs/03 Engine API/Behavior_Event_Response_Contract.md`
for source/editing semantics and the remaining Studio acceptance work.

This is now constructed by `tools/authoring/author_dungeon.py` using `project.create`
and public editing commands. The recipe reads only the raw Tiled map, PNGs and
WAVs, never the completed project, Scenes or catalog. Its checkpoints verify
undo/redo and save/reopen; playable checkpoints also start negotiated preview.

Reproduce it into a new, nonexistent directory:

```powershell
Set-Location C:\Peepshow\PeepOS
python tools/authoring/author_dungeon.py "$env:TEMP\dungeon.peepproj"
```

The result includes `construction.json`, an ordered public-edit journal. This is
an authoring recipe, not Python game rules or a private package builder. Reload
the canonical project explicitly in Studio; updating the backend cannot replace
an edited copy. **Host preview is supported; device export is not qualified.**

There is one ordinary Player machine, with Playing and Caught States:

| State / trigger | Authored response |
| --- | --- |
| Playing / cardinals | Check that direction's cell; Clear: face, move, finish turn; Blocked: face only |
| Playing / A | Interact ahead of Player |
| Playing / B | Open Equipment (`menu.open`, `menu_ref: equipment`) |
| Playing / Chest opened | Opening clip, confirmation sound, Unlock sent to Door |
| Playing / Door opened | Enter the other room |
| Playing / Caught | Enter Caught, invert Player, shake patrols, play loss sound |
| Caught / B | Restart this Scene |

No movement-disable, interaction-disable, patrol-forwarding, equipment-owner or
camera machines remain. Caught has no movement/interaction routes; repeated
Caught outputs do not repeat feedback. The explicit B route is the menu opener.

Each input checks a named adjacent destination in that input's direction. Both
branches face that direction. The Clear branch moves to that same destination
and calls the reusable Finish player turn flow. That flow increments Turns, then
queues Patrol A turn, Patrol B turn, Patrol A adjacency and Patrol B adjacency.
The Blocked branch never calls it. Bounds, terrain and
occupancy are engine checks; camera Follow resolves accepted positions before
drawing. Both patrols reuse one behavior with independent State and target bindings.

Chest accepts approach from below only and stays solid after opening. Door stops
blocking after the key is found; Unlock permits interaction and Opened changes
room. Chest/Door outputs explicitly target Player's handlers. Behavior, visuals,
world-position and presentation bindings remain inspectable source records.

Pause has a root page (Equipment, Apply and resume, Cancel and resume) and an
Equipment child page (Sword, Shield). Arrows navigate; A stages a choice. B at
Equipment returns to Pause; B at Pause cancels. Apply commits through Player's
declared equipment ownership. No new turn, dummy owner or Scene reload is needed.
Gameplay suspends, the world hides, menu navigation/audio continues, and shell
Resume returns to the menu. The host must honor held-input and audio-stop receipts.

`test_dungeon_from_empty` constructs and drives this game through public requests
and compares its documents with this canonical project. Studio must still repeat
the construction in its actual UI. A discoverable Menu workspace and visible
Open Menu action are required; an inspector-only form is insufficient. Complete
object prefabs/overrides and device export remain unfinished. See
`docs/11 Development Tools/Dungeon_Bottom_Up_Authoring.md` for the creation steps.
